Grailbird.data.tweets_2014_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517038384443707392",
  "text" : "TODAY I WILL ACTUALIZE SOMETHING REALIZED YESTERDAY.\n\nTHAT I HAVE SOMETHING ACTUAL TO SAY, BUT YOU WONT REALIZE IT.\n\nCUZ I AM AN DUMB AVATAR",
  "id" : 517038384443707392,
  "created_at" : "2014-09-30 19:48:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "517033690615275521",
  "geo" : { },
  "id_str" : "517034245798129664",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain  MANG COBAIN NEVER DISCLAIMERED",
  "id" : 517034245798129664,
  "in_reply_to_status_id" : 517033690615275521,
  "created_at" : "2014-09-30 19:32:24 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "517033962439331842",
  "text" : "TONIGHT IN OAKLAND  return  d3(d2(d1(s, p.d1, p.fb1, p.mix1), p.d2, p.fb2, p.mix2), p.d3, p.fb3, p.mix3) * amod(.5, .37, t, 60 \/ tempo )",
  "id" : 517033962439331842,
  "created_at" : "2014-09-30 19:31:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516836982635253760",
  "text" : "or even just because",
  "id" : 516836982635253760,
  "created_at" : "2014-09-30 06:28:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mad Bitcoins",
      "screen_name" : "MadBitcoins",
      "indices" : [ 0, 12 ],
      "id_str" : "1389824700",
      "id" : 1389824700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516668629220225024",
  "geo" : { },
  "id_str" : "516668790768025600",
  "in_reply_to_user_id" : 1389824700,
  "text" : "@MadBitcoins  u sad sinner",
  "id" : 516668790768025600,
  "in_reply_to_status_id" : 516668629220225024,
  "created_at" : "2014-09-29 19:20:13 +0000",
  "in_reply_to_screen_name" : "MadBitcoins",
  "in_reply_to_user_id_str" : "1389824700",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516665489364246528",
  "text" : "GO BITCOIN GO",
  "id" : 516665489364246528,
  "created_at" : "2014-09-29 19:07:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516293552892940288",
  "text" : "the two words 'in fact\" have no useful role outside of fiction, and I aint lying.",
  "id" : 516293552892940288,
  "created_at" : "2014-09-28 18:29:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516228561674321920",
  "text" : "lifeform",
  "id" : 516228561674321920,
  "created_at" : "2014-09-28 14:10:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/j4QkZcHniS",
      "expanded_url" : "https:\/\/twitter.com\/johnnyscript\/status\/516042881459421185",
      "display_url" : "twitter.com\/johnnyscript\/s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "516086784694820865",
  "text" : "come on, wheres the love?  \n\nhttps:\/\/t.co\/j4QkZcHniS",
  "id" : 516086784694820865,
  "created_at" : "2014-09-28 04:47:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "516044746146316288",
  "text" : "THE NEW MEATSPACE IS SO GAME OVER",
  "id" : 516044746146316288,
  "created_at" : "2014-09-28 02:00:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Robinson Young",
      "screen_name" : "shamakry",
      "indices" : [ 0, 9 ],
      "id_str" : "16900280",
      "id" : 16900280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "516017506155102208",
  "geo" : { },
  "id_str" : "516042521948860416",
  "in_reply_to_user_id" : 16900280,
  "text" : "@shamakry HAY IM PART OF A MESH",
  "id" : 516042521948860416,
  "in_reply_to_status_id" : 516017506155102208,
  "created_at" : "2014-09-28 01:51:39 +0000",
  "in_reply_to_screen_name" : "shamakry",
  "in_reply_to_user_id_str" : "16900280",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Russell Resthaven",
      "screen_name" : "dreadcraft_",
      "indices" : [ 0, 12 ],
      "id_str" : "63211776",
      "id" : 63211776
    }, {
      "name" : "jerkey waters",
      "screen_name" : "jerquee",
      "indices" : [ 13, 21 ],
      "id_str" : "885173964",
      "id" : 885173964
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515920842157723649",
  "geo" : { },
  "id_str" : "515999199519703040",
  "in_reply_to_user_id" : 63211776,
  "text" : "@dreadcraft_ @jerquee U MAKE A HELLUVA CAUCASIAN!",
  "id" : 515999199519703040,
  "in_reply_to_status_id" : 515920842157723649,
  "created_at" : "2014-09-27 22:59:30 +0000",
  "in_reply_to_screen_name" : "dreadcraft_",
  "in_reply_to_user_id_str" : "63211776",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515998586291511296",
  "text" : "let the doges hit the floor",
  "id" : 515998586291511296,
  "created_at" : "2014-09-27 22:57:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515986101715349504",
  "geo" : { },
  "id_str" : "515991360436830208",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove A FLY ENTERS A BRIGHTLY LIT AND POSITIVELY BUZZING VENUE",
  "id" : 515991360436830208,
  "in_reply_to_status_id" : 515986101715349504,
  "created_at" : "2014-09-27 22:28:21 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515985168247447552",
  "text" : "The view from my workshop.  Me building a doors.",
  "id" : 515985168247447552,
  "created_at" : "2014-09-27 22:03:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515918794909167616",
  "text" : "everything i touch turns to music",
  "id" : 515918794909167616,
  "created_at" : "2014-09-27 17:40:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515766739850645504",
  "text" : "I WAS CONDITIONED TO !BELIEVE",
  "id" : 515766739850645504,
  "created_at" : "2014-09-27 07:35:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515753044332380160",
  "text" : "cream of consciousness",
  "id" : 515753044332380160,
  "created_at" : "2014-09-27 06:41:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "515686428668219392",
  "geo" : { },
  "id_str" : "515691398318673920",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack  lol u pushed yr email password to github dewb",
  "id" : 515691398318673920,
  "in_reply_to_status_id" : 515686428668219392,
  "created_at" : "2014-09-27 02:36:25 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515444024703201281",
  "text" : "the entropics of capricorn",
  "id" : 515444024703201281,
  "created_at" : "2014-09-26 10:13:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515139088903839744",
  "text" : "social security coin",
  "id" : 515139088903839744,
  "created_at" : "2014-09-25 14:01:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 3, 15 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515115515866783744",
  "text" : "RT @dominictarr: Like, if you pay someone to camp out beside the apple store, but you havn't decided whether you want the new ithing, that'\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "515101175817842688",
    "text" : "Like, if you pay someone to camp out beside the apple store, but you havn't decided whether you want the new ithing, that's a monad.",
    "id" : 515101175817842688,
    "created_at" : "2014-09-25 11:31:05 +0000",
    "user" : {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "protected" : false,
      "id_str" : "136933779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1753980863\/gravatar_normal.jpeg",
      "id" : 136933779,
      "verified" : false
    }
  },
  "id" : 515115515866783744,
  "created_at" : "2014-09-25 12:28:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515014702318256128",
  "text" : "when i finally found that bug, it turned out to be no match for i",
  "id" : 515014702318256128,
  "created_at" : "2014-09-25 05:47:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515009478404472832",
  "text" : "one of the twelve ways I eat oats is with cheese and almond meal",
  "id" : 515009478404472832,
  "created_at" : "2014-09-25 05:26:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "515003566331670528",
  "text" : "I FOUND ANOTHER VULNERABILITY IN BASH\n\nIF U PUT THE CARROT ONE WAY IT DESTROYS YOUR FILE",
  "id" : 515003566331670528,
  "created_at" : "2014-09-25 05:03:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514997719966818304",
  "text" : "watch me live debug this shitcode, a sit com",
  "id" : 514997719966818304,
  "created_at" : "2014-09-25 04:39:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514986869012971520",
  "text" : "me collect shitcode",
  "id" : 514986869012971520,
  "created_at" : "2014-09-25 03:56:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514908961804668929",
  "text" : "techoes",
  "id" : 514908961804668929,
  "created_at" : "2014-09-24 22:47:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jace Cooke",
      "screen_name" : "jacecooke",
      "indices" : [ 0, 10 ],
      "id_str" : "20618461",
      "id" : 20618461
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 11, 23 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514831494704295936",
  "geo" : { },
  "id_str" : "514904100182687746",
  "in_reply_to_user_id" : 20618461,
  "text" : "@jacecooke @dominictarr i herd exclusivity is where it is at for the social gold, diamond and platinum blonde credit card",
  "id" : 514904100182687746,
  "in_reply_to_status_id" : 514831494704295936,
  "created_at" : "2014-09-24 22:27:58 +0000",
  "in_reply_to_screen_name" : "jacecooke",
  "in_reply_to_user_id_str" : "20618461",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/xdXFHKgFPr",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/The_Cold_Crush_Brothers",
      "display_url" : "en.wikipedia.org\/wiki\/The_Cold_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514903374282907648",
  "text" : "the Cold Crush pedia page reads like a liner note,  which is pleasing compared to so many hyper-edited entries\n  http:\/\/t.co\/xdXFHKgFPr",
  "id" : 514903374282907648,
  "created_at" : "2014-09-24 22:25:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 0, 8 ],
      "id_str" : "33519541",
      "id" : 33519541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514860424106622977",
  "geo" : { },
  "id_str" : "514863110381793280",
  "in_reply_to_user_id" : 33519541,
  "text" : "@pfrazee go to tehconference sponsored by techumpanies",
  "id" : 514863110381793280,
  "in_reply_to_status_id" : 514860424106622977,
  "created_at" : "2014-09-24 19:45:05 +0000",
  "in_reply_to_screen_name" : "pfrazee",
  "in_reply_to_user_id_str" : "33519541",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 0, 8 ],
      "id_str" : "33519541",
      "id" : 33519541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514860009335697408",
  "geo" : { },
  "id_str" : "514860164529156096",
  "in_reply_to_user_id" : 46961216,
  "text" : "@pfrazee  tech humpanies",
  "id" : 514860164529156096,
  "in_reply_to_status_id" : 514860009335697408,
  "created_at" : "2014-09-24 19:33:23 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514858473922654208",
  "text" : "tech companies\ntechumps",
  "id" : 514858473922654208,
  "created_at" : "2014-09-24 19:26:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514811564067545088",
  "text" : "run localishly",
  "id" : 514811564067545088,
  "created_at" : "2014-09-24 16:20:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514735043831271425",
  "geo" : { },
  "id_str" : "514797091256664065",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  what if idgaf about _legally_",
  "id" : 514797091256664065,
  "in_reply_to_status_id" : 514735043831271425,
  "created_at" : "2014-09-24 15:22:45 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/RygbWCkBTx",
      "expanded_url" : "https:\/\/www.indiegogo.com\/projects\/trial-by-fire-tour-hamartia",
      "display_url" : "indiegogo.com\/projects\/trial\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514648880458125312",
  "text" : "help these dirty lovable punks GTFO my house https:\/\/t.co\/RygbWCkBTx",
  "id" : 514648880458125312,
  "created_at" : "2014-09-24 05:33:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514625135521710080",
  "text" : "OH: \"viacoin has a higher refresh rate than bitcoin\"",
  "id" : 514625135521710080,
  "created_at" : "2014-09-24 03:59:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514623394789081089",
  "text" : "the PoS of shitcoin gave been hella weak",
  "id" : 514623394789081089,
  "created_at" : "2014-09-24 03:52:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dance.js",
      "screen_name" : "oaklanddancejs",
      "indices" : [ 0, 15 ],
      "id_str" : "2797358358",
      "id" : 2797358358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514609892938612736",
  "in_reply_to_user_id" : 2797358358,
  "text" : "@oaklanddancejs will there be multiple projectors?",
  "id" : 514609892938612736,
  "created_at" : "2014-09-24 02:58:54 +0000",
  "in_reply_to_screen_name" : "oaklanddancejs",
  "in_reply_to_user_id_str" : "2797358358",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/dx3pBl1tGA",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=E4fEeUZymDE",
      "display_url" : "youtube.com\/watch?v=E4fEeU\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "514503777999937536",
  "text" : "when crypto currencies run commerce, you'll have to crowdfund your war!\n\nhttps:\/\/t.co\/dx3pBl1tGA",
  "id" : 514503777999937536,
  "created_at" : "2014-09-23 19:57:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0E3FtcDrak",
      "screen_name" : "btcdrak",
      "indices" : [ 0, 8 ],
      "id_str" : "1387081490",
      "id" : 1387081490
    }, {
      "name" : "FTC",
      "screen_name" : "FTC",
      "indices" : [ 9, 13 ],
      "id_str" : "187993109",
      "id" : 187993109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514497655507271681",
  "geo" : { },
  "id_str" : "514498019539300352",
  "in_reply_to_user_id" : 1387081490,
  "text" : "@btcdrak @FTC HAY U AINT ALLOWED TO INVEST YORE HARD EARNED MONEY UNLESS YORE A RICH MAN!!!",
  "id" : 514498019539300352,
  "in_reply_to_status_id" : 514497655507271681,
  "created_at" : "2014-09-23 19:34:21 +0000",
  "in_reply_to_screen_name" : "btcdrak",
  "in_reply_to_user_id_str" : "1387081490",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 13, 27 ],
      "id_str" : "379919160",
      "id" : 379919160
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 28, 35 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 36, 45 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514491519773192192",
  "geo" : { },
  "id_str" : "514494295240617984",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @MikolaLysenko @tmpvar @substack another option would be the mp3-ish route of audio as functions which represent PCM over TIME",
  "id" : 514494295240617984,
  "in_reply_to_status_id" : 514491519773192192,
  "created_at" : "2014-09-23 19:19:33 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 13, 27 ],
      "id_str" : "379919160",
      "id" : 379919160
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 28, 35 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 36, 45 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514491519773192192",
  "geo" : { },
  "id_str" : "514493896748191746",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @MikolaLysenko @tmpvar @substack  easily done with new AudioContext.sampleRate",
  "id" : 514493896748191746,
  "in_reply_to_status_id" : 514491519773192192,
  "created_at" : "2014-09-23 19:17:58 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514493734608982016",
  "text" : "psychology and economics up to this day and age has been all eye of frog and spleens newt, tbh i always b smh",
  "id" : 514493734608982016,
  "created_at" : "2014-09-23 19:17:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514493477254885378",
  "text" : "anti intellectualism is forgetting what you know and getting new ones",
  "id" : 514493477254885378,
  "created_at" : "2014-09-23 19:16:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 18, 32 ],
      "id_str" : "379919160",
      "id" : 379919160
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 33, 40 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 41, 53 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 54, 63 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514486742507077632",
  "geo" : { },
  "id_str" : "514487292296433664",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  cc @MikolaLysenko @tmpvar @dominictarr @substack \ncuz then webaudio direct streaming  (sampleRates vary by soundcard)",
  "id" : 514487292296433664,
  "in_reply_to_status_id" : 514486742507077632,
  "created_at" : "2014-09-23 18:51:43 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514486585971462144",
  "geo" : { },
  "id_str" : "514486742507077632",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  preferably without having to use FFTs and frequency analysis",
  "id" : 514486742507077632,
  "in_reply_to_status_id" : 514486585971462144,
  "created_at" : "2014-09-23 18:49:32 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514486585971462144",
  "text" : "ok i need to OS this problem.  I have X samples per second of audio that I need to convert to Y sampleRate, and I have javascript.",
  "id" : 514486585971462144,
  "created_at" : "2014-09-23 18:48:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514483423990149120",
  "text" : "basically buying any crypto right is like buying bitcoin so low low",
  "id" : 514483423990149120,
  "created_at" : "2014-09-23 18:36:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514483210869538816",
  "text" : "if bitcoin goes to 1000 again i will sell my viacoin i swear",
  "id" : 514483210869538816,
  "created_at" : "2014-09-23 18:35:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "pierebel",
      "screen_name" : "pierebel",
      "indices" : [ 0, 9 ],
      "id_str" : "728868336",
      "id" : 728868336
    }, {
      "name" : "Mad Bitcoins",
      "screen_name" : "MadBitcoins",
      "indices" : [ 10, 22 ],
      "id_str" : "1389824700",
      "id" : 1389824700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514476576499445760",
  "geo" : { },
  "id_str" : "514482623666589696",
  "in_reply_to_user_id" : 728868336,
  "text" : "@pierebel @MadBitcoins epiC",
  "id" : 514482623666589696,
  "in_reply_to_status_id" : 514476576499445760,
  "created_at" : "2014-09-23 18:33:10 +0000",
  "in_reply_to_screen_name" : "pierebel",
  "in_reply_to_user_id_str" : "728868336",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514479205363351552",
  "text" : "to automate perfection \n\nor \n\nto perfect automation\n\nthat is the question behind the question",
  "id" : 514479205363351552,
  "created_at" : "2014-09-23 18:19:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514476496786714625",
  "text" : "why did I never think to bet on myself being wrong?",
  "id" : 514476496786714625,
  "created_at" : "2014-09-23 18:08:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ActualAdvice_BTC",
      "screen_name" : "ActualAdviceBTC",
      "indices" : [ 0, 16 ],
      "id_str" : "2216302500",
      "id" : 2216302500
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514475491747581952",
  "geo" : { },
  "id_str" : "514475737395376128",
  "in_reply_to_user_id" : 2216302500,
  "text" : "@ActualAdviceBTC  THAT'S HYPOTHETICAL ADVICE",
  "id" : 514475737395376128,
  "in_reply_to_status_id" : 514475491747581952,
  "created_at" : "2014-09-23 18:05:48 +0000",
  "in_reply_to_screen_name" : "ActualAdviceBTC",
  "in_reply_to_user_id_str" : "2216302500",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    }, {
      "name" : "Benjamin Coe",
      "screen_name" : "BenjaminCoe",
      "indices" : [ 11, 23 ],
      "id_str" : "24659495",
      "id" : 24659495
    }, {
      "name" : "Gabriel Silk",
      "screen_name" : "gabrielsilk",
      "indices" : [ 24, 36 ],
      "id_str" : "135262454",
      "id" : 135262454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514459625778069505",
  "geo" : { },
  "id_str" : "514475178814742528",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove @BenjaminCoe @gabrielsilk @The_Alpha_Nerd  \n\nFREE CARTWHEELS",
  "id" : 514475178814742528,
  "in_reply_to_status_id" : 514459625778069505,
  "created_at" : "2014-09-23 18:03:35 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 3, 13 ],
      "id_str" : "170605832",
      "id" : 170605832
    }, {
      "name" : "Benjamin Coe",
      "screen_name" : "BenjaminCoe",
      "indices" : [ 69, 81 ],
      "id_str" : "24659495",
      "id" : 24659495
    }, {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 82, 95 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "Gabriel Silk",
      "screen_name" : "gabrielsilk",
      "indices" : [ 96, 108 ],
      "id_str" : "135262454",
      "id" : 135262454
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DANCEJS",
      "indices" : [ 15, 23 ]
    } ],
    "urls" : [ {
      "indices" : [ 143, 144 ],
      "url" : "http:\/\/t.co\/i9ST4gjssJ",
      "expanded_url" : "http:\/\/dancejs.io\/",
      "display_url" : "dancejs.io"
    } ]
  },
  "geo" : { },
  "id_str" : "514474962300592128",
  "text" : "RT @nexxylove: #DANCEJS Oakland, OCT 4 \u2014 performances b\u032C\u033A\u034E\u032By\u031B\u0317\u032F\u0347\u0354\u031F\u032F\u0320 @BenjaminCoe @johnnyscript @gabrielsilk @the_alpha_nerd &amp; more http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/software\/tweetbot\/mac\" rel=\"nofollow\"\u003ETweetbot for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Benjamin Coe",
        "screen_name" : "BenjaminCoe",
        "indices" : [ 54, 66 ],
        "id_str" : "24659495",
        "id" : 24659495
      }, {
        "name" : "( +\\-)",
        "screen_name" : "johnnyscript",
        "indices" : [ 67, 80 ],
        "id_str" : "46961216",
        "id" : 46961216
      }, {
        "name" : "Gabriel Silk",
        "screen_name" : "gabrielsilk",
        "indices" : [ 81, 93 ],
        "id_str" : "135262454",
        "id" : 135262454
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "DANCEJS",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ {
        "indices" : [ 121, 143 ],
        "url" : "http:\/\/t.co\/i9ST4gjssJ",
        "expanded_url" : "http:\/\/dancejs.io\/",
        "display_url" : "dancejs.io"
      } ]
    },
    "geo" : { },
    "id_str" : "514459625778069505",
    "text" : "#DANCEJS Oakland, OCT 4 \u2014 performances b\u032C\u033A\u034E\u032By\u031B\u0317\u032F\u0347\u0354\u031F\u032F\u0320 @BenjaminCoe @johnnyscript @gabrielsilk @the_alpha_nerd &amp; more http:\/\/t.co\/i9ST4gjssJ",
    "id" : 514459625778069505,
    "created_at" : "2014-09-23 17:01:47 +0000",
    "user" : {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "protected" : false,
      "id_str" : "170605832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502610259668512768\/x4NytdX3_normal.jpeg",
      "id" : 170605832,
      "verified" : false
    }
  },
  "id" : 514474962300592128,
  "created_at" : "2014-09-23 18:02:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514473429156638720",
  "text" : "luckily nerds &lt;3 crypto currency",
  "id" : 514473429156638720,
  "created_at" : "2014-09-23 17:56:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514473358621020160",
  "text" : "nerd interest in crypto is a must cuz nerds run the internet",
  "id" : 514473358621020160,
  "created_at" : "2014-09-23 17:56:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514472739034259456",
  "text" : "cylcepathy",
  "id" : 514472739034259456,
  "created_at" : "2014-09-23 17:53:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514139706741637120",
  "text" : "i wonder if net neutrality would take off as an issue if those idiots, bumkins, and jackasses in rest coast USA knew how fast my internet is",
  "id" : 514139706741637120,
  "created_at" : "2014-09-22 19:50:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian AKA The Truth",
      "screen_name" : "jyap",
      "indices" : [ 0, 5 ],
      "id_str" : "5624402",
      "id" : 5624402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "514118148946010112",
  "geo" : { },
  "id_str" : "514128758576787456",
  "in_reply_to_user_id" : 5624402,
  "text" : "@jyap what is the purpose of the coin?",
  "id" : 514128758576787456,
  "in_reply_to_status_id" : 514118148946010112,
  "created_at" : "2014-09-22 19:07:02 +0000",
  "in_reply_to_screen_name" : "jyap",
  "in_reply_to_user_id_str" : "5624402",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "514093757600641024",
  "text" : "hertz boners",
  "id" : 514093757600641024,
  "created_at" : "2014-09-22 16:47:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dance.js",
      "screen_name" : "oaklanddancejs",
      "indices" : [ 0, 15 ],
      "id_str" : "2797358358",
      "id" : 2797358358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513786480594919426",
  "geo" : { },
  "id_str" : "513791327754915840",
  "in_reply_to_user_id" : 2797358358,
  "text" : "@oaklanddancejs\n\nThis will consist of me jacking @The_Alpha_Nerd 's audio signal and sending it thru multiple delays before your very ears.",
  "id" : 513791327754915840,
  "in_reply_to_status_id" : 513786480594919426,
  "created_at" : "2014-09-21 20:46:12 +0000",
  "in_reply_to_screen_name" : "oaklanddancejs",
  "in_reply_to_user_id_str" : "2797358358",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513748381546450944",
  "text" : "a crypto currency that taxes hoarding",
  "id" : 513748381546450944,
  "created_at" : "2014-09-21 17:55:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513515535149961216",
  "text" : "achievement unlocked:  most people who know are surprised when they see me wearing pants",
  "id" : 513515535149961216,
  "created_at" : "2014-09-21 02:30:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513491178595950592",
  "text" : "This paella is hella buen",
  "id" : 513491178595950592,
  "created_at" : "2014-09-21 00:53:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513490903395074048",
  "text" : "Protip:  u don't have to chew hard",
  "id" : 513490903395074048,
  "created_at" : "2014-09-21 00:52:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513490087468728320",
  "text" : "The knuckle tat of mobile is binary",
  "id" : 513490087468728320,
  "created_at" : "2014-09-21 00:49:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513489723508011008",
  "text" : "Stupid java type keys board android fuck u castrated devs",
  "id" : 513489723508011008,
  "created_at" : "2014-09-21 00:47:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roald Daal",
      "screen_name" : "ElSangito",
      "indices" : [ 0, 10 ],
      "id_str" : "24504850",
      "id" : 24504850
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freak",
      "indices" : [ 31, 37 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513489120513888257",
  "geo" : { },
  "id_str" : "513489457107206144",
  "in_reply_to_user_id" : 24504850,
  "text" : "@ElSangito My say\n\nVIRTU ALLY\n\n#freak",
  "id" : 513489457107206144,
  "in_reply_to_status_id" : 513489120513888257,
  "created_at" : "2014-09-21 00:46:41 +0000",
  "in_reply_to_screen_name" : "ElSangito",
  "in_reply_to_user_id_str" : "24504850",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513488500151160832",
  "geo" : { },
  "id_str" : "513489132077600769",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript Meh prolly do both cuz I can",
  "id" : 513489132077600769,
  "in_reply_to_status_id" : 513488500151160832,
  "created_at" : "2014-09-21 00:45:23 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513488500151160832",
  "text" : "Today maybe the ultimate pivot.  From one revolutionary protocol to another.  What can I say?  Culture before biz.  It's all commerce.",
  "id" : 513488500151160832,
  "created_at" : "2014-09-21 00:42:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513487787878653952",
  "text" : "Before any one suspects anything I've been broke 33 years in any coin but spirit.  The latter rides wilder than BTC and is only giveable.",
  "id" : 513487787878653952,
  "created_at" : "2014-09-21 00:40:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rob DaRock",
      "screen_name" : "CryptoDaRock",
      "indices" : [ 0, 13 ],
      "id_str" : "2238979286",
      "id" : 2238979286
    }, {
      "name" : "Charles T.",
      "screen_name" : "CharlestheGowl",
      "indices" : [ 14, 29 ],
      "id_str" : "2312519196",
      "id" : 2312519196
    }, {
      "name" : "BTC \u0E3Fite",
      "screen_name" : "btcbite",
      "indices" : [ 30, 38 ],
      "id_str" : "2596186036",
      "id" : 2596186036
    }, {
      "name" : "Jeremy Ross",
      "screen_name" : "jebus911",
      "indices" : [ 39, 48 ],
      "id_str" : "162573283",
      "id" : 162573283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513486245641850880",
  "geo" : { },
  "id_str" : "513486865337303040",
  "in_reply_to_user_id" : 2238979286,
  "text" : "@CryptoDaRock @CharlestheGowl @btcbite @jebus911 China breaks bitcoins back, news at 230am PST",
  "id" : 513486865337303040,
  "in_reply_to_status_id" : 513486245641850880,
  "created_at" : "2014-09-21 00:36:23 +0000",
  "in_reply_to_screen_name" : "CryptoDaRock",
  "in_reply_to_user_id_str" : "2238979286",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513486033954930688",
  "text" : "At a hideaway paella place in Oakland y'all never",
  "id" : 513486033954930688,
  "created_at" : "2014-09-21 00:33:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513485796406341632",
  "text" : "This beer is strong and beeerprd",
  "id" : 513485796406341632,
  "created_at" : "2014-09-21 00:32:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513485701854134272",
  "text" : "I will developing a premier app on the bitcoin of social networks.  It's not a coin.",
  "id" : 513485701854134272,
  "created_at" : "2014-09-21 00:31:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513485354632888320",
  "text" : "The decentralized social network test net launched today.  Real shit from the stackVM open source cartel",
  "id" : 513485354632888320,
  "created_at" : "2014-09-21 00:30:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513484886372392961",
  "text" : "Somebody invest in my life",
  "id" : 513484886372392961,
  "created_at" : "2014-09-21 00:28:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513484599716884481",
  "text" : "I get a laugh telling a suicide avatar to kill himself.  Every time.",
  "id" : 513484599716884481,
  "created_at" : "2014-09-21 00:27:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles T.",
      "screen_name" : "CharlestheGowl",
      "indices" : [ 0, 15 ],
      "id_str" : "2312519196",
      "id" : 2312519196
    }, {
      "name" : "BTC \u0E3Fite",
      "screen_name" : "btcbite",
      "indices" : [ 16, 24 ],
      "id_str" : "2596186036",
      "id" : 2596186036
    }, {
      "name" : "Rob DaRock",
      "screen_name" : "CryptoDaRock",
      "indices" : [ 25, 38 ],
      "id_str" : "2238979286",
      "id" : 2238979286
    }, {
      "name" : "Jeremy Ross",
      "screen_name" : "jebus911",
      "indices" : [ 39, 48 ],
      "id_str" : "162573283",
      "id" : 162573283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513483939949064192",
  "geo" : { },
  "id_str" : "513484338847940609",
  "in_reply_to_user_id" : 2312519196,
  "text" : "@CharlestheGowl @btcbite @CryptoDaRock @jebus911 kill yrself",
  "id" : 513484338847940609,
  "in_reply_to_status_id" : 513483939949064192,
  "created_at" : "2014-09-21 00:26:21 +0000",
  "in_reply_to_screen_name" : "CharlestheGowl",
  "in_reply_to_user_id_str" : "2312519196",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513431030506586113",
  "geo" : { },
  "id_str" : "513431317032083456",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  I already did it sounds ABSOLUTELY 0.62 TIME AS GOOD",
  "id" : 513431317032083456,
  "in_reply_to_status_id" : 513431030506586113,
  "created_at" : "2014-09-20 20:55:39 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513431030506586113",
  "text" : "in before aphex gets vaporwaved",
  "id" : 513431030506586113,
  "created_at" : "2014-09-20 20:54:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513426625648545792",
  "text" : "WHERE DOES THE META END AND THE DATA BEGIN?",
  "id" : 513426625648545792,
  "created_at" : "2014-09-20 20:37:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513426122550153216",
  "text" : "i think the crypto community should observe ancient social ritual and burn 10% of all reserves. prove deflation is god once and for all.",
  "id" : 513426122550153216,
  "created_at" : "2014-09-20 20:35:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513425541353848832",
  "text" : "PIE COIN",
  "id" : 513425541353848832,
  "created_at" : "2014-09-20 20:32:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513397888349532160",
  "text" : "with friends like robots, who needs secrets?",
  "id" : 513397888349532160,
  "created_at" : "2014-09-20 18:42:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513369984966225922",
  "geo" : { },
  "id_str" : "513370732693176322",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \n\nwhen i learn how to record it is when the golden showers will start\n\ncuz it will make you piss your shit",
  "id" : 513370732693176322,
  "in_reply_to_status_id" : 513369984966225922,
  "created_at" : "2014-09-20 16:54:55 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513369984966225922",
  "text" : "i possess a bass rune and I know how to use it",
  "id" : 513369984966225922,
  "created_at" : "2014-09-20 16:51:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513364986731577345",
  "geo" : { },
  "id_str" : "513366140005793792",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  yet it occupies brute force and pays brute force to be good, so there is that",
  "id" : 513366140005793792,
  "in_reply_to_status_id" : 513364986731577345,
  "created_at" : "2014-09-20 16:36:40 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513365965308829696",
  "text" : "DDOS COIN",
  "id" : 513365965308829696,
  "created_at" : "2014-09-20 16:35:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513364986731577345",
  "text" : "the crypto currency networks are still using brute force security like old world fiat",
  "id" : 513364986731577345,
  "created_at" : "2014-09-20 16:32:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 45, 57 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Peter Todd",
      "screen_name" : "petertoddbtc",
      "indices" : [ 58, 71 ],
      "id_str" : "1471313300",
      "id" : 1471313300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513363735688130561",
  "text" : "have you two bumped heads n split hair yet?\n\n@dominictarr @petertoddbtc",
  "id" : 513363735688130561,
  "created_at" : "2014-09-20 16:27:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Jones",
      "screen_name" : "riverofdoubt",
      "indices" : [ 0, 13 ],
      "id_str" : "97794798",
      "id" : 97794798
    }, {
      "name" : "SALVA",
      "screen_name" : "salva",
      "indices" : [ 14, 20 ],
      "id_str" : "118623177",
      "id" : 118623177
    }, {
      "name" : "LilFishBitch\u270C\uFE0F",
      "screen_name" : "PaulFisher210",
      "indices" : [ 21, 35 ],
      "id_str" : "337308342",
      "id" : 337308342
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513360967460470785",
  "geo" : { },
  "id_str" : "513362526206050304",
  "in_reply_to_user_id" : 97794798,
  "text" : "@riverofdoubt @salva @PaulFisher210 hey hitters im outfield derive n rhythm from nature crack me a pop fly n ill throw back like fire ya out",
  "id" : 513362526206050304,
  "in_reply_to_status_id" : 513360967460470785,
  "created_at" : "2014-09-20 16:22:18 +0000",
  "in_reply_to_screen_name" : "riverofdoubt",
  "in_reply_to_user_id_str" : "97794798",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/RDlDjLNCWx",
      "expanded_url" : "http:\/\/curecoin.net\/index.php\/en\/",
      "display_url" : "curecoin.net\/index.php\/en\/"
    }, {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/JTm4uamBSR",
      "expanded_url" : "https:\/\/bittrex.com\/Market\/?MarketName=BTC-CURE",
      "display_url" : "bittrex.com\/Market\/?Market\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "513361426212061185",
  "text" : "CURE COIN miners fold proteins\n\nhttp:\/\/t.co\/RDlDjLNCWx\n\nis trading for shit\n\nhttps:\/\/t.co\/JTm4uamBSR\n\nWHERE SETI@HOME@STARGAZE COIN@?",
  "id" : 513361426212061185,
  "created_at" : "2014-09-20 16:17:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513358485493256194",
  "text" : "THE SHLLIONS",
  "id" : 513358485493256194,
  "created_at" : "2014-09-20 16:06:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 8, 20 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513358279200632832",
  "text" : "calling @dominictarr to the shitcoin table, we need trust networks in commerce, and butt money people are paranoid of course.",
  "id" : 513358279200632832,
  "created_at" : "2014-09-20 16:05:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513356614665908226",
  "text" : "sry i have all these shitcoins and they are only worth 1\/10 of an opinion rn",
  "id" : 513356614665908226,
  "created_at" : "2014-09-20 15:58:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Todd",
      "screen_name" : "petertoddbtc",
      "indices" : [ 0, 13 ],
      "id_str" : "1471313300",
      "id" : 1471313300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513353855350738944",
  "geo" : { },
  "id_str" : "513356412835987456",
  "in_reply_to_user_id" : 46961216,
  "text" : "@petertoddbtc a good coin will keep miners, which will ensure a long line of waiting miners, so it's a positive feedback loop.",
  "id" : 513356412835987456,
  "in_reply_to_status_id" : 513353855350738944,
  "created_at" : "2014-09-20 15:58:01 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513356190303014912",
  "text" : "exclusivity in decentraland",
  "id" : 513356190303014912,
  "created_at" : "2014-09-20 15:57:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513356138234912768",
  "text" : "start calling miners BURROS",
  "id" : 513356138234912768,
  "created_at" : "2014-09-20 15:56:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Todd",
      "screen_name" : "petertoddbtc",
      "indices" : [ 0, 13 ],
      "id_str" : "1471313300",
      "id" : 1471313300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513352633009315841",
  "geo" : { },
  "id_str" : "513353855350738944",
  "in_reply_to_user_id" : 1471313300,
  "text" : "@petertoddbtc  trust networks + mining capacity limits? incentive to stay w\/ coin &amp; be a good miner, cuz if u leave, a line to return awaits",
  "id" : 513353855350738944,
  "in_reply_to_status_id" : 513352633009315841,
  "created_at" : "2014-09-20 15:47:51 +0000",
  "in_reply_to_screen_name" : "petertoddbtc",
  "in_reply_to_user_id_str" : "1471313300",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "DorianSatoshi",
      "indices" : [ 0, 14 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513350469868322816",
  "geo" : { },
  "id_str" : "513350946949038080",
  "in_reply_to_user_id" : 2375721396,
  "text" : "@DorianSatoshi  \"If the horse knew its strength, we would not ride them.\"  --Mark Twain",
  "id" : 513350946949038080,
  "in_reply_to_status_id" : 513350469868322816,
  "created_at" : "2014-09-20 15:36:18 +0000",
  "in_reply_to_screen_name" : "DorianSatoshi",
  "in_reply_to_user_id_str" : "2375721396",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513348104716693504",
  "text" : "so now every website using cloudflare is gonna buffer like its 1999?",
  "id" : 513348104716693504,
  "created_at" : "2014-09-20 15:25:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Todd",
      "screen_name" : "petertoddbtc",
      "indices" : [ 0, 13 ],
      "id_str" : "1471313300",
      "id" : 1471313300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513342393488506880",
  "geo" : { },
  "id_str" : "513347724041670657",
  "in_reply_to_user_id" : 1471313300,
  "text" : "@petertoddbtc that's a lot of power to process ~500 tx per block.  more nodes hashing less would provide same security, no?",
  "id" : 513347724041670657,
  "in_reply_to_status_id" : 513342393488506880,
  "created_at" : "2014-09-20 15:23:29 +0000",
  "in_reply_to_screen_name" : "petertoddbtc",
  "in_reply_to_user_id_str" : "1471313300",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Todd",
      "screen_name" : "petertoddbtc",
      "indices" : [ 0, 13 ],
      "id_str" : "1471313300",
      "id" : 1471313300
    }, {
      "name" : "J Schmidt",
      "screen_name" : "JSBTC",
      "indices" : [ 14, 20 ],
      "id_str" : "2371003794",
      "id" : 2371003794
    }, {
      "name" : "Kyle Torpey",
      "screen_name" : "kyletorpey",
      "indices" : [ 21, 32 ],
      "id_str" : "233318165",
      "id" : 233318165
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513200635463081985",
  "geo" : { },
  "id_str" : "513341782520639488",
  "in_reply_to_user_id" : 1471313300,
  "text" : "@petertoddbtc @JSBTC @kyletorpey according to this, nothing is gained by from hash power used in a coin network, just empty flops.  is true?",
  "id" : 513341782520639488,
  "in_reply_to_status_id" : 513200635463081985,
  "created_at" : "2014-09-20 14:59:53 +0000",
  "in_reply_to_screen_name" : "petertoddbtc",
  "in_reply_to_user_id_str" : "1471313300",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513165150002888704",
  "geo" : { },
  "id_str" : "513172645479591936",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove  u can be a johnny too if u want \n\nThat is what we are  ^__\u00B0",
  "id" : 513172645479591936,
  "in_reply_to_status_id" : 513165150002888704,
  "created_at" : "2014-09-20 03:47:47 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513171480956239872",
  "text" : "Bitcoin is currently heading into the triple bottom of the year, this one will go into OT.",
  "id" : 513171480956239872,
  "created_at" : "2014-09-20 03:43:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513164222088245249",
  "text" : "CRYPTO IS REAL",
  "id" : 513164222088245249,
  "created_at" : "2014-09-20 03:14:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513153559538315265",
  "text" : "no i am not buying domain names as a reminder list",
  "id" : 513153559538315265,
  "created_at" : "2014-09-20 02:31:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "513046896428859393",
  "text" : "You can choose velocity, direction, and the ability take measurement.  Pick 2.",
  "id" : 513046896428859393,
  "created_at" : "2014-09-19 19:28:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Troy Howard",
      "screen_name" : "thoward37",
      "indices" : [ 13, 23 ],
      "id_str" : "89108994",
      "id" : 89108994
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "513038776361160706",
  "geo" : { },
  "id_str" : "513046000605220864",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @thoward37 measurement \n\nlol",
  "id" : 513046000605220864,
  "in_reply_to_status_id" : 513038776361160706,
  "created_at" : "2014-09-19 19:24:33 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dance.js",
      "screen_name" : "oaklanddancejs",
      "indices" : [ 3, 18 ],
      "id_str" : "2797358358",
      "id" : 2797358358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 100 ],
      "url" : "https:\/\/t.co\/or5xcfvi2P",
      "expanded_url" : "https:\/\/soundcloud.com\/benjamin-e-coe\/ben-coe-dancejs-oct-4th-mini-mix",
      "display_url" : "soundcloud.com\/benjamin-e-coe\u2026"
    }, {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/OlDBGCqLtN",
      "expanded_url" : "http:\/\/dancejs.io",
      "display_url" : "dancejs.io"
    } ]
  },
  "geo" : { },
  "id_str" : "513001977605664768",
  "text" : "RT @oaklanddancejs: Your morning beats brought to you by Dance.js Minimix #1 https:\/\/t.co\/or5xcfvi2P. Just two more weeks to grab tickets h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 80 ],
        "url" : "https:\/\/t.co\/or5xcfvi2P",
        "expanded_url" : "https:\/\/soundcloud.com\/benjamin-e-coe\/ben-coe-dancejs-oct-4th-mini-mix",
        "display_url" : "soundcloud.com\/benjamin-e-coe\u2026"
      }, {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/OlDBGCqLtN",
        "expanded_url" : "http:\/\/dancejs.io",
        "display_url" : "dancejs.io"
      } ]
    },
    "geo" : { },
    "id_str" : "513001129316085760",
    "text" : "Your morning beats brought to you by Dance.js Minimix #1 https:\/\/t.co\/or5xcfvi2P. Just two more weeks to grab tickets http:\/\/t.co\/OlDBGCqLtN",
    "id" : 513001129316085760,
    "created_at" : "2014-09-19 16:26:14 +0000",
    "user" : {
      "name" : "Dance.js",
      "screen_name" : "oaklanddancejs",
      "protected" : false,
      "id_str" : "2797358358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/508874020683403264\/xB2uWFmY_normal.png",
      "id" : 2797358358,
      "verified" : false
    }
  },
  "id" : 513001977605664768,
  "created_at" : "2014-09-19 16:29:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512892223944269824",
  "text" : "YAY EVERY1 KILL YRSELF",
  "id" : 512892223944269824,
  "created_at" : "2014-09-19 09:13:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 3, 16 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512892134588837889",
  "text" : "RT @CryptoCobain: BTC DYING BUT PANDACOIN VALUE VERY STABLE AT ZERO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512891039540322304",
    "text" : "BTC DYING BUT PANDACOIN VALUE VERY STABLE AT ZERO",
    "id" : 512891039540322304,
    "created_at" : "2014-09-19 09:08:47 +0000",
    "user" : {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "protected" : false,
      "id_str" : "2259434528",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542045745441161216\/nj96qso4_normal.jpeg",
      "id" : 2259434528,
      "verified" : false
    }
  },
  "id" : 512892134588837889,
  "created_at" : "2014-09-19 09:13:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "DorianSatoshi",
      "indices" : [ 3, 17 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Priceless",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512886851258966016",
  "text" : "RT @DorianSatoshi: Bitcoin value when you first dismissed it: 0.08 USD\nBTC after its 47th demise: 623.87 USD\n\nWhen you finally understand b\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Priceless",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "488739474872864768",
    "text" : "Bitcoin value when you first dismissed it: 0.08 USD\nBTC after its 47th demise: 623.87 USD\n\nWhen you finally understand bitcoin: #Priceless",
    "id" : 488739474872864768,
    "created_at" : "2014-07-14 17:39:05 +0000",
    "user" : {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "DorianSatoshi",
      "protected" : false,
      "id_str" : "2375721396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469129664045535232\/MGYfTi6P_normal.jpeg",
      "id" : 2375721396,
      "verified" : false
    }
  },
  "id" : 512886851258966016,
  "created_at" : "2014-09-19 08:52:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "DorianSatoshi",
      "indices" : [ 3, 17 ],
      "id_str" : "2375721396",
      "id" : 2375721396
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512885944442032128",
  "text" : "RT @DorianSatoshi: As a rule I don't discuss the price of bitcoin.  If I open that door and get on the floor, it's possible everybody would\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512657093560512512",
    "text" : "As a rule I don't discuss the price of bitcoin.  If I open that door and get on the floor, it's possible everybody would walk the dinosaur.",
    "id" : 512657093560512512,
    "created_at" : "2014-09-18 17:39:10 +0000",
    "user" : {
      "name" : "Satoshi Nakamoto",
      "screen_name" : "DorianSatoshi",
      "protected" : false,
      "id_str" : "2375721396",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469129664045535232\/MGYfTi6P_normal.jpeg",
      "id" : 2375721396,
      "verified" : false
    }
  },
  "id" : 512885944442032128,
  "created_at" : "2014-09-19 08:48:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512883925530587136",
  "text" : "what's happening with bitcoin right now may be the most interesting thing in informational hypothesis",
  "id" : 512883925530587136,
  "created_at" : "2014-09-19 08:40:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512880013687803904",
  "text" : "i swear i'll kick beer when i find something better",
  "id" : 512880013687803904,
  "created_at" : "2014-09-19 08:24:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512879537583960064",
  "text" : "As a nutritional disorder, not an emotional one, alcoholism is quite manageable.",
  "id" : 512879537583960064,
  "created_at" : "2014-09-19 08:23:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roald Daal",
      "screen_name" : "ElSangito",
      "indices" : [ 3, 13 ],
      "id_str" : "24504850",
      "id" : 24504850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512874599973797888",
  "text" : "RT @ElSangito: a bagpipe version of the price is right losing horns",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512869359505514497",
    "text" : "a bagpipe version of the price is right losing horns",
    "id" : 512869359505514497,
    "created_at" : "2014-09-19 07:42:38 +0000",
    "user" : {
      "name" : "Roald Daal",
      "screen_name" : "ElSangito",
      "protected" : false,
      "id_str" : "24504850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549002961389506560\/cBShoBH2_normal.jpeg",
      "id" : 24504850,
      "verified" : false
    }
  },
  "id" : 512874599973797888,
  "created_at" : "2014-09-19 08:03:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512874013941444608",
  "text" : "Well it is exactly as Mark Twain wanted for the Jews and the Scottish, but only for the Scottish, and look at the Jewish state.",
  "id" : 512874013941444608,
  "created_at" : "2014-09-19 08:01:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512872525928210433",
  "text" : "Put raw anarchy and bitcoin on the referendum to disband.",
  "id" : 512872525928210433,
  "created_at" : "2014-09-19 07:55:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512872242200313856",
  "text" : "Should be we elect to run our own international bureaucracy?  That sounds worse than a bad fuck.",
  "id" : 512872242200313856,
  "created_at" : "2014-09-19 07:54:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512871694139027457",
  "text" : "Why bother going from one state to another?",
  "id" : 512871694139027457,
  "created_at" : "2014-09-19 07:51:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ashanty Roots",
      "screen_name" : "Caalavera",
      "indices" : [ 3, 13 ],
      "id_str" : "1284690523",
      "id" : 1284690523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512834543795982337",
  "text" : "RT @Caalavera: Que bonito es el amor y que pronto se gasta, hoy soy feliz con poco; con mi tristeza me basta.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "512813044334727168",
    "text" : "Que bonito es el amor y que pronto se gasta, hoy soy feliz con poco; con mi tristeza me basta.",
    "id" : 512813044334727168,
    "created_at" : "2014-09-19 03:58:52 +0000",
    "user" : {
      "name" : "Ashanty Roots",
      "screen_name" : "Caalavera",
      "protected" : false,
      "id_str" : "1284690523",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431894381360996352\/aQYrojE__normal.jpeg",
      "id" : 1284690523,
      "verified" : false
    }
  },
  "id" : 512834543795982337,
  "created_at" : "2014-09-19 05:24:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512831165904850945",
  "text" : "I wanna go to the club n drink tea",
  "id" : 512831165904850945,
  "created_at" : "2014-09-19 05:10:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512744496723800064",
  "text" : "THE TIDE OF BITCOIN RECESSES, REVEALING MANY A BITSEA WONDERS, LIKE BITSEA SLUGS N BITSEA ANENOMIE\n\nA SIGN READS:\n\nTSUNAMI ZONE\nWARNING!",
  "id" : 512744496723800064,
  "created_at" : "2014-09-18 23:26:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512741052814340098",
  "text" : "bitcoin is getting taken home rn",
  "id" : 512741052814340098,
  "created_at" : "2014-09-18 23:12:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512735897960202241",
  "text" : "my savings all in shitcoin\ncall that a lead parachute",
  "id" : 512735897960202241,
  "created_at" : "2014-09-18 22:52:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Retail Marketing",
      "screen_name" : "journik",
      "indices" : [ 0, 8 ],
      "id_str" : "18873970",
      "id" : 18873970
    }, {
      "name" : "Jeremy Ross",
      "screen_name" : "jebus911",
      "indices" : [ 9, 18 ],
      "id_str" : "162573283",
      "id" : 162573283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512729474287153152",
  "geo" : { },
  "id_str" : "512735611375992832",
  "in_reply_to_user_id" : 18873970,
  "text" : "@journik @jebus911  hahah traders aka middlemen have to deal w the real time market stability of great and awesome anti-middleman technology",
  "id" : 512735611375992832,
  "in_reply_to_status_id" : 512729474287153152,
  "created_at" : "2014-09-18 22:51:10 +0000",
  "in_reply_to_screen_name" : "journik",
  "in_reply_to_user_id_str" : "18873970",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512729078999166977",
  "text" : "im going to vegas, and im going to play poker, and im going to intentionally cause myself binary confusion while i swear about my potential.",
  "id" : 512729078999166977,
  "created_at" : "2014-09-18 22:25:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512728730284724224",
  "text" : "watching the shitcoin trades on twitter is like watching a poker table, one with a 1110 seats, each player sputtering not-so-cryptic feints.",
  "id" : 512728730284724224,
  "created_at" : "2014-09-18 22:23:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512727131453804544",
  "text" : "decentralized all the power",
  "id" : 512727131453804544,
  "created_at" : "2014-09-18 22:17:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512727076906885120",
  "text" : "there is no racism without power\nthere is no sexism without power\nthere is no classism without power\nthere is no war without power",
  "id" : 512727076906885120,
  "created_at" : "2014-09-18 22:17:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512726569194774530",
  "geo" : { },
  "id_str" : "512726748820041729",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove   that stage is amazing!",
  "id" : 512726748820041729,
  "in_reply_to_status_id" : 512726569194774530,
  "created_at" : "2014-09-18 22:15:57 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512726564442611712",
  "text" : "cut to the chase with your ideals and revolutions.  race, class, sex, nationality, it's all about power.  Keep power from those that want it",
  "id" : 512726564442611712,
  "created_at" : "2014-09-18 22:15:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512722512182927363",
  "geo" : { },
  "id_str" : "512724535129296896",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost im not saying it will be fashionable, yet, at that age, but... heh",
  "id" : 512724535129296896,
  "in_reply_to_status_id" : 512722512182927363,
  "created_at" : "2014-09-18 22:07:09 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512722512182927363",
  "geo" : { },
  "id_str" : "512724000582025216",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost  UR RIGHT I AM ENUF OF IT RIGHT NOW!!!",
  "id" : 512724000582025216,
  "in_reply_to_status_id" : 512722512182927363,
  "created_at" : "2014-09-18 22:05:02 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512722201657626625",
  "text" : "FUCK YOU",
  "id" : 512722201657626625,
  "created_at" : "2014-09-18 21:57:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512721342940995584",
  "text" : "EXAMPLE\n\nWHERE YOU WOULD SAY, SARCASTICALLY\n\n\"REAL CLASSY, $ASSHOLE\"\n\nINSTEAD, DONT BE SARCASTIC",
  "id" : 512721342940995584,
  "created_at" : "2014-09-18 21:54:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512720786600124416",
  "text" : "SAME GOES FOR MORALS, WHICH I THINK ARE LIKE ETHICS ABSTRACTED UP YOUR OWN ASS AND OUT YOUR NOSE, BUT IMMA DROPOUT SO WHAT DO I KNOW?",
  "id" : 512720786600124416,
  "created_at" : "2014-09-18 21:52:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512720614558138369",
  "text" : "DO NOT USE THE WORD CLASS OR CLASSY TO REFER TO AN ACT THAT IS OR IS NOT ETHICAL.  \n\nTHAT GIVES CLASS ITS POWER.",
  "id" : 512720614558138369,
  "created_at" : "2014-09-18 21:51:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CLASSY",
      "indices" : [ 22, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512720445590614016",
  "text" : "CLASS IF FOR CLOWNS \n\n#CLASSY",
  "id" : 512720445590614016,
  "created_at" : "2014-09-18 21:50:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512720046045396992",
  "text" : "stop wearing pants, and you will never go back\n\nthat is fucking logically true",
  "id" : 512720046045396992,
  "created_at" : "2014-09-18 21:49:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512719863958077441",
  "text" : "same with the khaki and polo shirt, so fucking clownish",
  "id" : 512719863958077441,
  "created_at" : "2014-09-18 21:48:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512719577227079681",
  "text" : "i have always viewed the standard suit as the costume of the working clown class, and the masters they emulate.",
  "id" : 512719577227079681,
  "created_at" : "2014-09-18 21:47:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512719178105511938",
  "text" : "i jus realized that in another 7-10 years, i will be old enuf to berate people with knowledge and wisdom, especially if they come near me!!!",
  "id" : 512719178105511938,
  "created_at" : "2014-09-18 21:45:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Remo",
      "screen_name" : "chrisremo",
      "indices" : [ 0, 10 ],
      "id_str" : "16792453",
      "id" : 16792453
    }, {
      "name" : "edna piranha",
      "screen_name" : "ednapiranha",
      "indices" : [ 11, 23 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512640485265915905",
  "geo" : { },
  "id_str" : "512718825863643137",
  "in_reply_to_user_id" : 16792453,
  "text" : "@chrisremo @ednapiranha  also, this represents another ironic truth, which is the same as the King Clothes.  That class is for clowns!",
  "id" : 512718825863643137,
  "in_reply_to_status_id" : 512640485265915905,
  "created_at" : "2014-09-18 21:44:28 +0000",
  "in_reply_to_screen_name" : "chrisremo",
  "in_reply_to_user_id_str" : "16792453",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Remo",
      "screen_name" : "chrisremo",
      "indices" : [ 0, 10 ],
      "id_str" : "16792453",
      "id" : 16792453
    }, {
      "name" : "edna piranha",
      "screen_name" : "ednapiranha",
      "indices" : [ 11, 23 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512640485265915905",
  "geo" : { },
  "id_str" : "512718607126519808",
  "in_reply_to_user_id" : 16792453,
  "text" : "@chrisremo @ednapiranha  this is truly ironic (-(true)) cuz it is less efficient in terms of care (wash everything), but plus++ convenient.",
  "id" : 512718607126519808,
  "in_reply_to_status_id" : 512640485265915905,
  "created_at" : "2014-09-18 21:43:36 +0000",
  "in_reply_to_screen_name" : "chrisremo",
  "in_reply_to_user_id_str" : "16792453",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512713692039770112",
  "text" : "one day robots with be the sexiest, so why try? \n\nyou stupid ugly monkey!!",
  "id" : 512713692039770112,
  "created_at" : "2014-09-18 21:24:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512691767636807680",
  "geo" : { },
  "id_str" : "512712618209849345",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain  how to determine how long buying high and selling low will be profitable come pump time?  im a newb  o\/",
  "id" : 512712618209849345,
  "in_reply_to_status_id" : 512691767636807680,
  "created_at" : "2014-09-18 21:19:48 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512712144115097600",
  "text" : "wtf is maidsafecoin, def not making the cut",
  "id" : 512712144115097600,
  "created_at" : "2014-09-18 21:17:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512593532045885440",
  "text" : "next week's band's name is\n\nsex for knowledge",
  "id" : 512593532045885440,
  "created_at" : "2014-09-18 13:26:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512591865644740608",
  "geo" : { },
  "id_str" : "512593145305919488",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \nthe philo-bum walks to berkeley, and reveals bags of philosopher coin, as people hungry for knowledge begin to surround...",
  "id" : 512593145305919488,
  "in_reply_to_status_id" : 512591865644740608,
  "created_at" : "2014-09-18 13:25:04 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512591865644740608",
  "geo" : { },
  "id_str" : "512592112513069057",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \n\nbizness man:  hahaha, those are shitcoin status on the exchanges!  good luck philosopher bum!",
  "id" : 512592112513069057,
  "in_reply_to_status_id" : 512591865644740608,
  "created_at" : "2014-09-18 13:20:57 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512591865644740608",
  "text" : "wow, you blew my mind, philosopher bum!  \n\nhere, take my philosopher's coins!",
  "id" : 512591865644740608,
  "created_at" : "2014-09-18 13:19:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512591552942981121",
  "text" : "i wanna make a crypto currency sketch comedy show rn",
  "id" : 512591552942981121,
  "created_at" : "2014-09-18 13:18:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512568551782510592",
  "geo" : { },
  "id_str" : "512575226165465089",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain kill yrself",
  "id" : 512575226165465089,
  "in_reply_to_status_id" : 512568551782510592,
  "created_at" : "2014-09-18 12:13:51 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512381825172652032",
  "text" : "I have begun to wonder if this spider is mouth fucking me 4 lyfe",
  "id" : 512381825172652032,
  "created_at" : "2014-09-17 23:25:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512351756714397696",
  "text" : "you are correct, I was not making an argument by calling you a fucking ignorant idiot, but that is what you are, so there is no argue!!!",
  "id" : 512351756714397696,
  "created_at" : "2014-09-17 21:25:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512340936307642369",
  "geo" : { },
  "id_str" : "512341179954757632",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \non the first day of crypto currency...",
  "id" : 512341179954757632,
  "in_reply_to_status_id" : 512340936307642369,
  "created_at" : "2014-09-17 20:43:50 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512340936307642369",
  "text" : "I was given a souvenir today: that I had ice cream waiting for me at home.  All I remember is the souvenir tho, not what the souvenir was.",
  "id" : 512340936307642369,
  "created_at" : "2014-09-17 20:42:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roald Daal",
      "screen_name" : "ElSangito",
      "indices" : [ 0, 10 ],
      "id_str" : "24504850",
      "id" : 24504850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512336094692519936",
  "geo" : { },
  "id_str" : "512338311201824768",
  "in_reply_to_user_id" : 24504850,
  "text" : "@ElSangito that character is the \"it's the thought that matters\" of passion",
  "id" : 512338311201824768,
  "in_reply_to_status_id" : 512336094692519936,
  "created_at" : "2014-09-17 20:32:26 +0000",
  "in_reply_to_screen_name" : "ElSangito",
  "in_reply_to_user_id_str" : "24504850",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512334155166650368",
  "text" : "FIR MY NEXT REVOLOOSHNRY ACT",
  "id" : 512334155166650368,
  "created_at" : "2014-09-17 20:15:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512332991591223296",
  "text" : "Soon imma have a publicly traded publicly trading crypto operation",
  "id" : 512332991591223296,
  "created_at" : "2014-09-17 20:11:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mercedes H",
      "screen_name" : "the_N0",
      "indices" : [ 0, 7 ],
      "id_str" : "42699163",
      "id" : 42699163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512324255774965761",
  "geo" : { },
  "id_str" : "512330688821878785",
  "in_reply_to_user_id" : 42699163,
  "text" : "@the_N0  free scifi",
  "id" : 512330688821878785,
  "in_reply_to_status_id" : 512324255774965761,
  "created_at" : "2014-09-17 20:02:09 +0000",
  "in_reply_to_screen_name" : "the_N0",
  "in_reply_to_user_id_str" : "42699163",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512322862280368128",
  "text" : "stretch goal:  we turn hackistan into a publicly available reality",
  "id" : 512322862280368128,
  "created_at" : "2014-09-17 19:31:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512317450894188545",
  "text" : "i work dillligently for my nappy head",
  "id" : 512317450894188545,
  "created_at" : "2014-09-17 19:09:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF61\u25D5 \u203F \u25D5\uFF61\u3000\u30CF\u30D5\u30ED\u30FC",
      "screen_name" : "HFLW",
      "indices" : [ 0, 5 ],
      "id_str" : "14694079",
      "id" : 14694079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512304610703601665",
  "geo" : { },
  "id_str" : "512307014685691904",
  "in_reply_to_user_id" : 14694079,
  "text" : "@HFLW  that's hella sus mang but wtf drop linkdin already",
  "id" : 512307014685691904,
  "in_reply_to_status_id" : 512304610703601665,
  "created_at" : "2014-09-17 18:28:05 +0000",
  "in_reply_to_screen_name" : "HFLW",
  "in_reply_to_user_id_str" : "14694079",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppleByteMe",
      "screen_name" : "AppleByteMe",
      "indices" : [ 0, 12 ],
      "id_str" : "2385708048",
      "id" : 2385708048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512300127814692864",
  "geo" : { },
  "id_str" : "512304588289241088",
  "in_reply_to_user_id" : 2385708048,
  "text" : "@AppleByteMe   u should encourage and educate artists for to get into linux instead of blocking linux users from your coin  ;^P",
  "id" : 512304588289241088,
  "in_reply_to_status_id" : 512300127814692864,
  "created_at" : "2014-09-17 18:18:26 +0000",
  "in_reply_to_screen_name" : "AppleByteMe",
  "in_reply_to_user_id_str" : "2385708048",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512303587842867200",
  "geo" : { },
  "id_str" : "512303664426668034",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  based on alt coins, sepcifically, natch",
  "id" : 512303664426668034,
  "in_reply_to_status_id" : 512303587842867200,
  "created_at" : "2014-09-17 18:14:46 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512303587842867200",
  "text" : "imma list a real world product based on crypto on counterparty and maybe clearinghouse (viacoin).  hollar about it if yr not daft.",
  "id" : 512303587842867200,
  "created_at" : "2014-09-17 18:14:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 16, 29 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512297273917968384",
  "geo" : { },
  "id_str" : "512303303943020544",
  "in_reply_to_user_id" : 2422531939,
  "text" : "@CryptoCorleone @CryptoCobain   shitcoin traders accusing shitcoin traders of pump n dump.  all of u are calling for buys when u selling.",
  "id" : 512303303943020544,
  "in_reply_to_status_id" : 512297273917968384,
  "created_at" : "2014-09-17 18:13:20 +0000",
  "in_reply_to_screen_name" : "streetSines_",
  "in_reply_to_user_id_str" : "2422531939",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AppleByteMe",
      "screen_name" : "AppleByteMe",
      "indices" : [ 0, 12 ],
      "id_str" : "2385708048",
      "id" : 2385708048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512299554142572544",
  "in_reply_to_user_id" : 2385708048,
  "text" : "@AppleByteMe where can I find info about this coin?  the devs, the premine or ICO, the algo and mining specs...?",
  "id" : 512299554142572544,
  "created_at" : "2014-09-17 17:58:26 +0000",
  "in_reply_to_screen_name" : "AppleByteMe",
  "in_reply_to_user_id_str" : "2385708048",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512182558847553537",
  "text" : "my life's dependencies are food, music and dance, art and science, and there lies my emotions.  dont fuck with my food.",
  "id" : 512182558847553537,
  "created_at" : "2014-09-17 10:13:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512181432567877632",
  "text" : "the truest current is the one that is created purely by its transmission",
  "id" : 512181432567877632,
  "created_at" : "2014-09-17 10:09:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512180240475381760",
  "text" : "the twelve analogies of crypto currency",
  "id" : 512180240475381760,
  "created_at" : "2014-09-17 10:04:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512173935358533633",
  "text" : "lol butts",
  "id" : 512173935358533633,
  "created_at" : "2014-09-17 09:39:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512173294502420480",
  "text" : "here is a hint into what I am developing\n\nit will raise the tide for all shitcoins",
  "id" : 512173294502420480,
  "created_at" : "2014-09-17 09:36:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    }, {
      "name" : "IamLoops",
      "screen_name" : "_Valar_Dohaeris",
      "indices" : [ 26, 42 ],
      "id_str" : "2729609654",
      "id" : 2729609654
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512171681897390080",
  "geo" : { },
  "id_str" : "512172885910114304",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain @gustavowiz @_Valar_Dohaeris kill yrself",
  "id" : 512172885910114304,
  "in_reply_to_status_id" : 512171681897390080,
  "created_at" : "2014-09-17 09:35:06 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512171530311446531",
  "text" : "free hifi",
  "id" : 512171530311446531,
  "created_at" : "2014-09-17 09:29:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512171281685704704",
  "text" : "some of my bands will play music in real life in oakland and surrounding area, but I don't leave east bay without at least pay",
  "id" : 512171281685704704,
  "created_at" : "2014-09-17 09:28:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512171032690851840",
  "text" : "does my avatar appear me huge?",
  "id" : 512171032690851840,
  "created_at" : "2014-09-17 09:27:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512170912414990336",
  "text" : "im kinda like a spectrum",
  "id" : 512170912414990336,
  "created_at" : "2014-09-17 09:27:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512170872799768577",
  "text" : "i have many bands",
  "id" : 512170872799768577,
  "created_at" : "2014-09-17 09:27:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512170849332645888",
  "text" : "i have a band",
  "id" : 512170849332645888,
  "created_at" : "2014-09-17 09:27:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 40, 62 ],
      "url" : "http:\/\/t.co\/jpmmgNRnVW",
      "expanded_url" : "http:\/\/cryptoasian.com\/tco-tacocoin\/",
      "display_url" : "cryptoasian.com\/tco-tacocoin\/"
    } ]
  },
  "geo" : { },
  "id_str" : "512065411324448768",
  "text" : "tacocoin got a 4 out of 5 crypto asians http:\/\/t.co\/jpmmgNRnVW",
  "id" : 512065411324448768,
  "created_at" : "2014-09-17 02:28:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    }, {
      "name" : "Oakland Intl Airport",
      "screen_name" : "IFlyOAKland",
      "indices" : [ 11, 23 ],
      "id_str" : "34063620",
      "id" : 34063620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512062836835885057",
  "geo" : { },
  "id_str" : "512063019321274368",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove @IFlyOAKland \nS\/O",
  "id" : 512063019321274368,
  "in_reply_to_status_id" : 512062836835885057,
  "created_at" : "2014-09-17 02:18:32 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    }, {
      "name" : "Angelo\u0E3FTC",
      "screen_name" : "AngeloBTC",
      "indices" : [ 14, 24 ],
      "id_str" : "916257050",
      "id" : 916257050
    }, {
      "name" : "Mr Sparrow",
      "screen_name" : "jackfru1t",
      "indices" : [ 25, 35 ],
      "id_str" : "2421317989",
      "id" : 2421317989
    }, {
      "name" : "Looposhi",
      "screen_name" : "22loops",
      "indices" : [ 36, 44 ],
      "id_str" : "2365864771",
      "id" : 2365864771
    }, {
      "name" : "Max Moyle",
      "screen_name" : "MaxMoyle",
      "indices" : [ 45, 54 ],
      "id_str" : "301731542",
      "id" : 301731542
    }, {
      "name" : "[Romano]",
      "screen_name" : "RNR_0",
      "indices" : [ 55, 61 ],
      "id_str" : "2199605117",
      "id" : 2199605117
    }, {
      "name" : "BTC \u0E3Fite",
      "screen_name" : "btcbite",
      "indices" : [ 62, 70 ],
      "id_str" : "2596186036",
      "id" : 2596186036
    }, {
      "name" : "Fullhdpixel",
      "screen_name" : "fullhdpixel",
      "indices" : [ 71, 83 ],
      "id_str" : "592964051",
      "id" : 592964051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512040566301806593",
  "geo" : { },
  "id_str" : "512061977733001216",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain @AngeloBTC @jackfru1t @22loops @MaxMoyle @RNR_0 @btcbite @fullhdpixel hello every one",
  "id" : 512061977733001216,
  "in_reply_to_status_id" : 512040566301806593,
  "created_at" : "2014-09-17 02:14:23 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    }, {
      "name" : "Cryptopath",
      "screen_name" : "Cryptopathic",
      "indices" : [ 14, 27 ],
      "id_str" : "2433432126",
      "id" : 2433432126
    }, {
      "name" : "Emerald",
      "screen_name" : "EmeraldCrypto",
      "indices" : [ 28, 42 ],
      "id_str" : "2377115558",
      "id" : 2377115558
    }, {
      "name" : "c\u00AEyp7oc4\u264F3l ",
      "screen_name" : "CryptoCamel",
      "indices" : [ 43, 55 ],
      "id_str" : "1677650622",
      "id" : 1677650622
    }, {
      "name" : "Philip Francis",
      "screen_name" : "philfrancis77",
      "indices" : [ 56, 70 ],
      "id_str" : "308265684",
      "id" : 308265684
    }, {
      "name" : "Luke Fitzgerald",
      "screen_name" : "darkip",
      "indices" : [ 71, 78 ],
      "id_str" : "26499336",
      "id" : 26499336
    }, {
      "name" : "Lindsay Lohan",
      "screen_name" : "lindsaylohan",
      "indices" : [ 79, 92 ],
      "id_str" : "65992743",
      "id" : 65992743
    }, {
      "name" : "ActualAdvice_BTC",
      "screen_name" : "ActualAdviceBTC",
      "indices" : [ 93, 109 ],
      "id_str" : "2216302500",
      "id" : 2216302500
    }, {
      "name" : "ActualAdvice_ALT",
      "screen_name" : "ActualAdviceALT",
      "indices" : [ 110, 126 ],
      "id_str" : "2514541536",
      "id" : 2514541536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "512041197829758976",
  "geo" : { },
  "id_str" : "512061872292376577",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain @Cryptopathic @EmeraldCrypto @CryptoCamel @philfrancis77 @darkip @lindsaylohan @ActualAdviceBTC @ActualAdviceALT  hi everybody",
  "id" : 512061872292376577,
  "in_reply_to_status_id" : 512041197829758976,
  "created_at" : "2014-09-17 02:13:58 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "512061476090032128",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair its gonna be a real thing watch out  ;^)",
  "id" : 512061476090032128,
  "created_at" : "2014-09-17 02:12:24 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511993486694838272",
  "text" : "Great god these fries better be good",
  "id" : 511993486694838272,
  "created_at" : "2014-09-16 21:42:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511990574971228160",
  "text" : "Its amazing right now dev skills can be converted directly into shitcoin, its like a market so awesome",
  "id" : 511990574971228160,
  "created_at" : "2014-09-16 21:30:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511989962523172864",
  "text" : "It's funny to watch the pumpers n dumpers say the opposite of what they want.",
  "id" : 511989962523172864,
  "created_at" : "2014-09-16 21:28:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511988207404056576",
  "geo" : { },
  "id_str" : "511988519258963969",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain kill urself?",
  "id" : 511988519258963969,
  "in_reply_to_status_id" : 511988207404056576,
  "created_at" : "2014-09-16 21:22:29 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/Nemt9MUYHs",
      "expanded_url" : "http:\/\/www.databass.biz",
      "display_url" : "databass.biz"
    } ]
  },
  "geo" : { },
  "id_str" : "511988271849562112",
  "text" : "http:\/\/t.co\/Nemt9MUYHs",
  "id" : 511988271849562112,
  "created_at" : "2014-09-16 21:21:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511968148786909185",
  "text" : "if the coin is shit, well at least their cheap rn",
  "id" : 511968148786909185,
  "created_at" : "2014-09-16 20:01:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511968103014490112",
  "text" : "if the coin is good, what im doing will be good for it",
  "id" : 511968103014490112,
  "created_at" : "2014-09-16 20:01:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511968040456437760",
  "text" : "it will be good for all crypto",
  "id" : 511968040456437760,
  "created_at" : "2014-09-16 20:01:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511967989793423361",
  "text" : "i think imma do a major development in crypto coin",
  "id" : 511967989793423361,
  "created_at" : "2014-09-16 20:00:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511962781847805952",
  "text" : "i use money as an artistic medium\n\ni create like how you spend money",
  "id" : 511962781847805952,
  "created_at" : "2014-09-16 19:40:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "indices" : [ 3, 14 ],
      "id_str" : "255617445",
      "id" : 255617445
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511960983267336192",
  "text" : "RT @worrydream: Seeing hand-lettering among the fonts, hearing true harmony among the equal temperament, making what you need among the man\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "511960726634655744",
    "text" : "Seeing hand-lettering among the fonts, hearing true harmony among the equal temperament, making what you need among the manufactured goods.",
    "id" : 511960726634655744,
    "created_at" : "2014-09-16 19:32:03 +0000",
    "user" : {
      "name" : "Bret Victor",
      "screen_name" : "worrydream",
      "protected" : false,
      "id_str" : "255617445",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/478069251790499841\/GNcGrhNt_normal.png",
      "id" : 255617445,
      "verified" : false
    }
  },
  "id" : 511960983267336192,
  "created_at" : "2014-09-16 19:33:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lily",
      "screen_name" : "luxuriousho",
      "indices" : [ 0, 12 ],
      "id_str" : "21127389",
      "id" : 21127389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511948747782516736",
  "geo" : { },
  "id_str" : "511949111600615424",
  "in_reply_to_user_id" : 21127389,
  "text" : "@luxuriousho haha u need frowny pants",
  "id" : 511949111600615424,
  "in_reply_to_status_id" : 511948747782516736,
  "created_at" : "2014-09-16 18:45:54 +0000",
  "in_reply_to_screen_name" : "luxuriousho",
  "in_reply_to_user_id_str" : "21127389",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511948026139922432",
  "text" : "POKEMONEY",
  "id" : 511948026139922432,
  "created_at" : "2014-09-16 18:41:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511947631648837633",
  "geo" : { },
  "id_str" : "511947781142245376",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain  pokemoney",
  "id" : 511947781142245376,
  "in_reply_to_status_id" : 511947631648837633,
  "created_at" : "2014-09-16 18:40:37 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511947636090617856",
  "text" : "pimp n passion palpable",
  "id" : 511947636090617856,
  "created_at" : "2014-09-16 18:40:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511943943597334528",
  "text" : "THIS IS A HOLD OUT",
  "id" : 511943943597334528,
  "created_at" : "2014-09-16 18:25:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511943819269787648",
  "text" : "WHAT DO YOU WANT TO BUILD?",
  "id" : 511943819269787648,
  "created_at" : "2014-09-16 18:24:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511943610506702848",
  "text" : "i could build an empire app in a week",
  "id" : 511943610506702848,
  "created_at" : "2014-09-16 18:24:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511943321598820352",
  "text" : "yes i am in fact one of the most advanced wizards of web development hahaha",
  "id" : 511943321598820352,
  "created_at" : "2014-09-16 18:22:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511943143999406080",
  "text" : "im probably gonna lose all my shitcoin, but that's tuition for you",
  "id" : 511943143999406080,
  "created_at" : "2014-09-16 18:22:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511943004614295552",
  "text" : "could u guys pump pink pls so i can exit and get back to via?",
  "id" : 511943004614295552,
  "created_at" : "2014-09-16 18:21:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511942794861355009",
  "text" : "haha employee may have been the biggest win in linguistic history",
  "id" : 511942794861355009,
  "created_at" : "2014-09-16 18:20:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511942735197388800",
  "text" : "\"employee\"",
  "id" : 511942735197388800,
  "created_at" : "2014-09-16 18:20:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian AKA The Truth",
      "screen_name" : "jyap",
      "indices" : [ 0, 5 ],
      "id_str" : "5624402",
      "id" : 5624402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511938164492345344",
  "geo" : { },
  "id_str" : "511942114209714176",
  "in_reply_to_user_id" : 5624402,
  "text" : "@jyap sure!",
  "id" : 511942114209714176,
  "in_reply_to_status_id" : 511938164492345344,
  "created_at" : "2014-09-16 18:18:06 +0000",
  "in_reply_to_screen_name" : "jyap",
  "in_reply_to_user_id_str" : "5624402",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511937547740540929",
  "text" : "know im in a flow when there are half full beers in all my usual haunts",
  "id" : 511937547740540929,
  "created_at" : "2014-09-16 17:59:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511935673142505472",
  "text" : "Gimme the app for singles trynna stay all one",
  "id" : 511935673142505472,
  "created_at" : "2014-09-16 17:52:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511934729738665984",
  "geo" : { },
  "id_str" : "511935285580398592",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \nBang bang",
  "id" : 511935285580398592,
  "in_reply_to_status_id" : 511934729738665984,
  "created_at" : "2014-09-16 17:50:58 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511934729738665984",
  "text" : "Dating is passion roulette.\nBut my gun loaded \nwith a passion.",
  "id" : 511934729738665984,
  "created_at" : "2014-09-16 17:48:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511933453256777728",
  "text" : "Let's put all the emo dependents in one place, with the romantics",
  "id" : 511933453256777728,
  "created_at" : "2014-09-16 17:43:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511933125278965760",
  "text" : "Why the fuck would I enter the realm of infinite forever emotional codependent searching?",
  "id" : 511933125278965760,
  "created_at" : "2014-09-16 17:42:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511932769966891008",
  "text" : "Lol twitter u don't know me if u think I am at all interested in \"dating\"",
  "id" : 511932769966891008,
  "created_at" : "2014-09-16 17:40:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian AKA The Truth",
      "screen_name" : "jyap",
      "indices" : [ 0, 5 ],
      "id_str" : "5624402",
      "id" : 5624402
    }, {
      "name" : "AltMarket.com",
      "screen_name" : "altmarketdotcom",
      "indices" : [ 6, 22 ],
      "id_str" : "2728382414",
      "id" : 2728382414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511928088813649921",
  "geo" : { },
  "id_str" : "511930575481888768",
  "in_reply_to_user_id" : 5624402,
  "text" : "@jyap @altmarketdotcom lookin for devs?",
  "id" : 511930575481888768,
  "in_reply_to_status_id" : 511928088813649921,
  "created_at" : "2014-09-16 17:32:15 +0000",
  "in_reply_to_screen_name" : "jyap",
  "in_reply_to_user_id_str" : "5624402",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian AKA The Truth",
      "screen_name" : "jyap",
      "indices" : [ 0, 5 ],
      "id_str" : "5624402",
      "id" : 5624402
    }, {
      "name" : "AltMarket.com",
      "screen_name" : "altmarketdotcom",
      "indices" : [ 6, 22 ],
      "id_str" : "2728382414",
      "id" : 2728382414
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511928088813649921",
  "geo" : { },
  "id_str" : "511929206691725312",
  "in_reply_to_user_id" : 5624402,
  "text" : "@jyap @altmarketdotcom GG",
  "id" : 511929206691725312,
  "in_reply_to_status_id" : 511928088813649921,
  "created_at" : "2014-09-16 17:26:48 +0000",
  "in_reply_to_screen_name" : "jyap",
  "in_reply_to_user_id_str" : "5624402",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511928747855839232",
  "text" : "If u run a portmanteaubot\nStop now n RT me instead",
  "id" : 511928747855839232,
  "created_at" : "2014-09-16 17:24:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511928467945177089",
  "text" : "I need to hire a selfitary",
  "id" : 511928467945177089,
  "created_at" : "2014-09-16 17:23:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511927789159608321",
  "text" : "Good drunk got me all balanced",
  "id" : 511927789159608321,
  "created_at" : "2014-09-16 17:21:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511926337028624385",
  "text" : "RILLY LOVING MY BODY RN",
  "id" : 511926337028624385,
  "created_at" : "2014-09-16 17:15:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heyLove*",
      "screen_name" : "djheylove",
      "indices" : [ 0, 10 ],
      "id_str" : "944568686",
      "id" : 944568686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511912995983613952",
  "geo" : { },
  "id_str" : "511913916675280898",
  "in_reply_to_user_id" : 944568686,
  "text" : "@djheylove whoa what what what!",
  "id" : 511913916675280898,
  "in_reply_to_status_id" : 511912995983613952,
  "created_at" : "2014-09-16 16:26:03 +0000",
  "in_reply_to_screen_name" : "djheylove",
  "in_reply_to_user_id_str" : "944568686",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/qtkgykQw3D",
      "expanded_url" : "http:\/\/dancejs.io\/",
      "display_url" : "dancejs.io"
    } ]
  },
  "geo" : { },
  "id_str" : "511910819328581632",
  "text" : "im speaking or performing and definitely dancing at this event in oakland  http:\/\/t.co\/qtkgykQw3D",
  "id" : 511910819328581632,
  "created_at" : "2014-09-16 16:13:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/qtkgykQw3D",
      "expanded_url" : "http:\/\/dancejs.io\/",
      "display_url" : "dancejs.io"
    } ]
  },
  "geo" : { },
  "id_str" : "511909624111316993",
  "text" : "get on it http:\/\/t.co\/qtkgykQw3D",
  "id" : 511909624111316993,
  "created_at" : "2014-09-16 16:08:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511908511253426176",
  "text" : "why did a bunch of fitness apps start following.\n\ni mean, how did they know im so sexy fit?",
  "id" : 511908511253426176,
  "created_at" : "2014-09-16 16:04:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511683033380823040",
  "text" : "Yeah, I'm the stupid",
  "id" : 511683033380823040,
  "created_at" : "2014-09-16 01:08:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511572509653598209",
  "text" : "i u don't pump my shitcoin, I won't share this rad synthesizer",
  "id" : 511572509653598209,
  "created_at" : "2014-09-15 17:49:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511571953107222528",
  "text" : "hows mah shitcoin doing bae  :^*",
  "id" : 511571953107222528,
  "created_at" : "2014-09-15 17:47:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511571826632163328",
  "text" : "processing bespoke low end waveforms before breakfast\n\ngaussian overtones\noscillating oscillators\nand of course\nfeedback\n\nme hungry",
  "id" : 511571826632163328,
  "created_at" : "2014-09-15 17:46:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/511565077019779072\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/3mCQ5sUegE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bxlxuf7CYAA_r2Z.jpg",
      "id_str" : "511565076340301824",
      "id" : 511565076340301824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bxlxuf7CYAA_r2Z.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1136,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 2048,
        "resize" : "fit",
        "w" : 1846
      }, {
        "h" : 665,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 377,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/3mCQ5sUegE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511565077019779072",
  "text" : "here's a snack for ya\n\na preview\n\nthis interface was auto generated\n\nfor to switch up functional params\n\n\u00B1INF http:\/\/t.co\/3mCQ5sUegE",
  "id" : 511565077019779072,
  "created_at" : "2014-09-15 17:19:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511561946865209345",
  "text" : "i literally created my own negative feedback effect\n\nso i will not be needing any otherses",
  "id" : 511561946865209345,
  "created_at" : "2014-09-15 17:07:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511559899344420864",
  "text" : "me crank n the float values \n\nwhere n b n order of magnitude\n\njohnny synthswears fuckyeah",
  "id" : 511559899344420864,
  "created_at" : "2014-09-15 16:59:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511557311597273088",
  "text" : "poor people coin\n\npplcoin",
  "id" : 511557311597273088,
  "created_at" : "2014-09-15 16:49:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511552835708665856",
  "text" : "new body, new mind",
  "id" : 511552835708665856,
  "created_at" : "2014-09-15 16:31:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511552414298550272",
  "text" : "yall didnt jus hear that psychic polyrhythm i made with my body\/drum\n\nunless you live with a quarter mile radius of my house\/speaker",
  "id" : 511552414298550272,
  "created_at" : "2014-09-15 16:29:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511545976926908416",
  "text" : "me gunn tune algoriddims n trade shitcoin",
  "id" : 511545976926908416,
  "created_at" : "2014-09-15 16:03:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Jones",
      "screen_name" : "riverofdoubt",
      "indices" : [ 0, 13 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "511517398885994496",
  "geo" : { },
  "id_str" : "511544259216822272",
  "in_reply_to_user_id" : 97794798,
  "text" : "@riverofdoubt  u gunn make an appearance UP EAR in Oakland?",
  "id" : 511544259216822272,
  "in_reply_to_status_id" : 511517398885994496,
  "created_at" : "2014-09-15 15:57:10 +0000",
  "in_reply_to_screen_name" : "riverofdoubt",
  "in_reply_to_user_id_str" : "97794798",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511531282245750785",
  "text" : "tree schemes",
  "id" : 511531282245750785,
  "created_at" : "2014-09-15 15:05:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511531155292565504",
  "text" : "Now getting drunk and having sex at the same time is doubly punk, and 2^4 punk if both members are inebriated.  Orgies are NP != P",
  "id" : 511531155292565504,
  "created_at" : "2014-09-15 15:05:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511530033538535424",
  "text" : "yes, life in the united states and western world as a \"pay tree arch\".  get on, fund the pyramid scheme, and ride it beginning to yr end.",
  "id" : 511530033538535424,
  "created_at" : "2014-09-15 15:00:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511529486165090304",
  "text" : "PAY TREE ARCH",
  "id" : 511529486165090304,
  "created_at" : "2014-09-15 14:58:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511529043368222720",
  "text" : "SB 967, makes clear that... consent given under the influence of alcohol and\/or drugs does not equal consent to sexual activity.",
  "id" : 511529043368222720,
  "created_at" : "2014-09-15 14:56:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511528740107456512",
  "text" : "lolling at this sexual consent bill",
  "id" : 511528740107456512,
  "created_at" : "2014-09-15 14:55:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pinkcoin",
      "indices" : [ 15, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "511208784861990913",
  "text" : "don't sleep on #pinkcoin",
  "id" : 511208784861990913,
  "created_at" : "2014-09-14 17:44:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510903272039665664",
  "text" : "document.biddy",
  "id" : 510903272039665664,
  "created_at" : "2014-09-13 21:30:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510899614321344512",
  "text" : "sign up for our quarterly invitation to draw your self quarterly",
  "id" : 510899614321344512,
  "created_at" : "2014-09-13 21:15:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "altcoins",
      "indices" : [ 103, 112 ]
    }, {
      "text" : "shitcoins",
      "indices" : [ 113, 123 ]
    }, {
      "text" : "coinmarkets",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/5RhMm6xhjE",
      "expanded_url" : "http:\/\/npmjs.org",
      "display_url" : "npmjs.org"
    } ]
  },
  "geo" : { },
  "id_str" : "510883713698127872",
  "text" : "protip for alt coin devs:  create an NPM module that exports a wallet creator  http:\/\/t.co\/5RhMm6xhjE\n\n#altcoins #shitcoins #coinmarkets",
  "id" : 510883713698127872,
  "created_at" : "2014-09-13 20:12:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510828802402811906",
  "text" : "weird is the unit of measurement for the difference between people",
  "id" : 510828802402811906,
  "created_at" : "2014-09-13 16:34:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510828656055160832",
  "text" : "i played poker last night with cryptokens",
  "id" : 510828656055160832,
  "created_at" : "2014-09-13 16:33:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510796970403717120",
  "geo" : { },
  "id_str" : "510801611673698304",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack  i dont like that model anyway, yr public key attached to a fiat social media profile.  that's not anarchy",
  "id" : 510801611673698304,
  "in_reply_to_status_id" : 510796970403717120,
  "created_at" : "2014-09-13 14:46:09 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 0, 16 ],
      "id_str" : "29117866",
      "id" : 29117866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510694412331253760",
  "geo" : { },
  "id_str" : "510707344456433664",
  "in_reply_to_user_id" : 29117866,
  "text" : "@materialdesignr  transcend it",
  "id" : 510707344456433664,
  "in_reply_to_status_id" : 510694412331253760,
  "created_at" : "2014-09-13 08:31:34 +0000",
  "in_reply_to_screen_name" : "materialdesignr",
  "in_reply_to_user_id_str" : "29117866",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dickinson",
      "screen_name" : "isntitvacant",
      "indices" : [ 0, 13 ],
      "id_str" : "15394440",
      "id" : 15394440
    }, {
      "name" : "Brian J Brennan",
      "screen_name" : "brianloveswords",
      "indices" : [ 14, 30 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/J46gHdMtpC",
      "expanded_url" : "https:\/\/www.npmjs.org\/search?q=jsynth",
      "display_url" : "npmjs.org\/search?q=jsynth"
    } ]
  },
  "in_reply_to_status_id_str" : "510655758577303552",
  "geo" : { },
  "id_str" : "510686581984743424",
  "in_reply_to_user_id" : 15394440,
  "text" : "@isntitvacant @brianloveswords  In the spirit of open source, I will do this for 20 BTC\n\nhttps:\/\/t.co\/J46gHdMtpC",
  "id" : 510686581984743424,
  "in_reply_to_status_id" : 510655758577303552,
  "created_at" : "2014-09-13 07:09:03 +0000",
  "in_reply_to_screen_name" : "isntitvacant",
  "in_reply_to_user_id_str" : "15394440",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510684076068442113",
  "text" : "MATH CONTROLLED GOLD",
  "id" : 510684076068442113,
  "created_at" : "2014-09-13 06:59:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lily",
      "screen_name" : "luxuriousho",
      "indices" : [ 0, 12 ],
      "id_str" : "21127389",
      "id" : 21127389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/pEmmfwgq1b",
      "expanded_url" : "https:\/\/twitter.com\/ashyda\/status\/510415353420054528",
      "display_url" : "twitter.com\/ashyda\/status\/\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "510617173534838784",
  "geo" : { },
  "id_str" : "510627008229830656",
  "in_reply_to_user_id" : 21127389,
  "text" : "@luxuriousho  sonic boom https:\/\/t.co\/pEmmfwgq1b",
  "id" : 510627008229830656,
  "in_reply_to_status_id" : 510617173534838784,
  "created_at" : "2014-09-13 03:12:20 +0000",
  "in_reply_to_screen_name" : "luxuriousho",
  "in_reply_to_user_id_str" : "21127389",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/l3K9fbzpMX",
      "expanded_url" : "http:\/\/i.imgur.com\/S6Vd7nx.jpg",
      "display_url" : "i.imgur.com\/S6Vd7nx.jpg"
    } ]
  },
  "geo" : { },
  "id_str" : "510624952890843136",
  "text" : "music and stuff sunday over here  http:\/\/t.co\/l3K9fbzpMX",
  "id" : 510624952890843136,
  "created_at" : "2014-09-13 03:04:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510553034959515648",
  "text" : "that word critical\n\ni do not think it means what you think me think it means",
  "id" : 510553034959515648,
  "created_at" : "2014-09-12 22:18:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510313647868870656",
  "text" : "PINK FROYD",
  "id" : 510313647868870656,
  "created_at" : "2014-09-12 06:27:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510165601268936704",
  "text" : "changed his status to lizard prince.",
  "id" : 510165601268936704,
  "created_at" : "2014-09-11 20:38:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510153214482604032",
  "text" : "actual size",
  "id" : 510153214482604032,
  "created_at" : "2014-09-11 19:49:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/510152554395607040\/photo\/1",
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/Wq4IaBcrFN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxRtCpTCUAEC1Mb.jpg",
      "id_str" : "510152550012571649",
      "id" : 510152550012571649,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxRtCpTCUAEC1Mb.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/Wq4IaBcrFN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510152554395607040",
  "text" : "The spider that bit me: http:\/\/t.co\/Wq4IaBcrFN",
  "id" : 510152554395607040,
  "created_at" : "2014-09-11 19:47:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/rVGVMhbjXQ",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/test-drums",
      "display_url" : "soundcloud.com\/johnnyscript\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "510128737304600576",
  "text" : "here's me smacking around on the drums a bit\nhttps:\/\/t.co\/rVGVMhbjXQ",
  "id" : 510128737304600576,
  "created_at" : "2014-09-11 18:12:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510127898137608193",
  "text" : "prawly cuz i sucked the venom out and swallowed it",
  "id" : 510127898137608193,
  "created_at" : "2014-09-11 18:09:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510127082588762112",
  "text" : "a spider bite me\nn i feel kinda high\n:^D",
  "id" : 510127082588762112,
  "created_at" : "2014-09-11 18:05:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/510103786883653632\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/UstjNP8YgF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BxRAr6LCIAAQG7I.jpg",
      "id_str" : "510103780893794304",
      "id" : 510103780893794304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BxRAr6LCIAAQG7I.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/UstjNP8YgF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510103786883653632",
  "text" : "Me not always play muh percs in a kit\n\nBut when i does\n\nIt look like this http:\/\/t.co\/UstjNP8YgF",
  "id" : 510103786883653632,
  "created_at" : "2014-09-11 16:33:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "184987977",
      "id" : 184987977
    }, {
      "name" : "HashiCorp",
      "screen_name" : "hashicorp",
      "indices" : [ 15, 25 ],
      "id_str" : "290900886",
      "id" : 290900886
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510102068577984512",
  "geo" : { },
  "id_str" : "510102351818936320",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah @hashicorp  i dunno maybe read the hobo manual?  Sleep like a bum on it?",
  "id" : 510102351818936320,
  "in_reply_to_status_id" : 510102068577984512,
  "created_at" : "2014-09-11 16:27:32 +0000",
  "in_reply_to_screen_name" : "jesusabdullah",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510101356225384448",
  "text" : "protip.\nif u, or some body u kno\nis an artist\nproducer\ninternet hackstarr\n&amp; wants to get paid:\naccept crypto coins\nu have my axe\naxe me how",
  "id" : 510101356225384448,
  "created_at" : "2014-09-11 16:23:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510100581751345153",
  "text" : "i love how i got to slam my pointer against the side o th'screen 2 get th'menu boner 2 pop out, on this new unity interface. love is funny.",
  "id" : 510100581751345153,
  "created_at" : "2014-09-11 16:20:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510090848768237568",
  "text" : "9\/11 : a great day to shop for deals",
  "id" : 510090848768237568,
  "created_at" : "2014-09-11 15:41:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "510090697655848961",
  "text" : "Never forget: go shopping to forget that ur a slave!",
  "id" : 510090697655848961,
  "created_at" : "2014-09-11 15:41:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "184987977",
      "id" : 184987977
    }, {
      "name" : "Brian J Brennan",
      "screen_name" : "brianloveswords",
      "indices" : [ 15, 31 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "510086599561187328",
  "geo" : { },
  "id_str" : "510088906998439936",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah @brianloveswords  carpe cup",
  "id" : 510088906998439936,
  "in_reply_to_status_id" : 510086599561187328,
  "created_at" : "2014-09-11 15:34:07 +0000",
  "in_reply_to_screen_name" : "jesusabdullah",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509926731986132992",
  "text" : "u muss be intimate with yr instrument",
  "id" : 509926731986132992,
  "created_at" : "2014-09-11 04:49:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Drake",
      "screen_name" : "kyledrake",
      "indices" : [ 0, 10 ],
      "id_str" : "7171612",
      "id" : 7171612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509824926610518016",
  "geo" : { },
  "id_str" : "509862567854878720",
  "in_reply_to_user_id" : 7171612,
  "text" : "@kyledrake aka the pinnacle of patriarchy?",
  "id" : 509862567854878720,
  "in_reply_to_status_id" : 509824926610518016,
  "created_at" : "2014-09-11 00:34:43 +0000",
  "in_reply_to_screen_name" : "kyledrake",
  "in_reply_to_user_id_str" : "7171612",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509566902373318656",
  "text" : "closed that recording with \nFARTS ON MIC\nFARTS ON MIC\nto \"Girls on Film\" melody",
  "id" : 509566902373318656,
  "created_at" : "2014-09-10 04:59:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509448743620341760",
  "text" : "fuck! shit! shitcoins!",
  "id" : 509448743620341760,
  "created_at" : "2014-09-09 21:10:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509447961785282560",
  "text" : "I dont want you to talk about the talking about the company products in my stream pls.\n\nlook wut u made me do",
  "id" : 509447961785282560,
  "created_at" : "2014-09-09 21:07:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509442605747163136",
  "text" : "im not gonna look at shitcoins todays",
  "id" : 509442605747163136,
  "created_at" : "2014-09-09 20:45:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509442515578011648",
  "text" : "woke up this mawnin \npulled the machine up close by me and sleepily fixed a major blockage en coding progress\nreturned to half n half state",
  "id" : 509442515578011648,
  "created_at" : "2014-09-09 20:45:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "Brian J Brennan",
      "screen_name" : "brianloveswords",
      "indices" : [ 5, 21 ],
      "id_str" : "17177251",
      "id" : 17177251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509423412272312320",
  "geo" : { },
  "id_str" : "509441978870661120",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs @brianloveswords correction, the v4 req is 99",
  "id" : 509441978870661120,
  "in_reply_to_status_id" : 509423412272312320,
  "created_at" : "2014-09-09 20:43:27 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "184987977",
      "id" : 184987977
    }, {
      "name" : "Women Who Code NYC",
      "screen_name" : "WomenWhoCodeNYC",
      "indices" : [ 15, 31 ],
      "id_str" : "2386905271",
      "id" : 2386905271
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "knightme",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "509429781105242112",
  "geo" : { },
  "id_str" : "509440662433841153",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah @WomenWhoCodeNYC  i dont care what they say, i'd roll up there all \"wanna ride my horse?\" intellectually speaking.  #knightme",
  "id" : 509440662433841153,
  "in_reply_to_status_id" : 509429781105242112,
  "created_at" : "2014-09-09 20:38:13 +0000",
  "in_reply_to_screen_name" : "jesusabdullah",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509439893513048064",
  "text" : "protip:  think one thing, do another",
  "id" : 509439893513048064,
  "created_at" : "2014-09-09 20:35:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 79 ],
      "url" : "http:\/\/t.co\/RqCIzgOx55",
      "expanded_url" : "http:\/\/busdriverse.com\/",
      "display_url" : "busdriverse.com"
    } ]
  },
  "geo" : { },
  "id_str" : "509404447693619200",
  "text" : "new album from busdriver, one of my favorite lyricists: \nhttp:\/\/t.co\/RqCIzgOx55",
  "id" : 509404447693619200,
  "created_at" : "2014-09-09 18:14:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509123675853836288",
  "text" : "LOL IF THE NSA GOT ALL OF US BY WAY OF THE CAPTCHA",
  "id" : 509123675853836288,
  "created_at" : "2014-09-08 23:38:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509121890942590976",
  "text" : "SUCH DOGE EGON WONDER\nMAKE ME WOW\nSO IS AINT IT?",
  "id" : 509121890942590976,
  "created_at" : "2014-09-08 23:31:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509120560496775168",
  "text" : "-1 IF U CAN'T BE LIKE WHATS MY SHITCOIN DOING?",
  "id" : 509120560496775168,
  "created_at" : "2014-09-08 23:26:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "509112383604658176",
  "text" : "THE HIPPY DAYS ARE OVER",
  "id" : 509112383604658176,
  "created_at" : "2014-09-08 22:53:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "viacoin",
      "screen_name" : "viacoin",
      "indices" : [ 3, 11 ],
      "id_str" : "2432540773",
      "id" : 2432540773
    }, {
      "name" : "expresscoin",
      "screen_name" : "expresscoin",
      "indices" : [ 118, 130 ],
      "id_str" : "2191536853",
      "id" : 2191536853
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "viacoin",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/OK8BadrBzl",
      "expanded_url" : "http:\/\/blog.viacoin.org\/2014\/09\/08\/expresscoin.html",
      "display_url" : "blog.viacoin.org\/2014\/09\/08\/exp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "509068527651663872",
  "text" : "RT @viacoin: Expresscoin are adding #viacoin support: http:\/\/t.co\/OK8BadrBzl $VIA will be coming to ATMs and Android. @expresscoin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "expresscoin",
        "screen_name" : "expresscoin",
        "indices" : [ 105, 117 ],
        "id_str" : "2191536853",
        "id" : 2191536853
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "viacoin",
        "indices" : [ 23, 31 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/OK8BadrBzl",
        "expanded_url" : "http:\/\/blog.viacoin.org\/2014\/09\/08\/expresscoin.html",
        "display_url" : "blog.viacoin.org\/2014\/09\/08\/exp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "509067672688947200",
    "text" : "Expresscoin are adding #viacoin support: http:\/\/t.co\/OK8BadrBzl $VIA will be coming to ATMs and Android. @expresscoin",
    "id" : 509067672688947200,
    "created_at" : "2014-09-08 19:56:05 +0000",
    "user" : {
      "name" : "viacoin",
      "screen_name" : "viacoin",
      "protected" : false,
      "id_str" : "2432540773",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484801576171622401\/8VNZ8-MR_normal.png",
      "id" : 2432540773,
      "verified" : false
    }
  },
  "id" : 509068527651663872,
  "created_at" : "2014-09-08 19:59:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ErykahBadoula",
      "screen_name" : "fatbellybella",
      "indices" : [ 0, 14 ],
      "id_str" : "18278629",
      "id" : 18278629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508885696732758016",
  "geo" : { },
  "id_str" : "508891487942082560",
  "in_reply_to_user_id" : 18278629,
  "text" : "@fatbellybella  kewl send me an uber pls, im listenin to Black Is The Color of My True Love's Hair on repeat rn",
  "id" : 508891487942082560,
  "in_reply_to_status_id" : 508885696732758016,
  "created_at" : "2014-09-08 08:16:00 +0000",
  "in_reply_to_screen_name" : "fatbellybella",
  "in_reply_to_user_id_str" : "18278629",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508890993018404864",
  "text" : "new life goal unlocked:  perform one show for every band name i got",
  "id" : 508890993018404864,
  "created_at" : "2014-09-08 08:14:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Todd",
      "screen_name" : "petertoddbtc",
      "indices" : [ 0, 13 ],
      "id_str" : "1471313300",
      "id" : 1471313300
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508846110048153603",
  "geo" : { },
  "id_str" : "508848801868550145",
  "in_reply_to_user_id" : 1471313300,
  "text" : "@petertoddbtc IMHO one coin is no bazaar.  But so if a single transport coin is needed for tx validation, viacoin ftw.",
  "id" : 508848801868550145,
  "in_reply_to_status_id" : 508846110048153603,
  "created_at" : "2014-09-08 05:26:22 +0000",
  "in_reply_to_screen_name" : "petertoddbtc",
  "in_reply_to_user_id_str" : "1471313300",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peter Todd",
      "screen_name" : "petertoddbtc",
      "indices" : [ 0, 13 ],
      "id_str" : "1471313300",
      "id" : 1471313300
    }, {
      "name" : "OpenBazaar",
      "screen_name" : "openbazaar",
      "indices" : [ 14, 25 ],
      "id_str" : "2516688952",
      "id" : 2516688952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508818667358810112",
  "geo" : { },
  "id_str" : "508841957678796800",
  "in_reply_to_user_id" : 1471313300,
  "text" : "@petertoddbtc @openbazaar and you'd use VIACOIN am i right?",
  "id" : 508841957678796800,
  "in_reply_to_status_id" : 508818667358810112,
  "created_at" : "2014-09-08 04:59:11 +0000",
  "in_reply_to_screen_name" : "petertoddbtc",
  "in_reply_to_user_id_str" : "1471313300",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 27 ],
      "url" : "https:\/\/t.co\/Ar1fMFPbKy",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=g6DIcgH32Xc",
      "display_url" : "youtube.com\/watch?v=g6DIcg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508840659529113600",
  "text" : "lol https:\/\/t.co\/Ar1fMFPbKy",
  "id" : 508840659529113600,
  "created_at" : "2014-09-08 04:54:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508696799666659330",
  "text" : "u have to inspire me or else nah",
  "id" : 508696799666659330,
  "created_at" : "2014-09-07 19:22:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508669801120546816",
  "text" : "aint it a shame to shoot rats on sunday\naint it a shame\nits a rat shootin shame\naint it a shame\nits a rat shootin shame",
  "id" : 508669801120546816,
  "created_at" : "2014-09-07 17:35:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508650293257453568",
  "text" : "ring dum ding dong bells",
  "id" : 508650293257453568,
  "created_at" : "2014-09-07 16:17:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508650237297053696",
  "text" : "ring dem ding dong bells",
  "id" : 508650237297053696,
  "created_at" : "2014-09-07 16:17:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508458716664848384",
  "geo" : { },
  "id_str" : "508461091572035584",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \nCHEW SLOWLY MY FRIENDS",
  "id" : 508461091572035584,
  "in_reply_to_status_id" : 508458716664848384,
  "created_at" : "2014-09-07 03:45:45 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508458716664848384",
  "text" : "i can get about 9 kilohashes \/ second on a $5 slice in shanghai, hold the ketchup, extra mustard",
  "id" : 508458716664848384,
  "created_at" : "2014-09-07 03:36:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508444605625282560",
  "text" : "IF U MARKET COIN\n\nTHEY WILL COME\n\n$JBS",
  "id" : 508444605625282560,
  "created_at" : "2014-09-07 02:40:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508438854374653952",
  "text" : "seriously considering bldg a music service the runs SCRYPT algos 4 mining pools while u listen to pay artists\n\nnow whatcha think about that",
  "id" : 508438854374653952,
  "created_at" : "2014-09-07 02:17:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508438136037203968",
  "text" : "i will always take stairs two or more at a time, and I will always try to beat the txt auto finish prediction MUTHAFUCKAS",
  "id" : 508438136037203968,
  "created_at" : "2014-09-07 02:14:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508437577771122688",
  "text" : "npm search motoman erc controller",
  "id" : 508437577771122688,
  "created_at" : "2014-09-07 02:12:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 0, 9 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/RwYtufGSpx",
      "expanded_url" : "http:\/\/spaz.org\/~jake\/robot\/479236-17-Communications.pdf",
      "display_url" : "spaz.org\/~jake\/robot\/47\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508437471231619073",
  "in_reply_to_user_id" : 411733308,
  "text" : "@sudoroom got a MOTOMAN http:\/\/t.co\/RwYtufGSpx\n\nI propose it be named Moto Jakson",
  "id" : 508437471231619073,
  "created_at" : "2014-09-07 02:11:54 +0000",
  "in_reply_to_screen_name" : "sudoroom",
  "in_reply_to_user_id_str" : "411733308",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/aWd68wribD",
      "expanded_url" : "http:\/\/altcoinpress.com\/2014\/09\/fbi-reveals-exactly-how-they-hacked-silk-road\/",
      "display_url" : "altcoinpress.com\/2014\/09\/fbi-re\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508373218755739648",
  "text" : "the silk road servers were revealed by plain use of google captchas, more at http:\/\/t.co\/aWd68wribD",
  "id" : 508373218755739648,
  "created_at" : "2014-09-06 21:56:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "King\u0E3FTC",
      "screen_name" : "kingbtc",
      "indices" : [ 0, 8 ],
      "id_str" : "2384463408",
      "id" : 2384463408
    }, {
      "name" : "\u0E3FtcDrak",
      "screen_name" : "btcdrak",
      "indices" : [ 9, 17 ],
      "id_str" : "1387081490",
      "id" : 1387081490
    }, {
      "name" : "Royce M.",
      "screen_name" : "RoyceMCutcheon",
      "indices" : [ 18, 33 ],
      "id_str" : "87730814",
      "id" : 87730814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "508357201564811264",
  "geo" : { },
  "id_str" : "508372573957001216",
  "in_reply_to_user_id" : 2384463408,
  "text" : "@kingbtc @btcdrak @RoyceMCutcheon  hahaha captcha",
  "id" : 508372573957001216,
  "in_reply_to_status_id" : 508357201564811264,
  "created_at" : "2014-09-06 21:54:01 +0000",
  "in_reply_to_screen_name" : "kingbtc",
  "in_reply_to_user_id_str" : "2384463408",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Drake",
      "screen_name" : "kyledrake",
      "indices" : [ 0, 10 ],
      "id_str" : "7171612",
      "id" : 7171612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 95 ],
      "url" : "https:\/\/t.co\/UYDO00UZPB",
      "expanded_url" : "https:\/\/github.com\/bitcoinjs\/bitcoinjs-lib\/blob\/master\/src\/networks.js",
      "display_url" : "github.com\/bitcoinjs\/bitc\u2026"
    }, {
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/XBpPbAN45G",
      "expanded_url" : "https:\/\/github.com\/viacoin\/viacoin\/blob\/0.10\/src\/chainparams.cpp#L34",
      "display_url" : "github.com\/viacoin\/viacoi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "508298955147329536",
  "in_reply_to_user_id" : 7171612,
  "text" : "@kyledrake request for assistance adding another coin to bitcoinjs-lib\n\nhttps:\/\/t.co\/UYDO00UZPB\n\nnamely https:\/\/t.co\/XBpPbAN45G",
  "id" : 508298955147329536,
  "created_at" : "2014-09-06 17:01:29 +0000",
  "in_reply_to_screen_name" : "kyledrake",
  "in_reply_to_user_id_str" : "7171612",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "508286242186735616",
  "text" : "STACKVM CREW REPRESENT",
  "id" : 508286242186735616,
  "created_at" : "2014-09-06 16:10:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/pEg81E0bwH",
      "expanded_url" : "http:\/\/filecoin.io\/filecoin.pdf",
      "display_url" : "filecoin.io\/filecoin.pdf"
    } ]
  },
  "geo" : { },
  "id_str" : "508114265912246272",
  "text" : "I CANT READ THIS http:\/\/t.co\/pEg81E0bwH",
  "id" : 508114265912246272,
  "created_at" : "2014-09-06 04:47:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507967773582962688",
  "text" : "WHY SO MUCH PAIN?",
  "id" : 507967773582962688,
  "created_at" : "2014-09-05 19:05:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507714285074534400",
  "text" : "call that an early brainer",
  "id" : 507714285074534400,
  "created_at" : "2014-09-05 02:18:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507481785098592256",
  "text" : "Networks and Interfaces, they are both I\/O.\n\nData is data.\n\nThat is what we do.",
  "id" : 507481785098592256,
  "created_at" : "2014-09-04 10:54:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "507371918500978688",
  "text" : "is there a canadian out there?  i would like to register coinse.ca but I need you to do it.",
  "id" : 507371918500978688,
  "created_at" : "2014-09-04 03:37:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VIACOIN",
      "indices" : [ 19, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506854629334712321",
  "text" : "SET MY RIG TO MINE #VIACOIN",
  "id" : 506854629334712321,
  "created_at" : "2014-09-02 17:22:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506844106824220673",
  "text" : "fuck u if u never been broke a dozen hundred time",
  "id" : 506844106824220673,
  "created_at" : "2014-09-02 16:40:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506836248661467136",
  "text" : "one of those day when i cant spell peice and me wants to break everything",
  "id" : 506836248661467136,
  "created_at" : "2014-09-02 16:09:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506607739385421826",
  "text" : "HOW U GIT YR PHONE OUTCH YR SELFIES WAY???",
  "id" : 506607739385421826,
  "created_at" : "2014-09-02 01:01:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506508783128817665",
  "text" : "WHAT IS THE WEIGHT OF BALANCE?",
  "id" : 506508783128817665,
  "created_at" : "2014-09-01 18:27:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dogecoin on Reddit",
      "screen_name" : "RedditDogecoin",
      "indices" : [ 0, 15 ],
      "id_str" : "2334001867",
      "id" : 2334001867
    }, {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "indices" : [ 16, 29 ],
      "id_str" : "2652920774",
      "id" : 2652920774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506450654857273344",
  "geo" : { },
  "id_str" : "506508156915044352",
  "in_reply_to_user_id" : 2334001867,
  "text" : "@RedditDogecoin @theDogeparty \n\nBURN SOME DOGE FOR OUR FALLEN DOGERADES",
  "id" : 506508156915044352,
  "in_reply_to_status_id" : 506450654857273344,
  "created_at" : "2014-09-01 18:25:29 +0000",
  "in_reply_to_screen_name" : "RedditDogecoin",
  "in_reply_to_user_id_str" : "2334001867",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506507755159420930",
  "text" : "my clock def drifted",
  "id" : 506507755159420930,
  "created_at" : "2014-09-01 18:23:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506505672503349251",
  "text" : "static if ( clause ) \u007B\n  \/\/  put your static evaluated\n  \/\/  if shit in here\n\u007D",
  "id" : 506505672503349251,
  "created_at" : "2014-09-01 18:15:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/uBRmgOm7Mh",
      "expanded_url" : "https:\/\/gist.github.com\/NHQ\/7b3e74966a48c353a490",
      "display_url" : "gist.github.com\/NHQ\/7b3e74966a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506469961070415872",
  "text" : "trick:  if u write a proxy for your callbacks, then you can engage your callbacks galore-iously.\n\nhttps:\/\/t.co\/uBRmgOm7Mh",
  "id" : 506469961070415872,
  "created_at" : "2014-09-01 15:53:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506469669721481216",
  "text" : "monkeypatching your dumb api wrapper",
  "id" : 506469669721481216,
  "created_at" : "2014-09-01 15:52:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506462918582341632",
  "text" : "AMERICA USA BRAND AMERICA FOREVER THE WIN!!!",
  "id" : 506462918582341632,
  "created_at" : "2014-09-01 15:25:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506462357858832384",
  "text" : "HAPPY SEMI-ANNUAL 3-DAY WEEKEND AMERICA USA!!!",
  "id" : 506462357858832384,
  "created_at" : "2014-09-01 15:23:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Ross",
      "screen_name" : "jebus911",
      "indices" : [ 0, 9 ],
      "id_str" : "162573283",
      "id" : 162573283
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506460668992565249",
  "geo" : { },
  "id_str" : "506462103751118848",
  "in_reply_to_user_id" : 162573283,
  "text" : "@jebus911  This is well said of many failure \/ success scenario.",
  "id" : 506462103751118848,
  "in_reply_to_status_id" : 506460668992565249,
  "created_at" : "2014-09-01 15:22:29 +0000",
  "in_reply_to_screen_name" : "jebus911",
  "in_reply_to_user_id_str" : "162573283",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bittrex",
      "screen_name" : "BittrexExchange",
      "indices" : [ 0, 16 ],
      "id_str" : "2309637680",
      "id" : 2309637680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506442843473186816",
  "geo" : { },
  "id_str" : "506445388937588736",
  "in_reply_to_user_id" : 46961216,
  "text" : "@BittrexExchange ok my bad  I didn't see withdrawl email verification.  2fa still a bust tho",
  "id" : 506445388937588736,
  "in_reply_to_status_id" : 506442843473186816,
  "created_at" : "2014-09-01 14:16:04 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bittrex",
      "screen_name" : "BittrexExchange",
      "indices" : [ 0, 16 ],
      "id_str" : "2309637680",
      "id" : 2309637680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506441708033159168",
  "geo" : { },
  "id_str" : "506442843473186816",
  "in_reply_to_user_id" : 46961216,
  "text" : "@BittrexExchange  and my VIA withdrawl is pending 4ever",
  "id" : 506442843473186816,
  "in_reply_to_status_id" : 506441708033159168,
  "created_at" : "2014-09-01 14:05:57 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bittrex",
      "screen_name" : "BittrexExchange",
      "indices" : [ 0, 16 ],
      "id_str" : "2309637680",
      "id" : 2309637680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506441708033159168",
  "in_reply_to_user_id" : 2309637680,
  "text" : "@BittrexExchange hi i am experiencing 2fa fail",
  "id" : 506441708033159168,
  "created_at" : "2014-09-01 14:01:27 +0000",
  "in_reply_to_screen_name" : "BittrexExchange",
  "in_reply_to_user_id_str" : "2309637680",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506399676443029504",
  "text" : "pussies, jus sell the bitcoins like ice cream",
  "id" : 506399676443029504,
  "created_at" : "2014-09-01 11:14:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506399353318031360",
  "text" : "cryptoccoins are not considered currency, so why do we have all this stupid procedure for buying them with USD?",
  "id" : 506399353318031360,
  "created_at" : "2014-09-01 11:13:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]