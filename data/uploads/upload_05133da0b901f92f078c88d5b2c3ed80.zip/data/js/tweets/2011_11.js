Grailbird.data.tweets_2011_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 3, 7 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/czBbrD8L",
      "expanded_url" : "http:\/\/arstechnica.com\/tech-policy\/news\/2011\/11\/us-judge-orders-hundreds-of-sites-de-indexed-from-google-twitter-bing-facebook.ars",
      "display_url" : "arstechnica.com\/tech-policy\/ne\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "141688307213017088",
  "text" : "RT @izs: We are already living under draconian censored fascism! Stand up against SOPA and ProtectIP if you love America. http:\/\/t.co\/cz ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/czBbrD8L",
        "expanded_url" : "http:\/\/arstechnica.com\/tech-policy\/news\/2011\/11\/us-judge-orders-hundreds-of-sites-de-indexed-from-google-twitter-bing-facebook.ars",
        "display_url" : "arstechnica.com\/tech-policy\/ne\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "141660335722606592",
    "text" : "We are already living under draconian censored fascism! Stand up against SOPA and ProtectIP if you love America. http:\/\/t.co\/czBbrD8L",
    "id" : 141660335722606592,
    "created_at" : "2011-11-29 23:30:30 +0000",
    "user" : {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "protected" : false,
      "id_str" : "8038312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/542222668691283968\/ngdJgyqs_normal.png",
      "id" : 8038312,
      "verified" : false
    }
  },
  "id" : 141688307213017088,
  "created_at" : "2011-11-30 01:21:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brendon Smith",
      "screen_name" : "seacloud9",
      "indices" : [ 0, 10 ],
      "id_str" : "14421804",
      "id" : 14421804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/Gicdbyj2",
      "expanded_url" : "http:\/\/iacopoapps.appspot.com\/hopalongwebgl",
      "display_url" : "iacopoapps.appspot.com\/hopalongwebgl"
    } ]
  },
  "geo" : { },
  "id_str" : "139508582952603648",
  "in_reply_to_user_id" : 14421804,
  "text" : "@seacloud9 I played a game as a kid where I traveled thru fractal portals inside my eyelids. It looked just like this http:\/\/t.co\/Gicdbyj2",
  "id" : 139508582952603648,
  "created_at" : "2011-11-24 01:00:12 +0000",
  "in_reply_to_screen_name" : "seacloud9",
  "in_reply_to_user_id_str" : "14421804",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ricardo Cabello",
      "screen_name" : "mrdoob",
      "indices" : [ 43, 50 ],
      "id_str" : "20733754",
      "id" : 20733754
    }, {
      "name" : "Brendon Smith",
      "screen_name" : "seacloud9",
      "indices" : [ 89, 99 ],
      "id_str" : "14421804",
      "id" : 14421804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/Gicdbyj2",
      "expanded_url" : "http:\/\/iacopoapps.appspot.com\/hopalongwebgl",
      "display_url" : "iacopoapps.appspot.com\/hopalongwebgl"
    } ]
  },
  "geo" : { },
  "id_str" : "139507653100580864",
  "text" : "Paging Dr. Mandelbrot http:\/\/t.co\/Gicdbyj2 @mrdoob I could stare at this for hours! \/via @seacloud9",
  "id" : 139507653100580864,
  "created_at" : "2011-11-24 00:56:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Irish",
      "screen_name" : "paul_irish",
      "indices" : [ 0, 11 ],
      "id_str" : "1671811",
      "id" : 1671811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139125977384095744",
  "geo" : { },
  "id_str" : "139501325070254082",
  "in_reply_to_user_id" : 1671811,
  "text" : "@paul_irish \njQuery does not respect the un-ended p tag. \nvar qv = '&lt;p id=\u2665&gt;Text'; \n$(qv).html() == \"\"",
  "id" : 139501325070254082,
  "in_reply_to_status_id" : 139125977384095744,
  "created_at" : "2011-11-24 00:31:22 +0000",
  "in_reply_to_screen_name" : "paul_irish",
  "in_reply_to_user_id_str" : "1671811",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 3, 14 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139486167354720256",
  "geo" : { },
  "id_str" : "139492293865517056",
  "in_reply_to_user_id" : 181328570,
  "text" : "if @grayamelia coughs in her closet quarters and tweets the report do you believe every word?",
  "id" : 139492293865517056,
  "in_reply_to_status_id" : 139486167354720256,
  "created_at" : "2011-11-23 23:55:29 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 18, 29 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "139480221190586368",
  "geo" : { },
  "id_str" : "139485765703966720",
  "in_reply_to_user_id" : 181328570,
  "text" : "cough cough kafka @grayamelia",
  "id" : 139485765703966720,
  "in_reply_to_status_id" : 139480221190586368,
  "created_at" : "2011-11-23 23:29:32 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 106, 113 ]
    }, {
      "text" : "javascript",
      "indices" : [ 114, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/14YndSN0",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Java_Man",
      "display_url" : "en.wikipedia.org\/wiki\/Java_Man"
    } ]
  },
  "geo" : { },
  "id_str" : "139130549464858626",
  "text" : "I like to believe the name Javascript refers to the ancient language of the Java Man http:\/\/t.co\/14YndSN0 #nodejs #javascript",
  "id" : 139130549464858626,
  "created_at" : "2011-11-22 23:58:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Irish",
      "screen_name" : "paul_irish",
      "indices" : [ 0, 11 ],
      "id_str" : "1671811",
      "id" : 1671811
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/S6NhtKC6",
      "expanded_url" : "http:\/\/paulirish.com\/2011\/primitives-html5-video\/",
      "display_url" : "paulirish.com\/2011\/primitive\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "139121482411425792",
  "in_reply_to_user_id" : 1671811,
  "text" : "@paul_irish quotation free attributes? An effin revelation! Esp. nice if you write alotta html strings in javascript http:\/\/t.co\/S6NhtKC6",
  "id" : 139121482411425792,
  "created_at" : "2011-11-22 23:22:00 +0000",
  "in_reply_to_screen_name" : "paul_irish",
  "in_reply_to_user_id_str" : "1671811",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/XPzgjOiu",
      "expanded_url" : "http:\/\/item.rakuten.co.jp\/icefield\/10013369\/",
      "display_url" : "item.rakuten.co.jp\/icefield\/10013\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "138716956923658240",
  "text" : "playground tactics! krazy trick master HTML http:\/\/t.co\/XPzgjOiu",
  "id" : 138716956923658240,
  "created_at" : "2011-11-21 20:34:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/rs4SDObA",
      "expanded_url" : "http:\/\/item.rakuten.co.jp\/icefield\/10015782\/",
      "display_url" : "item.rakuten.co.jp\/icefield\/10015\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "138715830144872449",
  "text" : "world  standard HTML p@intopia http:\/\/t.co\/rs4SDObA",
  "id" : 138715830144872449,
  "created_at" : "2011-11-21 20:30:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4thVoice",
      "screen_name" : "4thVoice",
      "indices" : [ 3, 12 ],
      "id_str" : "80131045",
      "id" : 80131045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138709653008818176",
  "text" : "RT @4thVoice: Koch Industries, 300 million tons of CO2 annually. Immense profitability on oil relies on freedom to pollute w\/o consequen ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "138708610120298496",
    "text" : "Koch Industries, 300 million tons of CO2 annually. Immense profitability on oil relies on freedom to pollute w\/o consequence at US expense",
    "id" : 138708610120298496,
    "created_at" : "2011-11-21 20:01:24 +0000",
    "user" : {
      "name" : "4thVoice",
      "screen_name" : "4thVoice",
      "protected" : false,
      "id_str" : "80131045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1117499932\/thumbnail_normal.jpg",
      "id" : 80131045,
      "verified" : false
    }
  },
  "id" : 138709653008818176,
  "created_at" : "2011-11-21 20:05:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Demand Progress",
      "screen_name" : "demandprogress",
      "indices" : [ 0, 15 ],
      "id_str" : "188809568",
      "id" : 188809568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "badform",
      "indices" : [ 80, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "138707067249770496",
  "in_reply_to_user_id" : 188809568,
  "text" : "@demandprogress don't automatically subscribe petition signers to ur email list #badform",
  "id" : 138707067249770496,
  "created_at" : "2011-11-21 19:55:16 +0000",
  "in_reply_to_screen_name" : "demandprogress",
  "in_reply_to_user_id_str" : "188809568",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Demand Progress",
      "screen_name" : "demandprogress",
      "indices" : [ 119, 134 ],
      "id_str" : "188809568",
      "id" : 188809568
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "StopCensorship",
      "indices" : [ 40, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/8NgE8FjB",
      "expanded_url" : "http:\/\/act.demandprogress.org\/act\/stop_censorship\/?referring_akid=.1473673.L3kS58&source=typ-tw",
      "display_url" : "act.demandprogress.org\/act\/stop_censo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "138701237800542209",
  "text" : "croowdbust congress with wikifilibuster #StopCensorship: Stand as one to block Internet bill- http:\/\/t.co\/8NgE8FjB via @demandprogress",
  "id" : 138701237800542209,
  "created_at" : "2011-11-21 19:32:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/51KkEhQ3",
      "expanded_url" : "http:\/\/www.nlp-class.org\/",
      "display_url" : "nlp-class.org"
    } ]
  },
  "geo" : { },
  "id_str" : "138092740272586753",
  "text" : "I'm attending Standford now. Stick yr pinkies in the ayer. Natural Language Processing online, free http:\/\/t.co\/51KkEhQ3",
  "id" : 138092740272586753,
  "created_at" : "2011-11-20 03:14:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Miguel Bloombito",
      "screen_name" : "ElBloombito",
      "indices" : [ 3, 15 ],
      "id_str" : "363450850",
      "id" : 363450850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137328666467254272",
  "text" : "RT @ElBloombito: Los billionairos! U\u00F1itedo! Will nevero be inco\u00F1venienced!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137305480925163523",
    "text" : "Los billionairos! U\u00F1itedo! Will nevero be inco\u00F1venienced!",
    "id" : 137305480925163523,
    "created_at" : "2011-11-17 23:05:52 +0000",
    "user" : {
      "name" : "Miguel Bloombito",
      "screen_name" : "ElBloombito",
      "protected" : false,
      "id_str" : "363450850",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1516815900\/bloombergmichael_roc4life_normal.jpeg",
      "id" : 363450850,
      "verified" : false
    }
  },
  "id" : 137328666467254272,
  "created_at" : "2011-11-18 00:38:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "4thVoice",
      "screen_name" : "4thVoice",
      "indices" : [ 3, 12 ],
      "id_str" : "80131045",
      "id" : 80131045
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OWS",
      "indices" : [ 42, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137327722895654912",
  "text" : "RT @4thVoice: Any mass media not covering #OWS now is obviously suppressing it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OWS",
        "indices" : [ 28, 32 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "137320542066847744",
    "text" : "Any mass media not covering #OWS now is obviously suppressing it.",
    "id" : 137320542066847744,
    "created_at" : "2011-11-18 00:05:43 +0000",
    "user" : {
      "name" : "4thVoice",
      "screen_name" : "4thVoice",
      "protected" : false,
      "id_str" : "80131045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1117499932\/thumbnail_normal.jpg",
      "id" : 80131045,
      "verified" : false
    }
  },
  "id" : 137327722895654912,
  "created_at" : "2011-11-18 00:34:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "137305054532210689",
  "text" : "I cast a spell on you, Computers.",
  "id" : 137305054532210689,
  "created_at" : "2011-11-17 23:04:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Queen Zhalli  \u2730\u2661*\u2022\u02DB\u2764",
      "screen_name" : "zhalli1",
      "indices" : [ 3, 11 ],
      "id_str" : "242299173",
      "id" : 242299173
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RichardReich",
      "indices" : [ 90, 103 ]
    }, {
      "text" : "OccupyLA",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "133680748128514049",
  "text" : "RT @zhalli1: I will believe Corps r PPL when Georgia & Texas start executing Corporations #RichardReich #OccupyLA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RichardReich",
        "indices" : [ 77, 90 ]
      }, {
        "text" : "OccupyLA",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "133678822506758144",
    "text" : "I will believe Corps r PPL when Georgia & Texas start executing Corporations #RichardReich #OccupyLA",
    "id" : 133678822506758144,
    "created_at" : "2011-11-07 22:54:49 +0000",
    "user" : {
      "name" : "Queen Zhalli  \u2730\u2661*\u2022\u02DB\u2764",
      "screen_name" : "zhalli1",
      "protected" : false,
      "id_str" : "242299173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/537188757095469056\/oEICeGeH_normal.png",
      "id" : 242299173,
      "verified" : false
    }
  },
  "id" : 133680748128514049,
  "created_at" : "2011-11-07 23:02:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/klvxX7hX",
      "expanded_url" : "http:\/\/www.smartplanet.com\/blog\/science-scope\/video-two-legged-robot-can-do-push-ups-and-sweat\/11087?t=1320218836",
      "display_url" : "smartplanet.com\/blog\/science-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "132230424272445440",
  "text" : "from the organization that brought you the internet (DARPA) http:\/\/t.co\/klvxX7hX",
  "id" : 132230424272445440,
  "created_at" : "2011-11-03 22:59:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/H4RhvXJX",
      "expanded_url" : "http:\/\/www.currantcat.com\/convergence\/",
      "display_url" : "currantcat.com\/convergence\/"
    } ]
  },
  "geo" : { },
  "id_str" : "132183252382396418",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin :^* http:\/\/t.co\/H4RhvXJX",
  "id" : 132183252382396418,
  "created_at" : "2011-11-03 19:51:57 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupy",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "ows",
      "indices" : [ 82, 86 ]
    }, {
      "text" : "occupyoakland",
      "indices" : [ 87, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/7PgJPmF2",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ExP0BPf3gLI",
      "display_url" : "youtube.com\/watch?v=ExP0BP\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "132179143956774913",
  "text" : "this doesn't have enough views Occupy vs. The Empire http:\/\/t.co\/7PgJPmF2 #occupy #ows #occupyoakland",
  "id" : 132179143956774913,
  "created_at" : "2011-11-03 19:35:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131902546573934592",
  "geo" : { },
  "id_str" : "131903187576827904",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin still @ work?",
  "id" : 131903187576827904,
  "in_reply_to_status_id" : 131902546573934592,
  "created_at" : "2011-11-03 01:19:05 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131880330142560257",
  "geo" : { },
  "id_str" : "131902441561145344",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin WHAT THAT IS",
  "id" : 131902441561145344,
  "in_reply_to_status_id" : 131880330142560257,
  "created_at" : "2011-11-03 01:16:07 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131880192124796929",
  "text" : "dada mining",
  "id" : 131880192124796929,
  "created_at" : "2011-11-02 23:47:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "J\u039BCK\u039BL",
      "screen_name" : "JackalAnon",
      "indices" : [ 3, 14 ],
      "id_str" : "363357451",
      "id" : 363357451
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131822526555889664",
  "text" : "RT @JackalAnon: Gas mask and filters $56. PantBall vest $35. Black heavy carpenter gloves $12. Being able to smile while being attacked  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "131813053586096128",
    "text" : "Gas mask and filters $56. PantBall vest $35. Black heavy carpenter gloves $12. Being able to smile while being attacked by cops. Priceless.",
    "id" : 131813053586096128,
    "created_at" : "2011-11-02 19:20:55 +0000",
    "user" : {
      "name" : "J\u039BCK\u039BL",
      "screen_name" : "JackalAnon",
      "protected" : false,
      "id_str" : "363357451",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2546620542\/jgal70d4hadklx6pnfq8_normal.jpeg",
      "id" : 363357451,
      "verified" : false
    }
  },
  "id" : 131822526555889664,
  "created_at" : "2011-11-02 19:58:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rapha\u00EBl",
      "screen_name" : "RaphaelJS",
      "indices" : [ 0, 10 ],
      "id_str" : "17180567",
      "id" : 17180567
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sadness",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131527645274968064",
  "in_reply_to_user_id" : 17180567,
  "text" : "@RaphaelJS g.raphael examples not rendering in FF, chrome, Safari - call stack exceeded, etc. #sadness",
  "id" : 131527645274968064,
  "created_at" : "2011-11-02 00:26:48 +0000",
  "in_reply_to_screen_name" : "RaphaelJS",
  "in_reply_to_user_id_str" : "17180567",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlie Robbins",
      "screen_name" : "indexzero",
      "indices" : [ 6, 16 ],
      "id_str" : "13696102",
      "id" : 13696102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 35, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131187018582593536",
  "text" : "HELP! @indexzero running forever 4 #nodejs started app, can't stop it! forever list says no processes, but it revives it after top-kill !!!",
  "id" : 131187018582593536,
  "created_at" : "2011-11-01 01:53:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]