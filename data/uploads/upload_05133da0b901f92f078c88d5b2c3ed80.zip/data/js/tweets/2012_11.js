Grailbird.data.tweets_2012_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/FJbLsYlk",
      "expanded_url" : "http:\/\/www.nytimes.com\/2012\/11\/30\/world\/asia\/cultivating-vultures-to-restore-a-mumbai-ritual.html?hp&_r=0",
      "display_url" : "nytimes.com\/2012\/11\/30\/wor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "274453588837806080",
  "text" : "if vultures die from diclofenac poisoning after eating Parsi corpses the government has promised to end the effort http:\/\/t.co\/FJbLsYlk",
  "id" : 274453588837806080,
  "created_at" : "2012-11-30 10:03:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274433703780970496",
  "text" : "RT @IAM_SHAKESPEARE: DUMAIN. In reason nothing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "274417484952637440",
    "text" : "DUMAIN. In reason nothing.",
    "id" : 274417484952637440,
    "created_at" : "2012-11-30 07:40:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 274433703780970496,
  "created_at" : "2012-11-30 08:44:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 19, 23 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LOL",
      "indices" : [ 24, 28 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "274246681405579264",
  "geo" : { },
  "id_str" : "274247807244857345",
  "in_reply_to_user_id" : 8038312,
  "text" : "HAUWOOOO! HAUWOOO! @izs #LOL",
  "id" : 274247807244857345,
  "in_reply_to_status_id" : 274246681405579264,
  "created_at" : "2012-11-29 20:25:47 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274246257294331904",
  "text" : "She likes being singed too \/\/ Coco, Coco",
  "id" : 274246257294331904,
  "created_at" : "2012-11-29 20:19:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "274027678204563458",
  "text" : "BIOLOGICAL! SELL LOGICAL!!",
  "id" : 274027678204563458,
  "created_at" : "2012-11-29 05:51:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 11, 23 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/7VpZS0sU",
      "expanded_url" : "http:\/\/events.ccc.de\/2012\/11\/03\/ticket-sale-has-opened\/",
      "display_url" : "events.ccc.de\/2012\/11\/03\/tic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "273665884734779393",
  "text" : "I nominate @dominictarr to represent at the Chaos Communication Congress http:\/\/t.co\/7VpZS0sU (dates???)",
  "id" : 273665884734779393,
  "created_at" : "2012-11-28 05:53:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hij1nx",
      "screen_name" : "hij1nx",
      "indices" : [ 0, 7 ],
      "id_str" : "95938827",
      "id" : 95938827
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 8, 20 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271164141727776768",
  "geo" : { },
  "id_str" : "271195286553108480",
  "in_reply_to_user_id" : 95938827,
  "text" : "@hij1nx @dominictarr and nevermore consistent",
  "id" : 271195286553108480,
  "in_reply_to_status_id" : 271164141727776768,
  "created_at" : "2012-11-21 10:16:09 +0000",
  "in_reply_to_screen_name" : "hij1nx",
  "in_reply_to_user_id_str" : "95938827",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 0, 12 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 13, 25 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "hij1nx",
      "screen_name" : "hij1nx",
      "indices" : [ 26, 33 ],
      "id_str" : "95938827",
      "id" : 95938827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271163571675742208",
  "geo" : { },
  "id_str" : "271164043715297280",
  "in_reply_to_user_id" : 46961216,
  "text" : "@astromanies @dominictarr @hij1nx and that's according to old information i have",
  "id" : 271164043715297280,
  "in_reply_to_status_id" : 271163571675742208,
  "created_at" : "2012-11-21 08:12:00 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "hij1nx",
      "screen_name" : "hij1nx",
      "indices" : [ 13, 20 ],
      "id_str" : "95938827",
      "id" : 95938827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "271160897144250369",
  "geo" : { },
  "id_str" : "271163571675742208",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @hij1nx you may want to amend your statement in light of the fact that \"is the new black\" is the new \"5 years ago\"",
  "id" : 271163571675742208,
  "in_reply_to_status_id" : 271160897144250369,
  "created_at" : "2012-11-21 08:10:08 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "271162263459725312",
  "text" : "How many my threads were you blocking with that bull shit complaint softy?",
  "id" : 271162263459725312,
  "created_at" : "2012-11-21 08:04:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/YDdVwOUl",
      "expanded_url" : "http:\/\/neighborhoodguard.org\/",
      "display_url" : "neighborhoodguard.org"
    } ]
  },
  "geo" : { },
  "id_str" : "270678101464346624",
  "text" : "Oakland Neighborhood Guard wants to build mesh of community run video cameras to use against crime http:\/\/t.co\/YDdVwOUl",
  "id" : 270678101464346624,
  "created_at" : "2012-11-20 00:01:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268972435100033024",
  "text" : "Don't let the GUI use you. Use slow and use loud.",
  "id" : 268972435100033024,
  "created_at" : "2012-11-15 07:03:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "268950837936656384",
  "text" : "RT @IAM_SHAKESPEARE: I and my hundred knights.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "268946436870246400",
    "text" : "I and my hundred knights.",
    "id" : 268946436870246400,
    "created_at" : "2012-11-15 05:20:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 268950837936656384,
  "created_at" : "2012-11-15 05:37:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vivaradio",
      "screen_name" : "vivaradio",
      "indices" : [ 0, 10 ],
      "id_str" : "17543835",
      "id" : 17543835
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "268519143869923330",
  "geo" : { },
  "id_str" : "268590456785481729",
  "in_reply_to_user_id" : 17543835,
  "text" : "@vivaradio TURN THE B UPSIDE DOWN",
  "id" : 268590456785481729,
  "in_reply_to_status_id" : 268519143869923330,
  "created_at" : "2012-11-14 05:45:29 +0000",
  "in_reply_to_screen_name" : "vivaradio",
  "in_reply_to_user_id_str" : "17543835",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/H1MrypXF",
      "expanded_url" : "http:\/\/www.nationalmemo.com\/final-results-obama-wins-popular-vote-by-3-percent\/",
      "display_url" : "nationalmemo.com\/final-results-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "268190640817446912",
  "text" : "Gerrymandering keeps GOP in control of House of Reps by a large margin (233-194), tho they lost the popular vote. http:\/\/t.co\/H1MrypXF",
  "id" : 268190640817446912,
  "created_at" : "2012-11-13 03:16:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "267734263477174272",
  "text" : "git commie, git vommit",
  "id" : 267734263477174272,
  "created_at" : "2012-11-11 21:03:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 33 ],
      "url" : "http:\/\/t.co\/H95v6qQ3",
      "expanded_url" : "http:\/\/dfm.org",
      "display_url" : "dfm.org"
    }, {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/pXWTvRRg",
      "expanded_url" : "http:\/\/github.com\/substack\/tuner",
      "display_url" : "github.com\/substack\/tuner"
    } ]
  },
  "geo" : { },
  "id_str" : "266653692252528640",
  "text" : "listening to http:\/\/t.co\/H95v6qQ3 with npm install -g tuner http:\/\/t.co\/pXWTvRRg",
  "id" : 266653692252528640,
  "created_at" : "2012-11-08 21:29:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 8, 24 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265978031535972352",
  "text" : "AH YEAH @IAM_SHAKESPEARE is playing KING LEAR.",
  "id" : 265978031535972352,
  "created_at" : "2012-11-07 00:44:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265976695033581568",
  "text" : "what are these buttons for anyway",
  "id" : 265976695033581568,
  "created_at" : "2012-11-07 00:39:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265976449880702977",
  "text" : "get in line before your polling place closes and you will still be able to vote in the year two thousand twelve",
  "id" : 265976449880702977,
  "created_at" : "2012-11-07 00:38:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265926222566027268",
  "text" : "VOTE YES ON #&amp;",
  "id" : 265926222566027268,
  "created_at" : "2012-11-06 21:18:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265703387042025472",
  "text" : "different molecular relaxation processes",
  "id" : 265703387042025472,
  "created_at" : "2012-11-06 06:33:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/jQIwyXY7",
      "expanded_url" : "http:\/\/cyborganthropology.com\/store\/",
      "display_url" : "cyborganthropology.com\/store\/"
    } ]
  },
  "geo" : { },
  "id_str" : "265667406616227842",
  "text" : "I want this book http:\/\/t.co\/jQIwyXY7",
  "id" : 265667406616227842,
  "created_at" : "2012-11-06 04:10:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265334656264704001",
  "text" : "SPAM OR SPASM",
  "id" : 265334656264704001,
  "created_at" : "2012-11-05 06:08:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/2DOa4ITl",
      "expanded_url" : "http:\/\/www.newscientist.com\/article\/mg21628874.200-destroying-drug-cartels-the-mathematical-way.html",
      "display_url" : "newscientist.com\/article\/mg2162\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265170951623294976",
  "text" : "Network analysis says best way to defeat a cartel is to take out the middle man. http:\/\/t.co\/2DOa4ITl",
  "id" : 265170951623294976,
  "created_at" : "2012-11-04 19:17:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "265161630298550272",
  "text" : "I just wanted to say THANKS JABLONKSI",
  "id" : 265161630298550272,
  "created_at" : "2012-11-04 18:40:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/1RojIUsg",
      "expanded_url" : "http:\/\/www.mikejablonski.org\/2009\/08\/25\/live365-stream-urls\/",
      "display_url" : "mikejablonski.org\/2009\/08\/25\/liv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "265161326551236608",
  "text" : "A bookmark to get live365 station streams for your favorite client. http:\/\/t.co\/1RojIUsg Thanks Jablonksi!",
  "id" : 265161326551236608,
  "created_at" : "2012-11-04 18:39:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264631819029327875",
  "text" : "NEEDS MORE STENTORIAN CHANTS",
  "id" : 264631819029327875,
  "created_at" : "2012-11-03 07:35:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/vnlbL5Gz",
      "expanded_url" : "http:\/\/datashat.net\/music_for_programming_15-dan_adeyemi.mp3",
      "display_url" : "datashat.net\/music_for_prog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "264160317561532417",
  "text" : "\"our work at IBM is directly related to the paperwork explosion.\"  http:\/\/t.co\/vnlbL5Gz",
  "id" : 264160317561532417,
  "created_at" : "2012-11-02 00:21:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264148878721429504",
  "text" : "Vote YES on Banishing Monsanto to the Middle of Hell.",
  "id" : 264148878721429504,
  "created_at" : "2012-11-01 23:36:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "264148165962383361",
  "text" : "Vote YES on 37 for labels on pig gene spliced foods",
  "id" : 264148165962383361,
  "created_at" : "2012-11-01 23:33:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 83 ],
      "url" : "https:\/\/t.co\/izdaQ9m3",
      "expanded_url" : "https:\/\/github.com\/NHQ\/numerical",
      "display_url" : "github.com\/NHQ\/numerical"
    } ]
  },
  "geo" : { },
  "id_str" : "263825855950766080",
  "text" : "prolly be done before, but here is some math for your numbers https:\/\/t.co\/izdaQ9m3 npm install numerical",
  "id" : 263825855950766080,
  "created_at" : "2012-11-01 02:12:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]