Grailbird.data.tweets_2012_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174933176404287488",
  "text" : "answer me damnit",
  "id" : 174933176404287488,
  "created_at" : "2012-02-29 19:04:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174927240272945152",
  "text" : "Was up until 4am last night hacking an font , paragraph and column styling algorithm",
  "id" : 174927240272945152,
  "created_at" : "2012-02-29 18:41:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Shaw",
      "screen_name" : "dshaw",
      "indices" : [ 0, 6 ],
      "id_str" : "806757",
      "id" : 806757
    }, {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 7, 14 ],
      "id_str" : "285766850",
      "id" : 285766850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174905673530880000",
  "geo" : { },
  "id_str" : "174923684040032256",
  "in_reply_to_user_id" : 806757,
  "text" : "@dshaw @NodeUp Interested User",
  "id" : 174923684040032256,
  "in_reply_to_status_id" : 174905673530880000,
  "created_at" : "2012-02-29 18:27:10 +0000",
  "in_reply_to_screen_name" : "dshaw",
  "in_reply_to_user_id_str" : "806757",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal",
      "screen_name" : "mikeal",
      "indices" : [ 96, 103 ],
      "id_str" : "668423",
      "id" : 668423
    }, {
      "name" : "Alex Sexton",
      "screen_name" : "SlexAxton",
      "indices" : [ 104, 114 ],
      "id_str" : "12806822",
      "id" : 12806822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174643688587264001",
  "geo" : { },
  "id_str" : "174646306155933698",
  "in_reply_to_user_id" : 668423,
  "text" : "legible !== decipherable, syntax is hard,  JS syntax !== CS syntax ... but i'm a bad programmar @mikeal @SlexAxton",
  "id" : 174646306155933698,
  "in_reply_to_status_id" : 174643688587264001,
  "created_at" : "2012-02-29 00:04:58 +0000",
  "in_reply_to_screen_name" : "mikeal",
  "in_reply_to_user_id_str" : "668423",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/SJfN0vRC",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=dVGINIsLnqU&feature=relmfu",
      "display_url" : "youtube.com\/watch?v=dVGINI\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174609675814322176",
  "text" : "freedom of choice, it's what you got. freedom from choice, it's what you want. http:\/\/t.co\/SJfN0vRC",
  "id" : 174609675814322176,
  "created_at" : "2012-02-28 21:39:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moveForward",
      "indices" : [ 21, 33 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/LlJIK1ww",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=Xbt30UnzRWw",
      "display_url" : "youtube.com\/watch?v=Xbt30U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174606901034749952",
  "text" : "http:\/\/t.co\/LlJIK1ww #moveForward",
  "id" : 174606901034749952,
  "created_at" : "2012-02-28 21:28:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "realTech",
      "indices" : [ 95, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174604151223889920",
  "text" : "Those who say the keyboard and computer mouse are terribly outmoded, those people are correct. #realTech",
  "id" : 174604151223889920,
  "created_at" : "2012-02-28 21:17:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "174602881205420033",
  "text" : "Has the End button ever worked right on a Mac?",
  "id" : 174602881205420033,
  "created_at" : "2012-02-28 21:12:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ {
      "indices" : [ 11, 32 ],
      "url" : "https:\/\/t.co\/yCZEi75X",
      "expanded_url" : "https:\/\/github.com\/edmellum\/browserijade",
      "display_url" : "github.com\/edmellum\/brows\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174593075702800386",
  "text" : "biggups to https:\/\/t.co\/yCZEi75X for that. Use Jade templates with the latest browserify release. #nodejs",
  "id" : 174593075702800386,
  "created_at" : "2012-02-28 20:33:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/PUGbTjZX",
      "expanded_url" : "http:\/\/www.mozilla.org\/en-US\/collusion\/demo\/",
      "display_url" : "mozilla.org\/en-US\/collusio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174559261144256513",
  "text" : "Mozilla is a browser's best friend. See real-time \"who the fuck is tracking me internet?\" visualizations: http:\/\/t.co\/PUGbTjZX",
  "id" : 174559261144256513,
  "created_at" : "2012-02-28 18:19:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/OPZphJ8B",
      "expanded_url" : "http:\/\/www.madinamerica.com\/2012\/02\/why-anti-authoritarians-are-diagnosed-as-mentally-ill\/",
      "display_url" : "madinamerica.com\/2012\/02\/why-an\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "174558613472415744",
  "text" : "I'm glad nobody ever bothered to have me \"diagnosed\" and \"treated\" for seeing the \"Emperors's Clothes\".  http:\/\/t.co\/OPZphJ8B",
  "id" : 174558613472415744,
  "created_at" : "2012-02-28 18:16:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AV",
      "screen_name" : "simpleav",
      "indices" : [ 0, 9 ],
      "id_str" : "2693067532",
      "id" : 2693067532
    }, {
      "name" : "Kenn R",
      "screen_name" : "heyitskenn",
      "indices" : [ 14, 25 ],
      "id_str" : "310502222",
      "id" : 310502222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "174263025983950848",
  "geo" : { },
  "id_str" : "174268128036003840",
  "in_reply_to_user_id" : 634703,
  "text" : "@SimpleAV  RT @heyitskenn This looks awesome... MIDI Fighter 3D \u2014",
  "id" : 174268128036003840,
  "in_reply_to_status_id" : 174263025983950848,
  "created_at" : "2012-02-27 23:02:14 +0000",
  "in_reply_to_screen_name" : "k3nnr",
  "in_reply_to_user_id_str" : "634703",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "indices" : [ 31, 40 ],
      "id_str" : "141834186",
      "id" : 141834186
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tucumcari",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/2e6Ak6BQ",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=C9TUOaPrBt8&feature=results_main&playnext=1&list=PL6D95F0DD5851C438",
      "display_url" : "youtube.com\/watch?v=C9TUOa\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "174241758446764033",
  "geo" : { },
  "id_str" : "174243653961781248",
  "in_reply_to_user_id" : 141834186,
  "text" : "@AngelineGragzin #tucumcari RT @FearDept We use our tasers to discipline citizens, even 14 year-old girls: http:\/\/t.co\/2e6Ak6BQ",
  "id" : 174243653961781248,
  "in_reply_to_status_id" : 174241758446764033,
  "created_at" : "2012-02-27 21:24:59 +0000",
  "in_reply_to_screen_name" : "FearDept",
  "in_reply_to_user_id_str" : "141834186",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "indices" : [ 0, 9 ],
      "id_str" : "141834186",
      "id" : 141834186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173880002637602817",
  "in_reply_to_user_id" : 141834186,
  "text" : "@FearDept is the Stephen Colbert of Corporate\/Government propaganda",
  "id" : 173880002637602817,
  "created_at" : "2012-02-26 21:19:57 +0000",
  "in_reply_to_screen_name" : "FearDept",
  "in_reply_to_user_id_str" : "141834186",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Humans",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173876324933451776",
  "text" : "RT @AngelineGragzin: Last week I had humans over for paella.  This week we're making cheese. Invite a human to your dwelling to make and ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Humans",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "173853464856764417",
    "text" : "Last week I had humans over for paella.  This week we're making cheese. Invite a human to your dwelling to make and eat food today! #Humans",
    "id" : 173853464856764417,
    "created_at" : "2012-02-26 19:34:30 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 173876324933451776,
  "created_at" : "2012-02-26 21:05:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u25D6(\u2022_\u2022)\u25D7",
      "screen_name" : "simurai",
      "indices" : [ 58, 66 ],
      "id_str" : "6896972",
      "id" : 6896972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 10, 30 ],
      "url" : "http:\/\/t.co\/Ddn3vaG3",
      "expanded_url" : "http:\/\/nodeca.github.com\/fontomas\/",
      "display_url" : "nodeca.github.com\/fontomas\/"
    }, {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/xg4GmfHY",
      "expanded_url" : "http:\/\/thenounproject.com\/",
      "display_url" : "thenounproject.com"
    } ]
  },
  "geo" : { },
  "id_str" : "173874927424897024",
  "text" : "awesome = http:\/\/t.co\/Ddn3vaG3 + http:\/\/t.co\/xg4GmfHY cc\/ @simurai",
  "id" : 173874927424897024,
  "created_at" : "2012-02-26 20:59:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 92, 104 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    }, {
      "name" : "T-Mobile USA",
      "screen_name" : "TMobileHelp",
      "indices" : [ 105, 117 ],
      "id_str" : "185728888",
      "id" : 185728888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/UJTNQNn4",
      "expanded_url" : "http:\/\/www.scpr.org\/news\/2012\/02\/24\/31380\/socal-iphone-user-wins-case-agains-t-over-data-thr\/",
      "display_url" : "scpr.org\/news\/2012\/02\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "173456873616449536",
  "text" : "RT @AngelineGragzin: SoCal man sues AT&T for throttling his \"unlimited\" data plan AND WINS. @astromanies @tmobilehelp http:\/\/t.co\/UJTNQNn4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "astromanies",
        "screen_name" : "astromanies",
        "indices" : [ 71, 83 ],
        "id_str" : "2588933322",
        "id" : 2588933322
      }, {
        "name" : "T-Mobile USA",
        "screen_name" : "TMobileHelp",
        "indices" : [ 84, 96 ],
        "id_str" : "185728888",
        "id" : 185728888
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/UJTNQNn4",
        "expanded_url" : "http:\/\/www.scpr.org\/news\/2012\/02\/24\/31380\/socal-iphone-user-wins-case-agains-t-over-data-thr\/",
        "display_url" : "scpr.org\/news\/2012\/02\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "173452497439043584",
    "text" : "SoCal man sues AT&T for throttling his \"unlimited\" data plan AND WINS. @astromanies @tmobilehelp http:\/\/t.co\/UJTNQNn4",
    "id" : 173452497439043584,
    "created_at" : "2012-02-25 17:01:12 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 173456873616449536,
  "created_at" : "2012-02-25 17:18:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 108, 117 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 118, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 126, 146 ],
      "url" : "http:\/\/t.co\/C74ktfL0",
      "expanded_url" : "http:\/\/substack.net\/posts\/b96642\/the-node-js-aesthetic",
      "display_url" : "substack.net\/posts\/b96642\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "173191945206759425",
  "text" : "\"If [app] ecosystems == economies : core libraries &lt;= gov't bureaucracies && &gt;= nationalized Inc.s\" - @substack #nodejs http:\/\/t.co\/C74ktfL0",
  "id" : 173191945206759425,
  "created_at" : "2012-02-24 23:45:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MLTalks",
      "indices" : [ 21, 29 ]
    }, {
      "text" : "drupaldroopings",
      "indices" : [ 30, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173186296422993921",
  "text" : "yr drupal's down son #MLTalks #drupaldroopings",
  "id" : 173186296422993921,
  "created_at" : "2012-02-24 23:23:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "encouraging",
      "indices" : [ 92, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173184940022837249",
  "text" : "A social network where all you can do is introduce yourself, over and over again as needed. #encouraging",
  "id" : 173184940022837249,
  "created_at" : "2012-02-24 23:18:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "173182020606885888",
  "text" : "I've seen the word orthogonal a lot lately. I'm going to look it up soon and then I'm going to know what it means.",
  "id" : 173182020606885888,
  "created_at" : "2012-02-24 23:06:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSS",
      "indices" : [ 38, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172896633032417280",
  "text" : "its been so long since I had to debug #CSS code I forgot what a msyteryPain it is",
  "id" : 172896633032417280,
  "created_at" : "2012-02-24 04:12:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172846856945152001",
  "text" : "The state of technology is fucking woeful. Automobiles, airplanes, computers, networks, all fucking slings and arrows.",
  "id" : 172846856945152001,
  "created_at" : "2012-02-24 00:54:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USA",
      "indices" : [ 136, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172845078337961984",
  "text" : "Can we make it a political \/ civic \"call to action\" or \"mandate\" or Constitutional Amendment to spank every Telecom Industry Executive? #USA",
  "id" : 172845078337961984,
  "created_at" : "2012-02-24 00:47:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172822780138631168",
  "text" : "The answer is not always a system.",
  "id" : 172822780138631168,
  "created_at" : "2012-02-23 23:18:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u25D6(\u2022_\u2022)\u25D7",
      "screen_name" : "simurai",
      "indices" : [ 15, 23 ],
      "id_str" : "6896972",
      "id" : 6896972
    }, {
      "name" : "Divya Manian",
      "screen_name" : "divya",
      "indices" : [ 33, 39 ],
      "id_str" : "6050",
      "id" : 6050
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/Ddn3vaG3",
      "expanded_url" : "http:\/\/nodeca.github.com\/fontomas\/",
      "display_url" : "nodeca.github.com\/fontomas\/"
    } ]
  },
  "geo" : { },
  "id_str" : "172789652649025536",
  "text" : "this gets a RT @simurai Indeed! \u201C@divya: This is fantastic, Open source iconic fonts composer http:\/\/t.co\/Ddn3vaG3\u201D",
  "id" : 172789652649025536,
  "created_at" : "2012-02-23 21:07:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 98, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172788346995748864",
  "text" : "I finally got around to implementing Stylus on the flow. Iterations in CSS. I'm never going back. #nodejs",
  "id" : 172788346995748864,
  "created_at" : "2012-02-23 21:02:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "172786684847603712",
  "text" : "This is a problem, really",
  "id" : 172786684847603712,
  "created_at" : "2012-02-23 20:55:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/AMGAJE3f",
      "expanded_url" : "http:\/\/www.brainpickings.org\/index.php\/2012\/02\/22\/ira-glass-on-the-secret-of-success\/",
      "display_url" : "brainpickings.org\/index.php\/2012\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "172409104864776192",
  "in_reply_to_user_id" : 58809542,
  "text" : "@angelinegragzin http:\/\/t.co\/AMGAJE3f",
  "id" : 172409104864776192,
  "created_at" : "2012-02-22 19:55:08 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gorilla",
      "indices" : [ 18, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "171676925838901248",
  "text" : "Insular networks! #gorilla",
  "id" : 171676925838901248,
  "created_at" : "2012-02-20 19:25:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 27, 38 ],
      "id_str" : "47951511",
      "id" : 47951511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "171391908516597761",
  "geo" : { },
  "id_str" : "171394247784792064",
  "in_reply_to_user_id" : 47951511,
  "text" : "Passive Voice FTW ALL-TIME @zunguzungu \"Mistakes were made.\"",
  "id" : 171394247784792064,
  "in_reply_to_status_id" : 171391908516597761,
  "created_at" : "2012-02-20 00:42:27 +0000",
  "in_reply_to_screen_name" : "zunguzungu",
  "in_reply_to_user_id_str" : "47951511",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Brilliant",
      "indices" : [ 89, 99 ]
    }, {
      "text" : "Terrific",
      "indices" : [ 100, 109 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/OlTFHXSk",
      "expanded_url" : "http:\/\/www.youtube.com\/embed\/VxSs1kGZQqc",
      "display_url" : "youtube.com\/embed\/VxSs1kGZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "171044768032374785",
  "text" : "Mass manufacturing tiny robots by printing and folding them like pop-up books \/ origami. #Brilliant #Terrific http:\/\/t.co\/OlTFHXSk",
  "id" : 171044768032374785,
  "created_at" : "2012-02-19 01:33:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "waterCoolerWhispers",
      "indices" : [ 0, 20 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170703375753678848",
  "text" : "#waterCoolerWhispers Mix hot with cold",
  "id" : 170703375753678848,
  "created_at" : "2012-02-18 02:57:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 75, 82 ]
    }, {
      "text" : "FSaaDB",
      "indices" : [ 83, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170688501489217536",
  "text" : "Node.js can fs.readFileSync() 8 files totaling 200kb, sequentially, in 8ms #nodejs #FSaaDB",
  "id" : 170688501489217536,
  "created_at" : "2012-02-18 01:58:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "html5",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 57, 78 ],
      "url" : "https:\/\/t.co\/MMSrDNwR",
      "expanded_url" : "https:\/\/github.com\/ajaxorg\/webfs",
      "display_url" : "github.com\/ajaxorg\/webfs"
    } ]
  },
  "geo" : { },
  "id_str" : "170685058527657985",
  "text" : "Oh yeah, the HTML5 File System API Wrap Battle winner is https:\/\/t.co\/MMSrDNwR\n#nodejs #html5",
  "id" : 170685058527657985,
  "created_at" : "2012-02-18 01:44:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 130, 137 ]
    } ],
    "urls" : [ {
      "indices" : [ 22, 43 ],
      "url" : "https:\/\/t.co\/MMSrDNwR",
      "expanded_url" : "https:\/\/github.com\/ajaxorg\/webfs",
      "display_url" : "github.com\/ajaxorg\/webfs"
    }, {
      "indices" : [ 108, 129 ],
      "url" : "https:\/\/t.co\/al6qs51F",
      "expanded_url" : "https:\/\/github.com\/ebidel\/filer.js",
      "display_url" : "github.com\/ebidel\/filer.js"
    } ]
  },
  "geo" : { },
  "id_str" : "170666562141949952",
  "text" : "Found this old module https:\/\/t.co\/MMSrDNwR A Node.js style FS for HTML5 File System API. Will compare with https:\/\/t.co\/al6qs51F #nodejs",
  "id" : 170666562141949952,
  "created_at" : "2012-02-18 00:30:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170591676337897472",
  "text" : "\"building a bomb ass, bitchin, mother-fucking system.\"",
  "id" : 170591676337897472,
  "created_at" : "2012-02-17 19:33:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stones Throw",
      "screen_name" : "stonesthrow",
      "indices" : [ 50, 62 ],
      "id_str" : "7495882",
      "id" : 7495882
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DamFunk",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/8sQqVGRQ",
      "expanded_url" : "http:\/\/www.stonesthrow.com\/news\/2012\/02\/prince-mix-by-dam-funk-for-wax-poetics",
      "display_url" : "stonesthrow.com\/news\/2012\/02\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "170288852731301890",
  "text" : "yeah Im gona stream this now http:\/\/t.co\/8sQqVGRQ @stonesthrow #DamFunk",
  "id" : 170288852731301890,
  "created_at" : "2012-02-16 23:30:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Rosen ",
      "screen_name" : "jayrosen_nyu",
      "indices" : [ 3, 16 ],
      "id_str" : "14834340",
      "id" : 14834340
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/Y541QR7k",
      "expanded_url" : "http:\/\/bit.ly\/zVKiHn",
      "display_url" : "bit.ly\/zVKiHn"
    } ]
  },
  "geo" : { },
  "id_str" : "170231922457448449",
  "text" : "RT @jayrosen_nyu: Just posted at The Guardian. My students and I studied all 839 questions the press asked at the debates. What we found ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/Y541QR7k",
        "expanded_url" : "http:\/\/bit.ly\/zVKiHn",
        "display_url" : "bit.ly\/zVKiHn"
      } ]
    },
    "geo" : { },
    "id_str" : "170221318497771520",
    "text" : "Just posted at The Guardian. My students and I studied all 839 questions the press asked at the debates. What we found: http:\/\/t.co\/Y541QR7k",
    "id" : 170221318497771520,
    "created_at" : "2012-02-16 19:01:39 +0000",
    "user" : {
      "name" : "Jay Rosen ",
      "screen_name" : "jayrosen_nyu",
      "protected" : false,
      "id_str" : "14834340",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472914265737658368\/6o7dqE39_normal.jpeg",
      "id" : 14834340,
      "verified" : true
    }
  },
  "id" : 170231922457448449,
  "created_at" : "2012-02-16 19:43:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 94 ],
      "url" : "https:\/\/t.co\/II44XItB",
      "expanded_url" : "https:\/\/github.com\/substack\/wreq",
      "display_url" : "github.com\/substack\/wreq"
    } ]
  },
  "geo" : { },
  "id_str" : "170189953521827840",
  "text" : "RT @substack: node-style require()s using async xhr without a build step https:\/\/t.co\/II44XItB",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 59, 80 ],
        "url" : "https:\/\/t.co\/II44XItB",
        "expanded_url" : "https:\/\/github.com\/substack\/wreq",
        "display_url" : "github.com\/substack\/wreq"
      } ]
    },
    "geo" : { },
    "id_str" : "170183776104755200",
    "text" : "node-style require()s using async xhr without a build step https:\/\/t.co\/II44XItB",
    "id" : 170183776104755200,
    "created_at" : "2012-02-16 16:32:28 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 170189953521827840,
  "created_at" : "2012-02-16 16:57:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Russell",
      "screen_name" : "slightlylate",
      "indices" : [ 88, 101 ],
      "id_str" : "229237555",
      "id" : 229237555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/uWsIs0hn",
      "expanded_url" : "http:\/\/infrequently.org\/2012\/02\/",
      "display_url" : "infrequently.org\/2012\/02\/"
    } ]
  },
  "geo" : { },
  "id_str" : "170187439913181184",
  "text" : "RT @viatropos: Epic post about the shortcomings of CSS by Chrome developer Alex Russell @slightlylate - http:\/\/t.co\/uWsIs0hn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alex Russell",
        "screen_name" : "slightlylate",
        "indices" : [ 73, 86 ],
        "id_str" : "229237555",
        "id" : 229237555
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/uWsIs0hn",
        "expanded_url" : "http:\/\/infrequently.org\/2012\/02\/",
        "display_url" : "infrequently.org\/2012\/02\/"
      } ]
    },
    "geo" : { },
    "id_str" : "170179563773636609",
    "text" : "Epic post about the shortcomings of CSS by Chrome developer Alex Russell @slightlylate - http:\/\/t.co\/uWsIs0hn",
    "id" : 170179563773636609,
    "created_at" : "2012-02-16 16:15:44 +0000",
    "user" : {
      "name" : "Lance Pollard",
      "screen_name" : "lancejpollard",
      "protected" : false,
      "id_str" : "17794723",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419403834985701377\/P4e8iIAF_normal.jpeg",
      "id" : 17794723,
      "verified" : false
    }
  },
  "id" : 170187439913181184,
  "created_at" : "2012-02-16 16:47:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CSS",
      "indices" : [ 94, 98 ]
    }, {
      "text" : "keyframes",
      "indices" : [ 99, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "170011448762843136",
  "text" : "Kinda lame that you have to have to nest browser prefixes inside a browser prefixed namespace #CSS #keyframes",
  "id" : 170011448762843136,
  "created_at" : "2012-02-16 05:07:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Master Prophet",
      "screen_name" : "tomravenscroft",
      "indices" : [ 3, 18 ],
      "id_str" : "82845447",
      "id" : 82845447
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "169485947744956417",
  "text" : "RT @tomravenscroft: Roses are Pantone CBAE9E, Violets are Pantone 19-3748 TCX. Both these colours are trademarked, so please don't use t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "169385784787484672",
    "text" : "Roses are Pantone CBAE9E, Violets are Pantone 19-3748 TCX. Both these colours are trademarked, so please don't use them without a license.",
    "id" : 169385784787484672,
    "created_at" : "2012-02-14 11:41:32 +0000",
    "user" : {
      "name" : "Master Prophet",
      "screen_name" : "tomravenscroft",
      "protected" : false,
      "id_str" : "82845447",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2762003154\/5390b964f7498b2ea99292cbe8e316e1_normal.jpeg",
      "id" : 82845447,
      "verified" : false
    }
  },
  "id" : 169485947744956417,
  "created_at" : "2012-02-14 18:19:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin",
      "screen_name" : "unknownt",
      "indices" : [ 0, 9 ],
      "id_str" : "19704084",
      "id" : 19704084
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thanks",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169458591282114561",
  "geo" : { },
  "id_str" : "169468329491312640",
  "in_reply_to_user_id" : 19704084,
  "text" : "@unknownt 1st fork \/ prong #thanks",
  "id" : 169468329491312640,
  "in_reply_to_status_id" : 169458591282114561,
  "created_at" : "2012-02-14 17:09:32 +0000",
  "in_reply_to_screen_name" : "unknownt",
  "in_reply_to_user_id_str" : "19704084",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Franklin",
      "screen_name" : "unknownt",
      "indices" : [ 0, 9 ],
      "id_str" : "19704084",
      "id" : 19704084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "169455843992023041",
  "geo" : { },
  "id_str" : "169457058331111424",
  "in_reply_to_user_id" : 19704084,
  "text" : "@unknownt \u007B\"error\":\"not_found\",\"reason\":\"Document is missing attachment\"\u007D",
  "id" : 169457058331111424,
  "in_reply_to_status_id" : 169455843992023041,
  "created_at" : "2012-02-14 16:24:45 +0000",
  "in_reply_to_screen_name" : "unknownt",
  "in_reply_to_user_id_str" : "19704084",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Maddow MSNBC",
      "screen_name" : "maddow",
      "indices" : [ 8, 15 ],
      "id_str" : "16129920",
      "id" : 16129920
    }, {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 56, 63 ],
      "id_str" : "11866582",
      "id" : 11866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "168179202141597696",
  "geo" : { },
  "id_str" : "168463272499101696",
  "in_reply_to_user_id" : 16129920,
  "text" : "What do @maddow's Post-Op-Eds have to do with anything? @LOLGOP",
  "id" : 168463272499101696,
  "in_reply_to_status_id" : 168179202141597696,
  "created_at" : "2012-02-11 22:35:48 +0000",
  "in_reply_to_screen_name" : "maddow",
  "in_reply_to_user_id_str" : "16129920",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 12, 19 ]
    }, {
      "text" : "html5",
      "indices" : [ 22, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "168444340421656578",
  "text" : "Me: Exp. LA #nodejs & #html5 dev w\/ prototypes seeks any other devs (front, sys\/linux, node.js, business) for Media\/PR\/Ad\/Networks bizplat",
  "id" : 168444340421656578,
  "created_at" : "2012-02-11 21:20:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lance Pollard",
      "screen_name" : "viatropos",
      "indices" : [ 6, 16 ],
      "id_str" : "2443416804",
      "id" : 2443416804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "167693595439144960",
  "geo" : { },
  "id_str" : "167700475234357251",
  "in_reply_to_user_id" : 17794723,
  "text" : "Nice! @viatropos where do I put it?",
  "id" : 167700475234357251,
  "in_reply_to_status_id" : 167693595439144960,
  "created_at" : "2012-02-09 20:04:43 +0000",
  "in_reply_to_screen_name" : "lancejpollard",
  "in_reply_to_user_id_str" : "17794723",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chicago",
      "indices" : [ 0, 8 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167694944251805696",
  "text" : "#Chicago to settle w\/ plaintiffs of class action lawsuit resulting from arrest of protesters on the day of Iraq Invasion. Protesting pays!",
  "id" : 167694944251805696,
  "created_at" : "2012-02-09 19:42:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167513225645137920",
  "text" : "I forks everything",
  "id" : 167513225645137920,
  "created_at" : "2012-02-09 07:40:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167510803782705152",
  "text" : "I'm going to disrupt your regularly scheduled sitcom.",
  "id" : 167510803782705152,
  "created_at" : "2012-02-09 07:31:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167506923783061504",
  "text" : "I didn't commit from the office the newshit I started which are mostly a bunch of the fundaments SYNTHESIZERED.",
  "id" : 167506923783061504,
  "created_at" : "2012-02-09 07:15:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bacteriology",
      "indices" : [ 100, 113 ]
    }, {
      "text" : "dontBeShy",
      "indices" : [ 114, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167083567128641536",
  "text" : "I need to crowd source this, please respond if u know. Which all bacteria poop is human nutritious? #bacteriology #dontBeShy",
  "id" : 167083567128641536,
  "created_at" : "2012-02-08 03:13:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chords",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "167047376899547138",
  "text" : "where the culture is jam a product & strap on later, i'm making components sure to be  re-used when I start jammin #chords",
  "id" : 167047376899547138,
  "created_at" : "2012-02-08 00:49:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speaker John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 10, 25 ],
      "id_str" : "7713202",
      "id" : 7713202
    }, {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 125, 132 ],
      "id_str" : "11866582",
      "id" : 11866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "166971015082147841",
  "geo" : { },
  "id_str" : "166972470056861696",
  "in_reply_to_user_id" : 7713202,
  "text" : "You know, @SpeakerBoehner, that it is not actually the Executive Branch's job to make the budgets. You know that, right? cc\/ @LOLGOP",
  "id" : 166972470056861696,
  "in_reply_to_status_id" : 166971015082147841,
  "created_at" : "2012-02-07 19:51:53 +0000",
  "in_reply_to_screen_name" : "SpeakerBoehner",
  "in_reply_to_user_id_str" : "7713202",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amplify.la",
      "screen_name" : "amplifyla",
      "indices" : [ 0, 10 ],
      "id_str" : "379028519",
      "id" : 379028519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166971090336358400",
  "in_reply_to_user_id" : 379028519,
  "text" : "@amplifyla Application HTTP POSTed",
  "id" : 166971090336358400,
  "created_at" : "2012-02-07 19:46:24 +0000",
  "in_reply_to_screen_name" : "amplifyla",
  "in_reply_to_user_id_str" : "379028519",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "indices" : [ 3, 11 ],
      "id_str" : "41296337",
      "id" : 41296337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166279046886469632",
  "text" : "RT @loudbot: FRACTAL ALLIGATORS. LIKE A NORMAL ALLIGATOR, BUT INSTEAD OF ARMS, THERE ARE MORE ALLIGATORS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/example.com\" rel=\"nofollow\"\u003EBITCHES DON'T KNOW 'BOUT MY INTENSIVE AERIAL BOMBARDMENT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "165351297200037889",
    "text" : "FRACTAL ALLIGATORS. LIKE A NORMAL ALLIGATOR, BUT INSTEAD OF ARMS, THERE ARE MORE ALLIGATORS",
    "id" : 165351297200037889,
    "created_at" : "2012-02-03 08:29:55 +0000",
    "user" : {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "protected" : false,
      "id_str" : "41296337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/404999194\/speaker_normal.png",
      "id" : 41296337,
      "verified" : false
    }
  },
  "id" : 166279046886469632,
  "created_at" : "2012-02-05 21:56:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 3, 10 ],
      "id_str" : "11866582",
      "id" : 11866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/8xDtUEjH",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=kxw4uZAezaI&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=kxw4uZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "166278636696113153",
  "text" : "RT @LOLGOP: If you wonder how xenophobic the election of 2012 may get, you haven't seen this ad. http:\/\/t.co\/8xDtUEjH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/8xDtUEjH",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=kxw4uZAezaI&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=kxw4uZ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "166246996691263489",
    "text" : "If you wonder how xenophobic the election of 2012 may get, you haven't seen this ad. http:\/\/t.co\/8xDtUEjH",
    "id" : 166246996691263489,
    "created_at" : "2012-02-05 19:49:07 +0000",
    "user" : {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "protected" : false,
      "id_str" : "11866582",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548604298095886336\/ZmsoghDo_normal.jpeg",
      "id" : 11866582,
      "verified" : false
    }
  },
  "id" : 166278636696113153,
  "created_at" : "2012-02-05 21:54:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 19, 23 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166229957398364162",
  "text" : "All industries the @FCC is supposed to regulate are the most unregulated of them all. By comparison, Wall Street wears a straight jacket.",
  "id" : 166229957398364162,
  "created_at" : "2012-02-05 18:41:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166229363380076544",
  "text" : "The entire wireless industry is proof negative that unregulated markets are the most innovative and competitive.",
  "id" : 166229363380076544,
  "created_at" : "2012-02-05 18:39:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tmobile",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166227820236910592",
  "text" : "Most businesses give their repeat and high volume customers the best service. #tmobile treats them like children.",
  "id" : 166227820236910592,
  "created_at" : "2012-02-05 18:32:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T-Mobile USA",
      "screen_name" : "TMobileHelp",
      "indices" : [ 0, 12 ],
      "id_str" : "185728888",
      "id" : 185728888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165852528850898944",
  "geo" : { },
  "id_str" : "166226410879451136",
  "in_reply_to_user_id" : 185728888,
  "text" : "@TMobileHelp The small % of ppl who use lots of data are not yr problem. Think: we use yr service the most. Like, repeat customers. GET IT?",
  "id" : 166226410879451136,
  "in_reply_to_status_id" : 165852528850898944,
  "created_at" : "2012-02-05 18:27:19 +0000",
  "in_reply_to_screen_name" : "TMobileHelp",
  "in_reply_to_user_id_str" : "185728888",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Schm\u00FCdde",
      "screen_name" : "dschmudde",
      "indices" : [ 0, 10 ],
      "id_str" : "191852002",
      "id" : 191852002
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tmobile",
      "indices" : [ 11, 19 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165896693357887488",
  "geo" : { },
  "id_str" : "166225336143589376",
  "in_reply_to_user_id" : 191852002,
  "text" : "@dschmudde #tmobile chokes your bandwidth \"due to the amount of data you have used\" even if you pay $40\/month for unlimited data",
  "id" : 166225336143589376,
  "in_reply_to_status_id" : 165896693357887488,
  "created_at" : "2012-02-05 18:23:03 +0000",
  "in_reply_to_screen_name" : "dschmudde",
  "in_reply_to_user_id_str" : "191852002",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T-Mobile USA",
      "screen_name" : "TMobileHelp",
      "indices" : [ 0, 12 ],
      "id_str" : "185728888",
      "id" : 185728888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "165852528850898944",
  "geo" : { },
  "id_str" : "166224716066078720",
  "in_reply_to_user_id" : 185728888,
  "text" : "@TMobileHelp I have the \"\"\"unlimited\"\"\" plan already how do I upgrade that?",
  "id" : 166224716066078720,
  "in_reply_to_status_id" : 165852528850898944,
  "created_at" : "2012-02-05 18:20:35 +0000",
  "in_reply_to_screen_name" : "TMobileHelp",
  "in_reply_to_user_id_str" : "185728888",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T-Mobile USA",
      "screen_name" : "TMobileHelp",
      "indices" : [ 3, 15 ],
      "id_str" : "185728888",
      "id" : 185728888
    }, {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 17, 29 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "166224534448504832",
  "text" : "RT @TMobileHelp: @astromanies\u00A0We dont like seeing you upset. Consider limiting video streaming, using wi-fi more,or upgrading your cap i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "astromanies",
        "screen_name" : "astromanies",
        "indices" : [ 0, 12 ],
        "id_str" : "2588933322",
        "id" : 2588933322
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "165850817830731776",
    "geo" : { },
    "id_str" : "165852528850898944",
    "in_reply_to_user_id" : 46961216,
    "text" : "@astromanies\u00A0We dont like seeing you upset. Consider limiting video streaming, using wi-fi more,or upgrading your cap if you need it \u00A0\u00A0\u00A0^KN",
    "id" : 165852528850898944,
    "in_reply_to_status_id" : 165850817830731776,
    "created_at" : "2012-02-04 17:41:38 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "T-Mobile USA",
      "screen_name" : "TMobileHelp",
      "protected" : false,
      "id_str" : "185728888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/448931643483381760\/GqzTA_lu_normal.jpeg",
      "id" : 185728888,
      "verified" : true
    }
  },
  "id" : 166224534448504832,
  "created_at" : "2012-02-05 18:19:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165896656720629760",
  "text" : "hey twitter im going on a dog walk",
  "id" : 165896656720629760,
  "created_at" : "2012-02-04 20:36:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tmobile",
      "indices" : [ 8, 16 ]
    }, {
      "text" : "losangeles",
      "indices" : [ 49, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165896213001015297",
  "text" : "current #tmobile 3g download speed: 0.06 mbps in #losangeles sloooooooooooooooooooooooooooooow",
  "id" : 165896213001015297,
  "created_at" : "2012-02-04 20:35:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/GeqOmv3D",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3551145",
      "display_url" : "news.ycombinator.com\/item?id=3551145"
    }, {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/hR1tw6y6",
      "expanded_url" : "http:\/\/news.ycombinator.com\/item?id=3549320",
      "display_url" : "news.ycombinator.com\/item?id=3549320"
    } ]
  },
  "geo" : { },
  "id_str" : "165852254556008448",
  "text" : "This definition of \"lit fic\" hits the mark: http:\/\/t.co\/GeqOmv3D via following thread http:\/\/t.co\/hR1tw6y6",
  "id" : 165852254556008448,
  "created_at" : "2012-02-04 17:40:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE REPUBLICAN DALEK",
      "screen_name" : "RepublicanDalek",
      "indices" : [ 3, 19 ],
      "id_str" : "308900763",
      "id" : 308900763
    }, {
      "name" : "Glenn Greenwald",
      "screen_name" : "ggreenwald",
      "indices" : [ 139, 140 ],
      "id_str" : "16076032",
      "id" : 16076032
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 123, 140 ],
      "url" : "http:\/\/t.co\/bK2tMQLW",
      "expanded_url" : "http:\/\/www.salon.com\/2012\/02\/04\/the_growing_iranian_military_behemoth\/singleton",
      "display_url" : "salon.com\/2012\/02\/04\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "165852228081565697",
  "text" : "RT @RepublicanDalek: IRAN MAY DOUBLE MILITARY SPENDING FROM DIDDLY ALL THE WAY TO SQUAT! BOMB THEM! BOMB THEM *RIGHT* NOW! http:\/\/t.co\/b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Glenn Greenwald",
        "screen_name" : "ggreenwald",
        "indices" : [ 126, 137 ],
        "id_str" : "16076032",
        "id" : 16076032
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/bK2tMQLW",
        "expanded_url" : "http:\/\/www.salon.com\/2012\/02\/04\/the_growing_iranian_military_behemoth\/singleton",
        "display_url" : "salon.com\/2012\/02\/04\/the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "165850906670272512",
    "text" : "IRAN MAY DOUBLE MILITARY SPENDING FROM DIDDLY ALL THE WAY TO SQUAT! BOMB THEM! BOMB THEM *RIGHT* NOW! http:\/\/t.co\/bK2tMQLW CC @ggreenwald",
    "id" : 165850906670272512,
    "created_at" : "2012-02-04 17:35:12 +0000",
    "user" : {
      "name" : "THE REPUBLICAN DALEK",
      "screen_name" : "RepublicanDalek",
      "protected" : false,
      "id_str" : "308900763",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511173133517090816\/19ZoONOP_normal.png",
      "id" : 308900763,
      "verified" : false
    }
  },
  "id" : 165852228081565697,
  "created_at" : "2012-02-04 17:40:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "T-Mobile",
      "screen_name" : "TMobile",
      "indices" : [ 0, 8 ],
      "id_str" : "17338082",
      "id" : 17338082
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165850817830731776",
  "in_reply_to_user_id" : 17338082,
  "text" : "@tmobile is strangling my unlimited internet and therefore they suck and I don't recommend them as a data provider.",
  "id" : 165850817830731776,
  "created_at" : "2012-02-04 17:34:50 +0000",
  "in_reply_to_screen_name" : "TMobile",
  "in_reply_to_user_id_str" : "17338082",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "165235843487899648",
  "text" : "Is MVC crucial to building superior web apps? I can't bring myself to do it.",
  "id" : 165235843487899648,
  "created_at" : "2012-02-03 00:51:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "learning",
      "indices" : [ 36, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164846347952988160",
  "text" : "half day of work = 20-30 open tabs. #learning",
  "id" : 164846347952988160,
  "created_at" : "2012-02-01 23:03:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alex Sexton",
      "screen_name" : "SlexAxton",
      "indices" : [ 0, 10 ],
      "id_str" : "12806822",
      "id" : 12806822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/4mvNd6ui",
      "expanded_url" : "http:\/\/jsfiddle.net\/xeHca\/",
      "display_url" : "jsfiddle.net\/xeHca\/"
    } ]
  },
  "in_reply_to_status_id_str" : "164843961310126080",
  "geo" : { },
  "id_str" : "164845100957044741",
  "in_reply_to_user_id" : 12806822,
  "text" : "@SlexAxton http:\/\/t.co\/4mvNd6ui",
  "id" : 164845100957044741,
  "in_reply_to_status_id" : 164843961310126080,
  "created_at" : "2012-02-01 22:58:29 +0000",
  "in_reply_to_screen_name" : "SlexAxton",
  "in_reply_to_user_id_str" : "12806822",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caleb Garling",
      "screen_name" : "CalebGarling",
      "indices" : [ 6, 19 ],
      "id_str" : "20543509",
      "id" : 20543509
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164834066766630912",
  "geo" : { },
  "id_str" : "164844435702681601",
  "in_reply_to_user_id" : 20543509,
  "text" : "sorry @CalebGarling but that is not what is irony",
  "id" : 164844435702681601,
  "in_reply_to_status_id" : 164834066766630912,
  "created_at" : "2012-02-01 22:55:50 +0000",
  "in_reply_to_screen_name" : "CalebGarling",
  "in_reply_to_user_id_str" : "20543509",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ian Henry",
      "screen_name" : "ianthehenry",
      "indices" : [ 0, 12 ],
      "id_str" : "16136334",
      "id" : 16136334
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/kPIR6PQc",
      "expanded_url" : "http:\/\/stackoverflow.com\/questions\/5086693\/how-can-i-make-a-plain-text-paste-in-a-contenteditable-span-without-breaking-und",
      "display_url" : "stackoverflow.com\/questions\/5086\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164835079867215872",
  "in_reply_to_user_id" : 16136334,
  "text" : "@ianthehenry Did you ever find a solution to your problem, via http:\/\/t.co\/kPIR6PQc",
  "id" : 164835079867215872,
  "created_at" : "2012-02-01 22:18:40 +0000",
  "in_reply_to_screen_name" : "ianthehenry",
  "in_reply_to_user_id_str" : "16136334",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164825745754034176",
  "text" : "rilly tho",
  "id" : 164825745754034176,
  "created_at" : "2012-02-01 21:41:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jquery",
      "indices" : [ 53, 60 ]
    }, {
      "text" : "javascript",
      "indices" : [ 61, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164801295948066817",
  "text" : "OH: jQuery paste event doesn't include clipboardData #jquery #javascript",
  "id" : 164801295948066817,
  "created_at" : "2012-02-01 20:04:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amplify.la",
      "screen_name" : "amplifyla",
      "indices" : [ 0, 10 ],
      "id_str" : "379028519",
      "id" : 379028519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164485127391559680",
  "geo" : { },
  "id_str" : "164491411973079041",
  "in_reply_to_user_id" : 379028519,
  "text" : "@amplifyla Can a young, networked digital media co. w\/ a well qualified node.js & HTML5 dev bypass the bizplan application for an interview?",
  "id" : 164491411973079041,
  "in_reply_to_status_id" : 164485127391559680,
  "created_at" : "2012-01-31 23:33:03 +0000",
  "in_reply_to_screen_name" : "amplifyla",
  "in_reply_to_user_id_str" : "379028519",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red List Radio",
      "screen_name" : "RedListRadio",
      "indices" : [ 26, 39 ],
      "id_str" : "227832849",
      "id" : 227832849
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "colorblindpeeps",
      "indices" : [ 78, 94 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164486549331906560",
  "geo" : { },
  "id_str" : "164488857683894272",
  "in_reply_to_user_id" : 227832849,
  "text" : "I got a wish list for you @RedListRadio no red text on black background ever. #colorblindpeeps (was free design crit on yr list?)",
  "id" : 164488857683894272,
  "in_reply_to_status_id" : 164486549331906560,
  "created_at" : "2012-01-31 23:22:54 +0000",
  "in_reply_to_screen_name" : "RedListRadio",
  "in_reply_to_user_id_str" : "227832849",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164488040067248128",
  "text" : "hsla(100, 30%, 95%, 1); That's the winner right there.",
  "id" : 164488040067248128,
  "created_at" : "2012-01-31 23:19:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]