Grailbird.data.tweets_2013_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/LjIpDKsYPB",
      "expanded_url" : "http:\/\/www.fastcolabs.com\/3021964\/the-argument-for-worker-owned-tech-collectives",
      "display_url" : "fastcolabs.com\/3021964\/the-ar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406838003328221184",
  "text" : "tech co-ops http:\/\/t.co\/LjIpDKsYPB",
  "id" : 406838003328221184,
  "created_at" : "2013-11-30 17:31:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yaroslaff Fedin",
      "screen_name" : "Inviz",
      "indices" : [ 0, 6 ],
      "id_str" : "5724722",
      "id" : 5724722
    }, {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 7, 21 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/w2i0HkQ5Pz",
      "expanded_url" : "http:\/\/tomorrowthemag.com\/articles\/insert-coins-to-continue",
      "display_url" : "tomorrowthemag.com\/articles\/inser\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "406661815494402048",
  "geo" : { },
  "id_str" : "406665523863113728",
  "in_reply_to_user_id" : 5724722,
  "text" : "@Inviz @jesusabdullah Valve and a greek economist experiment with markets http:\/\/t.co\/w2i0HkQ5Pz",
  "id" : 406665523863113728,
  "in_reply_to_status_id" : 406661815494402048,
  "created_at" : "2013-11-30 06:06:31 +0000",
  "in_reply_to_screen_name" : "Inviz",
  "in_reply_to_user_id_str" : "5724722",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 24, 47 ],
      "url" : "https:\/\/t.co\/SiHK69hrxY",
      "expanded_url" : "https:\/\/sites.google.com\/site\/semilleroadt\/raspberry-pi-tutorials\/gpio",
      "display_url" : "sites.google.com\/site\/semillero\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406663950328008704",
  "text" : "raspberry pi GPIO guide https:\/\/t.co\/SiHK69hrxY",
  "id" : 406663950328008704,
  "created_at" : "2013-11-30 06:00:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406641712467939328",
  "text" : "I hate my users.",
  "id" : 406641712467939328,
  "created_at" : "2013-11-30 04:31:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "envelope",
      "indices" : [ 99, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 132 ],
      "url" : "https:\/\/t.co\/SA4NnDRMYe",
      "expanded_url" : "https:\/\/gist.github.com\/atomizer\/1049745",
      "display_url" : "gist.github.com\/atomizer\/10497\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "406554222650331136",
  "text" : "de CastelJau's algorithm for plotting points on a bezier curve, given any number of control points #envelope https:\/\/t.co\/SA4NnDRMYe",
  "id" : 406554222650331136,
  "created_at" : "2013-11-29 22:44:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406164313104064512",
  "text" : "\"The pain of sorrow is strong in this one.  Yet, it won't drink?\"",
  "id" : 406164313104064512,
  "created_at" : "2013-11-28 20:54:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "406162185283317760",
  "text" : "make n do \nwith bake n goo",
  "id" : 406162185283317760,
  "created_at" : "2013-11-28 20:46:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405916782940012544",
  "text" : "I'm flying at low altitude over past, and through.",
  "id" : 405916782940012544,
  "created_at" : "2013-11-28 04:31:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405916079630725120",
  "text" : "upside's downside's",
  "id" : 405916079630725120,
  "created_at" : "2013-11-28 04:28:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405915784657911808",
  "text" : "Is this thing about?",
  "id" : 405915784657911808,
  "created_at" : "2013-11-28 04:27:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405915415127154688",
  "text" : "I'm talking to you.",
  "id" : 405915415127154688,
  "created_at" : "2013-11-28 04:25:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405915337641578496",
  "text" : "Tango Asana Foxtrot",
  "id" : 405915337641578496,
  "created_at" : "2013-11-28 04:25:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "405589467001389056",
  "text" : "call that psycherunk",
  "id" : 405589467001389056,
  "created_at" : "2013-11-27 06:50:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 46 ],
      "url" : "https:\/\/t.co\/GfsGjlCZg1",
      "expanded_url" : "https:\/\/soundcloud.com\/the-pipes-of-unix\/thereremix",
      "display_url" : "soundcloud.com\/the-pipes-of-u\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "405588519457812480",
  "text" : "currently listening to https:\/\/t.co\/GfsGjlCZg1",
  "id" : 405588519457812480,
  "created_at" : "2013-11-27 06:46:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/eIzHcji362",
      "expanded_url" : "http:\/\/instagram.com\/p\/hHKA4TD5Xd\/",
      "display_url" : "instagram.com\/p\/hHKA4TD5Xd\/"
    } ]
  },
  "geo" : { },
  "id_str" : "404742480027217920",
  "text" : "The internet http:\/\/t.co\/eIzHcji362",
  "id" : 404742480027217920,
  "created_at" : "2013-11-24 22:45:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "libcom.org",
      "screen_name" : "libcomorg",
      "indices" : [ 3, 13 ],
      "id_str" : "69545227",
      "id" : 69545227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BkP29vY6xu",
      "expanded_url" : "http:\/\/fb.me\/2OG0d7khq",
      "display_url" : "fb.me\/2OG0d7khq"
    } ]
  },
  "geo" : { },
  "id_str" : "404300745047961600",
  "text" : "RT @libcomorg: New online! Entire issue of Middle-Eastern revolutionary socialist journal, Khamsin. This issue focusing on women... http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/BkP29vY6xu",
        "expanded_url" : "http:\/\/fb.me\/2OG0d7khq",
        "display_url" : "fb.me\/2OG0d7khq"
      } ]
    },
    "geo" : { },
    "id_str" : "404201791480291329",
    "text" : "New online! Entire issue of Middle-Eastern revolutionary socialist journal, Khamsin. This issue focusing on women... http:\/\/t.co\/BkP29vY6xu",
    "id" : 404201791480291329,
    "created_at" : "2013-11-23 10:56:31 +0000",
    "user" : {
      "name" : "libcom.org",
      "screen_name" : "libcomorg",
      "protected" : false,
      "id_str" : "69545227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/444089680477184000\/_Y6tBqpa_normal.png",
      "id" : 69545227,
      "verified" : false
    }
  },
  "id" : 404300745047961600,
  "created_at" : "2013-11-23 17:29:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404026134561443840",
  "text" : "This tweet is a stick-up.",
  "id" : 404026134561443840,
  "created_at" : "2013-11-22 23:18:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404025617009479680",
  "text" : "Frankishly, yall, what I'm seeing is light.  Let's be heavy.",
  "id" : 404025617009479680,
  "created_at" : "2013-11-22 23:16:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "404023882803183616",
  "text" : "I'm a sexy feminist.  I also want to derange social order.",
  "id" : 404023882803183616,
  "created_at" : "2013-11-22 23:09:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403807555354255360",
  "text" : "Winds shaking a hundred-year house to the low down.  A flood of waves.  Instantly, entirely, the interior cools.",
  "id" : 403807555354255360,
  "created_at" : "2013-11-22 08:49:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403806004158009344",
  "text" : "It must be very hot somewhere right now.",
  "id" : 403806004158009344,
  "created_at" : "2013-11-22 08:43:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403580212757008384",
  "text" : "SO MUCH ZUG",
  "id" : 403580212757008384,
  "created_at" : "2013-11-21 17:46:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403408312193921024",
  "text" : "sys admeditation",
  "id" : 403408312193921024,
  "created_at" : "2013-11-21 06:23:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403334754612682752",
  "text" : "They got the game figured out all wrong.  Hackers like me should have agents, and competing bids for publishing deals.",
  "id" : 403334754612682752,
  "created_at" : "2013-11-21 01:31:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/7IuJmNG7iT",
      "expanded_url" : "http:\/\/instagram.com\/p\/g81FbUj5TZ\/",
      "display_url" : "instagram.com\/p\/g81FbUj5TZ\/"
    } ]
  },
  "geo" : { },
  "id_str" : "403264052484644866",
  "text" : "Basement h4xx http:\/\/t.co\/7IuJmNG7iT",
  "id" : 403264052484644866,
  "created_at" : "2013-11-20 20:50:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kraftwerk",
      "indices" : [ 17, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/1pBdG3jBk8",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=mN5UfJA2evY",
      "display_url" : "youtube.com\/watch?v=mN5UfJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "403248077428883456",
  "text" : "jam of the while #kraftwerk http:\/\/t.co\/1pBdG3jBk8",
  "id" : 403248077428883456,
  "created_at" : "2013-11-20 19:46:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 37 ],
      "url" : "http:\/\/t.co\/vNwq8ed8RY",
      "expanded_url" : "http:\/\/instagram.com\/p\/g8tNz6D5ZA\/",
      "display_url" : "instagram.com\/p\/g8tNz6D5ZA\/"
    } ]
  },
  "geo" : { },
  "id_str" : "403246724023844865",
  "text" : "Soaked chicken http:\/\/t.co\/vNwq8ed8RY",
  "id" : 403246724023844865,
  "created_at" : "2013-11-20 19:41:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403196168588365824",
  "text" : "I need a major economy to back their currency with bitcoin right now",
  "id" : 403196168588365824,
  "created_at" : "2013-11-20 16:20:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "403190962031034368",
  "text" : "Use your love power",
  "id" : 403190962031034368,
  "created_at" : "2013-11-20 15:59:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "superCawsius",
      "indices" : [ 0, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402887666993098752",
  "text" : "#superCawsius",
  "id" : 402887666993098752,
  "created_at" : "2013-11-19 19:54:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402887060962291712",
  "text" : "Update: the caw is purring (or snoring dreamily)",
  "id" : 402887060962291712,
  "created_at" : "2013-11-19 19:52:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402886500322246657",
  "text" : "Raining, overcast, with a caw crowing on the nearest pole.",
  "id" : 402886500322246657,
  "created_at" : "2013-11-19 19:50:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402854134119817216",
  "text" : "who's hiring in Buenos Aires?",
  "id" : 402854134119817216,
  "created_at" : "2013-11-19 17:41:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402848929454100481",
  "text" : "STAND BACK \nI HAVE A BITCOIN",
  "id" : 402848929454100481,
  "created_at" : "2013-11-19 17:20:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402638074456207360",
  "geo" : { },
  "id_str" : "402677255253405696",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack \nyou will never know\nwere all the tricks only one\nwearing disguises",
  "id" : 402677255253405696,
  "in_reply_to_status_id" : 402638074456207360,
  "created_at" : "2013-11-19 05:58:33 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402659493420335104",
  "text" : "THROUGH\nTHE RADICAL FILTER",
  "id" : 402659493420335104,
  "created_at" : "2013-11-19 04:47:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402648172456980480",
  "text" : ", I explained myself.  Sounds lower class, went the reply.",
  "id" : 402648172456980480,
  "created_at" : "2013-11-19 04:02:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402647776611164161",
  "text" : "The prophet of apostasy.",
  "id" : 402647776611164161,
  "created_at" : "2013-11-19 04:01:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402597352344518657",
  "text" : "I want the finest wine available to all humanity, and I want it here, and I want it now.",
  "id" : 402597352344518657,
  "created_at" : "2013-11-19 00:41:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/HI29RShoCr",
      "expanded_url" : "http:\/\/instagram.com\/p\/g4EyvgD5et\/",
      "display_url" : "instagram.com\/p\/g4EyvgD5et\/"
    } ]
  },
  "geo" : { },
  "id_str" : "402595011004739584",
  "text" : "sblood http:\/\/t.co\/HI29RShoCr",
  "id" : 402595011004739584,
  "created_at" : "2013-11-19 00:31:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    }, {
      "name" : "Chris Dickinson",
      "screen_name" : "isntitvacant",
      "indices" : [ 8, 21 ],
      "id_str" : "15394440",
      "id" : 15394440
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 22, 31 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 65 ],
      "url" : "https:\/\/t.co\/E0WR4Z2Zl3",
      "expanded_url" : "https:\/\/github.com\/NHQ\/jbuffers",
      "display_url" : "github.com\/NHQ\/jbuffers"
    }, {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/MKIxcfflLq",
      "expanded_url" : "https:\/\/npmjs.org\/package\/buffers",
      "display_url" : "npmjs.org\/package\/buffers"
    } ]
  },
  "in_reply_to_status_id_str" : "402514981712695296",
  "geo" : { },
  "id_str" : "402517455823568896",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross @isntitvacant @maxogden \nsee also https:\/\/t.co\/E0WR4Z2Zl3 which supports ArrayBuffers, a fork of https:\/\/t.co\/MKIxcfflLq",
  "id" : 402517455823568896,
  "in_reply_to_status_id" : 402514981712695296,
  "created_at" : "2013-11-18 19:23:34 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Dickinson",
      "screen_name" : "isntitvacant",
      "indices" : [ 0, 13 ],
      "id_str" : "15394440",
      "id" : 15394440
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 14, 23 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 24, 31 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402510409502306304",
  "geo" : { },
  "id_str" : "402514588974854144",
  "in_reply_to_user_id" : 15394440,
  "text" : "@isntitvacant @maxogden @feross node's Buffer is already shimmed in browserify, a la var buf = new Buffer( )",
  "id" : 402514588974854144,
  "in_reply_to_status_id" : 402510409502306304,
  "created_at" : "2013-11-18 19:12:11 +0000",
  "in_reply_to_screen_name" : "isntitvacant",
  "in_reply_to_user_id_str" : "15394440",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/4hSTYhzhtl",
      "expanded_url" : "http:\/\/shoop-team.2013.nodeknockout.com\/",
      "display_url" : "shoop-team.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "402509358665183232",
  "text" : "bitcoin mining in the browser, I hopes they'll open source it http:\/\/t.co\/4hSTYhzhtl",
  "id" : 402509358665183232,
  "created_at" : "2013-11-18 18:51:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402183515367673856",
  "text" : "internets make distance intimate",
  "id" : 402183515367673856,
  "created_at" : "2013-11-17 21:16:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402179889169592320",
  "text" : "#!\/bin\/johnnyscript\nwhere internal live I.\nwhere did you go?",
  "id" : 402179889169592320,
  "created_at" : "2013-11-17 21:02:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "402152542802427904",
  "text" : "hey imma go shovel chicken shit now.",
  "id" : 402152542802427904,
  "created_at" : "2013-11-17 19:13:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 11, 19 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "402132695137779712",
  "geo" : { },
  "id_str" : "402137736871571456",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack \n@soldair called npm scripts \" a beautiful setup... a true work of sysops art\"",
  "id" : 402137736871571456,
  "in_reply_to_status_id" : 402132695137779712,
  "created_at" : "2013-11-17 18:14:42 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/401855286371041280\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/BXS491uTZF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BZOtQPvCQAAlltP.png",
      "id_str" : "401855286379429888",
      "id" : 401855286379429888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BZOtQPvCQAAlltP.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/BXS491uTZF"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/RarIYfhjgy",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com\/",
      "display_url" : "los-manos.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "401855286371041280",
  "text" : "de http:\/\/t.co\/RarIYfhjgy\n\n# http:\/\/t.co\/BXS491uTZF",
  "id" : 401855286371041280,
  "created_at" : "2013-11-16 23:32:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401579874986373121",
  "text" : "Degradation nearly complete",
  "id" : 401579874986373121,
  "created_at" : "2013-11-16 05:17:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "localhost",
      "indices" : [ 79, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401534771416690688",
  "text" : "running ubuntu from a shell in the browser on the chromebook, and all are one. #localhost",
  "id" : 401534771416690688,
  "created_at" : "2013-11-16 02:18:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401182541232631808",
  "text" : "So crepe  much butter",
  "id" : 401182541232631808,
  "created_at" : "2013-11-15 02:59:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401126016921264128",
  "text" : "This happened: A \"woman in tech\" (wearing google glasses) visited my home and told me my probable Myers-Briggs type.",
  "id" : 401126016921264128,
  "created_at" : "2013-11-14 23:14:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401114901621395456",
  "text" : "System Vulnerability Detected: reference nullifiers, and loop negators",
  "id" : 401114901621395456,
  "created_at" : "2013-11-14 22:30:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401112910195195904",
  "text" : "Unfortunately for your \"theory\", my intuition rejects the classical.",
  "id" : 401112910195195904,
  "created_at" : "2013-11-14 22:22:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401098827945373696",
  "text" : "Y'all are a threat of queers.",
  "id" : 401098827945373696,
  "created_at" : "2013-11-14 21:26:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401098649419018240",
  "text" : "I am very queer",
  "id" : 401098649419018240,
  "created_at" : "2013-11-14 21:25:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401089605824307200",
  "text" : "toward a more perfect union, for me",
  "id" : 401089605824307200,
  "created_at" : "2013-11-14 20:49:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401087900168617984",
  "text" : "hacker housewife",
  "id" : 401087900168617984,
  "created_at" : "2013-11-14 20:43:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "401072851639230464",
  "text" : "I made 5 bean soup.",
  "id" : 401072851639230464,
  "created_at" : "2013-11-14 19:43:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetsontape.com\" rel=\"nofollow\"\u003ETweets on Tape\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 0, 12 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TweetsOnTape",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/qtSuhk99Fv",
      "expanded_url" : "http:\/\/taped.io\/t\/eygKRBu04",
      "display_url" : "taped.io\/t\/eygKRBu04"
    } ]
  },
  "in_reply_to_status_id_str" : "400025954585563137",
  "geo" : { },
  "id_str" : "400713993326956545",
  "in_reply_to_user_id" : 46961216,
  "text" : "@astromanies - Your tweet, read out loud: http:\/\/t.co\/qtSuhk99Fv #TweetsOnTape",
  "id" : 400713993326956545,
  "in_reply_to_status_id" : 400025954585563137,
  "created_at" : "2013-11-13 19:57:15 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetsontape.com\" rel=\"nofollow\"\u003ETweets on Tape\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CGE",
      "screen_name" : "aristosophy",
      "indices" : [ 0, 12 ],
      "id_str" : "2853662301",
      "id" : 2853662301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TweetsOnTape",
      "indices" : [ 65, 78 ]
    } ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/UxvU22WE3v",
      "expanded_url" : "http:\/\/taped.io\/t\/x1QhdN_0E",
      "display_url" : "taped.io\/t\/x1QhdN_0E"
    } ]
  },
  "in_reply_to_status_id_str" : "400340225571815424",
  "geo" : { },
  "id_str" : "400711660220186624",
  "in_reply_to_user_id" : 742620391,
  "text" : "@aristosophy - Your tweet, read out loud: http:\/\/t.co\/UxvU22WE3v #TweetsOnTape",
  "id" : 400711660220186624,
  "in_reply_to_status_id" : 400340225571815424,
  "created_at" : "2013-11-13 19:47:59 +0000",
  "in_reply_to_screen_name" : "GateOfHeavens",
  "in_reply_to_user_id_str" : "742620391",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/tweetsontape.com\" rel=\"nofollow\"\u003ETweets on Tape\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLT HULK",
      "screen_name" : "PLT_Hulk",
      "indices" : [ 0, 9 ],
      "id_str" : "484936561",
      "id" : 484936561
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TweetsOnTape",
      "indices" : [ 62, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/gdDk6xwUPu",
      "expanded_url" : "http:\/\/taped.io\/t\/gyfo6fd0E",
      "display_url" : "taped.io\/t\/gyfo6fd0E"
    } ]
  },
  "in_reply_to_status_id_str" : "400621629824196608",
  "geo" : { },
  "id_str" : "400708753093582848",
  "in_reply_to_user_id" : 484936561,
  "text" : "@PLT_Hulk - Your tweet, read out loud: http:\/\/t.co\/gdDk6xwUPu #TweetsOnTape",
  "id" : 400708753093582848,
  "in_reply_to_status_id" : 400621629824196608,
  "created_at" : "2013-11-13 19:36:26 +0000",
  "in_reply_to_screen_name" : "PLT_Hulk",
  "in_reply_to_user_id_str" : "484936561",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400585940776673280",
  "text" : "I'm up before the chickenses",
  "id" : 400585940776673280,
  "created_at" : "2013-11-13 11:28:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400448405383548928",
  "text" : "Computerweltschmerz",
  "id" : 400448405383548928,
  "created_at" : "2013-11-13 02:21:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blake G.",
      "screen_name" : "cwlcks",
      "indices" : [ 3, 10 ],
      "id_str" : "63545584",
      "id" : 63545584
    }, {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 12, 24 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400447979972067329",
  "text" : "RT @cwlcks: @astromanies what sort of devil algebra is this",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "astromanies",
        "screen_name" : "astromanies",
        "indices" : [ 0, 12 ],
        "id_str" : "2588933322",
        "id" : 2588933322
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "400428440454586368",
    "geo" : { },
    "id_str" : "400443361145782272",
    "in_reply_to_user_id" : 46961216,
    "text" : "@astromanies what sort of devil algebra is this",
    "id" : 400443361145782272,
    "in_reply_to_status_id" : 400428440454586368,
    "created_at" : "2013-11-13 02:01:51 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Blake G.",
      "screen_name" : "cwlcks",
      "protected" : false,
      "id_str" : "63545584",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515282524738564096\/2ZxZFZRM_normal.png",
      "id" : 63545584,
      "verified" : false
    }
  },
  "id" : 400447979972067329,
  "created_at" : "2013-11-13 02:20:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/400434783546650625\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/EmBBQBS3TR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY6hUGWCMAACVb0.png",
      "id_str" : "400434783555039232",
      "id" : 400434783555039232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY6hUGWCMAACVb0.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/EmBBQBS3TR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400434783546650625",
  "text" : "paradiso\n\n# http:\/\/t.co\/EmBBQBS3TR",
  "id" : 400434783546650625,
  "created_at" : "2013-11-13 01:27:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/400432834306785280\/photo\/1",
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/ygeAEl8nus",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY6fio3CQAA2G_0.png",
      "id_str" : "400432834315173888",
      "id" : 400432834315173888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY6fio3CQAA2G_0.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ygeAEl8nus"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400432834306785280",
  "text" : "invertre\n\n# http:\/\/t.co\/ygeAEl8nus",
  "id" : 400432834306785280,
  "created_at" : "2013-11-13 01:20:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400428440454586368",
  "text" : "every number is the square root of one",
  "id" : 400428440454586368,
  "created_at" : "2013-11-13 01:02:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "400422907605946368",
  "geo" : { },
  "id_str" : "400426755086749697",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison 7 doesn't remember if it was 4 + 3, five and two, or 2 by 3-point-5",
  "id" : 400426755086749697,
  "in_reply_to_status_id" : 400422907605946368,
  "created_at" : "2013-11-13 00:55:52 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400414010706644992",
  "text" : "-S = set Success ID\n-s = set Size in sectors\n8:^(u",
  "id" : 400414010706644992,
  "created_at" : "2013-11-13 00:05:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/RarIYfhjgy",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com\/",
      "display_url" : "los-manos.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "400294676592214016",
  "text" : "\"Novel approach to creating a gif, very unique.\" \"A real artist type could probably do some very cool work with this\"\nhttp:\/\/t.co\/RarIYfhjgy",
  "id" : 400294676592214016,
  "created_at" : "2013-11-12 16:11:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/rANSCXMD6d",
      "expanded_url" : "http:\/\/johnnyscript.us\/demos\/lightCorrection.gif",
      "display_url" : "johnnyscript.us\/demos\/lightCor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400055646080352257",
  "text" : "this gif shows manual light correction of webcam photos.\n\nhttp:\/\/t.co\/rANSCXMD6d",
  "id" : 400055646080352257,
  "created_at" : "2013-11-12 00:21:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/a7qVS8pcps",
      "expanded_url" : "http:\/\/johnnyscript.us\/demos\/speedtest.gif",
      "display_url" : "johnnyscript.us\/demos\/speedtes\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "400054488972533760",
  "text" : "This gif is the same shot in the same light showing increasing exposure time and \"film speed\".  With a webcam.\n\nhttp:\/\/t.co\/a7qVS8pcps",
  "id" : 400054488972533760,
  "created_at" : "2013-11-12 00:16:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/400046227204497409\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/Hn2GqclC5v",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY0_7JLCYAIZ37i.png",
      "id_str" : "400046227212886018",
      "id" : 400046227212886018,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY0_7JLCYAIZ37i.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Hn2GqclC5v"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/TiV1V66QxU",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com",
      "display_url" : "los-manos.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "400046227204497409",
  "text" : "5s webcam exposure (filmSpeed 5) of the back wall of puppet stage of the future\n\ntaken with http:\/\/t.co\/TiV1V66QxU http:\/\/t.co\/Hn2GqclC5v",
  "id" : 400046227204497409,
  "created_at" : "2013-11-11 23:43:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "400025954585563137",
  "text" : "Be for that feliziness, my people.",
  "id" : 400025954585563137,
  "created_at" : "2013-11-11 22:23:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "399997354591268864",
  "geo" : { },
  "id_str" : "399998778402304000",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight whoops! fixed!",
  "id" : 399998778402304000,
  "in_reply_to_status_id" : 399997354591268864,
  "created_at" : "2013-11-11 20:35:15 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodeKnockout",
      "indices" : [ 109, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/HYI0TDP2Yd",
      "expanded_url" : "http:\/\/youtu.be\/7siwcxicfBo",
      "display_url" : "youtu.be\/7siwcxicfBo"
    }, {
      "indices" : [ 85, 107 ],
      "url" : "http:\/\/t.co\/RarIYfhjgy",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com\/",
      "display_url" : "los-manos.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "399996339129307136",
  "text" : "Here is a screencast about our webcam image animation studio http:\/\/t.co\/HYI0TDP2Yd\n\nhttp:\/\/t.co\/RarIYfhjgy\n\n#nodeKnockout",
  "id" : 399996339129307136,
  "created_at" : "2013-11-11 20:25:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/399995539229396992\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/claNyZdP85",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY0R0twCUAA5xvI.png",
      "id_str" : "399995539237785600",
      "id" : 399995539237785600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY0R0twCUAA5xvI.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/claNyZdP85"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/RarIYfhjgy",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com\/",
      "display_url" : "los-manos.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "399995539229396992",
  "text" : "Fisheye 1 - Mine &amp; M.C. Escher\n\ncreated with http:\/\/t.co\/RarIYfhjgy\n\n# http:\/\/t.co\/claNyZdP85",
  "id" : 399995539229396992,
  "created_at" : "2013-11-11 20:22:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/399995357750231040\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/YeONK9F31d",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BY0RqJrCAAAybko.png",
      "id_str" : "399995357754425344",
      "id" : 399995357754425344,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BY0RqJrCAAAybko.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/YeONK9F31d"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/RarIYfhjgy",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com\/",
      "display_url" : "los-manos.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "399995357750231040",
  "text" : "Fisheye - Mine &amp; M.C. Escher\n\ncreated with http:\/\/t.co\/RarIYfhjgy\n\n# http:\/\/t.co\/YeONK9F31d",
  "id" : 399995357750231040,
  "created_at" : "2013-11-11 20:21:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/RarIYfhjgy",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com\/",
      "display_url" : "los-manos.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "399985198198059008",
  "text" : "HEY IF YOU WANT TO TRY MY WEBCAM ANIMATION STUDIO APP HOLLA AT ME \n\nhttp:\/\/t.co\/RarIYfhjgy",
  "id" : 399985198198059008,
  "created_at" : "2013-11-11 19:41:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 3, 18 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399932162780061696",
  "text" : "RT @libertymadison: You can close your eyes to the things you don't want to see, but you can't close your heart to the things you don't wan\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "399807438179688450",
    "text" : "You can close your eyes to the things you don't want to see, but you can't close your heart to the things you don't want to feel Johnny Deep",
    "id" : 399807438179688450,
    "created_at" : "2013-11-11 07:54:56 +0000",
    "user" : {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "protected" : false,
      "id_str" : "16163167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428817500285849601\/PSaV1pXZ_normal.jpeg",
      "id" : 16163167,
      "verified" : false
    }
  },
  "id" : 399932162780061696,
  "created_at" : "2013-11-11 16:10:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399792020471836672",
  "text" : "we all hmm n",
  "id" : 399792020471836672,
  "created_at" : "2013-11-11 06:53:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399787595292372992",
  "text" : "i am realer than u\n&amp;so it is with u\ni aint mad at u for it \ni is a bore\nu is aint i\ni n u\nwhere n be like n'\nwhich got us n a loop\nwitchgod!",
  "id" : 399787595292372992,
  "created_at" : "2013-11-11 06:36:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/TiV1V66QxU",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com",
      "display_url" : "los-manos.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "399766484517265408",
  "text" : "48 hours\n20 fingers \n4 hands \n2 men \nLos Manos give you: \nhttp:\/\/t.co\/TiV1V66QxU",
  "id" : 399766484517265408,
  "created_at" : "2013-11-11 05:12:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/399763298876268544\/photo\/1",
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/jNpW9pATR1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYw-mjBCIAAsphL.png",
      "id_str" : "399763298884657152",
      "id" : 399763298884657152,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYw-mjBCIAAsphL.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/jNpW9pATR1"
    } ],
    "hashtags" : [ {
      "text" : "selfie",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/oOw3Mq6AsQ",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com\/edit\/selfie",
      "display_url" : "los-manos.2013.nodeknockout.com\/edit\/selfie"
    } ]
  },
  "geo" : { },
  "id_str" : "399763298876268544",
  "text" : "#selfie \n\nhttp:\/\/t.co\/oOw3Mq6AsQ\n\n# http:\/\/t.co\/jNpW9pATR1",
  "id" : 399763298876268544,
  "created_at" : "2013-11-11 04:59:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/399758469252673537\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/tgXy6PDiq0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYw6NbRCcAA8kkL.png",
      "id_str" : "399758469261062144",
      "id" : 399758469261062144,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYw6NbRCcAA8kkL.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/tgXy6PDiq0"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/RarIYfhjgy",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com\/",
      "display_url" : "los-manos.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "399758469252673537",
  "text" : "double exposure \nvia http:\/\/t.co\/RarIYfhjgy http:\/\/t.co\/tgXy6PDiq0",
  "id" : 399758469252673537,
  "created_at" : "2013-11-11 04:40:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399744390752514049",
  "text" : "Hackathon over but I'm still hackin on the inside.",
  "id" : 399744390752514049,
  "created_at" : "2013-11-11 03:44:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/399732506326347777\/photo\/1",
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/fBDHUpcTgh",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYwimL1CMAA2u3n.png",
      "id_str" : "399732506334736384",
      "id" : 399732506334736384,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYwimL1CMAA2u3n.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/fBDHUpcTgh"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/HBDevhLTpB",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com\/edit\/NKO",
      "display_url" : "los-manos.2013.nodeknockout.com\/edit\/NKO"
    } ]
  },
  "geo" : { },
  "id_str" : "399732506326347777",
  "text" : "multiple exposure, cubism, made with http:\/\/t.co\/HBDevhLTpB http:\/\/t.co\/fBDHUpcTgh",
  "id" : 399732506326347777,
  "created_at" : "2013-11-11 02:57:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/399695130531090432\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/Yck2VPxj1h",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYwAmoICUAA3-ta.png",
      "id_str" : "399695130535284736",
      "id" : 399695130535284736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYwAmoICUAA3-ta.png",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/Yck2VPxj1h"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/TiV1V66QxU",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com",
      "display_url" : "los-manos.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "399695130531090432",
  "text" : "you can take multiple exposure pics with http:\/\/t.co\/TiV1V66QxU http:\/\/t.co\/Yck2VPxj1h",
  "id" : 399695130531090432,
  "created_at" : "2013-11-11 00:28:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 7, 15 ],
      "id_str" : "16893912",
      "id" : 16893912
    }, {
      "name" : "Node Knockout",
      "screen_name" : "node_knockout",
      "indices" : [ 51, 65 ],
      "id_str" : "148922824",
      "id" : 148922824
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 49 ],
      "url" : "http:\/\/t.co\/RarIYfhjgy",
      "expanded_url" : "http:\/\/los-manos.2013.nodeknockout.com\/",
      "display_url" : "los-manos.2013.nodeknockout.com"
    } ]
  },
  "geo" : { },
  "id_str" : "399693518953652224",
  "text" : "me and @soldair made this! http:\/\/t.co\/RarIYfhjgy .@node_knockout",
  "id" : 399693518953652224,
  "created_at" : "2013-11-11 00:22:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/399423982996176896\/photo\/1",
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/nFaV3zXpcm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYsJ_w2CQAItC5X.png",
      "id_str" : "399423983000371202",
      "id" : 399423983000371202,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYsJ_w2CQAItC5X.png",
      "sizes" : [ {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 573
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 573
      }, {
        "h" : 432,
        "resize" : "fit",
        "w" : 573
      } ],
      "display_url" : "pic.twitter.com\/nFaV3zXpcm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399423982996176896",
  "text" : "intstergram# http:\/\/t.co\/nFaV3zXpcm",
  "id" : 399423982996176896,
  "created_at" : "2013-11-10 06:31:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/399360832070373376\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/GEPRd7nVit",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYrQj5UCUAAQKYK.png",
      "id_str" : "399360832074567680",
      "id" : 399360832074567680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYrQj5UCUAAQKYK.png",
      "sizes" : [ {
        "h" : 192,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 722,
        "resize" : "fit",
        "w" : 1273
      }, {
        "h" : 580,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/GEPRd7nVit"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399360832070373376",
  "text" : "http:\/\/t.co\/GEPRd7nVit",
  "id" : 399360832070373376,
  "created_at" : "2013-11-10 02:20:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/399352113945276417\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/6McAai2Y50",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYrIobxCcAAXBaN.png",
      "id_str" : "399352113949470720",
      "id" : 399352113949470720,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYrIobxCcAAXBaN.png",
      "sizes" : [ {
        "h" : 418,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 237,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 886,
        "resize" : "fit",
        "w" : 1271
      }, {
        "h" : 713,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6McAai2Y50"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399352113945276417",
  "text" : "zone n!\nwhere n is what yr mind is about http:\/\/t.co\/6McAai2Y50",
  "id" : 399352113945276417,
  "created_at" : "2013-11-10 01:45:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399091972419244033",
  "text" : "Call me Hellen Keller.  This the making of a storyteller.",
  "id" : 399091972419244033,
  "created_at" : "2013-11-09 08:31:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/399091141405978624\/photo\/1",
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/A5bjX58M4E",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BYnbR1UCMAAcHrt.png",
      "id_str" : "399091141414367232",
      "id" : 399091141414367232,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BYnbR1UCMAAcHrt.png",
      "sizes" : [ {
        "h" : 918,
        "resize" : "fit",
        "w" : 1163
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 808,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/A5bjX58M4E"
    } ],
    "hashtags" : [ {
      "text" : "NKO",
      "indices" : [ 12, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399091141405978624",
  "text" : "test screen #NKO http:\/\/t.co\/A5bjX58M4E",
  "id" : 399091141405978624,
  "created_at" : "2013-11-09 08:28:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399089229138911233",
  "text" : "emitter.om('')",
  "id" : 399089229138911233,
  "created_at" : "2013-11-09 08:21:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399082733382553600",
  "text" : "DEPLOYING STATIC",
  "id" : 399082733382553600,
  "created_at" : "2013-11-09 07:55:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GIT",
      "indices" : [ 9, 13 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399080173103902720",
  "text" : "I OUSHED #GIT",
  "id" : 399080173103902720,
  "created_at" : "2013-11-09 07:45:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399070669507284992",
  "text" : "I ain't afraid o no globles",
  "id" : 399070669507284992,
  "created_at" : "2013-11-09 07:07:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399055813987168256",
  "text" : "LO PODEMOS\nBAMOS LOS MANOS",
  "id" : 399055813987168256,
  "created_at" : "2013-11-09 06:08:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399054977122832384",
  "text" : "I often get confused between x and y",
  "id" : 399054977122832384,
  "created_at" : "2013-11-09 06:04:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "399040751696236544",
  "text" : "zug fuck",
  "id" : 399040751696236544,
  "created_at" : "2013-11-09 05:08:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398887419249840128",
  "text" : "Girlfriend, here's a pen, call me 10am, come through, break fast on rugs that's Persian.",
  "id" : 398887419249840128,
  "created_at" : "2013-11-08 18:59:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/XIMFgU1j63",
      "expanded_url" : "http:\/\/designinstruct.com\/tool\/responsive-html-email-framework-zurb-ink\/",
      "display_url" : "designinstruct.com\/tool\/responsiv\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "398642594160201729",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison email template thing http:\/\/t.co\/XIMFgU1j63",
  "id" : 398642594160201729,
  "created_at" : "2013-11-08 02:46:15 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398636006179491840",
  "geo" : { },
  "id_str" : "398636285218152448",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison no la tengo",
  "id" : 398636285218152448,
  "in_reply_to_status_id" : 398636006179491840,
  "created_at" : "2013-11-08 02:21:11 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398635452602658817",
  "geo" : { },
  "id_str" : "398635806614495234",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison no, I can do naught with thatbook until I get a bootdisc.",
  "id" : 398635806614495234,
  "in_reply_to_status_id" : 398635452602658817,
  "created_at" : "2013-11-08 02:19:17 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398634266860322816",
  "geo" : { },
  "id_str" : "398635162440704000",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison i found a working, albeit very dim, webcam.  I have options. banjo dingalinging is the soundtrack of my existence right now.",
  "id" : 398635162440704000,
  "in_reply_to_status_id" : 398634266860322816,
  "created_at" : "2013-11-08 02:16:43 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398626438980452352",
  "geo" : { },
  "id_str" : "398633979525353472",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison lolseyes",
  "id" : 398633979525353472,
  "in_reply_to_status_id" : 398626438980452352,
  "created_at" : "2013-11-08 02:12:01 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398633257522036738",
  "text" : "throw them lols",
  "id" : 398633257522036738,
  "created_at" : "2013-11-08 02:09:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398628157168685056",
  "text" : "so shit",
  "id" : 398628157168685056,
  "created_at" : "2013-11-08 01:48:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/diZqHR0gCw",
      "expanded_url" : "http:\/\/jnordberg.github.io\/gif.js\/",
      "display_url" : "jnordberg.github.io\/gif.js\/"
    } ]
  },
  "in_reply_to_status_id_str" : "398543600796958720",
  "geo" : { },
  "id_str" : "398554486576140288",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight neat.  see also http:\/\/t.co\/diZqHR0gCw",
  "id" : 398554486576140288,
  "in_reply_to_status_id" : 398543600796958720,
  "created_at" : "2013-11-07 20:56:09 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "less_cunning",
      "screen_name" : "less_cunning",
      "indices" : [ 3, 16 ],
      "id_str" : "14259966",
      "id" : 14259966
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 85, 93 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/ya8e4tsDxM",
      "expanded_url" : "http:\/\/youtu.be\/TS8sSpQL-Rs",
      "display_url" : "youtu.be\/TS8sSpQL-Rs"
    } ]
  },
  "geo" : { },
  "id_str" : "398533022598721536",
  "text" : "RT @less_cunning: Ultramagnetic MCs - One, Two, One, Two: http:\/\/t.co\/ya8e4tsDxM via @youtube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 67, 75 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/ya8e4tsDxM",
        "expanded_url" : "http:\/\/youtu.be\/TS8sSpQL-Rs",
        "display_url" : "youtu.be\/TS8sSpQL-Rs"
      } ]
    },
    "geo" : { },
    "id_str" : "398531799548039168",
    "text" : "Ultramagnetic MCs - One, Two, One, Two: http:\/\/t.co\/ya8e4tsDxM via @youtube",
    "id" : 398531799548039168,
    "created_at" : "2013-11-07 19:26:00 +0000",
    "user" : {
      "name" : "less_cunning",
      "screen_name" : "less_cunning",
      "protected" : false,
      "id_str" : "14259966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484048574393491456\/5iARZBwB_normal.jpeg",
      "id" : 14259966,
      "verified" : false
    }
  },
  "id" : 398533022598721536,
  "created_at" : "2013-11-07 19:30:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398528372755558400",
  "text" : "shows you how little a billion is worth.  How much is a loaf of bread, 10K?",
  "id" : 398528372755558400,
  "created_at" : "2013-11-07 19:12:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398406021091041280",
  "text" : "conjuring multiplicities, and divising.",
  "id" : 398406021091041280,
  "created_at" : "2013-11-07 11:06:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398265571407450112",
  "text" : "Hashtags are all meta adjectives.",
  "id" : 398265571407450112,
  "created_at" : "2013-11-07 01:48:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "adjective",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398263752442671104",
  "text" : "#adjective",
  "id" : 398263752442671104,
  "created_at" : "2013-11-07 01:40:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Gruber",
      "screen_name" : "juliangruber",
      "indices" : [ 0, 13 ],
      "id_str" : "324544130",
      "id" : 324544130
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 14, 23 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Tiago Rodrigues ",
      "screen_name" : "trodrigues",
      "indices" : [ 24, 35 ],
      "id_str" : "6477652",
      "id" : 6477652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 116 ],
      "url" : "https:\/\/t.co\/1vpS3GdzLP",
      "expanded_url" : "https:\/\/github.com\/NHQ\/opa\/blob\/master\/index.js#L74",
      "display_url" : "github.com\/NHQ\/opa\/blob\/m\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "398188666696126464",
  "geo" : { },
  "id_str" : "398190353548722176",
  "in_reply_to_user_id" : 324544130,
  "text" : "@juliangruber @substack @trodrigues I double checked now, yes it does.  This is how I do it: https:\/\/t.co\/1vpS3GdzLP",
  "id" : 398190353548722176,
  "in_reply_to_status_id" : 398188666696126464,
  "created_at" : "2013-11-06 20:49:12 +0000",
  "in_reply_to_screen_name" : "juliangruber",
  "in_reply_to_user_id_str" : "324544130",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398177630824177664",
  "geo" : { },
  "id_str" : "398185998577713152",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison you abuse the social media already!  also social media pros don't know shit!",
  "id" : 398185998577713152,
  "in_reply_to_status_id" : 398177630824177664,
  "created_at" : "2013-11-06 20:31:54 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398160540599476225",
  "text" : "so butter cheese and ice cream",
  "id" : 398160540599476225,
  "created_at" : "2013-11-06 18:50:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398138544381648896",
  "text" : "these chickens are gonna get it",
  "id" : 398138544381648896,
  "created_at" : "2013-11-06 17:23:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julian Gruber",
      "screen_name" : "juliangruber",
      "indices" : [ 0, 13 ],
      "id_str" : "324544130",
      "id" : 324544130
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 14, 23 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Tiago Rodrigues ",
      "screen_name" : "trodrigues",
      "indices" : [ 24, 35 ],
      "id_str" : "6477652",
      "id" : 6477652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "398117020052369408",
  "geo" : { },
  "id_str" : "398118385348644864",
  "in_reply_to_user_id" : 324544130,
  "text" : "@juliangruber @substack @trodrigues \nwatchify works reliably for me, bundling only halts when I introduce an error.",
  "id" : 398118385348644864,
  "in_reply_to_status_id" : 398117020052369408,
  "created_at" : "2013-11-06 16:03:14 +0000",
  "in_reply_to_screen_name" : "juliangruber",
  "in_reply_to_user_id_str" : "324544130",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "398116098698006529",
  "text" : "Another day another eat",
  "id" : 398116098698006529,
  "created_at" : "2013-11-06 15:54:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "remix",
      "indices" : [ 38, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397986399908950016",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison a blue dress instead? #remix",
  "id" : 397986399908950016,
  "created_at" : "2013-11-06 07:18:46 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397977948398960640",
  "geo" : { },
  "id_str" : "397981384586719232",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison \nYou better get dance n in the mirror! \nWhere \"n\" is one of many movements, and \"the mirror\" is repetition.",
  "id" : 397981384586719232,
  "in_reply_to_status_id" : 397977948398960640,
  "created_at" : "2013-11-06 06:58:50 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397974792361373696",
  "geo" : { },
  "id_str" : "397977096925876224",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison +1 red dress, +1 green screen  ;^D",
  "id" : 397977096925876224,
  "in_reply_to_status_id" : 397974792361373696,
  "created_at" : "2013-11-06 06:41:48 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397958825992396800",
  "geo" : { },
  "id_str" : "397972997161504768",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison Give me 3 hats, 3 glasses, 3 cups, and 3 mustaches; and I'll play 3 x 5 males, each one attracted.",
  "id" : 397972997161504768,
  "in_reply_to_status_id" : 397958825992396800,
  "created_at" : "2013-11-06 06:25:31 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 0, 12 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397520754340020225",
  "geo" : { },
  "id_str" : "397581880247070720",
  "in_reply_to_user_id" : 46961216,
  "text" : "@astromanies hey it uploaded, neat.  This was taken in Phildelphia.",
  "id" : 397581880247070720,
  "in_reply_to_status_id" : 397520754340020225,
  "created_at" : "2013-11-05 04:31:21 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/vine.co\" rel=\"nofollow\"\u003EVine for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 38 ],
      "url" : "https:\/\/t.co\/bPXUiSbNoe",
      "expanded_url" : "https:\/\/vine.co\/v\/hjQDlFYLnaq",
      "display_url" : "vine.co\/v\/hjQDlFYLnaq"
    } ]
  },
  "geo" : { },
  "id_str" : "397520754340020225",
  "text" : "post-obsession https:\/\/t.co\/bPXUiSbNoe",
  "id" : 397520754340020225,
  "created_at" : "2013-11-05 00:28:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397233755267416064",
  "text" : "It's feasting season!",
  "id" : 397233755267416064,
  "created_at" : "2013-11-04 05:28:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397196627112251392",
  "text" : "Before there was disco, there was Banjo.",
  "id" : 397196627112251392,
  "created_at" : "2013-11-04 03:00:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397190129703333888",
  "text" : "SMASHING DATA",
  "id" : 397190129703333888,
  "created_at" : "2013-11-04 02:34:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "397175037599313920",
  "geo" : { },
  "id_str" : "397185566220886016",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost  I may have contracted mustache from this picture!",
  "id" : 397185566220886016,
  "in_reply_to_status_id" : 397175037599313920,
  "created_at" : "2013-11-04 02:16:32 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakland",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "397122687857725442",
  "text" : "we have a room for rent in our hacker house - furnished, clean, quiet, lovely #oakland",
  "id" : 397122687857725442,
  "created_at" : "2013-11-03 22:06:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homeCoookin",
      "indices" : [ 43, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/dQdtgutT5X",
      "expanded_url" : "http:\/\/instagram.com\/p\/gQ44zaD5YY\/",
      "display_url" : "instagram.com\/p\/gQ44zaD5YY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "397080153274454016",
  "text" : "Crepes, kale, onions, and wild mushrooms.  #homeCoookin http:\/\/t.co\/dQdtgutT5X",
  "id" : 397080153274454016,
  "created_at" : "2013-11-03 19:17:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396883254432628737",
  "text" : "It's not what I know.  \nIt's what I do, with what I know!",
  "id" : 396883254432628737,
  "created_at" : "2013-11-03 06:15:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/QXmSu8eAHm",
      "expanded_url" : "http:\/\/wesley.nnu.edu\/fileadmin\/imported_site\/biblical_studies\/wycliffe\/Mat.txt",
      "display_url" : "wesley.nnu.edu\/fileadmin\/impo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "396873111464734720",
  "text" : "\"Wise men\" in old english: astromyenes; modern: astral\/astro-men. \n\nCh. 2, ln. 1:  http:\/\/t.co\/QXmSu8eAHm\n\nThey studied myriad astromanies.",
  "id" : 396873111464734720,
  "created_at" : "2013-11-03 05:34:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396817633070178304",
  "text" : "Get n busy!  Where n = some labor of love.",
  "id" : 396817633070178304,
  "created_at" : "2013-11-03 01:54:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "losFelizMuertos",
      "indices" : [ 0, 16 ]
    } ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/YwhpU8i3Or",
      "expanded_url" : "http:\/\/instagram.com\/p\/gO08Whj5bO\/",
      "display_url" : "instagram.com\/p\/gO08Whj5bO\/"
    } ]
  },
  "geo" : { },
  "id_str" : "396789915985649664",
  "text" : "#losFelizMuertos http:\/\/t.co\/YwhpU8i3Or",
  "id" : 396789915985649664,
  "created_at" : "2013-11-03 00:04:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "losMuertos",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/wZCkJl7vxE",
      "expanded_url" : "http:\/\/instagram.com\/p\/gO0wyFj5a0\/",
      "display_url" : "instagram.com\/p\/gO0wyFj5a0\/"
    } ]
  },
  "geo" : { },
  "id_str" : "396789371955085312",
  "text" : "#losMuertos http:\/\/t.co\/wZCkJl7vxE",
  "id" : 396789371955085312,
  "created_at" : "2013-11-03 00:02:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "losMuertos",
      "indices" : [ 0, 11 ]
    }, {
      "text" : "homocides",
      "indices" : [ 12, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/V1n6uDUYm9",
      "expanded_url" : "http:\/\/instagram.com\/p\/gO0XEij5aK\/",
      "display_url" : "instagram.com\/p\/gO0XEij5aK\/"
    } ]
  },
  "geo" : { },
  "id_str" : "396788633954713600",
  "text" : "#losMuertos #homocides http:\/\/t.co\/V1n6uDUYm9",
  "id" : 396788633954713600,
  "created_at" : "2013-11-02 23:59:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "losMuertos",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/dXTdGKTK6a",
      "expanded_url" : "http:\/\/instagram.com\/p\/gO0DNlD5Zp\/",
      "display_url" : "instagram.com\/p\/gO0DNlD5Zp\/"
    } ]
  },
  "geo" : { },
  "id_str" : "396787825875902464",
  "text" : "#losMuertos http:\/\/t.co\/dXTdGKTK6a",
  "id" : 396787825875902464,
  "created_at" : "2013-11-02 23:56:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "losMuertos",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ {
      "indices" : [ 12, 34 ],
      "url" : "http:\/\/t.co\/TislqlH7bC",
      "expanded_url" : "http:\/\/instagram.com\/p\/gOz0_bD5ZR\/",
      "display_url" : "instagram.com\/p\/gOz0_bD5ZR\/"
    } ]
  },
  "geo" : { },
  "id_str" : "396787415240966144",
  "text" : "#losMuertos http:\/\/t.co\/TislqlH7bC",
  "id" : 396787415240966144,
  "created_at" : "2013-11-02 23:54:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396779738875707394",
  "text" : "This 15 man band is 2\/3 horns!",
  "id" : 396779738875707394,
  "created_at" : "2013-11-02 23:23:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396779593631150081",
  "text" : "Arriba Los Muertos!",
  "id" : 396779593631150081,
  "created_at" : "2013-11-02 23:23:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396766011589812225",
  "text" : "Dia de Los Muertos in Fruitvale is a huge festival!",
  "id" : 396766011589812225,
  "created_at" : "2013-11-02 22:29:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396734305105219584",
  "geo" : { },
  "id_str" : "396734622186225664",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison  I am.  I am gonna see the Dia de Los Muertos fest at the fruitvale stop.  Want to meet me there, or elsehwere later?",
  "id" : 396734622186225664,
  "in_reply_to_status_id" : 396734305105219584,
  "created_at" : "2013-11-02 20:24:39 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396733733484515329",
  "geo" : { },
  "id_str" : "396734370800603136",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison You got it, woman, let's do things!",
  "id" : 396734370800603136,
  "in_reply_to_status_id" : 396733733484515329,
  "created_at" : "2013-11-02 20:23:39 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396733260325081088",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertymadison let's get together and talk about doing things!",
  "id" : 396733260325081088,
  "created_at" : "2013-11-02 20:19:14 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396711895555510273",
  "text" : "\"Stop the violence, increase the peace, get these thugs up off the streets!\"  - Crowd at Fruitvale \/ MacArthur",
  "id" : 396711895555510273,
  "created_at" : "2013-11-02 18:54:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396693284292001794",
  "text" : "Estamos Los Manos!",
  "id" : 396693284292001794,
  "created_at" : "2013-11-02 17:40:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396668212013572096",
  "text" : "Dia de los Muertos festival today at Fruitvale village.",
  "id" : 396668212013572096,
  "created_at" : "2013-11-02 16:00:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "uhh",
      "indices" : [ 27, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396540789632692224",
  "text" : "can't update; won't update #uhh",
  "id" : 396540789632692224,
  "created_at" : "2013-11-02 07:34:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396538556924973056",
  "text" : "all my computers are belong in the garbage",
  "id" : 396538556924973056,
  "created_at" : "2013-11-02 07:25:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396493626160590848",
  "text" : "BART doesn't run late enough.",
  "id" : 396493626160590848,
  "created_at" : "2013-11-02 04:27:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sam Pullara",
      "screen_name" : "sampullara",
      "indices" : [ 0, 11 ],
      "id_str" : "668473",
      "id" : 668473
    }, {
      "name" : "Cian \u00D3 Maid\u00EDn",
      "screen_name" : "Cianomaidin",
      "indices" : [ 12, 24 ],
      "id_str" : "23092438",
      "id" : 23092438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "396350126253305856",
  "geo" : { },
  "id_str" : "396360591343755264",
  "in_reply_to_user_id" : 668473,
  "text" : "@sampullara @Cianomaidin That would be a dysphemism.",
  "id" : 396360591343755264,
  "in_reply_to_status_id" : 396350126253305856,
  "created_at" : "2013-11-01 19:38:23 +0000",
  "in_reply_to_screen_name" : "sampullara",
  "in_reply_to_user_id_str" : "668473",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 3, 18 ],
      "id_str" : "16163167",
      "id" : 16163167
    }, {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 24, 36 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396356794370359296",
  "text" : "RT @libertymadison: RT \"@astromanies: How do you decide if it's what you know or what you believe?\" &lt; I know that you're awesome!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "astromanies",
        "screen_name" : "astromanies",
        "indices" : [ 4, 16 ],
        "id_str" : "2588933322",
        "id" : 2588933322
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "396134786013466624",
    "text" : "RT \"@astromanies: How do you decide if it's what you know or what you believe?\" &lt; I know that you're awesome!",
    "id" : 396134786013466624,
    "created_at" : "2013-11-01 04:41:07 +0000",
    "user" : {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "protected" : false,
      "id_str" : "16163167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/428817500285849601\/PSaV1pXZ_normal.jpeg",
      "id" : 16163167,
      "verified" : false
    }
  },
  "id" : 396356794370359296,
  "created_at" : "2013-11-01 19:23:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396355983624003584",
  "text" : "~$ ln -s antics",
  "id" : 396355983624003584,
  "created_at" : "2013-11-01 19:20:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396158516081070080",
  "text" : "An idea is a perfectly acceptable costume for wearing in celebration of the assumed dead.",
  "id" : 396158516081070080,
  "created_at" : "2013-11-01 06:15:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396156641856331776",
  "text" : "CALL THYSELF OUT HO!",
  "id" : 396156641856331776,
  "created_at" : "2013-11-01 06:07:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396152900998557696",
  "text" : "I'm a beautiful, scienstitious, obgnostic, monk degree wizard.",
  "id" : 396152900998557696,
  "created_at" : "2013-11-01 05:53:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396141135829028864",
  "text" : ":^  \u2022",
  "id" : 396141135829028864,
  "created_at" : "2013-11-01 05:06:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#ThatTechGirl",
      "screen_name" : "libertymadison",
      "indices" : [ 0, 15 ],
      "id_str" : "16163167",
      "id" : 16163167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396140449066283008",
  "in_reply_to_user_id" : 16163167,
  "text" : "@libertyMadison I'm speak to tweetless",
  "id" : 396140449066283008,
  "created_at" : "2013-11-01 05:03:37 +0000",
  "in_reply_to_screen_name" : "libertymadison",
  "in_reply_to_user_id_str" : "16163167",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396132603360595969",
  "text" : "How do you decide if it's what you know or what you believe?",
  "id" : 396132603360595969,
  "created_at" : "2013-11-01 04:32:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "396052700493672448",
  "text" : "You wear a costume everyday.  Try to be your true self for Halloween.  Scary!",
  "id" : 396052700493672448,
  "created_at" : "2013-10-31 23:14:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]