Grailbird.data.tweets_2012_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/kJn9vb9I",
      "expanded_url" : "http:\/\/www.oaklandbudgetchallenge.com\/",
      "display_url" : "oaklandbudgetchallenge.com"
    } ]
  },
  "geo" : { },
  "id_str" : "263522353496068096",
  "text" : "I balanced the Oakland budget (+ 6M) by cutting Police and General Bureaucracy, and nothing else http:\/\/t.co\/kJn9vb9I",
  "id" : 263522353496068096,
  "created_at" : "2012-10-31 06:06:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263483392459419651",
  "text" : "I hope Disney buys Kiss, Metallica and Eminem next.",
  "id" : 263483392459419651,
  "created_at" : "2012-10-31 03:31:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sandy",
      "indices" : [ 74, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263107490210799617",
  "text" : "Who will pick up the schmoozing and hob nobbling slack while NYC is down? #sandy",
  "id" : 263107490210799617,
  "created_at" : "2012-10-30 02:38:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "263066737421991936",
  "geo" : { },
  "id_str" : "263067467910369280",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar is that your cost or retail, and when will they be available????",
  "id" : 263067467910369280,
  "in_reply_to_status_id" : 263066737421991936,
  "created_at" : "2012-10-29 23:59:06 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "263061367609774080",
  "text" : "today I cracked a nut and found two meat",
  "id" : 263061367609774080,
  "created_at" : "2012-10-29 23:34:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 58 ],
      "url" : "https:\/\/t.co\/ZWe9s7Xx",
      "expanded_url" : "https:\/\/github.com\/JensNockert\/fft.js",
      "display_url" : "github.com\/JensNockert\/ff\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "263010551142154240",
  "text" : "Do you know how to use one of these? https:\/\/t.co\/ZWe9s7Xx",
  "id" : 263010551142154240,
  "created_at" : "2012-10-29 20:12:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/ZKBBgrmt",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=njos57IJf-0&feature=relmfu",
      "display_url" : "youtube.com\/watch?v=njos57\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "262999586006781953",
  "text" : "\"I stomp on a mac and PC too, i'm on linux bitch, I thought you GNU\" http:\/\/t.co\/ZKBBgrmt",
  "id" : 262999586006781953,
  "created_at" : "2012-10-29 19:29:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 0, 11 ],
      "id_str" : "47951511",
      "id" : 47951511
    }, {
      "name" : "Karen Gregory, PhD",
      "screen_name" : "claudiakincaid",
      "indices" : [ 12, 27 ],
      "id_str" : "5478002",
      "id" : 5478002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/X6b6SFQM",
      "expanded_url" : "http:\/\/static.echonest.com\/InfiniteGangnamStyle\/",
      "display_url" : "static.echonest.com\/InfiniteGangna\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "262973670467723266",
  "geo" : { },
  "id_str" : "262974619038908418",
  "in_reply_to_user_id" : 47951511,
  "text" : "@zunguzungu @claudiakincaid rain dance http:\/\/t.co\/X6b6SFQM",
  "id" : 262974619038908418,
  "in_reply_to_status_id" : 262973670467723266,
  "created_at" : "2012-10-29 17:50:09 +0000",
  "in_reply_to_screen_name" : "zunguzungu",
  "in_reply_to_user_id_str" : "47951511",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262801237492252672",
  "text" : "RT @IAM_SHAKESPEARE: I do appoint him store of provender.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262800941219192832",
    "text" : "I do appoint him store of provender.",
    "id" : 262800941219192832,
    "created_at" : "2012-10-29 06:20:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 262801237492252672,
  "created_at" : "2012-10-29 06:21:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262647561679147008",
  "text" : "AHH COLONEL GRUNTZENSPLATZ",
  "id" : 262647561679147008,
  "created_at" : "2012-10-28 20:10:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sports Motivation",
      "screen_name" : "Sports_HQ",
      "indices" : [ 3, 13 ],
      "id_str" : "139986343",
      "id" : 139986343
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262443857206190080",
  "text" : "RT @Sports_HQ: Exercise in the morning before your brain figures out what you're doing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "262387629864124416",
    "text" : "Exercise in the morning before your brain figures out what you're doing.",
    "id" : 262387629864124416,
    "created_at" : "2012-10-28 02:57:40 +0000",
    "user" : {
      "name" : "Sports Motivation",
      "screen_name" : "Sports_HQ",
      "protected" : false,
      "id_str" : "139986343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2679035753\/b0d2eb7d0b01e7381bd8ca944b055f60_normal.jpeg",
      "id" : 139986343,
      "verified" : false
    }
  },
  "id" : 262443857206190080,
  "created_at" : "2012-10-28 06:41:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262427889570545664",
  "text" : "So many losing attempts to use any number of FFT juicers, but getting closer.",
  "id" : 262427889570545664,
  "created_at" : "2012-10-28 05:37:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/fmQy7FX0",
      "expanded_url" : "http:\/\/beerontherug.bandcamp.com\/",
      "display_url" : "beerontherug.bandcamp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "262336210016542720",
  "text" : "damn I am going to listen to them all http:\/\/t.co\/fmQy7FX0",
  "id" : 262336210016542720,
  "created_at" : "2012-10-27 23:33:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/gFXCHC0D",
      "expanded_url" : "http:\/\/beerontherug.bandcamp.com\/album\/floral-shoppe",
      "display_url" : "beerontherug.bandcamp.com\/album\/floral-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "262335148077494273",
  "text" : "you will probably enjoy this http:\/\/t.co\/gFXCHC0D",
  "id" : 262335148077494273,
  "created_at" : "2012-10-27 23:29:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262331747553931264",
  "text" : "i just discovered a new genre of music called vaporwave",
  "id" : 262331747553931264,
  "created_at" : "2012-10-27 23:15:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Racial Ghoul ",
      "screen_name" : "LouMinoti",
      "indices" : [ 0, 10 ],
      "id_str" : "262151877",
      "id" : 262151877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262322816806965248",
  "geo" : { },
  "id_str" : "262324160934576128",
  "in_reply_to_user_id" : 262151877,
  "text" : "@LouMinoti WASH THE THRONE",
  "id" : 262324160934576128,
  "in_reply_to_status_id" : 262322816806965248,
  "created_at" : "2012-10-27 22:45:28 +0000",
  "in_reply_to_screen_name" : "LouMinoti",
  "in_reply_to_user_id_str" : "262151877",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262286908086951937",
  "text" : "TIME IS A MEASUREMENT OF LENGTH \/\/ MAY ALL YOUR MONEY BE LONG",
  "id" : 262286908086951937,
  "created_at" : "2012-10-27 20:17:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262271614304006144",
  "text" : "words are your thought curves",
  "id" : 262271614304006144,
  "created_at" : "2012-10-27 19:16:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262072075412455424",
  "text" : "I challenge you to a game of rap battle chess.",
  "id" : 262072075412455424,
  "created_at" : "2012-10-27 06:03:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262059095979352065",
  "text" : "copped me some of those moves",
  "id" : 262059095979352065,
  "created_at" : "2012-10-27 05:12:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "262058734761693184",
  "text" : "that's that Arabian grandpa techno dancing FYI",
  "id" : 262058734761693184,
  "created_at" : "2012-10-27 05:10:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Jones",
      "screen_name" : "riverofdoubt",
      "indices" : [ 0, 13 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/ArnBYs8o",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=ZaHte8TnAqkbt",
      "display_url" : "youtube.com\/watch?v=ZaHte8\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "262056735949324288",
  "geo" : { },
  "id_str" : "262058363309916160",
  "in_reply_to_user_id" : 97794798,
  "text" : "@riverofdoubt and do like http:\/\/t.co\/ArnBYs8o",
  "id" : 262058363309916160,
  "in_reply_to_status_id" : 262056735949324288,
  "created_at" : "2012-10-27 05:09:17 +0000",
  "in_reply_to_screen_name" : "riverofdoubt",
  "in_reply_to_user_id_str" : "97794798",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "indices" : [ 33, 44 ],
      "id_str" : "122112121",
      "id" : 122112121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "262026154431619073",
  "geo" : { },
  "id_str" : "262053790792945664",
  "in_reply_to_user_id" : 122112121,
  "text" : "\"Don't be the pill, be the trip\" @uptownherd",
  "id" : 262053790792945664,
  "in_reply_to_status_id" : 262026154431619073,
  "created_at" : "2012-10-27 04:51:07 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pe\u031Bdr\u0358o\u0327 Te\u0340i\u035Cxei\u0489r\u035E",
      "screen_name" : "pgte",
      "indices" : [ 0, 5 ],
      "id_str" : "16401507",
      "id" : 16401507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261965722039750656",
  "geo" : { },
  "id_str" : "261967532959883264",
  "in_reply_to_user_id" : 16401507,
  "text" : "@pgte gut commit an omelette",
  "id" : 261967532959883264,
  "in_reply_to_status_id" : 261965722039750656,
  "created_at" : "2012-10-26 23:08:21 +0000",
  "in_reply_to_screen_name" : "pgte",
  "in_reply_to_user_id_str" : "16401507",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261966654651633664",
  "text" : "function declare this is stupid function!",
  "id" : 261966654651633664,
  "created_at" : "2012-10-26 23:04:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "javascript",
      "indices" : [ 117, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261966267131518978",
  "text" : "I used to say \"this is stupid\" before  I knew what a context was, and but now I know (Cogito ergo&amp; this == self) #javascript",
  "id" : 261966267131518978,
  "created_at" : "2012-10-26 23:03:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261963858627919872",
  "text" : "wait I mean x",
  "id" : 261963858627919872,
  "created_at" : "2012-10-26 22:53:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261963047046893568",
  "text" : "TILT!",
  "id" : 261963047046893568,
  "created_at" : "2012-10-26 22:50:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261962601636974592",
  "text" : "solve for n",
  "id" : 261962601636974592,
  "created_at" : "2012-10-26 22:48:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/HAQ1tjNg",
      "expanded_url" : "http:\/\/mathworld.wolfram.com\/images\/equations\/Sine\/NumberedEquation4.gif",
      "display_url" : "mathworld.wolfram.com\/images\/equatio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261962541155098624",
  "text" : "uhm if know \"sin x\" is it possible to solve for any http:\/\/t.co\/HAQ1tjNg ?",
  "id" : 261962541155098624,
  "created_at" : "2012-10-26 22:48:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "scriptWriting",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261952081957629952",
  "text" : "#scriptWriting",
  "id" : 261952081957629952,
  "created_at" : "2012-10-26 22:06:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 43 ],
      "url" : "https:\/\/t.co\/qOqqnhYE",
      "expanded_url" : "https:\/\/gist.github.com\/3961822",
      "display_url" : "gist.github.com\/3961822"
    } ]
  },
  "geo" : { },
  "id_str" : "261951983144026113",
  "text" : "Likes how this writes https:\/\/t.co\/qOqqnhYE",
  "id" : 261951983144026113,
  "created_at" : "2012-10-26 22:06:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261921956364943360",
  "text" : "I am not convinced the last decade of internet javascript must continue to work, forever, going forward. Breaker breaker.",
  "id" : 261921956364943360,
  "created_at" : "2012-10-26 20:07:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261897455120035842",
  "text" : "that's that shit I don't care",
  "id" : 261897455120035842,
  "created_at" : "2012-10-26 18:29:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261335227216060417",
  "text" : "socket.pipe(service).pipe(buffer).pipe(socket)",
  "id" : 261335227216060417,
  "created_at" : "2012-10-25 05:15:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261259805069557760",
  "text" : "Is it funny that you have the right to a Doctor at no cost if it's a \"Doctor of Jurisprudence\" (JD) &amp; ur too poor to defend urself in court?",
  "id" : 261259805069557760,
  "created_at" : "2012-10-25 00:16:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261258249918095360",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr how do I keep es.pipeline(in, middle, net.Socket.connection) from ending that last stream on my client?",
  "id" : 261258249918095360,
  "created_at" : "2012-10-25 00:09:55 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "261244311256064000",
  "text" : "I'm not afraid to write more antagonism into my scripts.",
  "id" : 261244311256064000,
  "created_at" : "2012-10-24 23:14:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "261182041918406656",
  "geo" : { },
  "id_str" : "261183150598795264",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden shush the musical is about to start",
  "id" : 261183150598795264,
  "in_reply_to_status_id" : 261182041918406656,
  "created_at" : "2012-10-24 19:11:30 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "anonymous",
      "indices" : [ 42, 52 ]
    } ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/FGHvXyTn",
      "expanded_url" : "http:\/\/www.indybay.org\/uploads\/2012\/09\/12\/unfinished_2012_4print.pdf",
      "display_url" : "indybay.org\/uploads\/2012\/0\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "261153893424168961",
  "text" : "unfinished acts, re anarchists in oakland #anonymous http:\/\/t.co\/FGHvXyTn",
  "id" : 261153893424168961,
  "created_at" : "2012-10-24 17:15:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260966953458479104",
  "text" : "ka ka ka fe fe fe",
  "id" : 260966953458479104,
  "created_at" : "2012-10-24 04:52:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260813782639579136",
  "text" : "man twitter's hater gay for a product roll out and I do not condone the union of man and this soft core technology",
  "id" : 260813782639579136,
  "created_at" : "2012-10-23 18:43:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 22, 34 ],
      "id_str" : "850972790",
      "id" : 850972790
    }, {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 35, 51 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 52, 64 ],
      "id_str" : "557228721",
      "id" : 557228721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260791796014133248",
  "geo" : { },
  "id_str" : "260793318093492224",
  "in_reply_to_user_id" : 850972790,
  "text" : "CAN I SHOOT UR BABIES @TheHatGhost @AngelineGragzin @vrroanhorse",
  "id" : 260793318093492224,
  "in_reply_to_status_id" : 260791796014133248,
  "created_at" : "2012-10-23 17:22:26 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260563663570751488",
  "text" : "The choice of first lady is clear enough.",
  "id" : 260563663570751488,
  "created_at" : "2012-10-23 02:09:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 92, 104 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260562268104835073",
  "geo" : { },
  "id_str" : "260563241082712064",
  "in_reply_to_user_id" : 813286,
  "text" : "\"On a range of issues regarding geo-political demarcations, you have been all over the map\" @BarackObama",
  "id" : 260563241082712064,
  "in_reply_to_status_id" : 260562268104835073,
  "created_at" : "2012-10-23 02:08:12 +0000",
  "in_reply_to_screen_name" : "BarackObama",
  "in_reply_to_user_id_str" : "813286",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260562337566695424",
  "text" : "THAT TEXAS RIGHT TO THE NEXT SEGMENT",
  "id" : 260562337566695424,
  "created_at" : "2012-10-23 02:04:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260561757007933440",
  "text" : "It is actually a problem that a missile to Israel would turn on the war industry. One reason I keep shallow roots...",
  "id" : 260561757007933440,
  "created_at" : "2012-10-23 02:02:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 51 ],
      "url" : "http:\/\/t.co\/9zaZavx1",
      "expanded_url" : "http:\/\/www.heritage.org\/research\/reports\/2012\/07\/~\/media\/Images\/Reports\/2012\/07\/KAI\/specialKAI201218asiannaviesvarybroadlysize750.ashx",
      "display_url" : "heritage.org\/research\/repor\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260559873085939713",
  "text" : "The Philippines has a frigate! http:\/\/t.co\/9zaZavx1",
  "id" : 260559873085939713,
  "created_at" : "2012-10-23 01:54:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE REPUBLICAN DALEK",
      "screen_name" : "RepublicanDalek",
      "indices" : [ 3, 19 ],
      "id_str" : "308900763",
      "id" : 308900763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260558710672343040",
  "text" : "RT @RepublicanDalek: ROMNEY: IRAN HAVING A HYPOTHETICAL NUCLEAR WEAPON IS UNACCEPTABLE. WE WILL ALSO BAN THE DEVELOPMENT OF FLYING CARPE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "260558497421328384",
    "text" : "ROMNEY: IRAN HAVING A HYPOTHETICAL NUCLEAR WEAPON IS UNACCEPTABLE. WE WILL ALSO BAN THE DEVELOPMENT OF FLYING CARPETS AND GENIES!",
    "id" : 260558497421328384,
    "created_at" : "2012-10-23 01:49:21 +0000",
    "user" : {
      "name" : "THE REPUBLICAN DALEK",
      "screen_name" : "RepublicanDalek",
      "protected" : false,
      "id_str" : "308900763",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/511173133517090816\/19ZoONOP_normal.png",
      "id" : 308900763,
      "verified" : false
    }
  },
  "id" : 260558710672343040,
  "created_at" : "2012-10-23 01:50:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260558505646366720",
  "text" : "ISREAL WILL MORPH INTO A TEXAS SIZED HAMMER PUNCH WHEN I PRESS THIS BUTTON",
  "id" : 260558505646366720,
  "created_at" : "2012-10-23 01:49:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260557143994949632",
  "text" : "DOWN-FORWARD-DOWN-FORWARD HI PUNCH",
  "id" : 260557143994949632,
  "created_at" : "2012-10-23 01:43:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260556941875630081",
  "text" : "HE'S TALKING ABOUT HIS MURDER CAPITALISM",
  "id" : 260556941875630081,
  "created_at" : "2012-10-23 01:43:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260556852113330176",
  "text" : "OMG LAST CHANCE",
  "id" : 260556852113330176,
  "created_at" : "2012-10-23 01:42:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260555298878672896",
  "text" : "Why are they making our domestic issue foreign",
  "id" : 260555298878672896,
  "created_at" : "2012-10-23 01:36:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE REPUBLICAN DALEK",
      "screen_name" : "RepublicanDalek",
      "indices" : [ 0, 16 ],
      "id_str" : "308900763",
      "id" : 308900763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260546859272114176",
  "geo" : { },
  "id_str" : "260547036150108160",
  "in_reply_to_user_id" : 308900763,
  "text" : "@RepublicanDalek I WOULD TRADE MY FIRST BORG",
  "id" : 260547036150108160,
  "in_reply_to_status_id" : 260546859272114176,
  "created_at" : "2012-10-23 01:03:48 +0000",
  "in_reply_to_screen_name" : "RepublicanDalek",
  "in_reply_to_user_id_str" : "308900763",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260546396128677889",
  "text" : "I AM SO FUNCTIONAL",
  "id" : 260546396128677889,
  "created_at" : "2012-10-23 01:01:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/cA8ZoLCq",
      "expanded_url" : "http:\/\/www.thenation.com\/article\/167683\/mitt-romneys-neocon-war-cabinet#",
      "display_url" : "thenation.com\/article\/167683\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "260256559622393857",
  "text" : "Here it is MItt Romney's NeoCon War Cabinet. NeoCons are my least favorite Baby Boomers. http:\/\/t.co\/cA8ZoLCq",
  "id" : 260256559622393857,
  "created_at" : "2012-10-22 05:49:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260247353360003072",
  "text" : "I do wonder who the people of the middle east part of the global map back for president",
  "id" : 260247353360003072,
  "created_at" : "2012-10-22 05:12:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260244848597168128",
  "text" : "I like the .save and .load commands in the Node.js REPL, and how it lets me get away with f)( instead of f() sometimes",
  "id" : 260244848597168128,
  "created_at" : "2012-10-22 05:03:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "260209423635599360",
  "geo" : { },
  "id_str" : "260220531738034176",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia judge gonna say I'm lying",
  "id" : 260220531738034176,
  "in_reply_to_status_id" : 260209423635599360,
  "created_at" : "2012-10-22 03:26:24 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "260208906972835840",
  "text" : "I meant to type telnet. Instead I typed telbert",
  "id" : 260208906972835840,
  "created_at" : "2012-10-22 02:40:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "259829271395201024",
  "geo" : { },
  "id_str" : "259857332215889920",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk BEHOLD THE MYTHIC WIG o' BRILLO",
  "id" : 259857332215889920,
  "in_reply_to_status_id" : 259829271395201024,
  "created_at" : "2012-10-21 03:23:10 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Romney",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258643587091288065",
  "text" : "this a reminder he likes his horses in bridles and his women in binders #Romney",
  "id" : 258643587091288065,
  "created_at" : "2012-10-17 19:00:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258642444634177536",
  "text" : "RT @AngelineGragzin: An idea is a memory from the future.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258632938999148544",
    "text" : "An idea is a memory from the future.",
    "id" : 258632938999148544,
    "created_at" : "2012-10-17 18:17:52 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 258642444634177536,
  "created_at" : "2012-10-17 18:55:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "indices" : [ 3, 11 ],
      "id_str" : "41296337",
      "id" : 41296337
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258384328537550849",
  "text" : "RT @loudbot: WE CAN NOW, BY VIRTUE OF NEW TECHNOLOGY, ACTUALLY GET ALL THE ENERGY WE NEED IN NORTH AMERICA, BY HARNESSING MY PERPETUAL B ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/example.com\" rel=\"nofollow\"\u003EBITCHES DON'T KNOW 'BOUT MY INTENSIVE AERIAL BOMBARDMENT\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "258384187059474432",
    "text" : "WE CAN NOW, BY VIRTUE OF NEW TECHNOLOGY, ACTUALLY GET ALL THE ENERGY WE NEED IN NORTH AMERICA, BY HARNESSING MY PERPETUAL BULLSHIT MACHINE",
    "id" : 258384187059474432,
    "created_at" : "2012-10-17 01:49:25 +0000",
    "user" : {
      "name" : "LOUDBOT",
      "screen_name" : "LOUDBOT",
      "protected" : false,
      "id_str" : "41296337",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/404999194\/speaker_normal.png",
      "id" : 41296337,
      "verified" : false
    }
  },
  "id" : 258384328537550849,
  "created_at" : "2012-10-17 01:49:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debate",
      "indices" : [ 114, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258382097985703938",
  "text" : "Mitt keeps talking about his private equity career. Obama should be like, \"About your record as a capitalist ...\" #debate",
  "id" : 258382097985703938,
  "created_at" : "2012-10-17 01:41:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "huzzah",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "HUZZAH",
      "indices" : [ 81, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258379611937845250",
  "text" : "Mitt: People with no capital will *not* have to pay capital gains taxes. #huzzah #HUZZAH",
  "id" : 258379611937845250,
  "created_at" : "2012-10-17 01:31:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258337925748649984",
  "text" : "I wonder if thefirstrow.eu will have the debate video.",
  "id" : 258337925748649984,
  "created_at" : "2012-10-16 22:45:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258337414253277185",
  "text" : "youtube asked me to watch a 2:34 long advertisement",
  "id" : 258337414253277185,
  "created_at" : "2012-10-16 22:43:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258314714914889728",
  "text" : "i blame dick baldface",
  "id" : 258314714914889728,
  "created_at" : "2012-10-16 21:13:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "258314597939941376",
  "text" : "twitter promoting that chevron brand propaganda is extremely not creative.",
  "id" : 258314597939941376,
  "created_at" : "2012-10-16 21:12:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257644367018340352",
  "geo" : { },
  "id_str" : "257645586738716672",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin I know what its like to have a lady mouth cut my circuitry, and wow",
  "id" : 257645586738716672,
  "in_reply_to_status_id" : 257644367018340352,
  "created_at" : "2012-10-15 00:54:29 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ponybear",
      "screen_name" : "ponybear",
      "indices" : [ 0, 9 ],
      "id_str" : "18341954",
      "id" : 18341954
    }, {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 10, 26 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/A2D8LEpp",
      "expanded_url" : "http:\/\/www.readwriteweb.com\/archives\/infographic-youtubes-top-1-000-channels-reveal-emerging-power-of-social-video.php",
      "display_url" : "readwriteweb.com\/archives\/infog\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257629465675444224",
  "in_reply_to_user_id" : 18341954,
  "text" : "@ponybear @AngelineGragzin info + graphics http:\/\/t.co\/A2D8LEpp",
  "id" : 257629465675444224,
  "created_at" : "2012-10-14 23:50:25 +0000",
  "in_reply_to_screen_name" : "ponybear",
  "in_reply_to_user_id_str" : "18341954",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257168651231297537",
  "text" : "I've never used reddit I've only heard about it. It's that illegible site with the teletubby right?",
  "id" : 257168651231297537,
  "created_at" : "2012-10-13 17:19:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/ZkKgieKQ",
      "expanded_url" : "http:\/\/www.imdb.com\/character\/ch0003521\/",
      "display_url" : "imdb.com\/character\/ch00\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "257166634605740032",
  "text" : "wow that reddit troll looks and acts like the offspring of Walter Sobchak and Walter Sobchak http:\/\/t.co\/ZkKgieKQ",
  "id" : 257166634605740032,
  "created_at" : "2012-10-13 17:11:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "257164934318784512",
  "text" : "RT @IAM_SHAKESPEARE: In vaults and prisons, and to thrill and shake",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "257163796177633280",
    "text" : "In vaults and prisons, and to thrill and shake",
    "id" : 257163796177633280,
    "created_at" : "2012-10-13 17:00:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 257164934318784512,
  "created_at" : "2012-10-13 17:04:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan Lehnardt",
      "screen_name" : "janl",
      "indices" : [ 112, 117 ],
      "id_str" : "819606",
      "id" : 819606
    }, {
      "name" : "Salvatore Sanfilippo",
      "screen_name" : "antirez",
      "indices" : [ 118, 126 ],
      "id_str" : "5813712",
      "id" : 5813712
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "257143824940408833",
  "geo" : { },
  "id_str" : "257158096261091328",
  "in_reply_to_user_id" : 819606,
  "text" : "Sexism is at root man's problem, not woman's. It's an individual woman's problem when and\/or if it affects her. @janl @antirez",
  "id" : 257158096261091328,
  "in_reply_to_status_id" : 257143824940408833,
  "created_at" : "2012-10-13 16:37:22 +0000",
  "in_reply_to_screen_name" : "janl",
  "in_reply_to_user_id_str" : "819606",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256816770353078272",
  "text" : "I will be spending my nights learning how to craft timbres on that.",
  "id" : 256816770353078272,
  "created_at" : "2012-10-12 18:01:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 103, 124 ],
      "url" : "https:\/\/t.co\/r1I8sS7m",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/wavegenerator\/id554998576?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/wavegen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256816017416806401",
  "text" : "and to wrap up this week in awesome music apps the PPG Wavegenerator app for IOS is  a serious machine https:\/\/t.co\/r1I8sS7m",
  "id" : 256816017416806401,
  "created_at" : "2012-10-12 17:58:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/XlxYYZFj",
      "expanded_url" : "http:\/\/charlie-roberts.com\/Control\/",
      "display_url" : "charlie-roberts.com\/Control\/"
    }, {
      "indices" : [ 116, 137 ],
      "url" : "https:\/\/t.co\/4IKKRdBh",
      "expanded_url" : "https:\/\/itunes.apple.com\/us\/app\/control-osc-+-midi\/id413224747?mt=8",
      "display_url" : "itunes.apple.com\/us\/app\/control\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "256815667678941185",
  "text" : "also, this mad scientist made a FOSS phonegap OSC\/Midi controller u can live-customize with JS http:\/\/t.co\/XlxYYZFj https:\/\/t.co\/4IKKRdBh",
  "id" : 256815667678941185,
  "created_at" : "2012-10-12 17:56:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jussi Kalliokoski",
      "screen_name" : "quinnirill",
      "indices" : [ 0, 11 ],
      "id_str" : "209694378",
      "id" : 209694378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/rd9D6MSB",
      "expanded_url" : "http:\/\/charlie-roberts.com\/gibber",
      "display_url" : "charlie-roberts.com\/gibber"
    } ]
  },
  "geo" : { },
  "id_str" : "256814884086489088",
  "in_reply_to_user_id" : 209694378,
  "text" : "@quinnirill  rad use of audiolib.js http:\/\/t.co\/rd9D6MSB",
  "id" : 256814884086489088,
  "created_at" : "2012-10-12 17:53:34 +0000",
  "in_reply_to_screen_name" : "quinnirill",
  "in_reply_to_user_id_str" : "209694378",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/rd9D6MSB",
      "expanded_url" : "http:\/\/charlie-roberts.com\/gibber",
      "display_url" : "charlie-roberts.com\/gibber"
    } ]
  },
  "geo" : { },
  "id_str" : "256814111449571328",
  "text" : "the Javascript music live scripting thing is being done by this awesome dude http:\/\/t.co\/rd9D6MSB",
  "id" : 256814111449571328,
  "created_at" : "2012-10-12 17:50:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "256235846582284288",
  "text" : "RT @IAM_SHAKESPEARE: BASTARD. Whate'er you think, good words, I think, were best.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "256217561639841792",
    "text" : "BASTARD. Whate'er you think, good words, I think, were best.",
    "id" : 256217561639841792,
    "created_at" : "2012-10-11 02:20:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 256235846582284288,
  "created_at" : "2012-10-11 03:32:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 55, 66 ],
      "id_str" : "47951511",
      "id" : 47951511
    }, {
      "name" : "Gov. Gary Johnson",
      "screen_name" : "GovGaryJohnson",
      "indices" : [ 67, 82 ],
      "id_str" : "95713333",
      "id" : 95713333
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255792217879371776",
  "geo" : { },
  "id_str" : "255795168152797185",
  "in_reply_to_user_id" : 47951511,
  "text" : "and the word \"gets\" adds that je ne sais... petulance  @zunguzungu @GovGaryJohnson",
  "id" : 255795168152797185,
  "in_reply_to_status_id" : 255792217879371776,
  "created_at" : "2012-10-09 22:21:35 +0000",
  "in_reply_to_screen_name" : "zunguzungu",
  "in_reply_to_user_id_str" : "47951511",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noOffense",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/Gr6jD2ap",
      "expanded_url" : "http:\/\/www.nodedublin.com\/resources\/images\/benNoordhuis.png",
      "display_url" : "nodedublin.com\/resources\/imag\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255429118672379905",
  "text" : "According to that site the ever helpful Ben Noordhuis is sexy androgynous #noOffense http:\/\/t.co\/Gr6jD2ap",
  "id" : 255429118672379905,
  "created_at" : "2012-10-08 22:07:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/2kwhwwfx",
      "expanded_url" : "http:\/\/www.nodedublin.com\/",
      "display_url" : "nodedublin.com"
    } ]
  },
  "geo" : { },
  "id_str" : "255428260203200513",
  "text" : "Wow Node Dublin did it up for their presenters http:\/\/t.co\/2kwhwwfx",
  "id" : 255428260203200513,
  "created_at" : "2012-10-08 22:03:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thx",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255426666510290944",
  "geo" : { },
  "id_str" : "255427610035777536",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden ok, will you please alert your housemates that a fellow named johnny will be coming by to repossess his power tools. #thx",
  "id" : 255427610035777536,
  "in_reply_to_status_id" : 255426666510290944,
  "created_at" : "2012-10-08 22:01:02 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "255426581667913728",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden will you be returning to Oakland between now and Dublin?",
  "id" : 255426581667913728,
  "created_at" : "2012-10-08 21:56:57 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/aON1oDuB",
      "expanded_url" : "http:\/\/arstechnica.com\/science\/2012\/10\/organism-without-a-brain-creates-external-memories-for-navigation\/",
      "display_url" : "arstechnica.com\/science\/2012\/1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255423412472786944",
  "text" : "that the slime mold can aggregate individual cells into a super organism is the real revelation. http:\/\/t.co\/aON1oDuB",
  "id" : 255423412472786944,
  "created_at" : "2012-10-08 21:44:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "superfeedr",
      "screen_name" : "superfeedr",
      "indices" : [ 23, 34 ],
      "id_str" : "43417156",
      "id" : 43417156
    }, {
      "name" : "Tantek \u00C7elik",
      "screen_name" : "t",
      "indices" : [ 35, 37 ],
      "id_str" : "11628",
      "id" : 11628
    }, {
      "name" : "Aaron Parecki",
      "screen_name" : "aaronpk",
      "indices" : [ 38, 46 ],
      "id_str" : "14447132",
      "id" : 14447132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "255417237459062784",
  "geo" : { },
  "id_str" : "255419483223638016",
  "in_reply_to_user_id" : 43417156,
  "text" : "hey thats a neat idea. @superfeedr @t @aaronpk",
  "id" : 255419483223638016,
  "in_reply_to_status_id" : 255417237459062784,
  "created_at" : "2012-10-08 21:28:44 +0000",
  "in_reply_to_screen_name" : "superfeedr",
  "in_reply_to_user_id_str" : "43417156",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindy West",
      "screen_name" : "thelindywest",
      "indices" : [ 3, 16 ],
      "id_str" : "73244642",
      "id" : 73244642
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 126 ],
      "url" : "http:\/\/t.co\/h04euVn8",
      "expanded_url" : "http:\/\/jezebel.com\/5949420\/im-not-interested-in-finding-a-truce-in-the-culture-war-im-interested-in-winning-it",
      "display_url" : "jezebel.com\/5949420\/im-not\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "255415459896258560",
  "text" : "RT @thelindywest: I\u2019m Not Interested in Finding a Truce in the Culture War. I\u2019m Interested in Winning It. http:\/\/t.co\/h04euVn8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/h04euVn8",
        "expanded_url" : "http:\/\/jezebel.com\/5949420\/im-not-interested-in-finding-a-truce-in-the-culture-war-im-interested-in-winning-it",
        "display_url" : "jezebel.com\/5949420\/im-not\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "255370861677268992",
    "text" : "I\u2019m Not Interested in Finding a Truce in the Culture War. I\u2019m Interested in Winning It. http:\/\/t.co\/h04euVn8",
    "id" : 255370861677268992,
    "created_at" : "2012-10-08 18:15:32 +0000",
    "user" : {
      "name" : "Lindy West",
      "screen_name" : "thelindywest",
      "protected" : false,
      "id_str" : "73244642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521738084027621376\/jhMapqYR_normal.jpeg",
      "id" : 73244642,
      "verified" : false
    }
  },
  "id" : 255415459896258560,
  "created_at" : "2012-10-08 21:12:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave DeSandro",
      "screen_name" : "desandro",
      "indices" : [ 0, 9 ],
      "id_str" : "1584511",
      "id" : 1584511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "254970883750379520",
  "geo" : { },
  "id_str" : "254977824480456705",
  "in_reply_to_user_id" : 1584511,
  "text" : "@desandro E=MC",
  "id" : 254977824480456705,
  "in_reply_to_status_id" : 254970883750379520,
  "created_at" : "2012-10-07 16:13:45 +0000",
  "in_reply_to_screen_name" : "desandro",
  "in_reply_to_user_id_str" : "1584511",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jsconfeu",
      "indices" : [ 42, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "254672964031762433",
  "text" : "i really want to see videos and code from #jsconfeu already!!!",
  "id" : 254672964031762433,
  "created_at" : "2012-10-06 20:02:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monoskop",
      "screen_name" : "monoskop",
      "indices" : [ 4, 13 ],
      "id_str" : "50769684",
      "id" : 50769684
    }, {
      "name" : "Steven",
      "screen_name" : "jonathanrosenb",
      "indices" : [ 82, 97 ],
      "id_str" : "2488998913",
      "id" : 2488998913
    }, {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 120, 136 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/lgEHqieU",
      "expanded_url" : "http:\/\/monoskop.org\/log\/?p=5857",
      "display_url" : "monoskop.org\/log\/?p=5857"
    } ]
  },
  "geo" : { },
  "id_str" : "254313251574263808",
  "text" : "via @monoskop: Independent Film book from 1988 with text from Jonathan Rosenbaum (@jonathanrosenb) http:\/\/t.co\/lgEHqieU @AngelineGragzin",
  "id" : 254313251574263808,
  "created_at" : "2012-10-05 20:12:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253976574662172672",
  "text" : "I'm installing Wolfram Alpha's \"Computable Document Format\"",
  "id" : 253976574662172672,
  "created_at" : "2012-10-04 21:55:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253905352934965248",
  "text" : "RT @IAM_SHAKESPEARE: BASTARD. Your breeches best may carry them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253904823504748545",
    "text" : "BASTARD. Your breeches best may carry them.",
    "id" : 253904823504748545,
    "created_at" : "2012-10-04 17:10:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 253905352934965248,
  "created_at" : "2012-10-04 17:12:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ponybear",
      "screen_name" : "ponybear",
      "indices" : [ 129, 138 ],
      "id_str" : "18341954",
      "id" : 18341954
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253716004864135168",
  "geo" : { },
  "id_str" : "253727369490214912",
  "in_reply_to_user_id" : 18341954,
  "text" : "Brilliant! Leave it to a nerd to think machines solve all problems. What are yr hourly rates? Can you track ten fingers at once? @ponybear",
  "id" : 253727369490214912,
  "in_reply_to_status_id" : 253716004864135168,
  "created_at" : "2012-10-04 05:24:53 +0000",
  "in_reply_to_screen_name" : "ponybear",
  "in_reply_to_user_id_str" : "18341954",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE REPUBLICAN DALEK",
      "screen_name" : "RepublicanDalek",
      "indices" : [ 94, 110 ],
      "id_str" : "308900763",
      "id" : 308900763
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253716452174094337",
  "geo" : { },
  "id_str" : "253717665531711488",
  "in_reply_to_user_id" : 308900763,
  "text" : "THE DEBATE WAS NOT WON OR LOST! WE ALL LOST TO IT BY A SOCK OUT! THE DEBATE WAS VICTORIOUS!!! @RepublicanDalek",
  "id" : 253717665531711488,
  "in_reply_to_status_id" : 253716452174094337,
  "created_at" : "2012-10-04 04:46:19 +0000",
  "in_reply_to_screen_name" : "RepublicanDalek",
  "in_reply_to_user_id_str" : "308900763",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 117, 124 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253715573119275009",
  "text" : "Just thinking about experimenting for real within the sandbox of a browser gives me deep fuggings. So much mistrust. @tmpvar",
  "id" : 253715573119275009,
  "created_at" : "2012-10-04 04:38:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253583810829107200",
  "geo" : { },
  "id_str" : "253713439455854592",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar neat I did not know that, but the _only_ thing I want to do with a browser client is make GUIs.",
  "id" : 253713439455854592,
  "in_reply_to_status_id" : 253583810829107200,
  "created_at" : "2012-10-04 04:29:32 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 45 ],
      "url" : "http:\/\/t.co\/ugNECO7X",
      "expanded_url" : "http:\/\/kujo.cs.pitt.edu\/cs1567\/images\/3\/33\/Spr2011-lecture-fir.pdf",
      "display_url" : "kujo.cs.pitt.edu\/cs1567\/images\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253709188792991744",
  "text" : "DSP for Dummies, I said. http:\/\/t.co\/ugNECO7X said Google",
  "id" : 253709188792991744,
  "created_at" : "2012-10-04 04:12:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253706833301213186",
  "text" : "I'm talking about hand eye coordination.",
  "id" : 253706833301213186,
  "created_at" : "2012-10-04 04:03:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253706147528335360",
  "text" : "The ideal digital interface will show me where my hands are.",
  "id" : 253706147528335360,
  "created_at" : "2012-10-04 04:00:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253683473108303874",
  "text" : "A debate where you pretend there is a time limit but really there is no time limit. Who leaves the building first wins.",
  "id" : 253683473108303874,
  "created_at" : "2012-10-04 02:30:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253682181040390145",
  "text" : "ultimate warrior enters ring and throws all over the ropes!",
  "id" : 253682181040390145,
  "created_at" : "2012-10-04 02:25:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 3, 14 ],
      "id_str" : "47951511",
      "id" : 47951511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253681578478276610",
  "text" : "RT @zunguzungu: THE BUSINESSES WILL SET UP TRAINING PROGRAMS WITH COMMUNITY COLLEGES WE'LL PUT THE ROTATING KNIVES HERE AND THE BLOOD WI ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253681162495610880",
    "text" : "THE BUSINESSES WILL SET UP TRAINING PROGRAMS WITH COMMUNITY COLLEGES WE'LL PUT THE ROTATING KNIVES HERE AND THE BLOOD WILL FLOW OUT HERE",
    "id" : 253681162495610880,
    "created_at" : "2012-10-04 02:21:16 +0000",
    "user" : {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "protected" : false,
      "id_str" : "47951511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540931347817062400\/PJ1jTwRd_normal.jpeg",
      "id" : 47951511,
      "verified" : false
    }
  },
  "id" : 253681578478276610,
  "created_at" : "2012-10-04 02:22:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "EAT. PRAY. THUG.",
      "screen_name" : "HIMANSHU",
      "indices" : [ 3, 12 ],
      "id_str" : "20450186",
      "id" : 20450186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253681426472501249",
  "text" : "RT @HIMANSHU: Obama should just repeat evvy thing Romney say in Def Comedy Jam white people voice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253680750686248961",
    "text" : "Obama should just repeat evvy thing Romney say in Def Comedy Jam white people voice.",
    "id" : 253680750686248961,
    "created_at" : "2012-10-04 02:19:38 +0000",
    "user" : {
      "name" : "EAT. PRAY. THUG.",
      "screen_name" : "HIMANSHU",
      "protected" : false,
      "id_str" : "20450186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548607106786803712\/Jgc5ClOA_normal.jpeg",
      "id" : 20450186,
      "verified" : true
    }
  },
  "id" : 253681426472501249,
  "created_at" : "2012-10-04 02:22:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253680662022868993",
  "text" : "abraham lincoln didn't need school what now",
  "id" : 253680662022868993,
  "created_at" : "2012-10-04 02:19:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "indices" : [ 27, 38 ],
      "id_str" : "122112121",
      "id" : 122112121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "253679326455795713",
  "geo" : { },
  "id_str" : "253679709030858754",
  "in_reply_to_user_id" : 122112121,
  "text" : "wait whisk whisk is whisk? @uptownherd",
  "id" : 253679709030858754,
  "in_reply_to_status_id" : 253679326455795713,
  "created_at" : "2012-10-04 02:15:30 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253678965733089280",
  "text" : "RT @IAM_SHAKESPEARE: O Lymoges! O Austria! thou dost shame",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253678331709497344",
    "text" : "O Lymoges! O Austria! thou dost shame",
    "id" : 253678331709497344,
    "created_at" : "2012-10-04 02:10:02 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 253678965733089280,
  "created_at" : "2012-10-04 02:12:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "evilAsHell",
      "indices" : [ 32, 43 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/dQYZXTae",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Category:Bain_Capital_companies",
      "display_url" : "en.wikipedia.org\/wiki\/Category:\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "253678748967251969",
  "text" : "bain capital owns guitar center #evilAsHell http:\/\/t.co\/dQYZXTae",
  "id" : 253678748967251969,
  "created_at" : "2012-10-04 02:11:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253676065178935297",
  "text" : "YOU AND ME WE ARE ALL JIM LEHRER",
  "id" : 253676065178935297,
  "created_at" : "2012-10-04 02:01:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253674448929034240",
  "text" : "I would repeal back 4 trillion layers of federal government onion",
  "id" : 253674448929034240,
  "created_at" : "2012-10-04 01:54:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253673719443124224",
  "text" : "real talk If you can't vote as a child why should you be able to vote in your \"second childhood\"? GO TO BED",
  "id" : 253673719443124224,
  "created_at" : "2012-10-04 01:51:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarah Lane",
      "screen_name" : "sarahlane",
      "indices" : [ 3, 13 ],
      "id_str" : "816214",
      "id" : 816214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253671185806684162",
  "text" : "RT @sarahlane: Romney just called Tesla a loser company? ENGAGE LASERS, SILICON VALLEY!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253670586834890752",
    "text" : "Romney just called Tesla a loser company? ENGAGE LASERS, SILICON VALLEY!",
    "id" : 253670586834890752,
    "created_at" : "2012-10-04 01:39:15 +0000",
    "user" : {
      "name" : "Sarah Lane",
      "screen_name" : "sarahlane",
      "protected" : false,
      "id_str" : "816214",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544261619170021377\/0afGSkqQ_normal.jpeg",
      "id" : 816214,
      "verified" : true
    }
  },
  "id" : 253671185806684162,
  "created_at" : "2012-10-04 01:41:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "indices" : [ 3, 14 ],
      "id_str" : "122112121",
      "id" : 122112121
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "debates",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253670286120058880",
  "text" : "RT @uptownherd: these two dudes are pivoting harder than the and1 mixtape tour playing the globetrotters in a hell world without hoops # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "debates",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253667892686630913",
    "text" : "these two dudes are pivoting harder than the and1 mixtape tour playing the globetrotters in a hell world without hoops #debates",
    "id" : 253667892686630913,
    "created_at" : "2012-10-04 01:28:33 +0000",
    "user" : {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "protected" : false,
      "id_str" : "122112121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518645860863709184\/iHz-222r_normal.jpeg",
      "id" : 122112121,
      "verified" : false
    }
  },
  "id" : 253670286120058880,
  "created_at" : "2012-10-04 01:38:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fight",
      "indices" : [ 35, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253668812761751552",
  "text" : "BIG BIRD vs KIDS WITH DISABILITIES #fight",
  "id" : 253668812761751552,
  "created_at" : "2012-10-04 01:32:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 3, 14 ],
      "id_str" : "47951511",
      "id" : 47951511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253668038149279744",
  "text" : "RT @zunguzungu: I LIKE COAL, BIG BIRD, AND JIM LEHRER",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253667836201947136",
    "text" : "I LIKE COAL, BIG BIRD, AND JIM LEHRER",
    "id" : 253667836201947136,
    "created_at" : "2012-10-04 01:28:19 +0000",
    "user" : {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "protected" : false,
      "id_str" : "47951511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540931347817062400\/PJ1jTwRd_normal.jpeg",
      "id" : 47951511,
      "verified" : false
    }
  },
  "id" : 253668038149279744,
  "created_at" : "2012-10-04 01:29:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253667353450143745",
  "text" : "whoever cuts my taxes by a trillion first wins",
  "id" : 253667353450143745,
  "created_at" : "2012-10-04 01:26:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "indices" : [ 20, 31 ],
      "id_str" : "122112121",
      "id" : 122112121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253664825476005888",
  "text" : "more commentary pls @uptownherd",
  "id" : 253664825476005888,
  "created_at" : "2012-10-04 01:16:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253374860485603328",
  "text" : "RT @IAM_SHAKESPEARE: ACT III. SCENE 1.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "253373825092292608",
    "text" : "ACT III. SCENE 1.",
    "id" : 253373825092292608,
    "created_at" : "2012-10-03 06:00:02 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 253374860485603328,
  "created_at" : "2012-10-03 06:04:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "music",
      "indices" : [ 128, 134 ]
    }, {
      "text" : "theory",
      "indices" : [ 135, 142 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253372705234104321",
  "text" : "After listening to so very much raw tonage &amp; freaky modulations, a song going 142 in C w\/ a female lead is TITS to my EARS. #music #theory",
  "id" : 253372705234104321,
  "created_at" : "2012-10-03 05:55:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 137 ],
      "url" : "https:\/\/t.co\/igupuT62",
      "expanded_url" : "https:\/\/github.com\/NHQ\/oscillators",
      "display_url" : "github.com\/NHQ\/oscillators"
    } ]
  },
  "geo" : { },
  "id_str" : "253371136610553856",
  "text" : "POSTED: the finest collection of oscillators anywhere in javascript. Whatever your Hz. Sine, saw, square, triangle. https:\/\/t.co\/igupuT62",
  "id" : 253371136610553856,
  "created_at" : "2012-10-03 05:49:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "253366958836293632",
  "text" : "im allabout the modulus",
  "id" : 253366958836293632,
  "created_at" : "2012-10-03 05:32:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "indices" : [ 3, 14 ],
      "id_str" : "47951511",
      "id" : 47951511
    }, {
      "name" : "Mike Konczal",
      "screen_name" : "rortybomb",
      "indices" : [ 76, 86 ],
      "id_str" : "48132847",
      "id" : 48132847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "252905750064676864",
  "text" : "RT @zunguzungu: Any day now, the big California Higher Education essay that @rortybomb and I wrote will be dropping at @DissentMagazine.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mike Konczal",
        "screen_name" : "rortybomb",
        "indices" : [ 60, 70 ],
        "id_str" : "48132847",
        "id" : 48132847
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "252900629603823616",
    "text" : "Any day now, the big California Higher Education essay that @rortybomb and I wrote will be dropping at @DissentMagazine.",
    "id" : 252900629603823616,
    "created_at" : "2012-10-01 22:39:43 +0000",
    "user" : {
      "name" : "Aaron Bady",
      "screen_name" : "zunguzungu",
      "protected" : false,
      "id_str" : "47951511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540931347817062400\/PJ1jTwRd_normal.jpeg",
      "id" : 47951511,
      "verified" : false
    }
  },
  "id" : 252905750064676864,
  "created_at" : "2012-10-01 23:00:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 8, 17 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Jan Lehnardt",
      "screen_name" : "janl",
      "indices" : [ 18, 23 ],
      "id_str" : "819606",
      "id" : 819606
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FOSS",
      "indices" : [ 57, 62 ]
    }, {
      "text" : "NODEJS",
      "indices" : [ 132, 139 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "252504966147751937",
  "geo" : { },
  "id_str" : "252515844251344896",
  "in_reply_to_user_id" : 12241752,
  "text" : "HELLYEA @maxogden @janl FRONTIERSMAN UNITE! HTML! HTTPS! #FOSS 2.0: THE UXERLAND! FREE INTERNET! EQUAL ACCESS! OCCUPY THE STANDARD! #NODEJS",
  "id" : 252515844251344896,
  "in_reply_to_status_id" : 252504966147751937,
  "created_at" : "2012-09-30 21:10:43 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]