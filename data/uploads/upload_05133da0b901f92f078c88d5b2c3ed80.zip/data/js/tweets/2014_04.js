Grailbird.data.tweets_2014_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461590298464772097",
  "text" : "without some intervention, I may shave my virgin beard wool",
  "id" : 461590298464772097,
  "created_at" : "2014-04-30 19:37:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461421245783760896",
  "text" : "i put a spell on you",
  "id" : 461421245783760896,
  "created_at" : "2014-04-30 08:26:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461417372696313857",
  "text" : "hella melancholy",
  "id" : 461417372696313857,
  "created_at" : "2014-04-30 08:10:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "R\u2588y B\u2588tl\u2588r",
      "screen_name" : "insatiant",
      "indices" : [ 0, 10 ],
      "id_str" : "328756230",
      "id" : 328756230
    }, {
      "name" : "Kyle Drake",
      "screen_name" : "kyledrake",
      "indices" : [ 11, 21 ],
      "id_str" : "7171612",
      "id" : 7171612
    }, {
      "name" : "Arthur Charpentier",
      "screen_name" : "freakonometrics",
      "indices" : [ 22, 38 ],
      "id_str" : "105530526",
      "id" : 105530526
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "461383528559550464",
  "geo" : { },
  "id_str" : "461417022664867840",
  "in_reply_to_user_id" : 328756230,
  "text" : "@insatiant @kyledrake @freakonometrics  there are no kiddie coorectional facilities on the internet",
  "id" : 461417022664867840,
  "in_reply_to_status_id" : 461383528559550464,
  "created_at" : "2014-04-30 08:09:25 +0000",
  "in_reply_to_screen_name" : "insatiant",
  "in_reply_to_user_id_str" : "328756230",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461262021648842752",
  "text" : "the neverending love story",
  "id" : 461262021648842752,
  "created_at" : "2014-04-29 21:53:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461238365061263360",
  "text" : "a trail of pixels\nits this way to pixieland",
  "id" : 461238365061263360,
  "created_at" : "2014-04-29 20:19:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "461012733832355840",
  "text" : "ripping the crotch of pants til I die",
  "id" : 461012733832355840,
  "created_at" : "2014-04-29 05:22:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TOLKIEN BLACK",
      "screen_name" : "therealhennessy",
      "indices" : [ 0, 16 ],
      "id_str" : "137090436",
      "id" : 137090436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460851299782000642",
  "geo" : { },
  "id_str" : "460852102370050049",
  "in_reply_to_user_id" : 137090436,
  "text" : "@therealhennessy  what are you doing in Kentucky?",
  "id" : 460852102370050049,
  "in_reply_to_status_id" : 460851299782000642,
  "created_at" : "2014-04-28 18:44:38 +0000",
  "in_reply_to_screen_name" : "therealhennessy",
  "in_reply_to_user_id_str" : "137090436",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460850675153268736",
  "text" : "naked drying off abt to rub olive oil on my selfie",
  "id" : 460850675153268736,
  "created_at" : "2014-04-28 18:38:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460821737383284737",
  "text" : "you only love me... \nFOR MY MACHINES!!!\nyou only love me... \nFOR MY MACHINES!!!\nyou only love me... \nFOR MY MACHINES!!!",
  "id" : 460821737383284737,
  "created_at" : "2014-04-28 16:43:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "selfie",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ {
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/ax6fbYO51n",
      "expanded_url" : "http:\/\/youtu.be\/Y9DVcBZto4E?t=26m26s",
      "display_url" : "youtu.be\/Y9DVcBZto4E?t=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "460805305794719745",
  "text" : "#selfie \n\nhttp:\/\/t.co\/ax6fbYO51n",
  "id" : 460805305794719745,
  "created_at" : "2014-04-28 15:38:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joe McCann",
      "screen_name" : "joemccann",
      "indices" : [ 0, 10 ],
      "id_str" : "14814762",
      "id" : 14814762
    }, {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 11, 18 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456499592067293184",
  "geo" : { },
  "id_str" : "460803427237240833",
  "in_reply_to_user_id" : 14814762,
  "text" : "@joemccann @feross \nmore like \n\u2014 ME, 2007",
  "id" : 460803427237240833,
  "in_reply_to_status_id" : 456499592067293184,
  "created_at" : "2014-04-28 15:31:13 +0000",
  "in_reply_to_screen_name" : "joemccann",
  "in_reply_to_user_id_str" : "14814762",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460797805355749377",
  "text" : "*opens empty bottle and dumps contents on yr head*\n\n\"There, now ur beautiful, like me\"",
  "id" : 460797805355749377,
  "created_at" : "2014-04-28 15:08:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460788559067115520",
  "text" : "I discovered a WIN-WIN Algorithm:\n1.  know thy self\n2.  recognize of thy self in others\n3.  love thy self  \n\n;^*",
  "id" : 460788559067115520,
  "created_at" : "2014-04-28 14:32:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460575708893294592",
  "text" : "lol",
  "id" : 460575708893294592,
  "created_at" : "2014-04-28 00:26:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460575349454024705",
  "text" : "Oh baby! I don't wanna tie you down...\nOh baby! I don't wanna tie you down...\nOh Jesus! I don't wanna nail you down...",
  "id" : 460575349454024705,
  "created_at" : "2014-04-28 00:24:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 41 ],
      "url" : "http:\/\/t.co\/UWYL6VcMii",
      "expanded_url" : "http:\/\/youtu.be\/Y9DVcBZto4E",
      "display_url" : "youtu.be\/Y9DVcBZto4E"
    } ]
  },
  "geo" : { },
  "id_str" : "460574719578615808",
  "text" : "such a great album\nhttp:\/\/t.co\/UWYL6VcMii",
  "id" : 460574719578615808,
  "created_at" : "2014-04-28 00:22:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460559784542887936",
  "text" : "a wizard, a true freek",
  "id" : 460559784542887936,
  "created_at" : "2014-04-27 23:23:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460556694028693504",
  "text" : "the drums will be returning presently",
  "id" : 460556694028693504,
  "created_at" : "2014-04-27 23:10:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460539986920493056",
  "text" : "when yr only good pants zipper is broken is when you invent a new style",
  "id" : 460539986920493056,
  "created_at" : "2014-04-27 22:04:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460539331556294657",
  "text" : "just given the heart\njust give n the heart",
  "id" : 460539331556294657,
  "created_at" : "2014-04-27 22:01:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heyLove*",
      "screen_name" : "djheylove",
      "indices" : [ 3, 13 ],
      "id_str" : "944568686",
      "id" : 944568686
    }, {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 15, 28 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460535768251772929",
  "text" : "RT @djheylove: @johnnyscript thank u for feeling the music &amp; for groovin'!!!\uD83D\uDE4F\uD83D\uDD0A\uD83C\uDFB6\u2665\uFE0F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "( +\\-)",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "460531715593601024",
    "geo" : { },
    "id_str" : "460535161176600577",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript thank u for feeling the music &amp; for groovin'!!!\uD83D\uDE4F\uD83D\uDD0A\uD83C\uDFB6\u2665\uFE0F",
    "id" : 460535161176600577,
    "in_reply_to_status_id" : 460531715593601024,
    "created_at" : "2014-04-27 21:45:13 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "heyLove*",
      "screen_name" : "djheylove",
      "protected" : false,
      "id_str" : "944568686",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/425136695499952128\/JRmlO0hJ_normal.jpeg",
      "id" : 944568686,
      "verified" : false
    }
  },
  "id" : 460535768251772929,
  "created_at" : "2014-04-27 21:47:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon (Be) Brown",
      "screen_name" : "afrobot",
      "indices" : [ 3, 11 ],
      "id_str" : "15665323",
      "id" : 15665323
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460534445624143872",
  "text" : "RT @afrobot: Hacking away at JS Study Group at Sudo Room is like going to a shoot-around with the Warriors",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "446856670044356608",
    "text" : "Hacking away at JS Study Group at Sudo Room is like going to a shoot-around with the Warriors",
    "id" : 446856670044356608,
    "created_at" : "2014-03-21 03:51:46 +0000",
    "user" : {
      "name" : "Brandon (Be) Brown",
      "screen_name" : "afrobot",
      "protected" : false,
      "id_str" : "15665323",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/442925524835254272\/1FJx1Wzd_normal.png",
      "id" : 15665323,
      "verified" : false
    }
  },
  "id" : 460534445624143872,
  "created_at" : "2014-04-27 21:42:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "heyLove*",
      "screen_name" : "djheylove",
      "indices" : [ 0, 10 ],
      "id_str" : "944568686",
      "id" : 944568686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460531715593601024",
  "in_reply_to_user_id" : 944568686,
  "text" : "@djheylove  i almost threw my sweaty tshirt on yr head last night, in homage &lt;3",
  "id" : 460531715593601024,
  "created_at" : "2014-04-27 21:31:31 +0000",
  "in_reply_to_screen_name" : "djheylove",
  "in_reply_to_user_id_str" : "944568686",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460529866576646144",
  "text" : "last night at this hawt dance party in Oakland the photographer would not give up trynna capture me groove n by myself, tho I tried to hide.",
  "id" : 460529866576646144,
  "created_at" : "2014-04-27 21:24:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460262241065910272",
  "geo" : { },
  "id_str" : "460262449552183297",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript the unit is miles",
  "id" : 460262449552183297,
  "in_reply_to_status_id" : 460262241065910272,
  "created_at" : "2014-04-27 03:41:33 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460262241065910272",
  "text" : "liking everybody within a 5 range on tinder",
  "id" : 460262241065910272,
  "created_at" : "2014-04-27 03:40:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Santa Hat Union",
      "screen_name" : "shu",
      "indices" : [ 0, 4 ],
      "id_str" : "55732226",
      "id" : 55732226
    }, {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 5, 21 ],
      "id_str" : "29117866",
      "id" : 29117866
    }, {
      "name" : "black lives matter",
      "screen_name" : "ashedryden",
      "indices" : [ 22, 33 ],
      "id_str" : "9510922",
      "id" : 9510922
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "460226045040287744",
  "geo" : { },
  "id_str" : "460260896242028544",
  "in_reply_to_user_id" : 55732226,
  "text" : "@shu @materialdesignr @ashedryden  as a shorty, I approve of this domain name.",
  "id" : 460260896242028544,
  "in_reply_to_status_id" : 460226045040287744,
  "created_at" : "2014-04-27 03:35:23 +0000",
  "in_reply_to_screen_name" : "shu",
  "in_reply_to_user_id_str" : "55732226",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460204998446428161",
  "text" : "i got five on it",
  "id" : 460204998446428161,
  "created_at" : "2014-04-26 23:53:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460109390125617153",
  "text" : "i have a nose for music",
  "id" : 460109390125617153,
  "created_at" : "2014-04-26 17:33:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "460103521358974977",
  "text" : "npm install -g tuner\ntuner kxlu",
  "id" : 460103521358974977,
  "created_at" : "2014-04-26 17:10:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459962269623787520",
  "text" : "i wondered what my friends would think of this",
  "id" : 459962269623787520,
  "created_at" : "2014-04-26 07:48:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459955830750588928",
  "text" : "ok boom boom",
  "id" : 459955830750588928,
  "created_at" : "2014-04-26 07:23:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459955743488106496",
  "text" : "don't touch",
  "id" : 459955743488106496,
  "created_at" : "2014-04-26 07:22:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459954803511025664",
  "text" : "i cast deliver me underwear on the internet, and it obeyed",
  "id" : 459954803511025664,
  "created_at" : "2014-04-26 07:19:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459954481656909825",
  "text" : "system is to order as complex is to chaos, in the controlled setting of my feeble mind",
  "id" : 459954481656909825,
  "created_at" : "2014-04-26 07:17:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459954105578827776",
  "text" : "c;mon\n\ni know u know system\n\nplay",
  "id" : 459954105578827776,
  "created_at" : "2014-04-26 07:16:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "afterHours",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459953966655086594",
  "text" : "#afterHours",
  "id" : 459953966655086594,
  "created_at" : "2014-04-26 07:15:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459953871188545536",
  "text" : "okay\n\nlet's talk about systems\n\nyou start",
  "id" : 459953871188545536,
  "created_at" : "2014-04-26 07:15:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "m. hokanson",
      "screen_name" : "h0ke",
      "indices" : [ 10, 15 ],
      "id_str" : "16802242",
      "id" : 16802242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459896670751178754",
  "geo" : { },
  "id_str" : "459953577700511744",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden @h0ke \n\nlight hoods n capes\n\n\/",
  "id" : 459953577700511744,
  "in_reply_to_status_id" : 459896670751178754,
  "created_at" : "2014-04-26 07:14:13 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Roggero",
      "screen_name" : "tomasdev",
      "indices" : [ 0, 9 ],
      "id_str" : "15382430",
      "id" : 15382430
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 10, 19 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459927833071341568",
  "geo" : { },
  "id_str" : "459949294045233153",
  "in_reply_to_user_id" : 15382430,
  "text" : "@tomasdev @substack I prefer the slower verseone",
  "id" : 459949294045233153,
  "in_reply_to_status_id" : 459927833071341568,
  "created_at" : "2014-04-26 06:57:11 +0000",
  "in_reply_to_screen_name" : "tomasdev",
  "in_reply_to_user_id_str" : "15382430",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459835071873429504",
  "text" : "It should not surprise you that any individual does not like being blamed for the system.",
  "id" : 459835071873429504,
  "created_at" : "2014-04-25 23:23:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459820237991735297",
  "text" : "maybe its cuz im only halfwhitemale",
  "id" : 459820237991735297,
  "created_at" : "2014-04-25 22:24:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459819882084065281",
  "text" : "Look, if I could have used my whitemale force to stop Dick Cheney, I would have.",
  "id" : 459819882084065281,
  "created_at" : "2014-04-25 22:22:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459817956516847617",
  "text" : "Lover, Nerd, Sadface",
  "id" : 459817956516847617,
  "created_at" : "2014-04-25 22:15:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459809239364403200",
  "text" : "It is gross to think that the new tech power is going to solve systemic social problems.  Power is the problem.",
  "id" : 459809239364403200,
  "created_at" : "2014-04-25 21:40:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 0, 16 ],
      "id_str" : "29117866",
      "id" : 29117866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459802042882465793",
  "geo" : { },
  "id_str" : "459807761308454912",
  "in_reply_to_user_id" : 29117866,
  "text" : "@materialdesignr  ok twitter psychologist",
  "id" : 459807761308454912,
  "in_reply_to_status_id" : 459802042882465793,
  "created_at" : "2014-04-25 21:34:47 +0000",
  "in_reply_to_screen_name" : "materialdesignr",
  "in_reply_to_user_id_str" : "29117866",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 0, 16 ],
      "id_str" : "29117866",
      "id" : 29117866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459802157848334336",
  "geo" : { },
  "id_str" : "459802385670352896",
  "in_reply_to_user_id" : 29117866,
  "text" : "@materialdesignr  fine, substitute your word for mine, and call me self centered and whining again.",
  "id" : 459802385670352896,
  "in_reply_to_status_id" : 459802157848334336,
  "created_at" : "2014-04-25 21:13:26 +0000",
  "in_reply_to_screen_name" : "materialdesignr",
  "in_reply_to_user_id_str" : "29117866",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 0, 16 ],
      "id_str" : "29117866",
      "id" : 29117866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459801174195970048",
  "geo" : { },
  "id_str" : "459801761713106944",
  "in_reply_to_user_id" : 29117866,
  "text" : "@materialdesignr  they could be slimey aliens, but that would'nt mean all slimey aliens should be blamed, or worse, accued of doing nothing",
  "id" : 459801761713106944,
  "in_reply_to_status_id" : 459801174195970048,
  "created_at" : "2014-04-25 21:10:57 +0000",
  "in_reply_to_screen_name" : "materialdesignr",
  "in_reply_to_user_id_str" : "29117866",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 0, 16 ],
      "id_str" : "29117866",
      "id" : 29117866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459800054669131778",
  "geo" : { },
  "id_str" : "459801146505183232",
  "in_reply_to_user_id" : 29117866,
  "text" : "@materialdesignr what do you call it when a class of human is singled out by the color of their skin, esp in a negative way?",
  "id" : 459801146505183232,
  "in_reply_to_status_id" : 459800054669131778,
  "created_at" : "2014-04-25 21:08:30 +0000",
  "in_reply_to_screen_name" : "materialdesignr",
  "in_reply_to_user_id_str" : "29117866",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 0, 16 ],
      "id_str" : "29117866",
      "id" : 29117866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459800393782816768",
  "geo" : { },
  "id_str" : "459800826291056640",
  "in_reply_to_user_id" : 29117866,
  "text" : "@materialdesignr that is a fisheye view from inside the bubble.  its simply not true.  if you and me had the power, we would obv. do smthng",
  "id" : 459800826291056640,
  "in_reply_to_status_id" : 459800393782816768,
  "created_at" : "2014-04-25 21:07:14 +0000",
  "in_reply_to_screen_name" : "materialdesignr",
  "in_reply_to_user_id_str" : "29117866",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 0, 16 ],
      "id_str" : "29117866",
      "id" : 29117866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459794935311376384",
  "geo" : { },
  "id_str" : "459799825316192256",
  "in_reply_to_user_id" : 29117866,
  "text" : "@materialdesignr  sure, in response to gauche hypocritical racism blaming a tiny subset (whitemales in tech) for not overturning patriarchy.",
  "id" : 459799825316192256,
  "in_reply_to_status_id" : 459794935311376384,
  "created_at" : "2014-04-25 21:03:15 +0000",
  "in_reply_to_screen_name" : "materialdesignr",
  "in_reply_to_user_id_str" : "29117866",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459785009289629696",
  "text" : "guess what, patriarchy is not owned by men.  it's like a mode of governance.  it *is*.  women are part of that the patriarchy too.",
  "id" : 459785009289629696,
  "created_at" : "2014-04-25 20:04:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459782435622776832",
  "text" : "THROW THE WHITEMALE UNDER THE GOOGLEBUS",
  "id" : 459782435622776832,
  "created_at" : "2014-04-25 19:54:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459782329326514176",
  "text" : "hey you, nerd, misfit, outsider, probably feminist, and now well paid programmer, you are part of the problem now becuz yr also whitemale.",
  "id" : 459782329326514176,
  "created_at" : "2014-04-25 19:53:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m. hokanson",
      "screen_name" : "h0ke",
      "indices" : [ 0, 5 ],
      "id_str" : "16802242",
      "id" : 16802242
    }, {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 6, 20 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459779654618853376",
  "geo" : { },
  "id_str" : "459781231652007936",
  "in_reply_to_user_id" : 16802242,
  "text" : "@h0ke @jesusabdullah  that post is also bullshit",
  "id" : 459781231652007936,
  "in_reply_to_status_id" : 459779654618853376,
  "created_at" : "2014-04-25 19:49:22 +0000",
  "in_reply_to_screen_name" : "h0ke",
  "in_reply_to_user_id_str" : "16802242",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edna piranha",
      "screen_name" : "ednapiranha",
      "indices" : [ 3, 15 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459779552646934528",
  "text" : "RT @ednapiranha: On CNN right now \"Sheryl Sandberg doubles down on Lean In\" .. like a beef patty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "459737046412566530",
    "text" : "On CNN right now \"Sheryl Sandberg doubles down on Lean In\" .. like a beef patty",
    "id" : 459737046412566530,
    "created_at" : "2014-04-25 16:53:48 +0000",
    "user" : {
      "name" : "edna piranha",
      "screen_name" : "ednapiranha",
      "protected" : false,
      "id_str" : "14113407",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544560496494379008\/jiG0dkLW_normal.jpeg",
      "id" : 14113407,
      "verified" : false
    }
  },
  "id" : 459779552646934528,
  "created_at" : "2014-04-25 19:42:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459779073514803200",
  "text" : "u empathize when you have lived a similar experience.  \n\nu sympathize when you are sensitive to the situatio and feel it vicariously",
  "id" : 459779073514803200,
  "created_at" : "2014-04-25 19:40:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 3, 17 ],
      "id_str" : "184987977",
      "id" : 184987977
    }, {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 19, 32 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459777654787297281",
  "text" : "RT @jesusabdullah: @johnnyscript Empathy makes you a good *person*.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "( +\\-)",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "459776792635514880",
    "geo" : { },
    "id_str" : "459777432258879488",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript Empathy makes you a good *person*.",
    "id" : 459777432258879488,
    "in_reply_to_status_id" : 459776792635514880,
    "created_at" : "2014-04-25 19:34:16 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "protected" : false,
      "id_str" : "184987977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446152211911831552\/WCKxiGLD_normal.jpeg",
      "id" : 184987977,
      "verified" : false
    }
  },
  "id" : 459777654787297281,
  "created_at" : "2014-04-25 19:35:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459776792635514880",
  "geo" : { },
  "id_str" : "459777031417262080",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  Shut up whitemale!",
  "id" : 459777031417262080,
  "in_reply_to_status_id" : 459776792635514880,
  "created_at" : "2014-04-25 19:32:41 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459776792635514880",
  "text" : "I empathize with the weak, the small, the poor, the invisible, the ignored, and the wretched.  Empathy makes me a good programmer, right?",
  "id" : 459776792635514880,
  "created_at" : "2014-04-25 19:31:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "m. hokanson",
      "screen_name" : "h0ke",
      "indices" : [ 0, 5 ],
      "id_str" : "16802242",
      "id" : 16802242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459772230692397056",
  "geo" : { },
  "id_str" : "459772760697225216",
  "in_reply_to_user_id" : 16802242,
  "text" : "@h0ke  are u hungry and \/or need to get on the BART???",
  "id" : 459772760697225216,
  "in_reply_to_status_id" : 459772230692397056,
  "created_at" : "2014-04-25 19:15:42 +0000",
  "in_reply_to_screen_name" : "h0ke",
  "in_reply_to_user_id_str" : "16802242",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459771623290073088",
  "text" : "I like giving people money",
  "id" : 459771623290073088,
  "created_at" : "2014-04-25 19:11:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459599399253852160",
  "geo" : { },
  "id_str" : "459599486458019840",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \nand this is why this must be free",
  "id" : 459599486458019840,
  "in_reply_to_status_id" : 459599399253852160,
  "created_at" : "2014-04-25 07:47:11 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459599399253852160",
  "text" : "new rule is I don't even try to code my side girl when my main context that day is contractually stultifying.  music, exercise, booze, okay.",
  "id" : 459599399253852160,
  "created_at" : "2014-04-25 07:46:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459585643157278721",
  "text" : "I am the one true Johnny.  All other Johnny's, if they are true, are also me.",
  "id" : 459585643157278721,
  "created_at" : "2014-04-25 06:52:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459582313534193664",
  "text" : "Two things I am loathe to do:  \n1)  promote myself\n2)  psychopathologize myself\nThis leaves me few options.  Truth, beauty, fuck n justice.",
  "id" : 459582313534193664,
  "created_at" : "2014-04-25 06:38:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459538163455639552",
  "text" : "I, friend to the friendless.",
  "id" : 459538163455639552,
  "created_at" : "2014-04-25 03:43:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459537875885752321",
  "text" : "I am a complete stranger to the view of my face or head from most angles.",
  "id" : 459537875885752321,
  "created_at" : "2014-04-25 03:42:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459476806341779456",
  "geo" : { },
  "id_str" : "459477436346822657",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  I'd be happy to help!  The flow is a must  ;^)",
  "id" : 459477436346822657,
  "in_reply_to_status_id" : 459476806341779456,
  "created_at" : "2014-04-24 23:42:12 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 123 ],
      "url" : "https:\/\/t.co\/zPN51Cly8X",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/browserify",
      "display_url" : "npmjs.org\/package\/browse\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "459471526543515648",
  "geo" : { },
  "id_str" : "459476503671996418",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  whatever you do, get on NPM, use browserify, and publish your synths stuff as modules!\nhttps:\/\/t.co\/zPN51Cly8X",
  "id" : 459476503671996418,
  "in_reply_to_status_id" : 459471526543515648,
  "created_at" : "2014-04-24 23:38:29 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "459471526543515648",
  "geo" : { },
  "id_str" : "459475624277442560",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  So I build stuff on top of the scriptProcessor, like am\/fm modulators, syncopators, envelopes, midi, etc.",
  "id" : 459475624277442560,
  "in_reply_to_status_id" : 459471526543515648,
  "created_at" : "2014-04-24 23:35:00 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kawandeep Virdee",
      "screen_name" : "whichlight",
      "indices" : [ 0, 11 ],
      "id_str" : "17092251",
      "id" : 17092251
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/S2x2bFA8ms",
      "expanded_url" : "http:\/\/studio.substack.net",
      "display_url" : "studio.substack.net"
    }, {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/e50FvtGtR2",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/jsynth",
      "display_url" : "npmjs.org\/package\/jsynth"
    } ]
  },
  "in_reply_to_status_id_str" : "459471526543515648",
  "geo" : { },
  "id_str" : "459474840068431872",
  "in_reply_to_user_id" : 17092251,
  "text" : "@whichlight  I played with yr synths!  rad fun.  I mainly use the scriptProcessor, a la http:\/\/t.co\/S2x2bFA8ms and https:\/\/t.co\/e50FvtGtR2",
  "id" : 459474840068431872,
  "in_reply_to_status_id" : 459471526543515648,
  "created_at" : "2014-04-24 23:31:53 +0000",
  "in_reply_to_screen_name" : "whichlight",
  "in_reply_to_user_id_str" : "17092251",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459446368616996866",
  "text" : "OH \"interaction paradigm\"",
  "id" : 459446368616996866,
  "created_at" : "2014-04-24 21:38:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459426881519894528",
  "text" : "something rapturous about to happen",
  "id" : 459426881519894528,
  "created_at" : "2014-04-24 20:21:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459111011413274624",
  "text" : "if this browser's gonna tell me im not spelling \"solution\" correctly,  maybe it is time to pluck out my eyes.",
  "id" : 459111011413274624,
  "created_at" : "2014-04-23 23:26:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459104469964181505",
  "text" : "call me lil alchahol, this afternoon",
  "id" : 459104469964181505,
  "created_at" : "2014-04-23 23:00:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459104280071245825",
  "text" : "sad immabout to spend the rest of this brilliant day shoveling digital bullshit",
  "id" : 459104280071245825,
  "created_at" : "2014-04-23 22:59:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "459104018195705856",
  "text" : "thinking that software can be done by a CERTAIN date is violence.",
  "id" : 459104018195705856,
  "created_at" : "2014-04-23 22:58:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458526504331141120",
  "text" : "ewwave",
  "id" : 458526504331141120,
  "created_at" : "2014-04-22 08:43:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason House",
      "screen_name" : "Jason_House",
      "indices" : [ 3, 15 ],
      "id_str" : "366493048",
      "id" : 366493048
    }, {
      "name" : "TOLKIEN BLACK",
      "screen_name" : "therealhennessy",
      "indices" : [ 17, 33 ],
      "id_str" : "137090436",
      "id" : 137090436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458503062370263040",
  "text" : "RT @Jason_House: @therealhennessy To swing a bouquet of flowers around like Morrissey in the This Charming Man video w\/ no fear of judgemen\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TOLKIEN BLACK",
        "screen_name" : "therealhennessy",
        "indices" : [ 0, 16 ],
        "id_str" : "137090436",
        "id" : 137090436
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "458474080845717504",
    "geo" : { },
    "id_str" : "458476054848352256",
    "in_reply_to_user_id" : 137090436,
    "text" : "@therealhennessy To swing a bouquet of flowers around like Morrissey in the This Charming Man video w\/ no fear of judgement is manly as fuck",
    "id" : 458476054848352256,
    "in_reply_to_status_id" : 458474080845717504,
    "created_at" : "2014-04-22 05:23:04 +0000",
    "in_reply_to_screen_name" : "therealhennessy",
    "in_reply_to_user_id_str" : "137090436",
    "user" : {
      "name" : "Jason House",
      "screen_name" : "Jason_House",
      "protected" : false,
      "id_str" : "366493048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419795231228182528\/BMFFloSA_normal.jpeg",
      "id" : 366493048,
      "verified" : false
    }
  },
  "id" : 458503062370263040,
  "created_at" : "2014-04-22 07:10:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "LocalWiki",
      "screen_name" : "localwiki",
      "indices" : [ 40, 50 ],
      "id_str" : "110866131",
      "id" : 110866131
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 88 ],
      "url" : "http:\/\/t.co\/8A1jZQTa8I",
      "expanded_url" : "http:\/\/guide.localwiki.org\/What_do_people_do_with_LocalWiki%3F",
      "display_url" : "guide.localwiki.org\/What_do_people\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "458502830903406592",
  "text" : "RT @marinakukso: What do people do with @localwiki in their city? http:\/\/t.co\/8A1jZQTa8I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "LocalWiki",
        "screen_name" : "localwiki",
        "indices" : [ 23, 33 ],
        "id_str" : "110866131",
        "id" : 110866131
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/8A1jZQTa8I",
        "expanded_url" : "http:\/\/guide.localwiki.org\/What_do_people_do_with_LocalWiki%3F",
        "display_url" : "guide.localwiki.org\/What_do_people\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "458500869105782785",
    "text" : "What do people do with @localwiki in their city? http:\/\/t.co\/8A1jZQTa8I",
    "id" : 458500869105782785,
    "created_at" : "2014-04-22 07:01:40 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545296557621268481\/seD5hVbi_normal.png",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 458502830903406592,
  "created_at" : "2014-04-22 07:09:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458491484514156544",
  "text" : "IM SOCIAL NETWORKING!!!",
  "id" : 458491484514156544,
  "created_at" : "2014-04-22 06:24:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458458131178090496",
  "text" : "i remember fondly chatting the internet anonymously",
  "id" : 458458131178090496,
  "created_at" : "2014-04-22 04:11:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "458363973805416448",
  "text" : "contemporary cultural criticism is the most obnoxious thing happening on the internet today.",
  "id" : 458363973805416448,
  "created_at" : "2014-04-21 21:57:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blake G.",
      "screen_name" : "cwlcks",
      "indices" : [ 0, 7 ],
      "id_str" : "63545584",
      "id" : 63545584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458358964804014081",
  "geo" : { },
  "id_str" : "458360521532514304",
  "in_reply_to_user_id" : 63545584,
  "text" : "@cwlcks youtube-dl",
  "id" : 458360521532514304,
  "in_reply_to_status_id" : 458358964804014081,
  "created_at" : "2014-04-21 21:43:58 +0000",
  "in_reply_to_screen_name" : "cwlcks",
  "in_reply_to_user_id_str" : "63545584",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "458316169658003456",
  "geo" : { },
  "id_str" : "458355382843211777",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr contribute to this project on goathub",
  "id" : 458355382843211777,
  "in_reply_to_status_id" : 458316169658003456,
  "created_at" : "2014-04-21 21:23:33 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Drake",
      "screen_name" : "kyledrake",
      "indices" : [ 0, 10 ],
      "id_str" : "7171612",
      "id" : 7171612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457939624753500160",
  "geo" : { },
  "id_str" : "457951623281524736",
  "in_reply_to_user_id" : 7171612,
  "text" : "@kyledrake  inflation is infuriating and so is academic pseudo scientist running economies!",
  "id" : 457951623281524736,
  "in_reply_to_status_id" : 457939624753500160,
  "created_at" : "2014-04-20 18:39:09 +0000",
  "in_reply_to_screen_name" : "kyledrake",
  "in_reply_to_user_id_str" : "7171612",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/457950169292492800\/photo\/1",
      "indices" : [ 3, 25 ],
      "url" : "http:\/\/t.co\/vnCu25nx8p",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Blr3QKDCIAALYAQ.jpg",
      "id_str" : "457950169078571008",
      "id" : 457950169078571008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Blr3QKDCIAALYAQ.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 750
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 750
      } ],
      "display_url" : "pic.twitter.com\/vnCu25nx8p"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457950169292492800",
  "text" : "Hi http:\/\/t.co\/vnCu25nx8p",
  "id" : 457950169292492800,
  "created_at" : "2014-04-20 18:33:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457733491862409216",
  "text" : "pls send entertainments",
  "id" : 457733491862409216,
  "created_at" : "2014-04-20 04:12:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ms. Ing Noe Mills",
      "screen_name" : "missthighgap",
      "indices" : [ 0, 13 ],
      "id_str" : "254707404",
      "id" : 254707404
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "457677201748410368",
  "geo" : { },
  "id_str" : "457697357576957953",
  "in_reply_to_user_id" : 254707404,
  "text" : "@missthighgap  Our love it is external. u can keep it roast it &amp; eat it. buried in yr depths, if from that love man is severed, it is death.",
  "id" : 457697357576957953,
  "in_reply_to_status_id" : 457677201748410368,
  "created_at" : "2014-04-20 01:48:48 +0000",
  "in_reply_to_screen_name" : "missthighgap",
  "in_reply_to_user_id_str" : "254707404",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457674863767851008",
  "text" : "broken chicken bone stage",
  "id" : 457674863767851008,
  "created_at" : "2014-04-20 00:19:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457667379468578816",
  "text" : "switched to npmd\nfeeling better",
  "id" : 457667379468578816,
  "created_at" : "2014-04-19 23:49:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457664889369022464",
  "text" : "npm is making me woozy",
  "id" : 457664889369022464,
  "created_at" : "2014-04-19 23:39:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457663107788046336",
  "text" : "im probably publishing \npublishing errors\nwho cares?\njohnny magic all one buffer\ncoming to an event close \nto your very next tick",
  "id" : 457663107788046336,
  "created_at" : "2014-04-19 23:32:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 44 ],
      "url" : "https:\/\/t.co\/RcuVX5rWoJ",
      "expanded_url" : "https:\/\/npmjs.org\/package\/jmao",
      "display_url" : "npmjs.org\/package\/jmao"
    } ]
  },
  "geo" : { },
  "id_str" : "457661868073443328",
  "text" : "Johnny Magic All One\nhttps:\/\/t.co\/RcuVX5rWoJ",
  "id" : 457661868073443328,
  "created_at" : "2014-04-19 23:27:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "THE END SOCIETY",
      "screen_name" : "theendsociety",
      "indices" : [ 0, 14 ],
      "id_str" : "182112182",
      "id" : 182112182
    }, {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 15, 26 ],
      "id_str" : "14236976",
      "id" : 14236976
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/RAer3yVSwD",
      "expanded_url" : "https:\/\/soundcloud.com\/the-pipes-of-unix\/dragon-noodle",
      "display_url" : "soundcloud.com\/the-pipes-of-u\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "457585345698078721",
  "geo" : { },
  "id_str" : "457643895564673024",
  "in_reply_to_user_id" : 182112182,
  "text" : "@theendsociety @ToddBailey  https:\/\/t.co\/RAer3yVSwD",
  "id" : 457643895564673024,
  "in_reply_to_status_id" : 457585345698078721,
  "created_at" : "2014-04-19 22:16:21 +0000",
  "in_reply_to_screen_name" : "theendsociety",
  "in_reply_to_user_id_str" : "182112182",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457625262088146944",
  "text" : "grooving to rach like he was bone thugs",
  "id" : 457625262088146944,
  "created_at" : "2014-04-19 21:02:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/JtZfxxJwJ9",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/jmao",
      "display_url" : "npmjs.org\/package\/jmao"
    } ]
  },
  "geo" : { },
  "id_str" : "457624551111684097",
  "text" : "HAHA IT BEGINGS\n\nhttps:\/\/t.co\/JtZfxxJwJ9",
  "id" : 457624551111684097,
  "created_at" : "2014-04-19 20:59:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457588802043650048",
  "text" : "deep loose equal",
  "id" : 457588802043650048,
  "created_at" : "2014-04-19 18:37:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457386023702372352",
  "text" : "imguring my entertainment right now",
  "id" : 457386023702372352,
  "created_at" : "2014-04-19 05:11:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457275576663830528",
  "text" : "The science on that subject is far behind my intuitive theories.",
  "id" : 457275576663830528,
  "created_at" : "2014-04-18 21:52:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457242803672600576",
  "text" : "space making me emotional",
  "id" : 457242803672600576,
  "created_at" : "2014-04-18 19:42:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457238516515090432",
  "text" : "ENGINES ARE CHILLED FOR FLIGHT",
  "id" : 457238516515090432,
  "created_at" : "2014-04-18 19:25:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457237302926790656",
  "text" : "T MINUS FIVE MINUTES",
  "id" : 457237302926790656,
  "created_at" : "2014-04-18 19:20:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457236270003924992",
  "text" : "ENGINES ARE CHILLING IN",
  "id" : 457236270003924992,
  "created_at" : "2014-04-18 19:16:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "457009853794222080",
  "text" : "I got muh micros workin",
  "id" : 457009853794222080,
  "created_at" : "2014-04-18 04:16:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456993731657224192",
  "text" : "-am  \"fixed automatic automatic merge conflicts\"",
  "id" : 456993731657224192,
  "created_at" : "2014-04-18 03:12:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456824874347282432",
  "text" : "wheres the ooctrl key?",
  "id" : 456824874347282432,
  "created_at" : "2014-04-17 16:01:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 3, 15 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456641726480781314",
  "text" : "RT @dominictarr: Free Startup Idea: prank USB keys that do not plug in either way.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "456632884124590080",
    "text" : "Free Startup Idea: prank USB keys that do not plug in either way.",
    "id" : 456632884124590080,
    "created_at" : "2014-04-17 03:18:58 +0000",
    "user" : {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "protected" : false,
      "id_str" : "136933779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1753980863\/gravatar_normal.jpeg",
      "id" : 136933779,
      "verified" : false
    }
  },
  "id" : 456641726480781314,
  "created_at" : "2014-04-17 03:54:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456629872039714816",
  "text" : "wanted: the raspberry pi of bitch n multi-core computers",
  "id" : 456629872039714816,
  "created_at" : "2014-04-17 03:06:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456553297650786304",
  "geo" : { },
  "id_str" : "456561566897287169",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost what if it folds into a bucky dome and you could live in it?",
  "id" : 456561566897287169,
  "in_reply_to_status_id" : 456553297650786304,
  "created_at" : "2014-04-16 22:35:34 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456497895399636992",
  "text" : "GRAB THAT FLYWHEEL AND MEET ME IN THE LABORATORY!",
  "id" : 456497895399636992,
  "created_at" : "2014-04-16 18:22:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456361351107977216",
  "geo" : { },
  "id_str" : "456485108279549953",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  dibs on using one of these as the cover art for my first ep",
  "id" : 456485108279549953,
  "in_reply_to_status_id" : 456361351107977216,
  "created_at" : "2014-04-16 17:31:45 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456278968706928641",
  "geo" : { },
  "id_str" : "456280133502910464",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah  until the investors come to get you!",
  "id" : 456280133502910464,
  "in_reply_to_status_id" : 456278968706928641,
  "created_at" : "2014-04-16 03:57:15 +0000",
  "in_reply_to_screen_name" : "jesusabdullah",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456276938504413184",
  "geo" : { },
  "id_str" : "456277729105571841",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah  Did u hear the bell toll just now?",
  "id" : 456277729105571841,
  "in_reply_to_status_id" : 456276938504413184,
  "created_at" : "2014-04-16 03:47:42 +0000",
  "in_reply_to_screen_name" : "jesusabdullah",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456273799051087872",
  "text" : "alas my twitter is also a lonesome place",
  "id" : 456273799051087872,
  "created_at" : "2014-04-16 03:32:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456272038634610689",
  "text" : "moon lighted",
  "id" : 456272038634610689,
  "created_at" : "2014-04-16 03:25:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "456263745124065280",
  "geo" : { },
  "id_str" : "456266594654507011",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah I'm sayin!  I was up the night retching out the old one.  Haven't cleaned it yet.   In bed and pain all day.  Ready to dance.",
  "id" : 456266594654507011,
  "in_reply_to_status_id" : 456263745124065280,
  "created_at" : "2014-04-16 03:03:27 +0000",
  "in_reply_to_screen_name" : "jesusabdullah",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456263344605782016",
  "text" : "i got this new body\nit's pretty nice",
  "id" : 456263344605782016,
  "created_at" : "2014-04-16 02:50:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456261778872082434",
  "text" : "git fresh",
  "id" : 456261778872082434,
  "created_at" : "2014-04-16 02:44:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456260872868855809",
  "text" : "indeed, as well inthought",
  "id" : 456260872868855809,
  "created_at" : "2014-04-16 02:40:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456260273389568000",
  "text" : "a purge is indeed what is needed",
  "id" : 456260273389568000,
  "created_at" : "2014-04-16 02:38:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456256580107767810",
  "text" : "I almost went with that eclipse last night",
  "id" : 456256580107767810,
  "created_at" : "2014-04-16 02:23:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456194217652387840",
  "text" : "fever rich",
  "id" : 456194217652387840,
  "created_at" : "2014-04-15 22:15:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "456192834828107777",
  "text" : "there is something not appropriate with this here",
  "id" : 456192834828107777,
  "created_at" : "2014-04-15 22:10:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455968387386990593",
  "text" : "You would see the moon flowers right now if you could see the moon.",
  "id" : 455968387386990593,
  "created_at" : "2014-04-15 07:18:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455872232107937792",
  "text" : "off by which one?",
  "id" : 455872232107937792,
  "created_at" : "2014-04-15 00:56:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455603390806896640",
  "geo" : { },
  "id_str" : "455616118028120064",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar this is causing me to get twitter ads that resemble this!",
  "id" : 455616118028120064,
  "in_reply_to_status_id" : 455603390806896640,
  "created_at" : "2014-04-14 07:58:42 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455615718701023232",
  "text" : "for you, my mooncalf",
  "id" : 455615718701023232,
  "created_at" : "2014-04-14 07:57:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455564701024280576",
  "text" : "Programming is Jenga in reverse.",
  "id" : 455564701024280576,
  "created_at" : "2014-04-14 04:34:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455563140365701120",
  "text" : "one of those constructs that doesn't hold until the final piece is placed",
  "id" : 455563140365701120,
  "created_at" : "2014-04-14 04:28:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 8, 16 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455562708503371776",
  "geo" : { },
  "id_str" : "455562968055308289",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar @soldair i think you meant no more earrors!",
  "id" : 455562968055308289,
  "in_reply_to_status_id" : 455562708503371776,
  "created_at" : "2014-04-14 04:27:30 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455534875055894528",
  "text" : "possible names for my next module:\njohnny-magic-all-one-buffer\npoet-blob\nsin-tax",
  "id" : 455534875055894528,
  "created_at" : "2014-04-14 02:35:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "455534185092874240",
  "text" : "all my haters gonna love this bangin' new module I'm laying down.",
  "id" : 455534185092874240,
  "created_at" : "2014-04-14 02:33:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "455185721066659840",
  "geo" : { },
  "id_str" : "455218395969908737",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar +1",
  "id" : 455218395969908737,
  "in_reply_to_status_id" : 455185721066659840,
  "created_at" : "2014-04-13 05:38:17 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454757005769469952",
  "geo" : { },
  "id_str" : "454785122483458049",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr level 8 completed",
  "id" : 454785122483458049,
  "in_reply_to_status_id" : 454757005769469952,
  "created_at" : "2014-04-12 00:56:37 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 0, 14 ],
      "id_str" : "379919160",
      "id" : 379919160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454662630586982400",
  "geo" : { },
  "id_str" : "454665785638535168",
  "in_reply_to_user_id" : 379919160,
  "text" : "@MikolaLysenko The intended use is [x,y,z].sort(shuffle).sort(shuffle).sort(shuffle).sort(shuffle)...",
  "id" : 454665785638535168,
  "in_reply_to_status_id" : 454662630586982400,
  "created_at" : "2014-04-11 17:02:25 +0000",
  "in_reply_to_screen_name" : "MikolaLysenko",
  "in_reply_to_user_id_str" : "379919160",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454649615883567104",
  "text" : "[x,y,z].sort(shuffle)\n\nfunction shuffle()\u007B\n  return Math.sin(Math.random() * Math.PI   * 2)\n\u007D",
  "id" : 454649615883567104,
  "created_at" : "2014-04-11 15:58:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454526201563209728",
  "text" : "i'll tell you something\nnaw, fuck it\ni aint tell n",
  "id" : 454526201563209728,
  "created_at" : "2014-04-11 07:47:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ssh",
      "indices" : [ 45, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454511415001247745",
  "text" : "did everybody else computer feel that, too?  #ssh",
  "id" : 454511415001247745,
  "created_at" : "2014-04-11 06:49:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454368391864672256",
  "text" : "phonegapificate",
  "id" : 454368391864672256,
  "created_at" : "2014-04-10 21:20:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454293704971280384",
  "text" : "tehculture of tehcommunity",
  "id" : 454293704971280384,
  "created_at" : "2014-04-10 16:23:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454160382043512832",
  "text" : "there are never enough meals in a day",
  "id" : 454160382043512832,
  "created_at" : "2014-04-10 07:34:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454146506153414656",
  "geo" : { },
  "id_str" : "454148662260547584",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross  &gt; . &gt;",
  "id" : 454148662260547584,
  "in_reply_to_status_id" : 454146506153414656,
  "created_at" : "2014-04-10 06:47:33 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "454137849487441920",
  "geo" : { },
  "id_str" : "454145358520528896",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross all TypedArrays are typeof object in V8",
  "id" : 454145358520528896,
  "in_reply_to_status_id" : 454137849487441920,
  "created_at" : "2014-04-10 06:34:25 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454143201230585856",
  "text" : "I learned the zero and the one, \nthen the one and the two, \nthen the two and the three.",
  "id" : 454143201230585856,
  "created_at" : "2014-04-10 06:25:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sudo Room",
      "screen_name" : "sudoroom",
      "indices" : [ 91, 100 ],
      "id_str" : "411733308",
      "id" : 411733308
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454080193427025920",
  "text" : "I'm listening to a trance wave  of interference patterns and I found a neural interface at @sudoroom",
  "id" : 454080193427025920,
  "created_at" : "2014-04-10 02:15:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Waugh",
      "screen_name" : "jdub",
      "indices" : [ 3, 8 ],
      "id_str" : "4690301",
      "id" : 4690301
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/theKos\/status\/454039117131546624\/photo\/1",
      "indices" : [ 10, 32 ],
      "url" : "http:\/\/t.co\/nzTqOehzyu",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk0SK9ICAAAZsWZ.png",
      "id_str" : "454039116850528256",
      "id" : 454039116850528256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk0SK9ICAAAZsWZ.png",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 324,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 554,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 184,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 866,
        "resize" : "fit",
        "w" : 1600
      } ],
      "display_url" : "pic.twitter.com\/nzTqOehzyu"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "454079978049531904",
  "text" : "RT @jdub: http:\/\/t.co\/nzTqOehzyu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/theKos\/status\/454039117131546624\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/nzTqOehzyu",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bk0SK9ICAAAZsWZ.png",
        "id_str" : "454039116850528256",
        "id" : 454039116850528256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bk0SK9ICAAAZsWZ.png",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 324,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 554,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 184,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 866,
          "resize" : "fit",
          "w" : 1600
        } ],
        "display_url" : "pic.twitter.com\/nzTqOehzyu"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "454077708792651776",
    "text" : "http:\/\/t.co\/nzTqOehzyu",
    "id" : 454077708792651776,
    "created_at" : "2014-04-10 02:05:36 +0000",
    "user" : {
      "name" : "Jeff Waugh",
      "screen_name" : "jdub",
      "protected" : false,
      "id_str" : "4690301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453689928635805696\/QX-fDaFu_normal.jpeg",
      "id" : 4690301,
      "verified" : false
    }
  },
  "id" : 454079978049531904,
  "created_at" : "2014-04-10 02:14:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/453966525418856448\/photo\/1",
      "indices" : [ 8, 30 ],
      "url" : "http:\/\/t.co\/fKzYncAfuA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BkzQJk_CYAAByZJ.jpg",
      "id_str" : "453966525423050752",
      "id" : 453966525423050752,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BkzQJk_CYAAByZJ.jpg",
      "sizes" : [ {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/fKzYncAfuA"
    } ],
    "hashtags" : [ {
      "text" : "selfie",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453966525418856448",
  "text" : "#selfie http:\/\/t.co\/fKzYncAfuA",
  "id" : 453966525418856448,
  "created_at" : "2014-04-09 18:43:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453801119634817024",
  "text" : "people been loving me on the dance floor since I hit it",
  "id" : 453801119634817024,
  "created_at" : "2014-04-09 07:46:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453799089516199936",
  "text" : "i do love what you notice",
  "id" : 453799089516199936,
  "created_at" : "2014-04-09 07:38:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/J0BkYSQEJH",
      "expanded_url" : "http:\/\/elhuervo.tumblr.com\/image\/52642212670",
      "display_url" : "elhuervo.tumblr.com\/image\/52642212\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453793637843750912",
  "text" : "likes \/ knows http:\/\/t.co\/J0BkYSQEJH",
  "id" : 453793637843750912,
  "created_at" : "2014-04-09 07:16:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/EKADLfmBCE",
      "expanded_url" : "http:\/\/elhuervo.tumblr.com\/",
      "display_url" : "elhuervo.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "453793422113923072",
  "text" : "likes http:\/\/t.co\/EKADLfmBCE",
  "id" : 453793422113923072,
  "created_at" : "2014-04-09 07:15:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Lord",
      "screen_name" : "jllord",
      "indices" : [ 0, 7 ],
      "id_str" : "126718519",
      "id" : 126718519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453736933768716288",
  "geo" : { },
  "id_str" : "453792139537707008",
  "in_reply_to_user_id" : 126718519,
  "text" : "@jllord I write these letters, and other emotions, often.  Leave it to some writer on the internet to presume the never-sent were lost.",
  "id" : 453792139537707008,
  "in_reply_to_status_id" : 453736933768716288,
  "created_at" : "2014-04-09 07:10:51 +0000",
  "in_reply_to_screen_name" : "jllord",
  "in_reply_to_user_id_str" : "126718519",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "indices" : [ 0, 8 ],
      "id_str" : "4784511",
      "id" : 4784511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "453739983552000000",
  "geo" : { },
  "id_str" : "453791126814613505",
  "in_reply_to_user_id" : 4784511,
  "text" : "@bigeasy it's good you're trying, tho.  and if you fall through the floor any given morning, getting out of bed, a wok is there to catch you",
  "id" : 453791126814613505,
  "in_reply_to_status_id" : 453739983552000000,
  "created_at" : "2014-04-09 07:06:50 +0000",
  "in_reply_to_screen_name" : "bigeasy",
  "in_reply_to_user_id_str" : "4784511",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "453432588858695680",
  "text" : "I WANT MY OWN BITCOIN PROTOCOL BACKEND",
  "id" : 453432588858695680,
  "created_at" : "2014-04-08 07:22:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stagas",
      "screen_name" : "stagas",
      "indices" : [ 0, 7 ],
      "id_str" : "50715651",
      "id" : 50715651
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 8, 17 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Samuel Ytterbrink",
      "screen_name" : "Neppord",
      "indices" : [ 18, 26 ],
      "id_str" : "63159372",
      "id" : 63159372
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/ihUGeSP8tQ",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/nvelope",
      "display_url" : "npmjs.org\/package\/nvelope"
    } ]
  },
  "in_reply_to_status_id_str" : "453276664949387264",
  "geo" : { },
  "id_str" : "453278116358545408",
  "in_reply_to_user_id" : 50715651,
  "text" : "@stagas @substack @Neppord \nit's mostly cuz our untamed functions!\nI'm building better envelopes and generators\nsee https:\/\/t.co\/ihUGeSP8tQ",
  "id" : 453278116358545408,
  "in_reply_to_status_id" : 453276664949387264,
  "created_at" : "2014-04-07 21:08:19 +0000",
  "in_reply_to_screen_name" : "stagas",
  "in_reply_to_user_id_str" : "50715651",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theorymix",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ {
      "indices" : [ 13, 35 ],
      "url" : "http:\/\/t.co\/lKjogaISsb",
      "expanded_url" : "http:\/\/studio.substack.net\/polytropon~$theorymix",
      "display_url" : "studio.substack.net\/polytropon~$th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "453272495827607552",
  "text" : "#theorymix \n\nhttp:\/\/t.co\/lKjogaISsb",
  "id" : 453272495827607552,
  "created_at" : "2014-04-07 20:45:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stagas",
      "screen_name" : "stagas",
      "indices" : [ 0, 7 ],
      "id_str" : "50715651",
      "id" : 50715651
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 8, 17 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/qFFBAUrAop",
      "expanded_url" : "http:\/\/studio.substack.net\/polytropon~$theorymix?time=1396843294983",
      "display_url" : "studio.substack.net\/polytropon~$th\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "452985667761340416",
  "geo" : { },
  "id_str" : "453020301232590849",
  "in_reply_to_user_id" : 46961216,
  "text" : "@stagas @substack\nwebaudio sets window._SAMPLERATE but not before the doc is ready so u have t press the any key\nhttp:\/\/t.co\/qFFBAUrAop",
  "id" : 453020301232590849,
  "in_reply_to_status_id" : 452985667761340416,
  "created_at" : "2014-04-07 04:03:51 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stagas",
      "screen_name" : "stagas",
      "indices" : [ 0, 7 ],
      "id_str" : "50715651",
      "id" : 50715651
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 8, 17 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/lKjogaISsb",
      "expanded_url" : "http:\/\/studio.substack.net\/polytropon~$theorymix",
      "display_url" : "studio.substack.net\/polytropon~$th\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "452933152588460032",
  "geo" : { },
  "id_str" : "452985667761340416",
  "in_reply_to_user_id" : 50715651,
  "text" : "@stagas @substack \nmemixed!\nhttp:\/\/t.co\/lKjogaISsb",
  "id" : 452985667761340416,
  "in_reply_to_status_id" : 452933152588460032,
  "created_at" : "2014-04-07 01:46:13 +0000",
  "in_reply_to_screen_name" : "stagas",
  "in_reply_to_user_id_str" : "50715651",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452964876151828480",
  "text" : "it looks good to feel beautiful.",
  "id" : 452964876151828480,
  "created_at" : "2014-04-07 00:23:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452961083335008256",
  "text" : "The answer is the destruction of the question.",
  "id" : 452961083335008256,
  "created_at" : "2014-04-07 00:08:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/wsF5uxYqbD",
      "expanded_url" : "http:\/\/neoism.info",
      "display_url" : "neoism.info"
    } ]
  },
  "geo" : { },
  "id_str" : "452960897426669568",
  "text" : "http:\/\/t.co\/wsF5uxYqbD\n&lt;meta http-equiv=\"refresh\" content=\"30\" \/&gt;",
  "id" : 452960897426669568,
  "created_at" : "2014-04-07 00:07:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/0SoTnuArvm",
      "expanded_url" : "http:\/\/neoism.info\/",
      "display_url" : "neoism.info"
    } ]
  },
  "geo" : { },
  "id_str" : "452958064086233088",
  "text" : "Neoism is a movement to create the illusion of a movement called Neoism.\nhttp:\/\/t.co\/0SoTnuArvm",
  "id" : 452958064086233088,
  "created_at" : "2014-04-06 23:56:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/yOp5MKxrJq",
      "expanded_url" : "http:\/\/www.neoism.info\/neoist_book.pdf",
      "display_url" : "neoism.info\/neoist_book.pdf"
    } ]
  },
  "geo" : { },
  "id_str" : "452956991330074624",
  "text" : "http:\/\/t.co\/yOp5MKxrJq\n\"Enjoy a painful and dizzzy love story b\/t Neoists and Neoism\"",
  "id" : 452956991330074624,
  "created_at" : "2014-04-06 23:52:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monoskop",
      "screen_name" : "monoskop",
      "indices" : [ 0, 9 ],
      "id_str" : "50769684",
      "id" : 50769684
    }, {
      "name" : "TOLKIEN BLACK",
      "screen_name" : "therealhennessy",
      "indices" : [ 22, 38 ],
      "id_str" : "137090436",
      "id" : 137090436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452894024999780352",
  "geo" : { },
  "id_str" : "452941467770560512",
  "in_reply_to_user_id" : 50769684,
  "text" : "@monoskop on topic cc\/@therealhennessy \"The Promised Land of Neoism\"",
  "id" : 452941467770560512,
  "in_reply_to_status_id" : 452894024999780352,
  "created_at" : "2014-04-06 22:50:35 +0000",
  "in_reply_to_screen_name" : "monoskop",
  "in_reply_to_user_id_str" : "50769684",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TOLKIEN BLACK",
      "screen_name" : "therealhennessy",
      "indices" : [ 0, 16 ],
      "id_str" : "137090436",
      "id" : 137090436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452860220101132288",
  "geo" : { },
  "id_str" : "452880047372660736",
  "in_reply_to_user_id" : 137090436,
  "text" : "@therealhennessy \nself-censoring on twitter for like 10 minutes or forever",
  "id" : 452880047372660736,
  "in_reply_to_status_id" : 452860220101132288,
  "created_at" : "2014-04-06 18:46:32 +0000",
  "in_reply_to_screen_name" : "therealhennessy",
  "in_reply_to_user_id_str" : "137090436",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452876468385611776",
  "text" : "pasted into the potential foreverness of the internet",
  "id" : 452876468385611776,
  "created_at" : "2014-04-06 18:32:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452665623860875266",
  "geo" : { },
  "id_str" : "452707080760070144",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar yeah font size pixels and css length pixels are not the same.  nobody understands.  jtype give you [width, height] for each letter.",
  "id" : 452707080760070144,
  "in_reply_to_status_id" : 452665623860875266,
  "created_at" : "2014-04-06 07:19:13 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/kfgKJyMkQ7",
      "expanded_url" : "http:\/\/requirebin.com\/embed?gist=NHQ\/10001318",
      "display_url" : "requirebin.com\/embed?gist=NHQ\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "452654936958840832",
  "geo" : { },
  "id_str" : "452655551281766400",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar modeule jtype gives heights using the DOM, measureText only does widths.\nhttp:\/\/t.co\/kfgKJyMkQ7",
  "id" : 452655551281766400,
  "in_reply_to_status_id" : 452654936958840832,
  "created_at" : "2014-04-06 03:54:28 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/TiYs7cgUa7",
      "expanded_url" : "http:\/\/jsbin.com\/golewowa\/4\/edit?js,console",
      "display_url" : "jsbin.com\/golewowa\/4\/edi\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "452650197516967936",
  "geo" : { },
  "id_str" : "452652325471911937",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar not sure what your example shows. I never used that method before tho.  Is that in pixels?  \nMonospace http:\/\/t.co\/TiYs7cgUa7",
  "id" : 452652325471911937,
  "in_reply_to_status_id" : 452650197516967936,
  "created_at" : "2014-04-06 03:41:38 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 85 ],
      "url" : "https:\/\/t.co\/DeRjB2Rfae",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/jtype",
      "display_url" : "npmjs.org\/package\/jtype"
    } ]
  },
  "in_reply_to_status_id_str" : "452621126489751552",
  "geo" : { },
  "id_str" : "452646001229037568",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar I'm pretty sure the pixel size is the same for both.  https:\/\/t.co\/DeRjB2Rfae",
  "id" : 452646001229037568,
  "in_reply_to_status_id" : 452621126489751552,
  "created_at" : "2014-04-06 03:16:31 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452585171879870464",
  "text" : "I let the chickens out front to eat snails today. \n\n\/me That's what twitter is for.  \n\nThey were easily corralled with tangents.",
  "id" : 452585171879870464,
  "created_at" : "2014-04-05 23:14:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Robinson Young",
      "screen_name" : "shamakry",
      "indices" : [ 0, 9 ],
      "id_str" : "16900280",
      "id" : 16900280
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "452305719010684928",
  "geo" : { },
  "id_str" : "452308385761734656",
  "in_reply_to_user_id" : 16900280,
  "text" : "@shamakry well dune guid srsly",
  "id" : 452308385761734656,
  "in_reply_to_status_id" : 452305719010684928,
  "created_at" : "2014-04-05 04:54:57 +0000",
  "in_reply_to_screen_name" : "shamakry",
  "in_reply_to_user_id_str" : "16900280",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "452211786079408128",
  "text" : "What have we learned?\n\nThat there should be no CEOs.\n\nThe end.",
  "id" : 452211786079408128,
  "created_at" : "2014-04-04 22:31:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451959563718115328",
  "text" : "its over\ni can build apps for the big EYE OS",
  "id" : 451959563718115328,
  "created_at" : "2014-04-04 05:48:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451932588978888704",
  "text" : "Eich deleted his twitter.  We should all follow suit.  This is a game of irlarp'n charades.  We'll have something better up in 3 months.",
  "id" : 451932588978888704,
  "created_at" : "2014-04-04 04:01:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451894402554662913",
  "text" : "OH:  \"Array.prototype.deduce:  takes an argument for reasoning\"",
  "id" : 451894402554662913,
  "created_at" : "2014-04-04 01:29:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451876827812753408",
  "text" : "BADGE ME:  Composed 80 line module of javascript in one take with zero errors.",
  "id" : 451876827812753408,
  "created_at" : "2014-04-04 00:20:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451876083764195328",
  "text" : "I aint even thinking.  I'm writing map reduces on instinct.",
  "id" : 451876083764195328,
  "created_at" : "2014-04-04 00:17:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451817299033354240",
  "text" : "pro-tip: don't do anything like a boss",
  "id" : 451817299033354240,
  "created_at" : "2014-04-03 20:23:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451758707928334336",
  "geo" : { },
  "id_str" : "451760535407558657",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia do me next",
  "id" : 451760535407558657,
  "in_reply_to_status_id" : 451758707928334336,
  "created_at" : "2014-04-03 16:37:59 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/QacFGl7ync",
      "expanded_url" : "http:\/\/studio.substack.net\/theorymix?time=1396513271743",
      "display_url" : "studio.substack.net\/theorymix?time\u2026"
    }, {
      "indices" : [ 89, 111 ],
      "url" : "http:\/\/t.co\/oL9rLJtrnE",
      "expanded_url" : "http:\/\/studio.substack.net\/-\/history\/theorymix",
      "display_url" : "studio.substack.net\/-\/history\/theo\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "451758975554289664",
  "text" : "I was groove n last night\nhttp:\/\/t.co\/QacFGl7ync\n\nnot sure which version I like the most\nhttp:\/\/t.co\/oL9rLJtrnE",
  "id" : 451758975554289664,
  "created_at" : "2014-04-03 16:31:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "John Schulz",
      "screen_name" : "JFSIII",
      "indices" : [ 13, 20 ],
      "id_str" : "4533541",
      "id" : 4533541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451616085247143936",
  "geo" : { },
  "id_str" : "451616719333638144",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @JFSIII \nLARGE",
  "id" : 451616719333638144,
  "in_reply_to_status_id" : 451616085247143936,
  "created_at" : "2014-04-03 07:06:31 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "disasteradio",
      "screen_name" : "disasteradio",
      "indices" : [ 0, 13 ],
      "id_str" : "90604368",
      "id" : 90604368
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451471328055267328",
  "geo" : { },
  "id_str" : "451488411568730112",
  "in_reply_to_user_id" : 90604368,
  "text" : "@disasteradio idk if you zealander's know this, but punks live to die... punks must die to live.....",
  "id" : 451488411568730112,
  "in_reply_to_status_id" : 451471328055267328,
  "created_at" : "2014-04-02 22:36:40 +0000",
  "in_reply_to_screen_name" : "disasteradio",
  "in_reply_to_user_id_str" : "90604368",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451465928689991680",
  "text" : "Who wrote this in what russian doll of a framework?",
  "id" : 451465928689991680,
  "created_at" : "2014-04-02 21:07:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twiter",
      "screen_name" : "twiter",
      "indices" : [ 0, 7 ],
      "id_str" : "2509250354",
      "id" : 2509250354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451465653187121152",
  "in_reply_to_user_id" : 2683371,
  "text" : "@twiter your web interface has the sux rly hard fyi",
  "id" : 451465653187121152,
  "created_at" : "2014-04-02 21:06:14 +0000",
  "in_reply_to_screen_name" : "bdavisseal",
  "in_reply_to_user_id_str" : "2683371",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DuckDuckGo",
      "screen_name" : "duckduckgo",
      "indices" : [ 61, 72 ],
      "id_str" : "14504859",
      "id" : 14504859
    }, {
      "name" : "Google",
      "screen_name" : "google",
      "indices" : [ 73, 80 ],
      "id_str" : "20536157",
      "id" : 20536157
    }, {
      "name" : "Bing",
      "screen_name" : "bing",
      "indices" : [ 81, 86 ],
      "id_str" : "14874480",
      "id" : 14874480
    }, {
      "name" : "Yahoo",
      "screen_name" : "Yahoo",
      "indices" : [ 87, 93 ],
      "id_str" : "19380829",
      "id" : 19380829
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 94, 106 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "npmbot",
      "screen_name" : "npmjs",
      "indices" : [ 107, 113 ],
      "id_str" : "309528017",
      "id" : 309528017
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "machineFunk",
      "indices" : [ 116, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451465283056582656",
  "text" : "Search engines need a \"try again\" button.  Get the clue?\n\ncc @duckduckgo @google @bing @yahoo @dominictarr @npmjs \n\n#machineFunk",
  "id" : 451465283056582656,
  "created_at" : "2014-04-02 21:04:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451166791868227584",
  "text" : "WHERES MY WRITE STUFF DOWN WITH KIT?\n\nITS LONG, TWISTED AND FITS IN A 8TH INCH.\n\nYOU KNOW?\n\nIT MAKES THE VIBRATIONS GO\n\nAND ITS ELECTRIC",
  "id" : 451166791868227584,
  "created_at" : "2014-04-02 01:18:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451164884806299648",
  "text" : "Where'd my good got go\nyeah\nway back chicago\nyeah\naint I bout to follow\nyeah\nno, said aint I bout follow\nyeah",
  "id" : 451164884806299648,
  "created_at" : "2014-04-02 01:11:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451151161936969728",
  "geo" : { },
  "id_str" : "451155994509189120",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr I don't read essays with titles that begin with \"how\" or \"why\".",
  "id" : 451155994509189120,
  "in_reply_to_status_id" : 451151161936969728,
  "created_at" : "2014-04-02 00:35:45 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "184987977",
      "id" : 184987977
    }, {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 15, 23 ],
      "id_str" : "33519541",
      "id" : 33519541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451120519619026944",
  "geo" : { },
  "id_str" : "451124953924919297",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah @pfrazee yes look at those weaves but note that you get a bolt of fabric, how you cut and hang it is up to you.",
  "id" : 451124953924919297,
  "in_reply_to_status_id" : 451120519619026944,
  "created_at" : "2014-04-01 22:32:25 +0000",
  "in_reply_to_screen_name" : "jesusabdullah",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Frazee",
      "screen_name" : "pfrazee",
      "indices" : [ 0, 8 ],
      "id_str" : "33519541",
      "id" : 33519541
    }, {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 9, 23 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hackerHouseWife",
      "indices" : [ 103, 119 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "451108340064473088",
  "geo" : { },
  "id_str" : "451115379075452928",
  "in_reply_to_user_id" : 33519541,
  "text" : "@pfrazee @jesusabdullah  Call it carbon sequestration.  Also, energy efficiency (thick curtains FTW).  #hackerHouseWife",
  "id" : 451115379075452928,
  "in_reply_to_status_id" : 451108340064473088,
  "created_at" : "2014-04-01 21:54:22 +0000",
  "in_reply_to_screen_name" : "pfrazee",
  "in_reply_to_user_id_str" : "33519541",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451110572084314112",
  "text" : "USER UPPERCUT",
  "id" : 451110572084314112,
  "created_at" : "2014-04-01 21:35:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 0, 14 ],
      "id_str" : "184987977",
      "id" : 184987977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/44DdNwXmlq",
      "expanded_url" : "http:\/\/www.hemptraders.com\/category-s\/1903.htm",
      "display_url" : "hemptraders.com\/category-s\/190\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "451101928093913088",
  "geo" : { },
  "id_str" : "451106822376550400",
  "in_reply_to_user_id" : 184987977,
  "text" : "@jesusabdullah funny you phrased it as such,  the tapestry of hackistan are made of heavy hemp canvas from http:\/\/t.co\/44DdNwXmlq",
  "id" : 451106822376550400,
  "in_reply_to_status_id" : 451101928093913088,
  "created_at" : "2014-04-01 21:20:22 +0000",
  "in_reply_to_screen_name" : "jesusabdullah",
  "in_reply_to_user_id_str" : "184987977",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451037775014289409",
  "text" : "Another nose report.  It smells like vehicle exhaust everywhere every day, and has been so as long as I've been breathing.",
  "id" : 451037775014289409,
  "created_at" : "2014-04-01 16:46:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "451037057461137408",
  "text" : "Don't ride in a BART car that has carpeted floors.  They always smell of mold, not only on rainy days.  Yuck.  Nose report PSA.",
  "id" : 451037057461137408,
  "created_at" : "2014-04-01 16:43:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450864335292616704",
  "geo" : { },
  "id_str" : "450867064408768512",
  "in_reply_to_user_id" : 46961216,
  "text" : "the URL as command\nthe web components of unix",
  "id" : 450867064408768512,
  "in_reply_to_status_id" : 450864335292616704,
  "created_at" : "2014-04-01 05:27:39 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450752032043827201",
  "geo" : { },
  "id_str" : "450864335292616704",
  "in_reply_to_user_id" : 46961216,
  "text" : "If make this, i'm calling it std3.js",
  "id" : 450864335292616704,
  "in_reply_to_status_id" : 450752032043827201,
  "created_at" : "2014-04-01 05:16:48 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Last",
      "screen_name" : "simonlast",
      "indices" : [ 0, 10 ],
      "id_str" : "29512984",
      "id" : 29512984
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 11, 23 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450760970776756225",
  "geo" : { },
  "id_str" : "450862764764852224",
  "in_reply_to_user_id" : 29512984,
  "text" : "@simonlast @dominictarr abstract the single poastMessage event to multiple event types. Then, in many cases, streams.  Buffers away!",
  "id" : 450862764764852224,
  "in_reply_to_status_id" : 450760970776756225,
  "created_at" : "2014-04-01 05:10:34 +0000",
  "in_reply_to_screen_name" : "simonlast",
  "in_reply_to_user_id_str" : "29512984",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450836776693673984",
  "text" : "We are living the theater of ideas.  Startup idea:  a traveling show.",
  "id" : 450836776693673984,
  "created_at" : "2014-04-01 03:27:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450833365764022272",
  "text" : "shut up and talk about the weather",
  "id" : 450833365764022272,
  "created_at" : "2014-04-01 03:13:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "450751612386934784",
  "geo" : { },
  "id_str" : "450752032043827201",
  "in_reply_to_user_id" : 46961216,
  "text" : "Then we can all make components, host them, and share them.  We can then build apps out of these components.  The web as package manager.",
  "id" : 450752032043827201,
  "in_reply_to_status_id" : 450751612386934784,
  "created_at" : "2014-03-31 21:50:33 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "450751612386934784",
  "text" : "I think the answer to web components is to make every component its own HTML page, use iframes, &amp; let them talk to each other w\/postMessage.",
  "id" : 450751612386934784,
  "created_at" : "2014-03-31 21:48:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]