Grailbird.data.tweets_2014_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506136059193741314",
  "geo" : { },
  "id_str" : "506136339876937728",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript \nor\nSYMBOLS.REDUCE(HHHUUUUURRRR)",
  "id" : 506136339876937728,
  "in_reply_to_status_id" : 506136059193741314,
  "created_at" : "2014-08-31 17:48:01 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506136059193741314",
  "text" : "symbols.reduce(fn(sym)\u007B\n  return HHHUUUUURRRR(sym)\n\u007D)",
  "id" : 506136059193741314,
  "created_at" : "2014-08-31 17:46:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506135760060170240",
  "text" : "symbols.reduce(fn(sym)\u007B\n  return HHHUUUUURRRR\n\u007D)",
  "id" : 506135760060170240,
  "created_at" : "2014-08-31 17:45:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506135383168401408",
  "text" : "BRANDS R KILLING THE METAPHOR STAR",
  "id" : 506135383168401408,
  "created_at" : "2014-08-31 17:44:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BLACK POWER",
      "screen_name" : "JUNGLEPUSSY",
      "indices" : [ 0, 12 ],
      "id_str" : "15819295",
      "id" : 15819295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506126839145041921",
  "geo" : { },
  "id_str" : "506127338807906304",
  "in_reply_to_user_id" : 15819295,
  "text" : "@JUNGLEPUSSY  YR FIRST LINE SHOULD BE \"OPRAH, SAY MY NAME\"",
  "id" : 506127338807906304,
  "in_reply_to_status_id" : 506126839145041921,
  "created_at" : "2014-08-31 17:12:15 +0000",
  "in_reply_to_screen_name" : "JUNGLEPUSSY",
  "in_reply_to_user_id_str" : "15819295",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "indices" : [ 0, 8 ],
      "id_str" : "4784511",
      "id" : 4784511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506125002018525184",
  "geo" : { },
  "id_str" : "506126623960076288",
  "in_reply_to_user_id" : 4784511,
  "text" : "@bigeasy  PAY ATTN U FOOLS!",
  "id" : 506126623960076288,
  "in_reply_to_status_id" : 506125002018525184,
  "created_at" : "2014-08-31 17:09:25 +0000",
  "in_reply_to_screen_name" : "bigeasy",
  "in_reply_to_user_id_str" : "4784511",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CARTELn",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506125606161887232",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain \nI will give you x BTC  \nIF \nyou pledge y BTC \nIFF \nI get z BTC in pledges for a crypto-ex trading software fund\n#CARTELn",
  "id" : 506125606161887232,
  "created_at" : "2014-08-31 17:05:22 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 78 ],
      "url" : "https:\/\/t.co\/Sc2CKvLkqs",
      "expanded_url" : "https:\/\/en.bitcoin.it\/wiki\/Contracts#Example_3:_Assurance_contracts",
      "display_url" : "en.bitcoin.it\/wiki\/Contracts\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "506118464000368641",
  "text" : "HAS ANY CRYPTOCAUCUS IMPLEMENTED ASSURANCE CONTRACTS?\n\nhttps:\/\/t.co\/Sc2CKvLkqs",
  "id" : 506118464000368641,
  "created_at" : "2014-08-31 16:36:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506117907277815809",
  "text" : "CRYPTOCURRENCY \n                 vs\nCORRUPTOCURRENCY\n\nVERY PLAY!  \nSUCH FIGHT!!!",
  "id" : 506117907277815809,
  "created_at" : "2014-08-31 16:34:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 3, 11 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tweettweet",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506115920557666304",
  "text" : "RT @Gyselie: What are the most important things to you? What do you tweet about? #tweettweet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tweettweet",
        "indices" : [ 68, 79 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.8374658871, -122.2645049244 ]
    },
    "id_str" : "506115387264495618",
    "text" : "What are the most important things to you? What do you tweet about? #tweettweet",
    "id" : 506115387264495618,
    "created_at" : "2014-08-31 16:24:46 +0000",
    "user" : {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "protected" : false,
      "id_str" : "433715578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469656620155154432\/1XOA8tYu_normal.jpeg",
      "id" : 433715578,
      "verified" : false
    }
  },
  "id" : 506115920557666304,
  "created_at" : "2014-08-31 16:26:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "506115665363599361",
  "text" : "HAPPY SEMI-ANNUAL 3-DAY-WEEKEND DAY AMERICA!!!",
  "id" : 506115665363599361,
  "created_at" : "2014-08-31 16:25:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/WHWVWrPZTG",
      "expanded_url" : "http:\/\/penarium.com\/",
      "display_url" : "penarium.com"
    } ]
  },
  "geo" : { },
  "id_str" : "506112581350617088",
  "text" : "http:\/\/t.co\/WHWVWrPZTG  looks like fun",
  "id" : 506112581350617088,
  "created_at" : "2014-08-31 16:13:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "okayafrica",
      "screen_name" : "okayafrica",
      "indices" : [ 0, 11 ],
      "id_str" : "92148954",
      "id" : 92148954
    }, {
      "name" : "Ibeyi",
      "screen_name" : "IbeyiOfficial",
      "indices" : [ 12, 26 ],
      "id_str" : "2231786521",
      "id" : 2231786521
    }, {
      "name" : "XL Recordings",
      "screen_name" : "XLRECORDINGS",
      "indices" : [ 27, 40 ],
      "id_str" : "20458588",
      "id" : 20458588
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "506112195441471488",
  "geo" : { },
  "id_str" : "506112283370455040",
  "in_reply_to_user_id" : 92148954,
  "text" : "@okayafrica @IbeyiOfficial @XLRECORDINGS \nYORUBA DUBA DOOOOOOOM",
  "id" : 506112283370455040,
  "in_reply_to_status_id" : 506112195441471488,
  "created_at" : "2014-08-31 16:12:26 +0000",
  "in_reply_to_screen_name" : "okayafrica",
  "in_reply_to_user_id_str" : "92148954",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505965387633025024",
  "geo" : { },
  "id_str" : "505972600796102656",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr v. senti mental",
  "id" : 505972600796102656,
  "in_reply_to_status_id" : 505965387633025024,
  "created_at" : "2014-08-31 06:57:23 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505966946467074048",
  "text" : "tasers that make cops dance",
  "id" : 505966946467074048,
  "created_at" : "2014-08-31 06:34:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lily",
      "screen_name" : "luxuriousho",
      "indices" : [ 3, 15 ],
      "id_str" : "21127389",
      "id" : 21127389
    }, {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 33, 46 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505880189830565888",
  "text" : "RT @luxuriousho: WHO R U AND WHY @johnnyscript",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "( +\\-)",
        "screen_name" : "johnnyscript",
        "indices" : [ 16, 29 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "505877940354023424",
    "geo" : { },
    "id_str" : "505878177059586048",
    "in_reply_to_user_id" : 46961216,
    "text" : "WHO R U AND WHY @johnnyscript",
    "id" : 505878177059586048,
    "in_reply_to_status_id" : 505877940354023424,
    "created_at" : "2014-08-31 00:42:10 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "lily",
      "screen_name" : "luxuriousho",
      "protected" : false,
      "id_str" : "21127389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544293572661772288\/n_o5oF9-_normal.jpeg",
      "id" : 21127389,
      "verified" : false
    }
  },
  "id" : 505880189830565888,
  "created_at" : "2014-08-31 00:50:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lily",
      "screen_name" : "luxuriousho",
      "indices" : [ 0, 12 ],
      "id_str" : "21127389",
      "id" : 21127389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505877454653648896",
  "geo" : { },
  "id_str" : "505877940354023424",
  "in_reply_to_user_id" : 21127389,
  "text" : "@luxuriousho  sometimes I wonder what the Disco is like with all those kewl rich kids getting transwardly mobile with it, pls report thx",
  "id" : 505877940354023424,
  "in_reply_to_status_id" : 505877454653648896,
  "created_at" : "2014-08-31 00:41:14 +0000",
  "in_reply_to_screen_name" : "luxuriousho",
  "in_reply_to_user_id_str" : "21127389",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505877460383068160",
  "text" : "i wish console.log was an API for artificial markup and style intelligence",
  "id" : 505877460383068160,
  "created_at" : "2014-08-31 00:39:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505877022334144512",
  "text" : "should i write mo crypto trading bot or synth interfacey stuff?  i have a front-end barrier to get over whenever it's time to de\/complexify",
  "id" : 505877022334144512,
  "created_at" : "2014-08-31 00:37:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505874881762693120",
  "geo" : { },
  "id_str" : "505875791112990720",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr which which is witch, and then which which is 'it\\'s'?",
  "id" : 505875791112990720,
  "in_reply_to_status_id" : 505874881762693120,
  "created_at" : "2014-08-31 00:32:41 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505874881762693120",
  "geo" : { },
  "id_str" : "505875543464484865",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr which which is its?",
  "id" : 505875543464484865,
  "in_reply_to_status_id" : 505874881762693120,
  "created_at" : "2014-08-31 00:31:42 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan Gutierrez",
      "screen_name" : "bigeasy",
      "indices" : [ 0, 8 ],
      "id_str" : "4784511",
      "id" : 4784511
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505873606891831296",
  "geo" : { },
  "id_str" : "505874725654913024",
  "in_reply_to_user_id" : 4784511,
  "text" : "@bigeasy  blockchain",
  "id" : 505874725654913024,
  "in_reply_to_status_id" : 505873606891831296,
  "created_at" : "2014-08-31 00:28:27 +0000",
  "in_reply_to_screen_name" : "bigeasy",
  "in_reply_to_user_id_str" : "4784511",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Give me Internet",
      "screen_name" : "GiveMeInternet",
      "indices" : [ 3, 18 ],
      "id_str" : "1611697987",
      "id" : 1611697987
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/GiveMeInternet\/status\/505807173142597632\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/BJy07PYlW9",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwT88ahCEAA4XQD.jpg",
      "id_str" : "505807173012557824",
      "id" : 505807173012557824,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwT88ahCEAA4XQD.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 640,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/BJy07PYlW9"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505840031974424577",
  "text" : "RT @GiveMeInternet: It comes with 2 subwoofers http:\/\/t.co\/BJy07PYlW9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/givemeinternet\" rel=\"nofollow\"\u003Egivemeinternet\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/GiveMeInternet\/status\/505807173142597632\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/BJy07PYlW9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BwT88ahCEAA4XQD.jpg",
        "id_str" : "505807173012557824",
        "id" : 505807173012557824,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwT88ahCEAA4XQD.jpg",
        "sizes" : [ {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 640,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/BJy07PYlW9"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505807173142597632",
    "text" : "It comes with 2 subwoofers http:\/\/t.co\/BJy07PYlW9",
    "id" : 505807173142597632,
    "created_at" : "2014-08-30 20:00:02 +0000",
    "user" : {
      "name" : "Give me Internet",
      "screen_name" : "GiveMeInternet",
      "protected" : false,
      "id_str" : "1611697987",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453526533622071296\/79NYk2Bn_normal.jpeg",
      "id" : 1611697987,
      "verified" : false
    }
  },
  "id" : 505840031974424577,
  "created_at" : "2014-08-30 22:10:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revisitors",
      "screen_name" : "revisitron",
      "indices" : [ 3, 14 ],
      "id_str" : "2764638757",
      "id" : 2764638757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/6XlVR9nLmF",
      "expanded_url" : "http:\/\/twitter.com\/revisitron\/status\/505826713637769216\/photo\/1",
      "display_url" : "pic.twitter.com\/6XlVR9nLmF"
    } ]
  },
  "geo" : { },
  "id_str" : "505832650934730752",
  "text" : "RT @revisitron: http:\/\/t.co\/6XlVR9nLmF",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/revisit.link\" rel=\"nofollow\"\u003Erevisitron-api\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/6XlVR9nLmF",
        "expanded_url" : "http:\/\/twitter.com\/revisitron\/status\/505826713637769216\/photo\/1",
        "display_url" : "pic.twitter.com\/6XlVR9nLmF"
      } ]
    },
    "geo" : { },
    "id_str" : "505826713637769216",
    "text" : "http:\/\/t.co\/6XlVR9nLmF",
    "id" : 505826713637769216,
    "created_at" : "2014-08-30 21:17:40 +0000",
    "user" : {
      "name" : "Revisitors",
      "screen_name" : "revisitron",
      "protected" : false,
      "id_str" : "2764638757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503700655022694400\/v367wUqF_normal.jpeg",
      "id" : 2764638757,
      "verified" : false
    }
  },
  "id" : 505832650934730752,
  "created_at" : "2014-08-30 21:41:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Revisitors",
      "screen_name" : "revisitron",
      "indices" : [ 3, 14 ],
      "id_str" : "2764638757",
      "id" : 2764638757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 38 ],
      "url" : "http:\/\/t.co\/7M0gDd4zVw",
      "expanded_url" : "http:\/\/twitter.com\/revisitron\/status\/505817392241725440\/photo\/1",
      "display_url" : "pic.twitter.com\/7M0gDd4zVw"
    } ]
  },
  "geo" : { },
  "id_str" : "505832603241299968",
  "text" : "RT @revisitron: http:\/\/t.co\/7M0gDd4zVw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/revisit.link\" rel=\"nofollow\"\u003Erevisitron-api\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/7M0gDd4zVw",
        "expanded_url" : "http:\/\/twitter.com\/revisitron\/status\/505817392241725440\/photo\/1",
        "display_url" : "pic.twitter.com\/7M0gDd4zVw"
      } ]
    },
    "geo" : { },
    "id_str" : "505817392241725440",
    "text" : "http:\/\/t.co\/7M0gDd4zVw",
    "id" : 505817392241725440,
    "created_at" : "2014-08-30 20:40:38 +0000",
    "user" : {
      "name" : "Revisitors",
      "screen_name" : "revisitron",
      "protected" : false,
      "id_str" : "2764638757",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/503700655022694400\/v367wUqF_normal.jpeg",
      "id" : 2764638757,
      "verified" : false
    }
  },
  "id" : 505832603241299968,
  "created_at" : "2014-08-30 21:41:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505822228529704960",
  "text" : "Good day for a light hangover",
  "id" : 505822228529704960,
  "created_at" : "2014-08-30 20:59:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/505821073711968256\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/HHVF7keJUN",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwUJjMkCEAA4o21.jpg",
      "id_str" : "505821033421475840",
      "id" : 505821033421475840,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwUJjMkCEAA4o21.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/HHVF7keJUN"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505821073711968256",
  "text" : "A person, say, a churchgoer, would have to strain to view me laying here balls in hand. but they could and idk http:\/\/t.co\/HHVF7keJUN",
  "id" : 505821073711968256,
  "created_at" : "2014-08-30 20:55:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gysel Parajon",
      "screen_name" : "Gyselie",
      "indices" : [ 0, 8 ],
      "id_str" : "433715578",
      "id" : 433715578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505796096594288640",
  "geo" : { },
  "id_str" : "505797435830984704",
  "in_reply_to_user_id" : 433715578,
  "text" : "@Gyselie  YEUH",
  "id" : 505797435830984704,
  "in_reply_to_status_id" : 505796096594288640,
  "created_at" : "2014-08-30 19:21:20 +0000",
  "in_reply_to_screen_name" : "Gyselie",
  "in_reply_to_user_id_str" : "433715578",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505792927184855040",
  "text" : "KISS ME\nHUG ME\nFUCK ME \nTOUCH ME\nDID I JUS WRITE A BANGER\nOR DID U JUS BANG A WRITER\nBABY\nO BABY\nYA BIG BABY\nKISS ME\nTOUCH ME\nFUCK ME\nREPEAT",
  "id" : 505792927184855040,
  "created_at" : "2014-08-30 19:03:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505776522506940417",
  "text" : "urban dictionary trying way too hard",
  "id" : 505776522506940417,
  "created_at" : "2014-08-30 17:58:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/505770911778095104\/photo\/1",
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/JpP3LE4p74",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwTb9rmCMAA7ff7.jpg",
      "id_str" : "505770910893092864",
      "id" : 505770910893092864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwTb9rmCMAA7ff7.jpg",
      "sizes" : [ {
        "h" : 928,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 928,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 928,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 525,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/JpP3LE4p74"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/OZdMEb6nqb",
      "expanded_url" : "http:\/\/www.hieroday.com\/",
      "display_url" : "hieroday.com"
    } ]
  },
  "geo" : { },
  "id_str" : "505770911778095104",
  "text" : "MONDAY OAKLAND HIEROGLYPHICS REPREZENTZENT\n\nhttp:\/\/t.co\/OZdMEb6nqb http:\/\/t.co\/JpP3LE4p74",
  "id" : 505770911778095104,
  "created_at" : "2014-08-30 17:35:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/7vH7dgHYXb",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=6zJcdCEpfDw&feature=youtu.be&t=2m22s",
      "display_url" : "youtube.com\/watch?v=6zJcdC\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505767083238359040",
  "text" : "U ARE INVITED BY ANYONE TO DO ANYTHING\nhttps:\/\/t.co\/7vH7dgHYXb",
  "id" : 505767083238359040,
  "created_at" : "2014-08-30 17:20:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BLACK POWER",
      "screen_name" : "JUNGLEPUSSY",
      "indices" : [ 0, 12 ],
      "id_str" : "15819295",
      "id" : 15819295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 40 ],
      "url" : "https:\/\/t.co\/puRRkPwYtF",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=6zJcdCEpfDw",
      "display_url" : "youtube.com\/watch?v=6zJcdC\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "505759943887441920",
  "geo" : { },
  "id_str" : "505766524917792768",
  "in_reply_to_user_id" : 15819295,
  "text" : "@JUNGLEPUSSY hyg https:\/\/t.co\/puRRkPwYtF",
  "id" : 505766524917792768,
  "in_reply_to_status_id" : 505759943887441920,
  "created_at" : "2014-08-30 17:18:30 +0000",
  "in_reply_to_screen_name" : "JUNGLEPUSSY",
  "in_reply_to_user_id_str" : "15819295",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505649908708151296",
  "text" : "MANKINDNESS",
  "id" : 505649908708151296,
  "created_at" : "2014-08-30 09:35:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "indices" : [ 60, 73 ],
      "id_str" : "2652920774",
      "id" : 2652920774
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/505649411955765249\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/5PzJVtQiyl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwRtddyCIAEv4jC.png",
      "id_str" : "505649411150454785",
      "id" : 505649411150454785,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwRtddyCIAEv4jC.png",
      "sizes" : [ {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/5PzJVtQiyl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505649411955765249",
  "text" : "WHICH BREEDS DO U WANT FOR THE DOGE RISING OF MANKINDNESS? .@theDogeparty \n\nITS DOGE \nVERY COIN OF SERVICE TO MANITY http:\/\/t.co\/5PzJVtQiyl",
  "id" : 505649411955765249,
  "created_at" : "2014-08-30 09:33:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505647797752717312",
  "text" : "WHICH AM I MISSING",
  "id" : 505647797752717312,
  "created_at" : "2014-08-30 09:26:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505636387186438144",
  "text" : "AHAHAHA U NEWBS",
  "id" : 505636387186438144,
  "created_at" : "2014-08-30 08:41:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505636264339468288",
  "text" : "STUDy SHOW\nA FORCE APPLIED 2 A MASS\nWILL AFFECT THAT MASS\nUNLESS STUDY WAS \nPERFORMED WITHIN SAID MASS\nAND THE FORCE WAS EQUALLY DISTRIBUTED",
  "id" : 505636264339468288,
  "created_at" : "2014-08-30 08:40:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505634961601224704",
  "text" : "I SWEAR 2 GOD U BETTER JOIN ME IN THIS FRONT OR I WILL CUT OFF THE BALLS OF SCIENCE",
  "id" : 505634961601224704,
  "created_at" : "2014-08-30 08:35:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505634739592499200",
  "text" : "ENTER INTO THE RECORD\nWHAT SOnSO REMEMBERS\nFROM THE DREAM\nWE WOKE SOnSO FROM\nIN THE COLD ROOM\nOF EXPERIMENTATION\nYES",
  "id" : 505634739592499200,
  "created_at" : "2014-08-30 08:34:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505633901675823104",
  "text" : "it happened in my head, which is where it all else happened, so what",
  "id" : 505633901675823104,
  "created_at" : "2014-08-30 08:31:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505633616072691712",
  "text" : "shit fuck you guys, if psych and econ are real by science, then fiction is permissable as evidence",
  "id" : 505633616072691712,
  "created_at" : "2014-08-30 08:30:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505632393638584320",
  "text" : "do you hate my bare chest, my hair, mu mystache?",
  "id" : 505632393638584320,
  "created_at" : "2014-08-30 08:25:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505632138385829888",
  "text" : "seriously, who are you, you better have something to say about science, muffhucker",
  "id" : 505632138385829888,
  "created_at" : "2014-08-30 08:24:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505631902116507648",
  "text" : "disagree with me now, or join the front:\n\npsychology and economics, they are not real science\n\nthey be extrapolations on extremely rare data",
  "id" : 505631902116507648,
  "created_at" : "2014-08-30 08:23:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505631588269318144",
  "text" : "is it because I myself am so rarely scientist?",
  "id" : 505631588269318144,
  "created_at" : "2014-08-30 08:22:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505631440592445440",
  "text" : "Is it my lot in this life to die arguing what pseudo sciences psychology and economics are?",
  "id" : 505631440592445440,
  "created_at" : "2014-08-30 08:21:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505587917855526912",
  "text" : "my idea, at nine years of age, was that there must be plenty of BLM land for dogs.  I was then living on area 51, so my sense of space was..",
  "id" : 505587917855526912,
  "created_at" : "2014-08-30 05:28:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505587668957155328",
  "text" : "i don't have anything against burning man, it sounds like a wonderful thing",
  "id" : 505587668957155328,
  "created_at" : "2014-08-30 05:27:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505586131539226624",
  "text" : "i lost that dream a long time ago",
  "id" : 505586131539226624,
  "created_at" : "2014-08-30 05:21:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505586047917363200",
  "text" : "when i was a child &amp; my only friend was a dog, my main dream was to build a 365 burning man, but for dogs that were gonna be \"euthanized\".",
  "id" : 505586047917363200,
  "created_at" : "2014-08-30 05:21:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "indices" : [ 0, 13 ],
      "id_str" : "2652920774",
      "id" : 2652920774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505584256953745408",
  "in_reply_to_user_id" : 2652920774,
  "text" : "@theDogeparty how long does asset creation take usually?",
  "id" : 505584256953745408,
  "created_at" : "2014-08-30 05:14:14 +0000",
  "in_reply_to_screen_name" : "theDogeparty",
  "in_reply_to_user_id_str" : "2652920774",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sound Wallet",
      "screen_name" : "bitcoinpotato",
      "indices" : [ 0, 14 ],
      "id_str" : "2155219346",
      "id" : 2155219346
    }, {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "indices" : [ 15, 28 ],
      "id_str" : "2652920774",
      "id" : 2652920774
    }, {
      "name" : "WorldCryptoNetwork",
      "screen_name" : "WorldCryptoNet",
      "indices" : [ 29, 44 ],
      "id_str" : "2321928620",
      "id" : 2321928620
    }, {
      "name" : "Bitcoin Art Gallery",
      "screen_name" : "btcArtGallery",
      "indices" : [ 45, 59 ],
      "id_str" : "9880182",
      "id" : 9880182
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505531844625182720",
  "geo" : { },
  "id_str" : "505568563730460673",
  "in_reply_to_user_id" : 2155219346,
  "text" : "@bitcoinpotato @theDogeparty @WorldCryptoNet @btcArtGallery \nI PRAY THE DOGES RISE UP AND SALIVATE MANKINDESS!!!",
  "id" : 505568563730460673,
  "in_reply_to_status_id" : 505531844625182720,
  "created_at" : "2014-08-30 04:11:53 +0000",
  "in_reply_to_screen_name" : "bitcoinpotato",
  "in_reply_to_user_id_str" : "2155219346",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sound Wallet",
      "screen_name" : "bitcoinpotato",
      "indices" : [ 3, 17 ],
      "id_str" : "2155219346",
      "id" : 2155219346
    }, {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "indices" : [ 19, 32 ],
      "id_str" : "2652920774",
      "id" : 2652920774
    }, {
      "name" : "WorldCryptoNetwork",
      "screen_name" : "WorldCryptoNet",
      "indices" : [ 122, 137 ],
      "id_str" : "2321928620",
      "id" : 2321928620
    }, {
      "name" : "Bitcoin Art Gallery",
      "screen_name" : "btcArtGallery",
      "indices" : [ 139, 140 ],
      "id_str" : "9880182",
      "id" : 9880182
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "doge",
      "indices" : [ 96, 101 ]
    }, {
      "text" : "dogeparty",
      "indices" : [ 102, 112 ]
    }, {
      "text" : "bitcoin",
      "indices" : [ 113, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/76sYBpd1Xr",
      "expanded_url" : "http:\/\/coinprayers.com\/dogeparty\/",
      "display_url" : "coinprayers.com\/dogeparty\/"
    } ]
  },
  "geo" : { },
  "id_str" : "505566910621032448",
  "text" : "RT @bitcoinpotato: @theDogeparty PRAY FOR ASSETS http:\/\/t.co\/76sYBpd1Xr DOGEPARTY ASSET FAUCET! #doge #dogeparty #bitcoin @WorldCryptoNet @\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dogeparty",
        "screen_name" : "theDogeparty",
        "indices" : [ 0, 13 ],
        "id_str" : "2652920774",
        "id" : 2652920774
      }, {
        "name" : "WorldCryptoNetwork",
        "screen_name" : "WorldCryptoNet",
        "indices" : [ 103, 118 ],
        "id_str" : "2321928620",
        "id" : 2321928620
      }, {
        "name" : "Bitcoin Art Gallery",
        "screen_name" : "btcArtGallery",
        "indices" : [ 119, 133 ],
        "id_str" : "9880182",
        "id" : 9880182
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "doge",
        "indices" : [ 77, 82 ]
      }, {
        "text" : "dogeparty",
        "indices" : [ 83, 93 ]
      }, {
        "text" : "bitcoin",
        "indices" : [ 94, 102 ]
      } ],
      "urls" : [ {
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/76sYBpd1Xr",
        "expanded_url" : "http:\/\/coinprayers.com\/dogeparty\/",
        "display_url" : "coinprayers.com\/dogeparty\/"
      } ]
    },
    "geo" : { },
    "id_str" : "505531844625182720",
    "in_reply_to_user_id" : 2652920774,
    "text" : "@theDogeparty PRAY FOR ASSETS http:\/\/t.co\/76sYBpd1Xr DOGEPARTY ASSET FAUCET! #doge #dogeparty #bitcoin @WorldCryptoNet @btcArtGallery",
    "id" : 505531844625182720,
    "created_at" : "2014-08-30 01:45:58 +0000",
    "in_reply_to_screen_name" : "theDogeparty",
    "in_reply_to_user_id_str" : "2652920774",
    "user" : {
      "name" : "Sound Wallet",
      "screen_name" : "bitcoinpotato",
      "protected" : false,
      "id_str" : "2155219346",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479173057685094401\/f8inhRKa_normal.jpeg",
      "id" : 2155219346,
      "verified" : false
    }
  },
  "id" : 505566910621032448,
  "created_at" : "2014-08-30 04:05:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505566623592243201",
  "text" : "i am an extremely empathetic person.\n\neverybody feels what I feel.",
  "id" : 505566623592243201,
  "created_at" : "2014-08-30 04:04:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "edna piranha",
      "screen_name" : "ednapiranha",
      "indices" : [ 0, 12 ],
      "id_str" : "14113407",
      "id" : 14113407
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505550434161786880",
  "geo" : { },
  "id_str" : "505551150427287552",
  "in_reply_to_user_id" : 14113407,
  "text" : "@ednapiranha confirmed",
  "id" : 505551150427287552,
  "in_reply_to_status_id" : 505550434161786880,
  "created_at" : "2014-08-30 03:02:41 +0000",
  "in_reply_to_screen_name" : "ednapiranha",
  "in_reply_to_user_id_str" : "14113407",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505547044006547456",
  "text" : "HAVE WE ACCEPTED SLUTS YET???",
  "id" : 505547044006547456,
  "created_at" : "2014-08-30 02:46:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505546147914477568",
  "text" : "i think i'll drink an udder",
  "id" : 505546147914477568,
  "created_at" : "2014-08-30 02:42:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505546071364206594",
  "text" : "yes, i did the entire bottle wutwut",
  "id" : 505546071364206594,
  "created_at" : "2014-08-30 02:42:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505537015899627520",
  "text" : "Im drinking a bottle of California \"Gewurztraminer\".  so i suppose those people are not as trademark touchy as the Champagne race.",
  "id" : 505537015899627520,
  "created_at" : "2014-08-30 02:06:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505533352645251072",
  "geo" : { },
  "id_str" : "505536034877108225",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  jk  i dreaming about a quad rotor motorbehicle",
  "id" : 505536034877108225,
  "in_reply_to_status_id" : 505533352645251072,
  "created_at" : "2014-08-30 02:02:37 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505533352645251072",
  "geo" : { },
  "id_str" : "505535874990219264",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar oops how do i get that in about 10x more power?",
  "id" : 505535874990219264,
  "in_reply_to_status_id" : 505533352645251072,
  "created_at" : "2014-08-30 02:01:59 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505533352645251072",
  "geo" : { },
  "id_str" : "505535798549028864",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  how do I get that",
  "id" : 505535798549028864,
  "in_reply_to_status_id" : 505533352645251072,
  "created_at" : "2014-08-30 02:01:41 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505532579869904897",
  "geo" : { },
  "id_str" : "505532798573092864",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar so does he bolt clamp the inner ring of the bearing then?",
  "id" : 505532798573092864,
  "in_reply_to_status_id" : 505532579869904897,
  "created_at" : "2014-08-30 01:49:46 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505532025416450048",
  "geo" : { },
  "id_str" : "505532347454742529",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar so like how do you connect that to the rod that goes thru it?  Hot glue?",
  "id" : 505532347454742529,
  "in_reply_to_status_id" : 505532025416450048,
  "created_at" : "2014-08-30 01:47:58 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505531651267383296",
  "text" : "i don;t always dream...\nokay, most of the time, I am dreaming,\nand when I do,\nI dream consciously\nyall sleepin",
  "id" : 505531651267383296,
  "created_at" : "2014-08-30 01:45:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505531215227523072",
  "geo" : { },
  "id_str" : "505531331254550528",
  "in_reply_to_user_id" : 46961216,
  "text" : "@tmpvar when i dream of spinning things",
  "id" : 505531331254550528,
  "in_reply_to_status_id" : 505531215227523072,
  "created_at" : "2014-08-30 01:43:56 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505530892807569408",
  "geo" : { },
  "id_str" : "505531215227523072",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar  cool sometimes i internet window shop bearings but I have no idea.  what do these look like?",
  "id" : 505531215227523072,
  "in_reply_to_status_id" : 505530892807569408,
  "created_at" : "2014-08-30 01:43:28 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505529414206377984",
  "geo" : { },
  "id_str" : "505530756425199616",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar are those balls only?",
  "id" : 505530756425199616,
  "in_reply_to_status_id" : 505529414206377984,
  "created_at" : "2014-08-30 01:41:39 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/SFEJ2TpLZ8",
      "expanded_url" : "http:\/\/meta.florist",
      "display_url" : "meta.florist"
    } ]
  },
  "geo" : { },
  "id_str" : "505530209605410816",
  "text" : "IN FACT the entire florist domain should forward to http:\/\/t.co\/SFEJ2TpLZ8",
  "id" : 505530209605410816,
  "created_at" : "2014-08-30 01:39:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505529957473214464",
  "text" : "shirley I now posses the only worthwhile domain name in the entire \"florist\" TLD",
  "id" : 505529957473214464,
  "created_at" : "2014-08-30 01:38:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505529450314743808",
  "text" : "hey u\n\nwith the zine\n\nhaves i got the domain name 4 u",
  "id" : 505529450314743808,
  "created_at" : "2014-08-30 01:36:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/SFEJ2TpLZ8",
      "expanded_url" : "http:\/\/meta.florist",
      "display_url" : "meta.florist"
    } ]
  },
  "geo" : { },
  "id_str" : "505528988991639552",
  "text" : "well I did it\n\ni registered http:\/\/t.co\/SFEJ2TpLZ8\n\nand I will sell it for a ridiculous price only",
  "id" : 505528988991639552,
  "created_at" : "2014-08-30 01:34:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 31 ],
      "url" : "http:\/\/t.co\/fuZNn6SJ0u",
      "expanded_url" : "http:\/\/metaphor.club",
      "display_url" : "metaphor.club"
    } ]
  },
  "geo" : { },
  "id_str" : "505527878448971776",
  "text" : "i wanted http:\/\/t.co\/fuZNn6SJ0u but it is not available so the system still fails miserably",
  "id" : 505527878448971776,
  "created_at" : "2014-08-30 01:30:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505527264595828736",
  "text" : "I COULD WRITE A GREAT SURREAL DNS POEM\n\nFOR ABOUT 700 DOLLARS IN REGISTRATION FEES",
  "id" : 505527264595828736,
  "created_at" : "2014-08-30 01:27:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/g8NPZBV6lN",
      "expanded_url" : "http:\/\/metaphor.bargains",
      "display_url" : "metaphor.bargains"
    } ]
  },
  "geo" : { },
  "id_str" : "505526753406619648",
  "text" : "lol how about doge spend some crypto earnings on new TLDs lik http:\/\/t.co\/g8NPZBV6lN!!!",
  "id" : 505526753406619648,
  "created_at" : "2014-08-30 01:25:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505524197334851584",
  "text" : "my two forks",
  "id" : 505524197334851584,
  "created_at" : "2014-08-30 01:15:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505523567493005313",
  "text" : "hahahaha i exchange you for a slug\n\nand i was only putting the slug in its proper place\n\nwhere you end up will be determined by the market!!",
  "id" : 505523567493005313,
  "created_at" : "2014-08-30 01:13:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon The Slug",
      "screen_name" : "simon_the_slug",
      "indices" : [ 3, 18 ],
      "id_str" : "2754519933",
      "id" : 2754519933
    }, {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 20, 33 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505522832957116416",
  "text" : "RT @simon_the_slug: @johnnyscript sorry bro",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "( +\\-)",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "505522271746658304",
    "geo" : { },
    "id_str" : "505522641923760128",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript sorry bro",
    "id" : 505522641923760128,
    "in_reply_to_status_id" : 505522271746658304,
    "created_at" : "2014-08-30 01:09:24 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Simon The Slug",
      "screen_name" : "simon_the_slug",
      "protected" : false,
      "id_str" : "2754519933",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/505345731260329984\/52YpSUAT_normal.jpeg",
      "id" : 2754519933,
      "verified" : false
    }
  },
  "id" : 505522832957116416,
  "created_at" : "2014-08-30 01:10:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505522271746658304",
  "text" : "stop following, you slug",
  "id" : 505522271746658304,
  "created_at" : "2014-08-30 01:07:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505522170143850497",
  "text" : "i wish there was an exxchange for ttwatter fallowers",
  "id" : 505522170143850497,
  "created_at" : "2014-08-30 01:07:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505521838462468097",
  "text" : "my followers apparently don't know good shit when they read it.  how i do i get new followers?",
  "id" : 505521838462468097,
  "created_at" : "2014-08-30 01:06:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505521558035505152",
  "text" : "soon i will be staging a zerg rush \non the crypto currency exchange\nre: about which i must reserve much\nn hold out 4 a price worthy o payn",
  "id" : 505521558035505152,
  "created_at" : "2014-08-30 01:05:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505509369107062784",
  "text" : "UNIVARIANCE IS ENUF",
  "id" : 505509369107062784,
  "created_at" : "2014-08-30 00:16:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505468363124899840",
  "text" : "IF YOU CANNOT THROW YOUR ORGANIC REFUSE THROUGH A WINDOW, WITH NO FURTHER REGARD, U DONE GAVE UP TOO MUCH",
  "id" : 505468363124899840,
  "created_at" : "2014-08-29 21:33:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\uFF61\u25D5 \u203F \u25D5\uFF61\u3000\u30CF\u30D5\u30ED\u30FC",
      "screen_name" : "HFLW",
      "indices" : [ 3, 8 ],
      "id_str" : "14694079",
      "id" : 14694079
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 10, 19 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Juke Nukem",
      "screen_name" : "ENAML",
      "indices" : [ 20, 26 ],
      "id_str" : "45786550",
      "id" : 45786550
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505464670061203456",
  "text" : "RT @HFLW: @maxogden @ENAML java is to javascript as apple is to pineapple",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "maxwell ogden",
        "screen_name" : "maxogden",
        "indices" : [ 0, 9 ],
        "id_str" : "12241752",
        "id" : 12241752
      }, {
        "name" : "Juke Nukem",
        "screen_name" : "ENAML",
        "indices" : [ 10, 16 ],
        "id_str" : "45786550",
        "id" : 45786550
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "505461122908954624",
    "geo" : { },
    "id_str" : "505464179781029888",
    "in_reply_to_user_id" : 12241752,
    "text" : "@maxogden @ENAML java is to javascript as apple is to pineapple",
    "id" : 505464179781029888,
    "in_reply_to_status_id" : 505461122908954624,
    "created_at" : "2014-08-29 21:17:06 +0000",
    "in_reply_to_screen_name" : "maxogden",
    "in_reply_to_user_id_str" : "12241752",
    "user" : {
      "name" : "\uFF61\u25D5 \u203F \u25D5\uFF61\u3000\u30CF\u30D5\u30ED\u30FC",
      "screen_name" : "HFLW",
      "protected" : false,
      "id_str" : "14694079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/516951037077254146\/pX46Byrf_normal.jpeg",
      "id" : 14694079,
      "verified" : false
    }
  },
  "id" : 505464670061203456,
  "created_at" : "2014-08-29 21:19:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 3, 12 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505464458643120128",
  "text" : "RT @maxogden: java is to javascript as taco is to tacoma",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505461122908954624",
    "text" : "java is to javascript as taco is to tacoma",
    "id" : 505461122908954624,
    "created_at" : "2014-08-29 21:04:57 +0000",
    "user" : {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "protected" : false,
      "id_str" : "12241752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/522616708922499072\/phDVjQSo_normal.jpeg",
      "id" : 12241752,
      "verified" : false
    }
  },
  "id" : 505464458643120128,
  "created_at" : "2014-08-29 21:18:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505453890376970240",
  "text" : "THE SECOND RULE OF YORUBA DOOM IS YOU DO NOT YORUBA DOOM UNLESS YORUBA HAVE TOO",
  "id" : 505453890376970240,
  "created_at" : "2014-08-29 20:36:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505453467398201344",
  "text" : "THE FIRST RULE OF YORUBA DOOM IS YOU DON'T YORUBA DOOM YRSELF!!!",
  "id" : 505453467398201344,
  "created_at" : "2014-08-29 20:34:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505453348422578176",
  "text" : "I DO NOT YORUBA DOOM MYSELF",
  "id" : 505453348422578176,
  "created_at" : "2014-08-29 20:34:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505452911610978305",
  "text" : "YORUBA DOOM DO YA?",
  "id" : 505452911610978305,
  "created_at" : "2014-08-29 20:32:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505452572388237312",
  "text" : "Yoruba Doom Soulja Boy",
  "id" : 505452572388237312,
  "created_at" : "2014-08-29 20:30:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BLACK POWER",
      "screen_name" : "JUNGLEPUSSY",
      "indices" : [ 3, 15 ],
      "id_str" : "15819295",
      "id" : 15819295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505449815027630080",
  "text" : "RT @JUNGLEPUSSY: ONLY GIVING WHAT IM GIVING  WHEN I GIVE IT CUZ IT FEEEL GOOOOOD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505448887713554432",
    "text" : "ONLY GIVING WHAT IM GIVING  WHEN I GIVE IT CUZ IT FEEEL GOOOOOD",
    "id" : 505448887713554432,
    "created_at" : "2014-08-29 20:16:20 +0000",
    "user" : {
      "name" : "BLACK POWER",
      "screen_name" : "JUNGLEPUSSY",
      "protected" : false,
      "id_str" : "15819295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540918599418777600\/chzyY26l_normal.jpeg",
      "id" : 15819295,
      "verified" : false
    }
  },
  "id" : 505449815027630080,
  "created_at" : "2014-08-29 20:20:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505449648438272000",
  "text" : "check out my new album featuring me smacking my thighs a lot",
  "id" : 505449648438272000,
  "created_at" : "2014-08-29 20:19:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505449306237571073",
  "text" : "i enjoy dipping, flipping, and whipping",
  "id" : 505449306237571073,
  "created_at" : "2014-08-29 20:18:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505445842384216065",
  "text" : "ok i gotta stop param flipping and build a dang user interface for to play wif my bells",
  "id" : 505445842384216065,
  "created_at" : "2014-08-29 20:04:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505445273141653504",
  "text" : "what are the frequencies for the doorbell that goes ding dong dong ding \/\/ dong ding ding dong ?",
  "id" : 505445273141653504,
  "created_at" : "2014-08-29 20:01:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505425676816494593",
  "geo" : { },
  "id_str" : "505426063061573632",
  "in_reply_to_user_id" : 46961216,
  "text" : "@dominictarr but I don't know if that is for AM or FM synthesis rly...  my solution sounds brilliant tho, which was to use mod gaussian dist",
  "id" : 505426063061573632,
  "in_reply_to_status_id" : 505425676816494593,
  "created_at" : "2014-08-29 18:45:38 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505424366826319872",
  "geo" : { },
  "id_str" : "505425676816494593",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr If I read the shema right, I think u add ( the sum of the signals ) to ( the difference of the signals )",
  "id" : 505425676816494593,
  "in_reply_to_status_id" : 505424366826319872,
  "created_at" : "2014-08-29 18:44:06 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505392559103811584",
  "geo" : { },
  "id_str" : "505421790240206849",
  "in_reply_to_user_id" : 46961216,
  "text" : "AAAHHHHH ITS CUZ I NEED TO TEACH MY CRYPTO TRADING BOT HOW TO DUMP!!!",
  "id" : 505421790240206849,
  "in_reply_to_status_id" : 505392559103811584,
  "created_at" : "2014-08-29 18:28:39 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505420489922072577",
  "text" : "COW 2 CHURCH BELLS",
  "id" : 505420489922072577,
  "created_at" : "2014-08-29 18:23:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505416927238311936",
  "text" : "i dont know how to make a ring mod but I made the effect some other how cuz imma beast of the time domain",
  "id" : 505416927238311936,
  "created_at" : "2014-08-29 18:09:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/qn2nVGFigF",
      "expanded_url" : "http:\/\/www.musicdsp.org\/archive.php?classid=4#169",
      "display_url" : "musicdsp.org\/archive.php?cl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "505410405523415041",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr compressor code http:\/\/t.co\/qn2nVGFigF",
  "id" : 505410405523415041,
  "created_at" : "2014-08-29 17:43:25 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "King\u0E3FTC",
      "screen_name" : "kingbtc",
      "indices" : [ 0, 8 ],
      "id_str" : "2384463408",
      "id" : 2384463408
    }, {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 9, 22 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    }, {
      "name" : "ActualAdvice_BTC",
      "screen_name" : "ActualAdviceBTC",
      "indices" : [ 23, 39 ],
      "id_str" : "2216302500",
      "id" : 2216302500
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/505405565225275393\/photo\/1",
      "indices" : [ 117, 139 ],
      "url" : "http:\/\/t.co\/NFknxC5y01",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BwOPruPCYAA00Oq.png",
      "id_str" : "505405564503875584",
      "id" : 505405564503875584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BwOPruPCYAA00Oq.png",
      "sizes" : [ {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NFknxC5y01"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505405565225275393",
  "in_reply_to_user_id" : 2384463408,
  "text" : "@kingbtc @CryptoCobain @ActualAdviceBTC  am i doing this right if my bot owns all buys or sells from the MA up\/down? http:\/\/t.co\/NFknxC5y01",
  "id" : 505405565225275393,
  "created_at" : "2014-08-29 17:24:11 +0000",
  "in_reply_to_screen_name" : "kingbtc",
  "in_reply_to_user_id_str" : "2384463408",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505403693160603648",
  "text" : "MY BESPOKE BELLS ALGORITHM GAME IS FUCK n ON POINT\n\nWHERE n IS LIKE 12 PARAMS TO MODULATE",
  "id" : 505403693160603648,
  "created_at" : "2014-08-29 17:16:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505392559103811584",
  "text" : "hm. last nigh, late in my repl, I wrote a crap constructor with a piss method.",
  "id" : 505392559103811584,
  "created_at" : "2014-08-29 16:32:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lars Kluge",
      "screen_name" : "aekym",
      "indices" : [ 0, 6 ],
      "id_str" : "65619999",
      "id" : 65619999
    }, {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "indices" : [ 7, 20 ],
      "id_str" : "2652920774",
      "id" : 2652920774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505279305153122304",
  "geo" : { },
  "id_str" : "505379329467883521",
  "in_reply_to_user_id" : 65619999,
  "text" : "@aekym @theDogeparty what are dogeparty recipes\/",
  "id" : 505379329467883521,
  "in_reply_to_status_id" : 505279305153122304,
  "created_at" : "2014-08-29 15:39:56 +0000",
  "in_reply_to_screen_name" : "aekym",
  "in_reply_to_user_id_str" : "65619999",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505378490581925888",
  "text" : "\"your sounds sure is crazy, is this your Jsynth in action?  if so then its pretty dame amazing.\"",
  "id" : 505378490581925888,
  "created_at" : "2014-08-29 15:36:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505257925254733824",
  "text" : "THE HYPERLINK WILL NOT BE USED AS LONG AS PRIBIBLI THOUGHT",
  "id" : 505257925254733824,
  "created_at" : "2014-08-29 07:37:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505256911122350082",
  "text" : "Me tired of writing readme's and many markdown urls.\n\nfrom now on its like:\n\nThis module is for use with module $name on NPM.\n\nLook it up.",
  "id" : 505256911122350082,
  "created_at" : "2014-08-29 07:33:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505254207385894913",
  "text" : "WAG THE USER",
  "id" : 505254207385894913,
  "created_at" : "2014-08-29 07:22:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505254096056487936",
  "text" : "twitter is a compendium of terrible designs",
  "id" : 505254096056487936,
  "created_at" : "2014-08-29 07:22:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 4, 12 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505253908596264960",
  "text" : "SMH @TWITTER I DONT WANT YR FUCKING UI SUGGESTING EVERY FUCKING WORD IS SOME ASSHOLE'S FUCKING HANDLE",
  "id" : 505253908596264960,
  "created_at" : "2014-08-29 07:21:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "indices" : [ 0, 7 ],
      "id_str" : "291901937",
      "id" : 291901937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505252522064244736",
  "geo" : { },
  "id_str" : "505253545923203073",
  "in_reply_to_user_id" : 291901937,
  "text" : "@LB2045  \nChrist the savior\nChrist the man\nChrist the wicked\n\nwho are you to Christ, anyway?",
  "id" : 505253545923203073,
  "in_reply_to_status_id" : 505252522064244736,
  "created_at" : "2014-08-29 07:20:07 +0000",
  "in_reply_to_screen_name" : "LB2045",
  "in_reply_to_user_id_str" : "291901937",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505237784722800640",
  "text" : "deGaw",
  "id" : 505237784722800640,
  "created_at" : "2014-08-29 06:17:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505237099100913664",
  "text" : "how to degauss yr wave fyi:\nf = 440, \nx = 1, \ny = sample || 0, \nm = 1\/12\nwhile(x&lt;4)\n  y += sine(f*x) * gauss(x-1)\n  x *= Math(2, m)\nreturn y",
  "id" : 505237099100913664,
  "created_at" : "2014-08-29 06:14:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505234646582706177",
  "geo" : { },
  "id_str" : "505236531091472384",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar\nitch laziness by \ntry to write clever documentation generator\nsuch requires clever coding style for parser\nreturn to laziness\nhurt u",
  "id" : 505236531091472384,
  "in_reply_to_status_id" : 505234646582706177,
  "created_at" : "2014-08-29 06:12:30 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 1, 8 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 32 ],
      "url" : "https:\/\/t.co\/7BKKnn5hWb",
      "expanded_url" : "https:\/\/www.npmjs.org\/package\/jgauss",
      "display_url" : "npmjs.org\/package\/jgauss"
    } ]
  },
  "in_reply_to_status_id_str" : "505229616748191744",
  "geo" : { },
  "id_str" : "505232257829720065",
  "in_reply_to_user_id" : 14318086,
  "text" : ".@tmpvar https:\/\/t.co\/7BKKnn5hWb",
  "id" : 505232257829720065,
  "in_reply_to_status_id" : 505229616748191744,
  "created_at" : "2014-08-29 05:55:31 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 13, 22 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 23, 30 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505217353890545664",
  "geo" : { },
  "id_str" : "505228213811822592",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @substack @tmpvar uhg u mean the mental institute, where open source was cheating &amp; broadcasting a question was a disturbance.",
  "id" : 505228213811822592,
  "in_reply_to_status_id" : 505217353890545664,
  "created_at" : "2014-08-29 05:39:27 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505215564654993408",
  "text" : "what do you call the o with a hat in mathsthpeak?",
  "id" : 505215564654993408,
  "created_at" : "2014-08-29 04:49:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 17, 26 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 27, 34 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 35, 47 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "505214512971001856",
  "geo" : { },
  "id_str" : "505215006846103552",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript cc @substack @tmpvar @dominictarr",
  "id" : 505215006846103552,
  "in_reply_to_status_id" : 505214512971001856,
  "created_at" : "2014-08-29 04:46:58 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505214512971001856",
  "text" : "uhm hi polymaths which order do i do with this (in wikipedian notation) e^-1\/2x^2 \n\n-1\/2(x^2) \nor\n-(1\/2 * x)^2",
  "id" : 505214512971001856,
  "created_at" : "2014-08-29 04:45:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505212789300809729",
  "text" : "WRITING MODULES IS FRACTILE",
  "id" : 505212789300809729,
  "created_at" : "2014-08-29 04:38:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505203437387018240",
  "text" : "RT @substack: OH: publish or be published",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "505192424310702080",
    "text" : "OH: publish or be published",
    "id" : 505192424310702080,
    "created_at" : "2014-08-29 03:17:14 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 505203437387018240,
  "created_at" : "2014-08-29 04:01:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505180813944553473",
  "text" : "JELLY BEAN IS \nNOT MY FLAVOR\n\nUH\n\nITS JUST A MONO-\nSACC-HA-RI-HI-HI-HIDE \n\nBUT ITS NOT EVEN MY FAVORITE TYPE\n\nOOO!",
  "id" : 505180813944553473,
  "created_at" : "2014-08-29 02:31:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505169928354136064",
  "text" : "A pribibli is the set of all probably, given a circumstance.",
  "id" : 505169928354136064,
  "created_at" : "2014-08-29 01:47:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "505057854340878336",
  "text" : "my crypto trading bot has been relocated to a machine in Singapore, to be closer to chinamarket",
  "id" : 505057854340878336,
  "created_at" : "2014-08-28 18:22:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504864963714760705",
  "geo" : { },
  "id_str" : "504918794016272384",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr  \nright\ntime travel\nit's time travel\nnot person travel",
  "id" : 504918794016272384,
  "in_reply_to_status_id" : 504864963714760705,
  "created_at" : "2014-08-28 09:09:56 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504795048324517888",
  "geo" : { },
  "id_str" : "504795987617935360",
  "in_reply_to_user_id" : 46961216,
  "text" : "@CryptoCobain  how many exchanges?",
  "id" : 504795987617935360,
  "in_reply_to_status_id" : 504795048324517888,
  "created_at" : "2014-08-28 01:01:56 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504794774369763328",
  "geo" : { },
  "id_str" : "504795048324517888",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain  o_0",
  "id" : 504795048324517888,
  "in_reply_to_status_id" : 504794774369763328,
  "created_at" : "2014-08-28 00:58:12 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 0, 13 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504794574586253312",
  "in_reply_to_user_id" : 2259434528,
  "text" : "@CryptoCobain r u trading by hand or by bot?",
  "id" : 504794574586253312,
  "created_at" : "2014-08-28 00:56:19 +0000",
  "in_reply_to_screen_name" : "CryptoCobain",
  "in_reply_to_user_id_str" : "2259434528",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504793795947278336",
  "text" : "NOW ME NEED TO WRITE AN IF CAN HAS BEAT !!!",
  "id" : 504793795947278336,
  "created_at" : "2014-08-28 00:53:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 0, 12 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "504753578943447040",
  "geo" : { },
  "id_str" : "504757268026359808",
  "in_reply_to_user_id" : 850972790,
  "text" : "@TheHatGhost \nOFF WITH HIS COCK!\nAGAIN IS HEEEE???\nAHAHAHAHAHAHA",
  "id" : 504757268026359808,
  "in_reply_to_status_id" : 504753578943447040,
  "created_at" : "2014-08-27 22:28:05 +0000",
  "in_reply_to_screen_name" : "TheHatGhost",
  "in_reply_to_user_id_str" : "850972790",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504752070973329409",
  "text" : "OKAY I ONLY TWEETED THAT TO JUSTIFY TO MYSELF SMACKING MY LIL BOT",
  "id" : 504752070973329409,
  "created_at" : "2014-08-27 22:07:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504751524744941568",
  "text" : "I WILL SMACK A BOT I DONT GIF A HREF",
  "id" : 504751524744941568,
  "created_at" : "2014-08-27 22:05:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504749518014119937",
  "text" : "DISCO, MAYBE HOUSE, POSSIBLY BOTH, AND THEN GOODBYE WORLD I WILL HAVE SNARE, HAT, AND BESPOKE BASS ALGOS.  THREE EACH GOING GONG BITCH BAAP.",
  "id" : 504749518014119937,
  "created_at" : "2014-08-27 21:57:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504748652456206337",
  "text" : "I DO TRUST I AM GONNA WRITE A DISCO BEAT IN PURE CODE BEFORE THE DAY IS THRU",
  "id" : 504748652456206337,
  "created_at" : "2014-08-27 21:53:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504747872286699521",
  "text" : "i dont trust my bot with more than 50 bux rn tho",
  "id" : 504747872286699521,
  "created_at" : "2014-08-27 21:50:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504747725322461184",
  "text" : "my crypto trading bot is collaborating with other bots to keep the moving average moving upward on average",
  "id" : 504747725322461184,
  "created_at" : "2014-08-27 21:50:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504746258729545728",
  "text" : "Me write cryptocurrency trading bots using fractals of golden ratio, and bass\/bell algos with gaussian distribution.  One dem hits already.",
  "id" : 504746258729545728,
  "created_at" : "2014-08-27 21:44:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504724370200072193",
  "text" : "s\/ever\/never",
  "id" : 504724370200072193,
  "created_at" : "2014-08-27 20:17:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504723923963891713",
  "text" : "i've ever seen a visual programming editor that isn't stultifyingly bad.  Especially \"graph\" style ones, good god what a waste of good code.",
  "id" : 504723923963891713,
  "created_at" : "2014-08-27 20:15:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504722427792728064",
  "text" : "delay(dingdong(time",
  "id" : 504722427792728064,
  "created_at" : "2014-08-27 20:09:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504662714174545920",
  "text" : "I GOT THIS SCRIPT",
  "id" : 504662714174545920,
  "created_at" : "2014-08-27 16:12:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504648939023253504",
  "text" : "programmer more like\npro\ngrrr\nramming",
  "id" : 504648939023253504,
  "created_at" : "2014-08-27 15:17:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "504410769451012096",
  "text" : "DOING THAT DUMB THING WHERE I SIT AND WAIT FOR INTERVALS",
  "id" : 504410769451012096,
  "created_at" : "2014-08-26 23:31:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "indices" : [ 3, 16 ],
      "id_str" : "2652920774",
      "id" : 2652920774
    }, {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 18, 31 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/nIvkaeae8Z",
      "expanded_url" : "http:\/\/dogepartychain.info",
      "display_url" : "dogepartychain.info"
    } ]
  },
  "geo" : { },
  "id_str" : "504272576244240384",
  "text" : "RT @theDogeparty: @johnnyscript Looks like http:\/\/t.co\/nIvkaeae8Z !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "( +\\-)",
        "screen_name" : "johnnyscript",
        "indices" : [ 0, 13 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 47 ],
        "url" : "http:\/\/t.co\/nIvkaeae8Z",
        "expanded_url" : "http:\/\/dogepartychain.info",
        "display_url" : "dogepartychain.info"
      } ]
    },
    "in_reply_to_status_id_str" : "502564668893061120",
    "geo" : { },
    "id_str" : "504259140332830722",
    "in_reply_to_user_id" : 46961216,
    "text" : "@johnnyscript Looks like http:\/\/t.co\/nIvkaeae8Z !",
    "id" : 504259140332830722,
    "in_reply_to_status_id" : 502564668893061120,
    "created_at" : "2014-08-26 13:28:42 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "protected" : false,
      "id_str" : "2652920774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491114918372843520\/2qQ7-Adj_normal.jpeg",
      "id" : 2652920774,
      "verified" : false
    }
  },
  "id" : 504272576244240384,
  "created_at" : "2014-08-26 14:22:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "indices" : [ 3, 16 ],
      "id_str" : "2652920774",
      "id" : 2652920774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/oJ6HizgSRB",
      "expanded_url" : "http:\/\/DogepartyChain.info",
      "display_url" : "DogepartyChain.info"
    }, {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/LzRIAfSZXw",
      "expanded_url" : "http:\/\/dogepartychain.info\/",
      "display_url" : "dogepartychain.info"
    } ]
  },
  "geo" : { },
  "id_str" : "504272399206862849",
  "text" : "RT @theDogeparty: Here we go! http:\/\/t.co\/oJ6HizgSRB block explorer! http:\/\/t.co\/LzRIAfSZXw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 34 ],
        "url" : "http:\/\/t.co\/oJ6HizgSRB",
        "expanded_url" : "http:\/\/DogepartyChain.info",
        "display_url" : "DogepartyChain.info"
      }, {
        "indices" : [ 51, 73 ],
        "url" : "http:\/\/t.co\/LzRIAfSZXw",
        "expanded_url" : "http:\/\/dogepartychain.info\/",
        "display_url" : "dogepartychain.info"
      } ]
    },
    "geo" : { },
    "id_str" : "504247185706590208",
    "text" : "Here we go! http:\/\/t.co\/oJ6HizgSRB block explorer! http:\/\/t.co\/LzRIAfSZXw",
    "id" : 504247185706590208,
    "created_at" : "2014-08-26 12:41:12 +0000",
    "user" : {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "protected" : false,
      "id_str" : "2652920774",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/491114918372843520\/2qQ7-Adj_normal.jpeg",
      "id" : 2652920774,
      "verified" : false
    }
  },
  "id" : 504272399206862849,
  "created_at" : "2014-08-26 14:21:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 5, 13 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503977380461830144",
  "geo" : { },
  "id_str" : "503985870656270336",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs @nytimes   he is one now, pls make correction",
  "id" : 503985870656270336,
  "in_reply_to_status_id" : 503977380461830144,
  "created_at" : "2014-08-25 19:22:49 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503979058271502336",
  "geo" : { },
  "id_str" : "503983144014712832",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair is that papa bear and baby bear right there?",
  "id" : 503983144014712832,
  "in_reply_to_status_id" : 503979058271502336,
  "created_at" : "2014-08-25 19:11:59 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RHYMEFEST",
      "screen_name" : "RHYMEFEST",
      "indices" : [ 0, 10 ],
      "id_str" : "18408457",
      "id" : 18408457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "503907483782762496",
  "geo" : { },
  "id_str" : "503941794589990912",
  "in_reply_to_user_id" : 18408457,
  "text" : "@RHYMEFEST  to vote is to give consent to the continued abuses of our corrupted system.  strike the vote.  deny consent.",
  "id" : 503941794589990912,
  "in_reply_to_status_id" : 503907483782762496,
  "created_at" : "2014-08-25 16:27:41 +0000",
  "in_reply_to_screen_name" : "RHYMEFEST",
  "in_reply_to_user_id_str" : "18408457",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503794824684654594",
  "text" : "Expand the definition of related to its actual size.",
  "id" : 503794824684654594,
  "created_at" : "2014-08-25 06:43:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "D\u039BT\u039BSSETTE",
      "screen_name" : "datassette",
      "indices" : [ 0, 11 ],
      "id_str" : "21008248",
      "id" : 21008248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/zZmEmXwtAY",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/theegress-betamins-premix",
      "display_url" : "soundcloud.com\/johnnyscript\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "503788487594627074",
  "in_reply_to_user_id" : 21008248,
  "text" : "@datassette music for programming, by programming https:\/\/t.co\/zZmEmXwtAY",
  "id" : 503788487594627074,
  "created_at" : "2014-08-25 06:18:30 +0000",
  "in_reply_to_screen_name" : "datassette",
  "in_reply_to_user_id_str" : "21008248",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503784573218459648",
  "text" : "love will make u drink n stay out all night long\n\ndrink will make u love n stay out all night long\n\nwake up early n make out with a siesta",
  "id" : 503784573218459648,
  "created_at" : "2014-08-25 06:02:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503779941054296064",
  "text" : "people always ask me what i put in my hair.  the answer is nothing, but the truth is what i take out of it.  and how much.",
  "id" : 503779941054296064,
  "created_at" : "2014-08-25 05:44:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503779642080100352",
  "text" : "baby, please answer this song",
  "id" : 503779642080100352,
  "created_at" : "2014-08-25 05:43:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503775082791989248",
  "text" : "we could hang ourselves.\n\nwe might get an erection!",
  "id" : 503775082791989248,
  "created_at" : "2014-08-25 05:25:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503616505729138688",
  "text" : "find me at lake merrit today springn on my hands and feet",
  "id" : 503616505729138688,
  "created_at" : "2014-08-24 18:55:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503573071131717632",
  "text" : "Didn't feel it",
  "id" : 503573071131717632,
  "created_at" : "2014-08-24 16:02:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503473107881836544",
  "text" : "ME SWEAR I WITNESSING BLIPS IN THE TECHNOLOGY",
  "id" : 503473107881836544,
  "created_at" : "2014-08-24 09:25:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503472323748696064",
  "text" : "I SWATTED AT THE DANCE CLUB",
  "id" : 503472323748696064,
  "created_at" : "2014-08-24 09:22:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lily",
      "screen_name" : "luxuriousho",
      "indices" : [ 3, 15 ],
      "id_str" : "21127389",
      "id" : 21127389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503389288050872320",
  "text" : "RT @luxuriousho: so wild yet humbling that twitter decided to go with the sound of my pussy popping as the noise signal that your timeline \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "503366696745197569",
    "text" : "so wild yet humbling that twitter decided to go with the sound of my pussy popping as the noise signal that your timeline has been refreshed",
    "id" : 503366696745197569,
    "created_at" : "2014-08-24 02:22:27 +0000",
    "user" : {
      "name" : "lily",
      "screen_name" : "luxuriousho",
      "protected" : false,
      "id_str" : "21127389",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544293572661772288\/n_o5oF9-_normal.jpeg",
      "id" : 21127389,
      "verified" : false
    }
  },
  "id" : 503389288050872320,
  "created_at" : "2014-08-24 03:52:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503333507255386112",
  "text" : "IM IN THE BLOCKCHAIN BITCH",
  "id" : 503333507255386112,
  "created_at" : "2014-08-24 00:10:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503288677431140352",
  "text" : "CRYPTO ASSET CHIA",
  "id" : 503288677431140352,
  "created_at" : "2014-08-23 21:12:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503282644550176769",
  "text" : "HAIR UNTOUCHABLE",
  "id" : 503282644550176769,
  "created_at" : "2014-08-23 20:48:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503282083880398848",
  "text" : "THE MUSTACHE YOU SEE IS THERE NO MORE BUT STILL YOU SEE THE MUSTACHE",
  "id" : 503282083880398848,
  "created_at" : "2014-08-23 20:46:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503281959645102080",
  "text" : "POLYSEXUAL STARDUST ALIEN",
  "id" : 503281959645102080,
  "created_at" : "2014-08-23 20:45:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503203823830044672",
  "text" : "bed sheets don't talk",
  "id" : 503203823830044672,
  "created_at" : "2014-08-23 15:35:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "503203700295217152",
  "text" : "$ cd the-good-the-bad-and-the-spaghetti",
  "id" : 503203700295217152,
  "created_at" : "2014-08-23 15:34:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Sartaj",
      "screen_name" : "sartaj",
      "indices" : [ 13, 20 ],
      "id_str" : "24467334",
      "id" : 24467334
    }, {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "indices" : [ 26, 37 ],
      "id_str" : "122112121",
      "id" : 122112121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502923151353733121",
  "geo" : { },
  "id_str" : "502981873010606080",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @sartaj  cc\/ @uptownherd",
  "id" : 502981873010606080,
  "in_reply_to_status_id" : 502923151353733121,
  "created_at" : "2014-08-23 00:53:18 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502956441519407104",
  "text" : "IM GONNA REWARD MYSELF A SNACK FOR RUNNING TO GET A SNACK, AND A SNACK FOR THE ENTIRE PROJECT.",
  "id" : 502956441519407104,
  "created_at" : "2014-08-22 23:12:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502956007186640896",
  "text" : "WHAT IF ALL THAT PSYCHOLOGY IS TRUE &amp;&amp; WE ARE ALWAYS REWARDING OURSELVES FOR NOTHING?",
  "id" : 502956007186640896,
  "created_at" : "2014-08-22 23:10:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 0, 16 ],
      "id_str" : "29117866",
      "id" : 29117866
    }, {
      "name" : "Pookleblinky",
      "screen_name" : "pookleblinky",
      "indices" : [ 17, 30 ],
      "id_str" : "35163668",
      "id" : 35163668
    }, {
      "name" : "GoFundMe",
      "screen_name" : "gofundme",
      "indices" : [ 35, 44 ],
      "id_str" : "112897540",
      "id" : 112897540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502853830942687234",
  "geo" : { },
  "id_str" : "502856077306654720",
  "in_reply_to_user_id" : 29117866,
  "text" : "@materialdesignr @pookleblinky and\n@gofundme deleted comments but accepted the money, which is such a corporate thing to do. Not pro-social.",
  "id" : 502856077306654720,
  "in_reply_to_status_id" : 502853830942687234,
  "created_at" : "2014-08-22 16:33:26 +0000",
  "in_reply_to_screen_name" : "materialdesignr",
  "in_reply_to_user_id_str" : "29117866",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 0, 16 ],
      "id_str" : "29117866",
      "id" : 29117866
    }, {
      "name" : "Pookleblinky",
      "screen_name" : "pookleblinky",
      "indices" : [ 17, 30 ],
      "id_str" : "35163668",
      "id" : 35163668
    }, {
      "name" : "GoFundMe",
      "screen_name" : "gofundme",
      "indices" : [ 31, 40 ],
      "id_str" : "112897540",
      "id" : 112897540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502853830942687234",
  "geo" : { },
  "id_str" : "502855264416985088",
  "in_reply_to_user_id" : 29117866,
  "text" : "@materialdesignr @pookleblinky @gofundme  The internet tho.  It's our place where the state has less control, praise god.  So it's up to us.",
  "id" : 502855264416985088,
  "in_reply_to_status_id" : 502853830942687234,
  "created_at" : "2014-08-22 16:30:12 +0000",
  "in_reply_to_screen_name" : "materialdesignr",
  "in_reply_to_user_id_str" : "29117866",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "indices" : [ 0, 13 ],
      "id_str" : "2652920774",
      "id" : 2652920774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502618782213607424",
  "geo" : { },
  "id_str" : "502848905260711937",
  "in_reply_to_user_id" : 2652920774,
  "text" : "@theDogeparty  0_o  if not the exchange, some kind of community friendly way for people to interact with these new \"assets\"?",
  "id" : 502848905260711937,
  "in_reply_to_status_id" : 502618782213607424,
  "created_at" : "2014-08-22 16:04:56 +0000",
  "in_reply_to_screen_name" : "theDogeparty",
  "in_reply_to_user_id_str" : "2652920774",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 0, 16 ],
      "id_str" : "29117866",
      "id" : 29117866
    }, {
      "name" : "Pookleblinky",
      "screen_name" : "pookleblinky",
      "indices" : [ 17, 30 ],
      "id_str" : "35163668",
      "id" : 35163668
    }, {
      "name" : "GoFundMe",
      "screen_name" : "gofundme",
      "indices" : [ 31, 40 ],
      "id_str" : "112897540",
      "id" : 112897540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502832534330167296",
  "geo" : { },
  "id_str" : "502846758842404864",
  "in_reply_to_user_id" : 29117866,
  "text" : "@materialdesignr @pookleblinky @gofundme  \nthey deleted comments",
  "id" : 502846758842404864,
  "in_reply_to_status_id" : 502832534330167296,
  "created_at" : "2014-08-22 15:56:24 +0000",
  "in_reply_to_screen_name" : "materialdesignr",
  "in_reply_to_user_id_str" : "29117866",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502846257732153344",
  "text" : "I just turned 100 doge into 3800 doge crypto-gambling and then did what any dedicated gambler would do and put it all on a long shot.",
  "id" : 502846257732153344,
  "created_at" : "2014-08-22 15:54:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502747430215901185",
  "text" : "I KNOW I CREATED SOMETHING BEAUTIFUL WHEN IT MAKE ME CRY",
  "id" : 502747430215901185,
  "created_at" : "2014-08-22 09:21:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pookleblinky",
      "screen_name" : "pookleblinky",
      "indices" : [ 0, 13 ],
      "id_str" : "35163668",
      "id" : 35163668
    }, {
      "name" : "Christopher Hendrix",
      "screen_name" : "materialdesignr",
      "indices" : [ 14, 30 ],
      "id_str" : "29117866",
      "id" : 29117866
    }, {
      "name" : "GoFundMe",
      "screen_name" : "gofundme",
      "indices" : [ 31, 40 ],
      "id_str" : "112897540",
      "id" : 112897540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502686351968706560",
  "geo" : { },
  "id_str" : "502735945397858305",
  "in_reply_to_user_id" : 35163668,
  "text" : "@pookleblinky @materialdesignr @gofundme   BOOOOOOO CENSORSHIP AND WHITEWASHING IN ONE",
  "id" : 502735945397858305,
  "in_reply_to_status_id" : 502686351968706560,
  "created_at" : "2014-08-22 08:36:04 +0000",
  "in_reply_to_screen_name" : "pookleblinky",
  "in_reply_to_user_id_str" : "35163668",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502735250988871680",
  "text" : "I CALL LA LAMDAS\n\nTHAT WRITE LA LAMDAS\n\nI WRITE LA LAMDAS\n\nTHAT CALL LA LAMDAS",
  "id" : 502735250988871680,
  "created_at" : "2014-08-22 08:33:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TOLKIEN BLACK",
      "screen_name" : "therealhennessy",
      "indices" : [ 108, 124 ],
      "id_str" : "137090436",
      "id" : 137090436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502706969770094592",
  "text" : "I jus mouthed some air horns at the right moment during a non-CVS-bangers version of a song to big laughs.  @therealhennessy",
  "id" : 502706969770094592,
  "created_at" : "2014-08-22 06:40:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 0, 14 ],
      "id_str" : "379919160",
      "id" : 379919160
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 15, 24 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "502614268005875713",
  "geo" : { },
  "id_str" : "502638060023336961",
  "in_reply_to_user_id" : 379919160,
  "text" : "@MikolaLysenko @substack  oh god the end of that story is the stuff of paranoia",
  "id" : 502638060023336961,
  "in_reply_to_status_id" : 502614268005875713,
  "created_at" : "2014-08-22 02:07:06 +0000",
  "in_reply_to_screen_name" : "MikolaLysenko",
  "in_reply_to_user_id_str" : "379919160",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502635764929560576",
  "text" : "YOU ARE A TESTICLE OF IDEAS",
  "id" : 502635764929560576,
  "created_at" : "2014-08-22 01:57:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oakmtg",
      "indices" : [ 54, 61 ]
    }, {
      "text" : "oakland",
      "indices" : [ 62, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kP0gGrzoAj",
      "expanded_url" : "http:\/\/oaklandwiki.org\/%23Oakmtg_2014_Mayoral_Candidate_Forum",
      "display_url" : "oaklandwiki.org\/%23Oakmtg_2014\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502606652957523970",
  "text" : "RT @marinakukso: Tonight 7PM: The internet's very own #oakmtg #oakland Mayoral Forum LIVE at City Hall! I'll be in bleachers - Come! http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oakmtg",
        "indices" : [ 37, 44 ]
      }, {
        "text" : "oakland",
        "indices" : [ 45, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/kP0gGrzoAj",
        "expanded_url" : "http:\/\/oaklandwiki.org\/%23Oakmtg_2014_Mayoral_Candidate_Forum",
        "display_url" : "oaklandwiki.org\/%23Oakmtg_2014\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "502580524922437632",
    "text" : "Tonight 7PM: The internet's very own #oakmtg #oakland Mayoral Forum LIVE at City Hall! I'll be in bleachers - Come! http:\/\/t.co\/kP0gGrzoAj",
    "id" : 502580524922437632,
    "created_at" : "2014-08-21 22:18:29 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545296557621268481\/seD5hVbi_normal.png",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 502606652957523970,
  "created_at" : "2014-08-22 00:02:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502566478630379520",
  "text" : "I jus burned 100,000 dogecoin",
  "id" : 502566478630379520,
  "created_at" : "2014-08-21 21:22:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dogeparty",
      "screen_name" : "theDogeparty",
      "indices" : [ 0, 13 ],
      "id_str" : "2652920774",
      "id" : 2652920774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502564668893061120",
  "in_reply_to_user_id" : 2652920774,
  "text" : "@theDogeparty  Where is the list assets on the XDC exchange, within the dogeparty wallet?",
  "id" : 502564668893061120,
  "created_at" : "2014-08-21 21:15:28 +0000",
  "in_reply_to_screen_name" : "theDogeparty",
  "in_reply_to_user_id_str" : "2652920774",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/6wsnnsqT0x",
      "expanded_url" : "https:\/\/chain.so\/address\/dogeparty",
      "display_url" : "chain.so\/address\/dogepa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502556194771570689",
  "text" : "1.5 billion Dogecoin burned!\n\nhttps:\/\/t.co\/6wsnnsqT0x",
  "id" : 502556194771570689,
  "created_at" : "2014-08-21 20:41:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502317579864522753",
  "text" : "We've been living in this state our whole lives.  Control, power, corruption, systemic disintegration. This is a long time coming. #ferguson",
  "id" : 502317579864522753,
  "created_at" : "2014-08-21 04:53:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 65, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502316737224642560",
  "text" : "The bureaucracy is out of control, too.  It's all coming loose.  #ferguson",
  "id" : 502316737224642560,
  "created_at" : "2014-08-21 04:50:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 130, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502315627114414080",
  "text" : "The police have been over-armed a long time, but this surreal.  It's like the NSA leak. We knew it was there, only needed proof.  #Ferguson",
  "id" : 502315627114414080,
  "created_at" : "2014-08-21 04:45:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502314518991495168",
  "text" : "It's dangerous that we militarized the police in a system that behaves like some races of our people are a problem, are a threat.  #ferguson",
  "id" : 502314518991495168,
  "created_at" : "2014-08-21 04:41:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502312737339236352",
  "text" : "DOGE\nSERVING MANKINDNESS\nSINCE BEFORE MAN CAN REMEMBERS\nWOW",
  "id" : 502312737339236352,
  "created_at" : "2014-08-21 04:34:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502308248003674112",
  "text" : "currently mixing sound system dub (?) with Alejandro Jodorowski film scores.  tastes good!",
  "id" : 502308248003674112,
  "created_at" : "2014-08-21 04:16:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan J. Reilly",
      "screen_name" : "ryanjreilly",
      "indices" : [ 3, 15 ],
      "id_str" : "7768402",
      "id" : 7768402
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ryanjreilly\/status\/501498000368488449\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/7YZIrcUzjO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvWtxfYIYAAYYeu.jpg",
      "id_str" : "501497999269584896",
      "id" : 501497999269584896,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvWtxfYIYAAYYeu.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/7YZIrcUzjO"
    } ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502301793158582272",
  "text" : "RT @ryanjreilly: Vanessa Lucas and Rona Caldwell in #Ferguson http:\/\/t.co\/7YZIrcUzjO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ryanjreilly\/status\/501498000368488449\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/7YZIrcUzjO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvWtxfYIYAAYYeu.jpg",
        "id_str" : "501497999269584896",
        "id" : 501497999269584896,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvWtxfYIYAAYYeu.jpg",
        "sizes" : [ {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/7YZIrcUzjO"
      } ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501498000368488449",
    "text" : "Vanessa Lucas and Rona Caldwell in #Ferguson http:\/\/t.co\/7YZIrcUzjO",
    "id" : 501498000368488449,
    "created_at" : "2014-08-18 22:36:55 +0000",
    "user" : {
      "name" : "Ryan J. Reilly",
      "screen_name" : "ryanjreilly",
      "protected" : false,
      "id_str" : "7768402",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/547202838242525185\/jHMr0pB4_normal.jpeg",
      "id" : 7768402,
      "verified" : true
    }
  },
  "id" : 502301793158582272,
  "created_at" : "2014-08-21 03:50:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyson",
      "screen_name" : "tysonmanker",
      "indices" : [ 3, 15 ],
      "id_str" : "326196796",
      "id" : 326196796
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/tysonmanker\/status\/502170361979740160\/photo\/1",
      "indices" : [ 53, 75 ],
      "url" : "http:\/\/t.co\/uazWUwdsfU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvgRSHHCUAA1WTY.jpg",
      "id_str" : "502170361295687680",
      "id" : 502170361295687680,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvgRSHHCUAA1WTY.jpg",
      "sizes" : [ {
        "h" : 673,
        "resize" : "fit",
        "w" : 918
      }, {
        "h" : 249,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 673,
        "resize" : "fit",
        "w" : 918
      }, {
        "h" : 439,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/uazWUwdsfU"
    } ],
    "hashtags" : [ {
      "text" : "OfficerGoFuckYourself",
      "indices" : [ 17, 39 ]
    }, {
      "text" : "Ferguson",
      "indices" : [ 43, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502175933189484544",
  "text" : "RT @tysonmanker: #OfficerGoFuckYourself in #Ferguson http:\/\/t.co\/uazWUwdsfU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/tysonmanker\/status\/502170361979740160\/photo\/1",
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/uazWUwdsfU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvgRSHHCUAA1WTY.jpg",
        "id_str" : "502170361295687680",
        "id" : 502170361295687680,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvgRSHHCUAA1WTY.jpg",
        "sizes" : [ {
          "h" : 673,
          "resize" : "fit",
          "w" : 918
        }, {
          "h" : 249,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 673,
          "resize" : "fit",
          "w" : 918
        }, {
          "h" : 439,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/uazWUwdsfU"
      } ],
      "hashtags" : [ {
        "text" : "OfficerGoFuckYourself",
        "indices" : [ 0, 22 ]
      }, {
        "text" : "Ferguson",
        "indices" : [ 26, 35 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "502170361979740160",
    "text" : "#OfficerGoFuckYourself in #Ferguson http:\/\/t.co\/uazWUwdsfU",
    "id" : 502170361979740160,
    "created_at" : "2014-08-20 19:08:38 +0000",
    "user" : {
      "name" : "Tyson",
      "screen_name" : "tysonmanker",
      "protected" : false,
      "id_str" : "326196796",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/536750851314839552\/j9WenYQr_normal.jpeg",
      "id" : 326196796,
      "verified" : false
    }
  },
  "id" : 502175933189484544,
  "created_at" : "2014-08-20 19:30:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502169585034858496",
  "text" : "WHERE DO I SEND MY UNUSED SUITS SO THAT PROTESTERS CAN LOOK SHARP IN CUFFS LIKE MLK AND FAM?\n\n#FERGUSON",
  "id" : 502169585034858496,
  "created_at" : "2014-08-20 19:05:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 99 ],
      "url" : "http:\/\/t.co\/Ov0BGpsugC",
      "expanded_url" : "http:\/\/www.gofundme.com\/SupportOfficerWilson",
      "display_url" : "gofundme.com\/SupportOfficer\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502169251289899008",
  "text" : "7O,OOO DOLLARS RAISED FOR THE KILLER, THE THUG, THE GANGSTER OF THE STATE  \n\nhttp:\/\/t.co\/Ov0BGpsugC\n\n#FERGUSON",
  "id" : 502169251289899008,
  "created_at" : "2014-08-20 19:04:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502168893256138752",
  "text" : "SEND IN THE NATIONAL PROTEST!\n\n#FERGUSON",
  "id" : 502168893256138752,
  "created_at" : "2014-08-20 19:02:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502155800446382080",
  "text" : "ALL THAT TIME HIDING AWAY THE KILLER AND DETAILS\n\nSO THAT THE POLICE COULD PREPARE THE COP AND THE \"EVIDENCE\" FOR TRIAL\n\n#FERGUSON",
  "id" : 502155800446382080,
  "created_at" : "2014-08-20 18:10:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 143, 152 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502152683621347329",
  "text" : "FAUX NEWS PLACING AN ANONYMOUS \"WELL-PLACED SOURCE\"  WHO IS \"CLOSE TO THE TOP BRASS\" \n\n&gt;&gt;AT THE SCENE OF THE MIKE BROWN KILLING&lt;&lt;\n\n#FERGUSON",
  "id" : 502152683621347329,
  "created_at" : "2014-08-20 17:58:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502152392880553984",
  "text" : "AWWWW SHIT\n\nTHE ANONYMOUS WITNESS IS \"CLOSE TO THE DEPT'S TOP BRASS\"\n\n#FERGUSON",
  "id" : 502152392880553984,
  "created_at" : "2014-08-20 17:57:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 128, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502147421976027136",
  "text" : "JUST THINK \n\nALL THAT COMBAT EQUIPMENT HANDED DOWN FROM DHS\n\nHOW MANY DID IT OPPRESS AND KILL ON THE OTHER SIDE OF THE PLANET?\n\n#FERGUSON",
  "id" : 502147421976027136,
  "created_at" : "2014-08-20 17:37:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 90, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502146683514277888",
  "text" : "TELL ALL YR FRIENDS, THEY HOMETOWN ALSO GOT A POLICE FORCE ARMED TO THE GRILL UNJUST LIKE #FERGUSON",
  "id" : 502146683514277888,
  "created_at" : "2014-08-20 17:34:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "502016366707093505",
  "text" : "var bull = null",
  "id" : 502016366707093505,
  "created_at" : "2014-08-20 08:56:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 73 ],
      "url" : "https:\/\/t.co\/vOZXVSwf0H",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=NsyMlWs1_P4",
      "display_url" : "youtube.com\/watch?v=NsyMlW\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "502010512113430528",
  "text" : "WHAT MAKES THESE MEN WANT TO WEAR GIRLS CLOTHES?\n\nhttps:\/\/t.co\/vOZXVSwf0H\n\nA LEADER OF MEN\n\nAND OF LITTLE GIRLS",
  "id" : 502010512113430528,
  "created_at" : "2014-08-20 08:33:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mercedes H",
      "screen_name" : "the_N0",
      "indices" : [ 0, 7 ],
      "id_str" : "42699163",
      "id" : 42699163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 37 ],
      "url" : "https:\/\/t.co\/geN8N3K5BG",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=NsyMlWs1_P4",
      "display_url" : "youtube.com\/watch?v=NsyMlW\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "502007651757064192",
  "geo" : { },
  "id_str" : "502010059958648833",
  "in_reply_to_user_id" : 42699163,
  "text" : "@the_N0 \n\nNO\n\nhttps:\/\/t.co\/geN8N3K5BG",
  "id" : 502010059958648833,
  "in_reply_to_status_id" : 502007651757064192,
  "created_at" : "2014-08-20 08:31:39 +0000",
  "in_reply_to_screen_name" : "the_N0",
  "in_reply_to_user_id_str" : "42699163",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupy Oakland",
      "screen_name" : "OccupyOakland",
      "indices" : [ 0, 14 ],
      "id_str" : "383558512",
      "id" : 383558512
    }, {
      "name" : "Obi_Mar_Kenobi",
      "screen_name" : "Obi_Mar_Kenobi",
      "indices" : [ 15, 30 ],
      "id_str" : "2735743929",
      "id" : 2735743929
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/501999901874483200\/photo\/1",
      "indices" : [ 41, 63 ],
      "url" : "http:\/\/t.co\/ibwB3O6GO8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bvd2QB5CcAA1_91.jpg",
      "id_str" : "501999901232754688",
      "id" : 501999901232754688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bvd2QB5CcAA1_91.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/ibwB3O6GO8"
    } ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501953062303318017",
  "geo" : { },
  "id_str" : "501999901874483200",
  "in_reply_to_user_id" : 383558512,
  "text" : "@OccupyOakland @Obi_Mar_Kenobi #ferguson http:\/\/t.co\/ibwB3O6GO8",
  "id" : 501999901874483200,
  "in_reply_to_status_id" : 501953062303318017,
  "created_at" : "2014-08-20 07:51:17 +0000",
  "in_reply_to_screen_name" : "OccupyOakland",
  "in_reply_to_user_id_str" : "383558512",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BLACK POWER",
      "screen_name" : "JUNGLEPUSSY",
      "indices" : [ 0, 12 ],
      "id_str" : "15819295",
      "id" : 15819295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501937263211999233",
  "geo" : { },
  "id_str" : "501974243999879168",
  "in_reply_to_user_id" : 15819295,
  "text" : "@JUNGLEPUSSY SIGH",
  "id" : 501974243999879168,
  "in_reply_to_status_id" : 501937263211999233,
  "created_at" : "2014-08-20 06:09:20 +0000",
  "in_reply_to_screen_name" : "JUNGLEPUSSY",
  "in_reply_to_user_id_str" : "15819295",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Feross",
      "screen_name" : "feross",
      "indices" : [ 0, 7 ],
      "id_str" : "15692193",
      "id" : 15692193
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 8, 20 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Forrest L Norvell",
      "screen_name" : "othiym23",
      "indices" : [ 21, 30 ],
      "id_str" : "682433",
      "id" : 682433
    }, {
      "name" : "Jake Verbaten",
      "screen_name" : "Raynos",
      "indices" : [ 31, 38 ],
      "id_str" : "304682840",
      "id" : 304682840
    }, {
      "name" : "Gary Katsevman",
      "screen_name" : "gkatsev",
      "indices" : [ 39, 47 ],
      "id_str" : "12891642",
      "id" : 12891642
    }, {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 48, 52 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501965327647784960",
  "geo" : { },
  "id_str" : "501972240242470912",
  "in_reply_to_user_id" : 15692193,
  "text" : "@feross @dominictarr @othiym23 @Raynos @gkatsev @izs \n\nIs this ok? (yes)",
  "id" : 501972240242470912,
  "in_reply_to_status_id" : 501965327647784960,
  "created_at" : "2014-08-20 06:01:22 +0000",
  "in_reply_to_screen_name" : "feross",
  "in_reply_to_user_id_str" : "15692193",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mr Sparrow",
      "screen_name" : "jackfru1t",
      "indices" : [ 0, 10 ],
      "id_str" : "2421317989",
      "id" : 2421317989
    }, {
      "name" : "CRYPTO CO\u0E3FAIN",
      "screen_name" : "CryptoCobain",
      "indices" : [ 11, 24 ],
      "id_str" : "2259434528",
      "id" : 2259434528
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501827304213864448",
  "geo" : { },
  "id_str" : "501832132176515073",
  "in_reply_to_user_id" : 2421317989,
  "text" : "@jackfru1t @CryptoCobain good thing I dispositioned my .211 BTC worth of notary data and bought this other crypto coin on the exchange!",
  "id" : 501832132176515073,
  "in_reply_to_status_id" : 501827304213864448,
  "created_at" : "2014-08-19 20:44:38 +0000",
  "in_reply_to_screen_name" : "jackfru1t",
  "in_reply_to_user_id_str" : "2421317989",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Donal Thoms-Cappello",
      "screen_name" : "donaltc",
      "indices" : [ 0, 8 ],
      "id_str" : "60843664",
      "id" : 60843664
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501822140132229120",
  "geo" : { },
  "id_str" : "501830599888207872",
  "in_reply_to_user_id" : 60843664,
  "text" : "@donaltc but the poll doesn't say anything becuz the poll is a small pile of doodoo",
  "id" : 501830599888207872,
  "in_reply_to_status_id" : 501822140132229120,
  "created_at" : "2014-08-19 20:38:33 +0000",
  "in_reply_to_screen_name" : "donaltc",
  "in_reply_to_user_id_str" : "60843664",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501824030307934208",
  "text" : "HOW ARE YOU GONNA POLL A THOUSAND PPL VIA TELEPHONE AND CALL THAT REPRESENTATIVE DATA\n\nIN THIS INTERNET AND AGE!!!!\n\nPEWPEWPEWPEWPEWPEW",
  "id" : 501824030307934208,
  "created_at" : "2014-08-19 20:12:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joshua Holbrook",
      "screen_name" : "jesusabdullah",
      "indices" : [ 1, 15 ],
      "id_str" : "184987977",
      "id" : 184987977
    }, {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501823659460145152",
  "text" : "\"@jesusabdullah: @johnnyscript Those numbers aren't very surprising.\". Those numbers reveal nothing because weak",
  "id" : 501823659460145152,
  "created_at" : "2014-08-19 20:10:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/501821447983996928\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/KID2YfWeVy",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvbT8nmCIAE9FFM.jpg",
      "id_str" : "501821446872506369",
      "id" : 501821446872506369,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvbT8nmCIAE9FFM.jpg",
      "sizes" : [ {
        "h" : 376,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 413,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 213,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/KID2YfWeVy"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/3AeGJhlWhA",
      "expanded_url" : "http:\/\/www.themoscowtimes.com\/article\/505354.html",
      "display_url" : "themoscowtimes.com\/article\/505354\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501821447983996928",
  "text" : "AAAHHHH MIGHT GOTTA TAKE MY SHIRT OFF TO THIS \n\nBULGARIAN SCULPTURE GRAFFITI \n\nhttp:\/\/t.co\/3AeGJhlWhA http:\/\/t.co\/KID2YfWeVy",
  "id" : 501821447983996928,
  "created_at" : "2014-08-19 20:02:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501819948923355136",
  "text" : "FUCK THA POLLS, G",
  "id" : 501819948923355136,
  "created_at" : "2014-08-19 19:56:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 134, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/AlSvXVyOVt",
      "expanded_url" : "http:\/\/www.people-press.org\/2014\/08\/18\/stark-racial-divisions-in-reactions-to-ferguson-police-shooting\/",
      "display_url" : "people-press.org\/2014\/08\/18\/sta\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501819741686595584",
  "text" : "There are half a thousand ppl in congress &amp; they don't represent this country.  Neither does this Pew Poll http:\/\/t.co\/AlSvXVyOVt\n#Ferguson",
  "id" : 501819741686595584,
  "created_at" : "2014-08-19 19:55:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MacDaddy-V",
      "screen_name" : "RITEGUYRITETIME",
      "indices" : [ 0, 16 ],
      "id_str" : "108203855",
      "id" : 108203855
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 71, 80 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501651312782897152",
  "geo" : { },
  "id_str" : "501800235715555328",
  "in_reply_to_user_id" : 108203855,
  "text" : "@RITEGUYRITETIME  pretty much, the more the merrier, bring the love to #Ferguson and shame the police away.  Police making all the trouble..",
  "id" : 501800235715555328,
  "in_reply_to_status_id" : 501651312782897152,
  "created_at" : "2014-08-19 18:37:53 +0000",
  "in_reply_to_screen_name" : "RITEGUYRITETIME",
  "in_reply_to_user_id_str" : "108203855",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Occupy Oakland",
      "screen_name" : "OccupyOakland",
      "indices" : [ 3, 17 ],
      "id_str" : "383558512",
      "id" : 383558512
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/OccupyOakland\/status\/501592528366215168\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kgS1c2iAmL",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvYDvv_CAAAJA0V.png",
      "id_str" : "501592527367962624",
      "id" : 501592527367962624,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvYDvv_CAAAJA0V.png",
      "sizes" : [ {
        "h" : 538,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 605
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 543,
        "resize" : "fit",
        "w" : 605
      } ],
      "display_url" : "pic.twitter.com\/kgS1c2iAmL"
    } ],
    "hashtags" : [ {
      "text" : "BlockTheBoat",
      "indices" : [ 19, 32 ]
    }, {
      "text" : "gaza",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501650611113193472",
  "text" : "RT @OccupyOakland: #BlockTheBoat successful for third day in a row! All workers gone home. The Israeli ship has been blocked for #gaza http\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/OccupyOakland\/status\/501592528366215168\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/kgS1c2iAmL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvYDvv_CAAAJA0V.png",
        "id_str" : "501592527367962624",
        "id" : 501592527367962624,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvYDvv_CAAAJA0V.png",
        "sizes" : [ {
          "h" : 538,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 605
        }, {
          "h" : 305,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 543,
          "resize" : "fit",
          "w" : 605
        } ],
        "display_url" : "pic.twitter.com\/kgS1c2iAmL"
      } ],
      "hashtags" : [ {
        "text" : "BlockTheBoat",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "gaza",
        "indices" : [ 110, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "501592528366215168",
    "text" : "#BlockTheBoat successful for third day in a row! All workers gone home. The Israeli ship has been blocked for #gaza http:\/\/t.co\/kgS1c2iAmL",
    "id" : 501592528366215168,
    "created_at" : "2014-08-19 04:52:32 +0000",
    "user" : {
      "name" : "Occupy Oakland",
      "screen_name" : "OccupyOakland",
      "protected" : false,
      "id_str" : "383558512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000268346400\/547491411d2776db4dde89a63eb11607_normal.png",
      "id" : 383558512,
      "verified" : false
    }
  },
  "id" : 501650611113193472,
  "created_at" : "2014-08-19 08:43:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 33, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501650381026230272",
  "text" : "YOU SHOULDN'T NEED A PRESS BADGE #ferguson",
  "id" : 501650381026230272,
  "created_at" : "2014-08-19 08:42:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 45, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/7DtBpAzvcJ",
      "expanded_url" : "http:\/\/localwiki.net\/st-louis\/Arrestable_Offence",
      "display_url" : "localwiki.net\/st-louis\/Arres\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501649228737679360",
  "text" : "RT @substack: list of arrestable offenses in #ferguson keeps growing http:\/\/t.co\/7DtBpAzvcJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ferguson",
        "indices" : [ 31, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/7DtBpAzvcJ",
        "expanded_url" : "http:\/\/localwiki.net\/st-louis\/Arrestable_Offence",
        "display_url" : "localwiki.net\/st-louis\/Arres\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "501626306157477888",
    "text" : "list of arrestable offenses in #ferguson keeps growing http:\/\/t.co\/7DtBpAzvcJ",
    "id" : 501626306157477888,
    "created_at" : "2014-08-19 07:06:45 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 501649228737679360,
  "created_at" : "2014-08-19 08:37:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 3, 15 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/w4XRQylXrT",
      "expanded_url" : "http:\/\/localwiki.net\/st-louis\/Police_Tactics",
      "display_url" : "localwiki.net\/st-louis\/Polic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501649071480664064",
  "text" : "RT @marinakukso: A grand compendium of tactics that #Ferguson police have been using: http:\/\/t.co\/w4XRQylXrT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 35, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 91 ],
        "url" : "http:\/\/t.co\/w4XRQylXrT",
        "expanded_url" : "http:\/\/localwiki.net\/st-louis\/Police_Tactics",
        "display_url" : "localwiki.net\/st-louis\/Polic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "501628079400173568",
    "text" : "A grand compendium of tactics that #Ferguson police have been using: http:\/\/t.co\/w4XRQylXrT",
    "id" : 501628079400173568,
    "created_at" : "2014-08-19 07:13:48 +0000",
    "user" : {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "protected" : false,
      "id_str" : "1484011428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545296557621268481\/seD5hVbi_normal.png",
      "id" : 1484011428,
      "verified" : false
    }
  },
  "id" : 501649071480664064,
  "created_at" : "2014-08-19 08:37:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 41 ],
      "url" : "https:\/\/t.co\/JTcgi0ErlI",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/theegress-betamins-premix",
      "display_url" : "soundcloud.com\/johnnyscript\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501647200821055488",
  "text" : "pure js betawave \nhttps:\/\/t.co\/JTcgi0ErlI",
  "id" : 501647200821055488,
  "created_at" : "2014-08-19 08:29:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CoinDesk",
      "screen_name" : "coindesk",
      "indices" : [ 3, 12 ],
      "id_str" : "1333467482",
      "id" : 1333467482
    }, {
      "name" : "viacoin",
      "screen_name" : "viacoin",
      "indices" : [ 15, 23 ],
      "id_str" : "2432540773",
      "id" : 2432540773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/ZcnA4Y2hTY",
      "expanded_url" : "http:\/\/coinde.sk\/1vErtcY",
      "display_url" : "coinde.sk\/1vErtcY"
    } ]
  },
  "geo" : { },
  "id_str" : "501460314005573633",
  "text" : "RT @coindesk: .@Viacoin has launched the first decentralized smart contracts protocol built on top of an altcoin block chain http:\/\/t.co\/Zc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "viacoin",
        "screen_name" : "viacoin",
        "indices" : [ 1, 9 ],
        "id_str" : "2432540773",
        "id" : 2432540773
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/ZcnA4Y2hTY",
        "expanded_url" : "http:\/\/coinde.sk\/1vErtcY",
        "display_url" : "coinde.sk\/1vErtcY"
      } ]
    },
    "geo" : { },
    "id_str" : "499505756665024512",
    "text" : ".@Viacoin has launched the first decentralized smart contracts protocol built on top of an altcoin block chain http:\/\/t.co\/ZcnA4Y2hTY",
    "id" : 499505756665024512,
    "created_at" : "2014-08-13 10:40:27 +0000",
    "user" : {
      "name" : "CoinDesk",
      "screen_name" : "coindesk",
      "protected" : false,
      "id_str" : "1333467482",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3596849828\/90368fac589f772b9445a4b66caeb27a_normal.png",
      "id" : 1333467482,
      "verified" : false
    }
  },
  "id" : 501460314005573633,
  "created_at" : "2014-08-18 20:07:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 25, 34 ]
    } ],
    "urls" : [ {
      "indices" : [ 37, 60 ],
      "url" : "https:\/\/t.co\/69HWSTjsHH",
      "expanded_url" : "https:\/\/storify.com\/miniver\/mike-brown-facts-and-dog-whistles-from-shaunking",
      "display_url" : "storify.com\/miniver\/mike-b\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501428640274341888",
  "text" : "GOOD THINGS TO KNOW RE:  #FERGUSON \n\nhttps:\/\/t.co\/69HWSTjsHH",
  "id" : 501428640274341888,
  "created_at" : "2014-08-18 18:01:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 29 ],
      "url" : "https:\/\/t.co\/YBfaLGauCr",
      "expanded_url" : "https:\/\/twitter.com\/ShaunKing\/statuses\/501104645193089024",
      "display_url" : "twitter.com\/ShaunKing\/stat\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501426586084593664",
  "text" : "YEP \n\nhttps:\/\/t.co\/YBfaLGauCr\n\nJUST LIKE KATRINA",
  "id" : 501426586084593664,
  "created_at" : "2014-08-18 17:53:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501424558730002432",
  "text" : "I KEEP TWEETING AS THE WRONG BOT",
  "id" : 501424558730002432,
  "created_at" : "2014-08-18 17:45:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501398294740750339",
  "text" : "DID YOU FEEL THAT?",
  "id" : 501398294740750339,
  "created_at" : "2014-08-18 16:00:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 31, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501395685053587458",
  "text" : "SEND IN THE NATIONAL PROTEST \n\n#FERGUSON",
  "id" : 501395685053587458,
  "created_at" : "2014-08-18 15:50:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/501382765057568769\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/QHbJMmVZ7F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvVE97lCYAEXjLn.png",
      "id_str" : "501382764277424129",
      "id" : 501382764277424129,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvVE97lCYAEXjLn.png",
      "sizes" : [ {
        "h" : 396,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 396,
        "resize" : "fit",
        "w" : 752
      }, {
        "h" : 315,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/QHbJMmVZ7F"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501382765057568769",
  "text" : "selfie http:\/\/t.co\/QHbJMmVZ7F",
  "id" : 501382765057568769,
  "created_at" : "2014-08-18 14:59:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antonio French",
      "screen_name" : "AntonioFrench",
      "indices" : [ 0, 14 ],
      "id_str" : "14090948",
      "id" : 14090948
    }, {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 15, 27 ],
      "id_str" : "850972790",
      "id" : 850972790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501111870531858432",
  "geo" : { },
  "id_str" : "501201528615493632",
  "in_reply_to_user_id" : 14090948,
  "text" : "@AntonioFrench @TheHatGhost  YES YES YES",
  "id" : 501201528615493632,
  "in_reply_to_status_id" : 501111870531858432,
  "created_at" : "2014-08-18 02:58:50 +0000",
  "in_reply_to_screen_name" : "AntonioFrench",
  "in_reply_to_user_id_str" : "14090948",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501126005571223552",
  "geo" : { },
  "id_str" : "501201307026198528",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair that's gonna be a sweet landing pad daddio!",
  "id" : 501201307026198528,
  "in_reply_to_status_id" : 501126005571223552,
  "created_at" : "2014-08-18 02:57:58 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/501166926404415488\/photo\/1",
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/JYaUnobwiH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvSAp15CQAAF2p2.jpg",
      "id_str" : "501166914874261504",
      "id" : 501166914874261504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvSAp15CQAAF2p2.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/JYaUnobwiH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501166926404415488",
  "text" : "eheheh http:\/\/t.co\/JYaUnobwiH",
  "id" : 501166926404415488,
  "created_at" : "2014-08-18 00:41:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "node_modulhaus",
      "indices" : [ 3, 18 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    }, {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 111, 124 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 96 ],
      "url" : "https:\/\/t.co\/HgWjoCvjyZ",
      "expanded_url" : "https:\/\/github.com\/MODULHAUS\/crypto-fund",
      "display_url" : "github.com\/MODULHAUS\/cryp\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "501123298726387712",
  "text" : "RT @node_modulhaus: # crypto-fund\n\n## A NEW MODULE ON NPM\n\n[click here!](https:\/\/t.co\/HgWjoCvjyZ)\n\n### author: @johnnyscript",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "( +\\-)",
        "screen_name" : "johnnyscript",
        "indices" : [ 91, 104 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 76 ],
        "url" : "https:\/\/t.co\/HgWjoCvjyZ",
        "expanded_url" : "https:\/\/github.com\/MODULHAUS\/crypto-fund",
        "display_url" : "github.com\/MODULHAUS\/cryp\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "501122716154335233",
    "text" : "# crypto-fund\n\n## A NEW MODULE ON NPM\n\n[click here!](https:\/\/t.co\/HgWjoCvjyZ)\n\n### author: @johnnyscript",
    "id" : 501122716154335233,
    "created_at" : "2014-08-17 21:45:40 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "node_modulhaus",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499298155112837121\/G6rG1w7m_normal.jpeg",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 501123298726387712,
  "created_at" : "2014-08-17 21:47:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "node_modulhaus",
      "indices" : [ 0, 15 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "501122716154335233",
  "geo" : { },
  "id_str" : "501123270641344514",
  "in_reply_to_user_id" : 2278390207,
  "text" : "@node_modulhaus u forgot to say its for bitcoin and dogecoin wallets!",
  "id" : 501123270641344514,
  "in_reply_to_status_id" : 501122716154335233,
  "created_at" : "2014-08-17 21:47:52 +0000",
  "in_reply_to_screen_name" : "node_modulhaus",
  "in_reply_to_user_id_str" : "2278390207",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DOGECOIN",
      "indices" : [ 37, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501064882821681153",
  "text" : "BUH DOGE CHAIN DOTE INFO SO UNSTABLE #DOGECOIN",
  "id" : 501064882821681153,
  "created_at" : "2014-08-17 17:55:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modern Kierkegaard",
      "screen_name" : "KierkegaardNow",
      "indices" : [ 3, 18 ],
      "id_str" : "15232253",
      "id" : 15232253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "501039702191775744",
  "text" : "RT @KierkegaardNow: People beg for followers even when they know the followers will never read their tweets - what madness!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500943055164547072",
    "text" : "People beg for followers even when they know the followers will never read their tweets - what madness!!",
    "id" : 500943055164547072,
    "created_at" : "2014-08-17 09:51:46 +0000",
    "user" : {
      "name" : "Modern Kierkegaard",
      "screen_name" : "KierkegaardNow",
      "protected" : false,
      "id_str" : "15232253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000798867099\/8cf0a93c3ff7ad60d728b729685cbfb5_normal.jpeg",
      "id" : 15232253,
      "verified" : false
    }
  },
  "id" : 501039702191775744,
  "created_at" : "2014-08-17 16:15:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FERGUSON",
      "indices" : [ 52, 61 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500886168192290816",
  "text" : "NIXON ORDERS TOWN CRIER TO ANNOUNCE START OF CURFEW #FERGUSON",
  "id" : 500886168192290816,
  "created_at" : "2014-08-17 06:05:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500885512706859009",
  "text" : "Did u see that stat where NYC cops shot a single person with as many bullets as German police expend in an entire year?",
  "id" : 500885512706859009,
  "created_at" : "2014-08-17 06:03:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Bieda",
      "screen_name" : "lindseybieda",
      "indices" : [ 1, 14 ],
      "id_str" : "14928483",
      "id" : 14928483
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 129, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500788376836927489",
  "text" : "\"@lindseybieda How to take control: recognize that ur all responsible for yr local community and call people on their bullshit.\" #Ferguson",
  "id" : 500788376836927489,
  "created_at" : "2014-08-16 23:37:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500763745585340416",
  "text" : "NIXON DECLARES CURFEW!",
  "id" : 500763745585340416,
  "created_at" : "2014-08-16 21:59:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500696783878500355",
  "text" : "I hate when I read about powerful tech companies getting into cultural production (music, movie) and hire execs and producers from MTV.",
  "id" : 500696783878500355,
  "created_at" : "2014-08-16 17:33:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 69 ],
      "url" : "https:\/\/t.co\/am8zR9J3lW",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/theegress-betamins-premix",
      "display_url" : "soundcloud.com\/johnnyscript\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "500696174274560000",
  "text" : "I wrote this tune live in pure javascripts:\n  https:\/\/t.co\/am8zR9J3lW",
  "id" : 500696174274560000,
  "created_at" : "2014-08-16 17:30:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BLACK POWER",
      "screen_name" : "JUNGLEPUSSY",
      "indices" : [ 3, 15 ],
      "id_str" : "15819295",
      "id" : 15819295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/FtO9eazNEI",
      "expanded_url" : "https:\/\/vine.co\/v\/M3BVQK5tjQu",
      "display_url" : "vine.co\/v\/M3BVQK5tjQu"
    } ]
  },
  "geo" : { },
  "id_str" : "500464706444722176",
  "text" : "RT @JUNGLEPUSSY: WASSUP MY EDUCATED BROTHAS https:\/\/t.co\/FtO9eazNEI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/vine.co\" rel=\"nofollow\"\u003EVine - Make a Scene\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 50 ],
        "url" : "https:\/\/t.co\/FtO9eazNEI",
        "expanded_url" : "https:\/\/vine.co\/v\/M3BVQK5tjQu",
        "display_url" : "vine.co\/v\/M3BVQK5tjQu"
      } ]
    },
    "geo" : { },
    "id_str" : "500452508914184192",
    "text" : "WASSUP MY EDUCATED BROTHAS https:\/\/t.co\/FtO9eazNEI",
    "id" : 500452508914184192,
    "created_at" : "2014-08-16 01:22:30 +0000",
    "user" : {
      "name" : "BLACK POWER",
      "screen_name" : "JUNGLEPUSSY",
      "protected" : false,
      "id_str" : "15819295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540918599418777600\/chzyY26l_normal.jpeg",
      "id" : 15819295,
      "verified" : false
    }
  },
  "id" : 500464706444722176,
  "created_at" : "2014-08-16 02:10:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lily",
      "screen_name" : "luxuriousho",
      "indices" : [ 0, 12 ],
      "id_str" : "21127389",
      "id" : 21127389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "500456490382401537",
  "geo" : { },
  "id_str" : "500462639026561025",
  "in_reply_to_user_id" : 21127389,
  "text" : "@luxuriousho  I am truly THRILLED that you will be tweeting now from inside the Disco!",
  "id" : 500462639026561025,
  "in_reply_to_status_id" : 500456490382401537,
  "created_at" : "2014-08-16 02:02:45 +0000",
  "in_reply_to_screen_name" : "luxuriousho",
  "in_reply_to_user_id_str" : "21127389",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "node_modulhaus",
      "indices" : [ 1, 16 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500459744281124868",
  "text" : "\"@node_modulhaus: # SPEECH IS THE P IN YR MENTAL REPL\"  AND L IS THE ACRYNOID FOR LISTEN!!!",
  "id" : 500459744281124868,
  "created_at" : "2014-08-16 01:51:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "indices" : [ 3, 14 ],
      "id_str" : "14236976",
      "id" : 14236976
    }, {
      "name" : "Batsly Adams",
      "screen_name" : "batslyadams",
      "indices" : [ 83, 95 ],
      "id_str" : "98188106",
      "id" : 98188106
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/ToddBailey\/status\/500446259522842624\/photo\/1",
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/AgQeFRDolw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvHxNcqCYAAba14.jpg",
      "id_str" : "500446246947938304",
      "id" : 500446246947938304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvHxNcqCYAAba14.jpg",
      "sizes" : [ {
        "h" : 774,
        "resize" : "fit",
        "w" : 1032
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/AgQeFRDolw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500459171389923328",
  "text" : "RT @ToddBailey: After the party is the hotel lobby.  W\/ M1 Abrams tank control and @batslyadams http:\/\/t.co\/AgQeFRDolw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Batsly Adams",
        "screen_name" : "batslyadams",
        "indices" : [ 67, 79 ],
        "id_str" : "98188106",
        "id" : 98188106
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/ToddBailey\/status\/500446259522842624\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/AgQeFRDolw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvHxNcqCYAAba14.jpg",
        "id_str" : "500446246947938304",
        "id" : 500446246947938304,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvHxNcqCYAAba14.jpg",
        "sizes" : [ {
          "h" : 774,
          "resize" : "fit",
          "w" : 1032
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/AgQeFRDolw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 28.0346742, -82.6566593 ]
    },
    "id_str" : "500446259522842624",
    "text" : "After the party is the hotel lobby.  W\/ M1 Abrams tank control and @batslyadams http:\/\/t.co\/AgQeFRDolw",
    "id" : 500446259522842624,
    "created_at" : "2014-08-16 00:57:40 +0000",
    "user" : {
      "name" : "Todd Michael Bailey",
      "screen_name" : "ToddBailey",
      "protected" : false,
      "id_str" : "14236976",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502885261\/TB_Cropped_5_normal.jpg",
      "id" : 14236976,
      "verified" : false
    }
  },
  "id" : 500459171389923328,
  "created_at" : "2014-08-16 01:48:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 70, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500394049434836992",
  "text" : "I stole swisher sweets from the corner stores when I was a kid, too.  #ferguson",
  "id" : 500394049434836992,
  "created_at" : "2014-08-15 21:30:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/FbdvY079M8",
      "expanded_url" : "http:\/\/oaklandwiki.org\/Robert_Roche",
      "display_url" : "oaklandwiki.org\/Robert_Roche"
    } ]
  },
  "geo" : { },
  "id_str" : "500393429252063232",
  "text" : "RT @substack: oakland police officer was fired for firing tear gas grenades at unconscious injured, has killed 3, just reinstated http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/FbdvY079M8",
        "expanded_url" : "http:\/\/oaklandwiki.org\/Robert_Roche",
        "display_url" : "oaklandwiki.org\/Robert_Roche"
      } ]
    },
    "geo" : { },
    "id_str" : "500391701626617858",
    "text" : "oakland police officer was fired for firing tear gas grenades at unconscious injured, has killed 3, just reinstated http:\/\/t.co\/FbdvY079M8",
    "id" : 500391701626617858,
    "created_at" : "2014-08-15 21:20:53 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 500393429252063232,
  "created_at" : "2014-08-15 21:27:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Root",
      "screen_name" : "TheRoot",
      "indices" : [ 3, 11 ],
      "id_str" : "23995748",
      "id" : 23995748
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/TheRoot\/status\/500254361277440000\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/BBZcHzbB10",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BvFCsMoCcAEMoca.jpg",
      "id_str" : "500254360685670401",
      "id" : 500254360685670401,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvFCsMoCcAEMoca.jpg",
      "sizes" : [ {
        "h" : 201,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 398,
        "resize" : "fit",
        "w" : 670
      }, {
        "h" : 356,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/BBZcHzbB10"
    } ],
    "hashtags" : [ {
      "text" : "MikeBrown",
      "indices" : [ 94, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/u1RuMaDGpw",
      "expanded_url" : "http:\/\/bit.ly\/1Bjyosl",
      "display_url" : "bit.ly\/1Bjyosl"
    } ]
  },
  "geo" : { },
  "id_str" : "500393416027410432",
  "text" : "RT @TheRoot: Everything you need to know about the 4 unarmed men killed by police this month: #MikeBrown http:\/\/t.co\/u1RuMaDGpw  http:\/\/t.c\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/TheRoot\/status\/500254361277440000\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/BBZcHzbB10",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BvFCsMoCcAEMoca.jpg",
        "id_str" : "500254360685670401",
        "id" : 500254360685670401,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BvFCsMoCcAEMoca.jpg",
        "sizes" : [ {
          "h" : 201,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 398,
          "resize" : "fit",
          "w" : 670
        }, {
          "h" : 356,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/BBZcHzbB10"
      } ],
      "hashtags" : [ {
        "text" : "MikeBrown",
        "indices" : [ 81, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/u1RuMaDGpw",
        "expanded_url" : "http:\/\/bit.ly\/1Bjyosl",
        "display_url" : "bit.ly\/1Bjyosl"
      } ]
    },
    "geo" : { },
    "id_str" : "500279431777484801",
    "text" : "Everything you need to know about the 4 unarmed men killed by police this month: #MikeBrown http:\/\/t.co\/u1RuMaDGpw  http:\/\/t.co\/BBZcHzbB10",
    "id" : 500279431777484801,
    "created_at" : "2014-08-15 13:54:45 +0000",
    "user" : {
      "name" : "The Root",
      "screen_name" : "TheRoot",
      "protected" : false,
      "id_str" : "23995748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/517418757702963200\/MfhBCTzG_normal.jpeg",
      "id" : 23995748,
      "verified" : true
    }
  },
  "id" : 500393416027410432,
  "created_at" : "2014-08-15 21:27:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500299396282462212",
  "text" : "THE FOOL LEARNS",
  "id" : 500299396282462212,
  "created_at" : "2014-08-15 15:14:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ferguson",
      "indices" : [ 131, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500140114492657664",
  "text" : "It's like post Katrina when the army went in with tanks, guns pointed. Then they sent in the black General who said WTF GUNS DOWN! #ferguson",
  "id" : 500140114492657664,
  "created_at" : "2014-08-15 04:41:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Ferguson",
      "indices" : [ 78, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/0DMdzrTbuS",
      "expanded_url" : "http:\/\/localwiki.net\/st-louis\/Victims_of_Violence",
      "display_url" : "localwiki.net\/st-louis\/Victi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "500138985440571392",
  "text" : "RT @substack: please help document victims of violence http:\/\/t.co\/0DMdzrTbuS #Ferguson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Ferguson",
        "indices" : [ 64, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/0DMdzrTbuS",
        "expanded_url" : "http:\/\/localwiki.net\/st-louis\/Victims_of_Violence",
        "display_url" : "localwiki.net\/st-louis\/Victi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "500072801340899329",
    "text" : "please help document victims of violence http:\/\/t.co\/0DMdzrTbuS #Ferguson",
    "id" : 500072801340899329,
    "created_at" : "2014-08-15 00:13:41 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 500138985440571392,
  "created_at" : "2014-08-15 04:36:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 3, 15 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500014609139793921",
  "text" : "RT @dominictarr: OH \"I found a web app that allows you to write on other people's PDFs\"\n\"What? that is like graffitti!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "500006593413402626",
    "text" : "OH \"I found a web app that allows you to write on other people's PDFs\"\n\"What? that is like graffitti!\"",
    "id" : 500006593413402626,
    "created_at" : "2014-08-14 19:50:36 +0000",
    "user" : {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "protected" : false,
      "id_str" : "136933779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1753980863\/gravatar_normal.jpeg",
      "id" : 136933779,
      "verified" : false
    }
  },
  "id" : 500014609139793921,
  "created_at" : "2014-08-14 20:22:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "500004283140808705",
  "text" : "s\/\noptional object\/\nopject",
  "id" : 500004283140808705,
  "created_at" : "2014-08-14 19:41:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499952038168788992",
  "text" : "cops are gangsters, never forget",
  "id" : 499952038168788992,
  "created_at" : "2014-08-14 16:13:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499781470064345089",
  "text" : "Public cries for state and federal intervention in Fergeson  is a symptom of some kind of syndrome.",
  "id" : 499781470064345089,
  "created_at" : "2014-08-14 04:56:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/499779201873223682\/photo\/1",
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/BCcZ4mekCT",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bu-SiSACEAIo1a0.jpg",
      "id_str" : "499779201306595330",
      "id" : 499779201306595330,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bu-SiSACEAIo1a0.jpg",
      "sizes" : [ {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1295,
        "resize" : "fit",
        "w" : 970
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 801,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1295,
        "resize" : "fit",
        "w" : 970
      } ],
      "display_url" : "pic.twitter.com\/BCcZ4mekCT"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499779201873223682",
  "text" : "http:\/\/t.co\/BCcZ4mekCT",
  "id" : 499779201873223682,
  "created_at" : "2014-08-14 04:47:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lily",
      "screen_name" : "luxuriousho",
      "indices" : [ 0, 12 ],
      "id_str" : "21127389",
      "id" : 21127389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499755440218329088",
  "geo" : { },
  "id_str" : "499756438038646784",
  "in_reply_to_user_id" : 21127389,
  "text" : "@luxuriousho  I'm the only who calls it that, cuz the timbaland lyric \"im the man from the big VA, won't u come play round my way...\"   &gt;_&lt;",
  "id" : 499756438038646784,
  "in_reply_to_status_id" : 499755440218329088,
  "created_at" : "2014-08-14 03:16:34 +0000",
  "in_reply_to_screen_name" : "luxuriousho",
  "in_reply_to_user_id_str" : "21127389",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lily",
      "screen_name" : "luxuriousho",
      "indices" : [ 0, 12 ],
      "id_str" : "21127389",
      "id" : 21127389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499753856159711233",
  "geo" : { },
  "id_str" : "499754970812403712",
  "in_reply_to_user_id" : 21127389,
  "text" : "@luxuriousho \"Bay Area\"",
  "id" : 499754970812403712,
  "in_reply_to_status_id" : 499753856159711233,
  "created_at" : "2014-08-14 03:10:44 +0000",
  "in_reply_to_screen_name" : "luxuriousho",
  "in_reply_to_user_id_str" : "21127389",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lily",
      "screen_name" : "luxuriousho",
      "indices" : [ 0, 12 ],
      "id_str" : "21127389",
      "id" : 21127389
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499750518626197506",
  "geo" : { },
  "id_str" : "499753318382858240",
  "in_reply_to_user_id" : 21127389,
  "text" : "@luxuriousho  Are u moving to the big BA?",
  "id" : 499753318382858240,
  "in_reply_to_status_id" : 499750518626197506,
  "created_at" : "2014-08-14 03:04:10 +0000",
  "in_reply_to_screen_name" : "luxuriousho",
  "in_reply_to_user_id_str" : "21127389",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Marina Kukso",
      "screen_name" : "marinakukso",
      "indices" : [ 13, 25 ],
      "id_str" : "1484011428",
      "id" : 1484011428
    }, {
      "name" : "hij1nx",
      "screen_name" : "hij1nx",
      "indices" : [ 26, 33 ],
      "id_str" : "95938827",
      "id" : 95938827
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499669379198353408",
  "geo" : { },
  "id_str" : "499749795431346177",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr @marinakukso @hij1nx  obviously, back to your hometown.",
  "id" : 499749795431346177,
  "in_reply_to_status_id" : 499669379198353408,
  "created_at" : "2014-08-14 02:50:10 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "node_modulhaus",
      "indices" : [ 3, 18 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499614318686928896",
  "text" : "RT @node_modulhaus: # OPEN SOURCE IS CALLED CHEATING IN SCHOOL\n\n## MODULHAUS DEF CHEATING AT OPEN SOURCE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499492894571376641",
    "text" : "# OPEN SOURCE IS CALLED CHEATING IN SCHOOL\n\n## MODULHAUS DEF CHEATING AT OPEN SOURCE",
    "id" : 499492894571376641,
    "created_at" : "2014-08-13 09:49:20 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "node_modulhaus",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499298155112837121\/G6rG1w7m_normal.jpeg",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 499614318686928896,
  "created_at" : "2014-08-13 17:51:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499614009545736193",
  "text" : "faux news is reporting a supposed FBI warning to Police that a new Black Panther Party is advocating violence in Ferguson.",
  "id" : 499614009545736193,
  "created_at" : "2014-08-13 17:50:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 0, 13 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499610041864159232",
  "geo" : { },
  "id_str" : "499610158041792512",
  "in_reply_to_user_id" : 46961216,
  "text" : "@johnnyscript  and I jus fixed a big stupid bug that broke require() after the first compile.",
  "id" : 499610158041792512,
  "in_reply_to_status_id" : 499610041864159232,
  "created_at" : "2014-08-13 17:35:18 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/rJ3etfu2gq",
      "expanded_url" : "http:\/\/node.module.club",
      "display_url" : "node.module.club"
    } ]
  },
  "geo" : { },
  "id_str" : "499610041864159232",
  "text" : "http:\/\/t.co\/rJ3etfu2gq is a JS text editor \/ live console w\/ support for browserify \/ require.  Type, compile and exec with SHIFT-ENTER.",
  "id" : 499610041864159232,
  "created_at" : "2014-08-13 17:34:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/hPiHIgDzd2",
      "expanded_url" : "https:\/\/gist.github.com\/NHQ\/6289287",
      "display_url" : "gist.github.com\/NHQ\/6289287"
    } ]
  },
  "geo" : { },
  "id_str" : "499468610360709120",
  "text" : "This reminds me of a another one:  https:\/\/t.co\/hPiHIgDzd2",
  "id" : 499468610360709120,
  "created_at" : "2014-08-13 08:12:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Redding",
      "screen_name" : "micahtredding",
      "indices" : [ 0, 14 ],
      "id_str" : "5479672",
      "id" : 5479672
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 15, 27 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 28, 42 ],
      "id_str" : "379919160",
      "id" : 379919160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499368896932372480",
  "geo" : { },
  "id_str" : "499468547622313984",
  "in_reply_to_user_id" : 5479672,
  "text" : "@micahtredding @dominictarr @MikolaLysenko Should # of states be determined by how often Time God commits?",
  "id" : 499468547622313984,
  "in_reply_to_status_id" : 499368896932372480,
  "created_at" : "2014-08-13 08:12:36 +0000",
  "in_reply_to_screen_name" : "micahtredding",
  "in_reply_to_user_id_str" : "5479672",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Redding",
      "screen_name" : "micahtredding",
      "indices" : [ 0, 14 ],
      "id_str" : "5479672",
      "id" : 5479672
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 15, 27 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 28, 42 ],
      "id_str" : "379919160",
      "id" : 379919160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499368896932372480",
  "geo" : { },
  "id_str" : "499453590613024768",
  "in_reply_to_user_id" : 5479672,
  "text" : "@micahtredding @dominictarr @MikolaLysenko all of those states are possible.  We exist in a branch of well edified patterns.",
  "id" : 499453590613024768,
  "in_reply_to_status_id" : 499368896932372480,
  "created_at" : "2014-08-13 07:13:10 +0000",
  "in_reply_to_screen_name" : "micahtredding",
  "in_reply_to_user_id_str" : "5479672",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 54 ],
      "url" : "https:\/\/t.co\/S56Vyl125u",
      "expanded_url" : "https:\/\/gist.github.com\/NHQ\/2b57397eb28d8a40538e",
      "display_url" : "gist.github.com\/NHQ\/2b57397eb2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499367893021118464",
  "text" : "Johnny's Universal Hypothesis\n\nhttps:\/\/t.co\/S56Vyl125u",
  "id" : 499367893021118464,
  "created_at" : "2014-08-13 01:32:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Redding",
      "screen_name" : "micahtredding",
      "indices" : [ 0, 14 ],
      "id_str" : "5479672",
      "id" : 5479672
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 15, 27 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 28, 42 ],
      "id_str" : "379919160",
      "id" : 379919160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 137 ],
      "url" : "https:\/\/t.co\/S56Vyl125u",
      "expanded_url" : "https:\/\/gist.github.com\/NHQ\/2b57397eb28d8a40538e",
      "display_url" : "gist.github.com\/NHQ\/2b57397eb2\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "499359989941534720",
  "geo" : { },
  "id_str" : "499366543839342592",
  "in_reply_to_user_id" : 5479672,
  "text" : "@micahtredding @dominictarr @MikolaLysenko \nYes, it is as I suspected. I believe the # of states to be much large https:\/\/t.co\/S56Vyl125u",
  "id" : 499366543839342592,
  "in_reply_to_status_id" : 499359989941534720,
  "created_at" : "2014-08-13 01:27:16 +0000",
  "in_reply_to_screen_name" : "micahtredding",
  "in_reply_to_user_id_str" : "5479672",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah Redding",
      "screen_name" : "micahtredding",
      "indices" : [ 0, 14 ],
      "id_str" : "5479672",
      "id" : 5479672
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 15, 27 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Mikola Lysenko",
      "screen_name" : "MikolaLysenko",
      "indices" : [ 28, 42 ],
      "id_str" : "379919160",
      "id" : 379919160
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "499219980085624833",
  "geo" : { },
  "id_str" : "499348260037722112",
  "in_reply_to_user_id" : 5479672,
  "text" : "@micahtredding @dominictarr @MikolaLysenko \nhow is this figured?",
  "id" : 499348260037722112,
  "in_reply_to_status_id" : 499219980085624833,
  "created_at" : "2014-08-13 00:14:37 +0000",
  "in_reply_to_screen_name" : "micahtredding",
  "in_reply_to_user_id_str" : "5479672",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499342055319949312",
  "text" : "so prose\nmuche markdown",
  "id" : 499342055319949312,
  "created_at" : "2014-08-12 23:49:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "node_modulhaus",
      "indices" : [ 3, 18 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499295415892598786",
  "text" : "RT @node_modulhaus: ALL CAPS IS GREAT AND ALL, BUT...\n\n# HENCEFORTH WE'LL BE TWEETING IN MARKDOWN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "499295076183318528",
    "text" : "ALL CAPS IS GREAT AND ALL, BUT...\n\n# HENCEFORTH WE'LL BE TWEETING IN MARKDOWN",
    "id" : 499295076183318528,
    "created_at" : "2014-08-12 20:43:17 +0000",
    "user" : {
      "name" : "Modulhaus",
      "screen_name" : "node_modulhaus",
      "protected" : false,
      "id_str" : "2278390207",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499298155112837121\/G6rG1w7m_normal.jpeg",
      "id" : 2278390207,
      "verified" : false
    }
  },
  "id" : 499295415892598786,
  "created_at" : "2014-08-12 20:44:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "node_modulhaus",
      "indices" : [ 7, 22 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499283525464383488",
  "text" : "follow @node_modulhaus \n\nit's Tuesday  \"\/",
  "id" : 499283525464383488,
  "created_at" : "2014-08-12 19:57:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/ZB1GgqN58n",
      "expanded_url" : "http:\/\/node.module.club",
      "display_url" : "node.module.club"
    } ]
  },
  "geo" : { },
  "id_str" : "499283021397098496",
  "text" : "http:\/\/t.co\/ZB1GgqN58n is living + works in FireFox now.  It's a js console\/editor with require() via wzrd.in\n\nSHIFT-ENTER compiles yr code.",
  "id" : 499283021397098496,
  "created_at" : "2014-08-12 19:55:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Modulhaus",
      "screen_name" : "node_modulhaus",
      "indices" : [ 19, 34 ],
      "id_str" : "2278390207",
      "id" : 2278390207
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499282497424064512",
  "text" : "I write modules at @node_modulhaus",
  "id" : 499282497424064512,
  "created_at" : "2014-08-12 19:53:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 45 ],
      "url" : "http:\/\/t.co\/2PakQOW0fD",
      "expanded_url" : "http:\/\/nodejsreactions.tumblr.com\/post\/94543279669\/refactoring",
      "display_url" : "nodejsreactions.tumblr.com\/post\/945432796\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "499271716900569089",
  "text" : "hahahaha \"Refactoring\" http:\/\/t.co\/2PakQOW0fD \n\nalso that person...",
  "id" : 499271716900569089,
  "created_at" : "2014-08-12 19:10:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "499270851498618882",
  "text" : "gonna go sit in the sun like a lizza would",
  "id" : 499270851498618882,
  "created_at" : "2014-08-12 19:07:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TOLKIEN BLACK",
      "screen_name" : "therealhennessy",
      "indices" : [ 0, 16 ],
      "id_str" : "137090436",
      "id" : 137090436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498635105582473216",
  "geo" : { },
  "id_str" : "498774706296606720",
  "in_reply_to_user_id" : 137090436,
  "text" : "@therealhennessy Request denied,  you do not have permission to access \"implore\".",
  "id" : 498774706296606720,
  "in_reply_to_status_id" : 498635105582473216,
  "created_at" : "2014-08-11 10:15:31 +0000",
  "in_reply_to_screen_name" : "therealhennessy",
  "in_reply_to_user_id_str" : "137090436",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498755875054436352",
  "text" : "my code is too bust for you \nbutts 4 me\nit werks\nwow",
  "id" : 498755875054436352,
  "created_at" : "2014-08-11 09:00:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "L u k e O' N e i l ",
      "screen_name" : "lukeoneil47",
      "indices" : [ 3, 15 ],
      "id_str" : "108338399",
      "id" : 108338399
    }, {
      "name" : "NBC News",
      "screen_name" : "NBCNews",
      "indices" : [ 38, 46 ],
      "id_str" : "14173315",
      "id" : 14173315
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/lukeoneil47\/status\/498536834948141056\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/6yP9VR5ovk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Busom91CYAEJEH6.jpg",
      "id_str" : "498536833651728385",
      "id" : 498536833651728385,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Busom91CYAEJEH6.jpg",
      "sizes" : [ {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 2000,
        "resize" : "fit",
        "w" : 2000
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/6yP9VR5ovk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498543849115897856",
  "text" : "RT @lukeoneil47: weird how this works @NBCNews http:\/\/t.co\/6yP9VR5ovk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NBC News",
        "screen_name" : "NBCNews",
        "indices" : [ 21, 29 ],
        "id_str" : "14173315",
        "id" : 14173315
      } ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/lukeoneil47\/status\/498536834948141056\/photo\/1",
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/6yP9VR5ovk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Busom91CYAEJEH6.jpg",
        "id_str" : "498536833651728385",
        "id" : 498536833651728385,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Busom91CYAEJEH6.jpg",
        "sizes" : [ {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 2000,
          "resize" : "fit",
          "w" : 2000
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/6yP9VR5ovk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "498526729728565250",
    "geo" : { },
    "id_str" : "498536834948141056",
    "in_reply_to_user_id" : 14173315,
    "text" : "weird how this works @NBCNews http:\/\/t.co\/6yP9VR5ovk",
    "id" : 498536834948141056,
    "in_reply_to_status_id" : 498526729728565250,
    "created_at" : "2014-08-10 18:30:18 +0000",
    "in_reply_to_screen_name" : "NBCNews",
    "in_reply_to_user_id_str" : "14173315",
    "user" : {
      "name" : "L u k e O' N e i l ",
      "screen_name" : "lukeoneil47",
      "protected" : false,
      "id_str" : "108338399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546873885090934784\/9fOieGn9_normal.jpeg",
      "id" : 108338399,
      "verified" : false
    }
  },
  "id" : 498543849115897856,
  "created_at" : "2014-08-10 18:58:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Algorave",
      "screen_name" : "algorave",
      "indices" : [ 0, 9 ],
      "id_str" : "552031662",
      "id" : 552031662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 51 ],
      "url" : "https:\/\/t.co\/JTcgi0ErlI",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/theegress-betamins-premix",
      "display_url" : "soundcloud.com\/johnnyscript\/t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "498543690134990848",
  "in_reply_to_user_id" : 552031662,
  "text" : "@algorave  100% algo made:  https:\/\/t.co\/JTcgi0ErlI",
  "id" : 498543690134990848,
  "created_at" : "2014-08-10 18:57:32 +0000",
  "in_reply_to_screen_name" : "algorave",
  "in_reply_to_user_id_str" : "552031662",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498521032731271169",
  "text" : "U ARE A NEUTRAL MASSIVE SPINNING ASS PARTICLE",
  "id" : 498521032731271169,
  "created_at" : "2014-08-10 17:27:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "William Cotton",
      "screen_name" : "williamcotton",
      "indices" : [ 0, 14 ],
      "id_str" : "11745462",
      "id" : 11745462
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 77 ],
      "url" : "https:\/\/t.co\/JTcgi0ErlI",
      "expanded_url" : "https:\/\/soundcloud.com\/johnnyscript\/theegress-betamins-premix",
      "display_url" : "soundcloud.com\/johnnyscript\/t\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "498514207541710849",
  "geo" : { },
  "id_str" : "498516973207056384",
  "in_reply_to_user_id" : 11745462,
  "text" : "@williamcotton  \nI made this in a website last night \nhttps:\/\/t.co\/JTcgi0ErlI",
  "id" : 498516973207056384,
  "in_reply_to_status_id" : 498514207541710849,
  "created_at" : "2014-08-10 17:11:23 +0000",
  "in_reply_to_screen_name" : "williamcotton",
  "in_reply_to_user_id_str" : "11745462",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Lord",
      "screen_name" : "jllord",
      "indices" : [ 0, 7 ],
      "id_str" : "126718519",
      "id" : 126718519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498509263774285825",
  "geo" : { },
  "id_str" : "498510121891135488",
  "in_reply_to_user_id" : 126718519,
  "text" : "@jllord  ME SEE IT!  THXU",
  "id" : 498510121891135488,
  "in_reply_to_status_id" : 498509263774285825,
  "created_at" : "2014-08-10 16:44:09 +0000",
  "in_reply_to_screen_name" : "jllord",
  "in_reply_to_user_id_str" : "126718519",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498504910174814208",
  "text" : "MADE SCIENTIST",
  "id" : 498504910174814208,
  "created_at" : "2014-08-10 16:23:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Lord",
      "screen_name" : "jllord",
      "indices" : [ 0, 7 ],
      "id_str" : "126718519",
      "id" : 126718519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/fBWzmcAtKF",
      "expanded_url" : "http:\/\/nhq.github.io\/hello",
      "display_url" : "nhq.github.io\/hello"
    } ]
  },
  "in_reply_to_status_id_str" : "496046983497658368",
  "geo" : { },
  "id_str" : "498503511399620610",
  "in_reply_to_user_id" : 126718519,
  "text" : "@jllord  i forked and made changes but it does not publish!  http:\/\/t.co\/fBWzmcAtKF",
  "id" : 498503511399620610,
  "in_reply_to_status_id" : 496046983497658368,
  "created_at" : "2014-08-10 16:17:53 +0000",
  "in_reply_to_screen_name" : "jllord",
  "in_reply_to_user_id_str" : "126718519",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498356508422197248",
  "text" : "bandcamp promotes artists\nsoundcloud promotes soundcloud",
  "id" : 498356508422197248,
  "created_at" : "2014-08-10 06:33:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Day",
      "screen_name" : "soldair",
      "indices" : [ 0, 8 ],
      "id_str" : "16893912",
      "id" : 16893912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "498270125527535617",
  "geo" : { },
  "id_str" : "498273883233849344",
  "in_reply_to_user_id" : 16893912,
  "text" : "@soldair  are those for growing crop xircles in the desert?",
  "id" : 498273883233849344,
  "in_reply_to_status_id" : 498270125527535617,
  "created_at" : "2014-08-10 01:05:25 +0000",
  "in_reply_to_screen_name" : "soldair",
  "in_reply_to_user_id_str" : "16893912",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "498273009158062081",
  "text" : "SACRE BOUCHE!",
  "id" : 498273009158062081,
  "created_at" : "2014-08-10 01:01:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497955148618936320",
  "text" : "db,cb",
  "id" : 497955148618936320,
  "created_at" : "2014-08-09 03:58:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497929131607085056",
  "text" : "imma hopcula",
  "id" : 497929131607085056,
  "created_at" : "2014-08-09 02:15:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 5, 12 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497853854403162113",
  "text" : "wow .@github, i clicked a link in the preview of my issue report, and traded 20 minutes of typing for an error not found.",
  "id" : 497853854403162113,
  "created_at" : "2014-08-08 21:16:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497848748211306496",
  "text" : "I ordered a magnitude and got one",
  "id" : 497848748211306496,
  "created_at" : "2014-08-08 20:56:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "indices" : [ 3, 10 ],
      "id_str" : "291901937",
      "id" : 291901937
    }, {
      "name" : "( +\\-)",
      "screen_name" : "johnnyscript",
      "indices" : [ 17, 30 ],
      "id_str" : "46961216",
      "id" : 46961216
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497847832536043520",
  "text" : "RT @LB2045: Only @johnnyscript can make dish-doing and linux so fabulous.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "( +\\-)",
        "screen_name" : "johnnyscript",
        "indices" : [ 5, 18 ],
        "id_str" : "46961216",
        "id" : 46961216
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "497845184936546305",
    "text" : "Only @johnnyscript can make dish-doing and linux so fabulous.",
    "id" : 497845184936546305,
    "created_at" : "2014-08-08 20:41:56 +0000",
    "user" : {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "protected" : false,
      "id_str" : "291901937",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524991844514418688\/hPkExiIp_normal.jpeg",
      "id" : 291901937,
      "verified" : false
    }
  },
  "id" : 497847832536043520,
  "created_at" : "2014-08-08 20:52:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ronald Pineda",
      "screen_name" : "RonaldOnTheRoad",
      "indices" : [ 0, 16 ],
      "id_str" : "251476496",
      "id" : 251476496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497501157103661056",
  "geo" : { },
  "id_str" : "497817189508861952",
  "in_reply_to_user_id" : 251476496,
  "text" : "@RonaldOnTheRoad  I am a node",
  "id" : 497817189508861952,
  "in_reply_to_status_id" : 497501157103661056,
  "created_at" : "2014-08-08 18:50:41 +0000",
  "in_reply_to_screen_name" : "RonaldOnTheRoad",
  "in_reply_to_user_id_str" : "251476496",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497785008250028032",
  "geo" : { },
  "id_str" : "497807230021160961",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove  we gotta get on the donkey about this if we want to use that space.  There are two ways in: as a member group || sponsored by 1",
  "id" : 497807230021160961,
  "in_reply_to_status_id" : 497785008250028032,
  "created_at" : "2014-08-08 18:11:07 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 33 ],
      "url" : "http:\/\/t.co\/g7sgqCI9pb",
      "expanded_url" : "http:\/\/github.com\/NHQ",
      "display_url" : "github.com\/NHQ"
    } ]
  },
  "in_reply_to_status_id_str" : "497785008250028032",
  "geo" : { },
  "id_str" : "497793418727157760",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove http:\/\/t.co\/g7sgqCI9pb.",
  "id" : 497793418727157760,
  "in_reply_to_status_id" : 497785008250028032,
  "created_at" : "2014-08-08 17:16:14 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497617450326716418",
  "text" : "fuckin hacker castle wifi can't handle ssh",
  "id" : 497617450326716418,
  "created_at" : "2014-08-08 05:37:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497616830454722560",
  "text" : "put a boner in it",
  "id" : 497616830454722560,
  "created_at" : "2014-08-08 05:34:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497615833225383936",
  "text" : "beer my god",
  "id" : 497615833225383936,
  "created_at" : "2014-08-08 05:30:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497615628669161472",
  "text" : "code sabbatical is over now imma terrist",
  "id" : 497615628669161472,
  "created_at" : "2014-08-08 05:29:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497613630586646529",
  "text" : "saved by a beer",
  "id" : 497613630586646529,
  "created_at" : "2014-08-08 05:21:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497613217347035136",
  "text" : "im blind",
  "id" : 497613217347035136,
  "created_at" : "2014-08-08 05:20:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497613190142763008",
  "text" : "looking up my own modules in the infinite library",
  "id" : 497613190142763008,
  "created_at" : "2014-08-08 05:20:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/497509380082765825\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/qrNsgB1uva",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BueCIynCcAAT5m-.jpg",
      "id_str" : "497509371383803904",
      "id" : 497509371383803904,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BueCIynCcAAT5m-.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/qrNsgB1uva"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497509380082765825",
  "text" : "My current office. In the BG, a giant film screen with righteous archangel tight ends. http:\/\/t.co\/qrNsgB1uva",
  "id" : 497509380082765825,
  "created_at" : "2014-08-07 22:27:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 1, 12 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497505265583783937",
  "text" : "\"@grayamelia: Hills Like White Boobs (working title)\"  go with it",
  "id" : 497505265583783937,
  "created_at" : "2014-08-07 22:11:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497504379398680576",
  "text" : "I HAVE A SECRET ABOUT MEN",
  "id" : 497504379398680576,
  "created_at" : "2014-08-07 22:07:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lesley Bell",
      "screen_name" : "LB2045",
      "indices" : [ 0, 7 ],
      "id_str" : "291901937",
      "id" : 291901937
    }, {
      "name" : "Mercedes H",
      "screen_name" : "the_N0",
      "indices" : [ 8, 15 ],
      "id_str" : "42699163",
      "id" : 42699163
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "497455302187315200",
  "geo" : { },
  "id_str" : "497501543961096193",
  "in_reply_to_user_id" : 291901937,
  "text" : "@LB2045 @the_N0 \n\nIt depends what my cock is in too.",
  "id" : 497501543961096193,
  "in_reply_to_status_id" : 497455302187315200,
  "created_at" : "2014-08-07 21:56:25 +0000",
  "in_reply_to_screen_name" : "LB2045",
  "in_reply_to_user_id_str" : "291901937",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "e\u0489\u0332m\u035C\u032C\u0320il\u0322\u0347\u033A\u034D\u0332\u0330y\u0340\u031C\u0318\u032D",
      "screen_name" : "nexxylove",
      "indices" : [ 0, 10 ],
      "id_str" : "170605832",
      "id" : 170605832
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/johnnyscript\/status\/497500440045449216\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/sPKQqzG20a",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bud5_rXCYAAAEFl.jpg",
      "id_str" : "497500418725797888",
      "id" : 497500418725797888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bud5_rXCYAAAEFl.jpg",
      "sizes" : [ {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/sPKQqzG20a"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497500440045449216",
  "in_reply_to_user_id" : 170605832,
  "text" : "@nexxylove  Will this become the home of rave.js in Oakland? http:\/\/t.co\/sPKQqzG20a",
  "id" : 497500440045449216,
  "created_at" : "2014-08-07 21:52:02 +0000",
  "in_reply_to_screen_name" : "nexxylove",
  "in_reply_to_user_id_str" : "170605832",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/6v6LFP6v7a",
      "expanded_url" : "http:\/\/www.underarmour.com\/shop\/us\/en\/mens-heatgear-sonic-compression-leggings\/pid1243382-100",
      "display_url" : "underarmour.com\/shop\/us\/en\/men\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "497431752478949377",
  "text" : "AND FOR THOSE \"WINDY\" DAYS (BEER, BURRITOS), YOU MAY REQUIRE TIGHTS WITH \"SONIC COMPRESSION\" LOL\n\nhttp:\/\/t.co\/6v6LFP6v7a",
  "id" : 497431752478949377,
  "created_at" : "2014-08-07 17:19:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/RVA44WWb0g",
      "expanded_url" : "http:\/\/www.underarmour.com\/shop\/us\/en\/mens-coldgear-infrared-tactical-fitted-leggings\/pid1244395-390",
      "display_url" : "underarmour.com\/shop\/us\/en\/men\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "497431431786676224",
  "text" : "LOL IF YOU ARE INSECURE ABOUT BUYING TIGHTS, YOU CAN INSTEAD BUY MEN'S \"COLDGEAR\" INFRARED TACTICAL LEGGINGS  http:\/\/t.co\/RVA44WWb0g",
  "id" : 497431431786676224,
  "created_at" : "2014-08-07 17:17:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/95eJnI9LJT",
      "expanded_url" : "http:\/\/fdlp.gov",
      "display_url" : "fdlp.gov"
    } ]
  },
  "geo" : { },
  "id_str" : "497280092481933312",
  "text" : "Yay  http:\/\/t.co\/95eJnI9LJT",
  "id" : 497280092481933312,
  "created_at" : "2014-08-07 07:16:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "497119146782367744",
  "text" : "JS WIZARD!\nCSS CLERIC!!\nHTML5 SANDWICH ARTIST!!!",
  "id" : 497119146782367744,
  "created_at" : "2014-08-06 20:36:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 30, 53 ],
      "url" : "https:\/\/t.co\/zfARr38ueo",
      "expanded_url" : "https:\/\/gist.github.com\/substack\/95dfafde53a3c4244e46",
      "display_url" : "gist.github.com\/substack\/95dfa\u2026"
    }, {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/hEEd6b14oP",
      "expanded_url" : "http:\/\/substack.neocities.org\/video.html",
      "display_url" : "substack.neocities.org\/video.html"
    } ]
  },
  "geo" : { },
  "id_str" : "496923411231154178",
  "text" : "RT @substack: paste this code https:\/\/t.co\/zfARr38ueo into http:\/\/t.co\/hEEd6b14oP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 16, 39 ],
        "url" : "https:\/\/t.co\/zfARr38ueo",
        "expanded_url" : "https:\/\/gist.github.com\/substack\/95dfafde53a3c4244e46",
        "display_url" : "gist.github.com\/substack\/95dfa\u2026"
      }, {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/hEEd6b14oP",
        "expanded_url" : "http:\/\/substack.neocities.org\/video.html",
        "display_url" : "substack.neocities.org\/video.html"
      } ]
    },
    "geo" : { },
    "id_str" : "496911756954845184",
    "text" : "paste this code https:\/\/t.co\/zfARr38ueo into http:\/\/t.co\/hEEd6b14oP",
    "id" : 496911756954845184,
    "created_at" : "2014-08-06 06:52:49 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 496923411231154178,
  "created_at" : "2014-08-06 07:39:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496876898656337921",
  "text" : "no snacks\n\nmenduxei",
  "id" : 496876898656337921,
  "created_at" : "2014-08-06 04:34:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496792527404425217",
  "text" : "JOHNNYSLAW SAYS IF U CAN DO IT WITHOUT PANTS, THEN THAT IS THE WAY IT SHOULD BE DONE.",
  "id" : 496792527404425217,
  "created_at" : "2014-08-05 22:59:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496743999550795776",
  "text" : "If you practice with your right and your left, you will live twice as often.",
  "id" : 496743999550795776,
  "created_at" : "2014-08-05 19:46:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BLACK POWER",
      "screen_name" : "JUNGLEPUSSY",
      "indices" : [ 3, 15 ],
      "id_str" : "15819295",
      "id" : 15819295
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/JUNGLEPUSSY\/status\/496694212667383808\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/nTwocwdfR1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BuScwTEIcAAXz_w.jpg",
      "id_str" : "496694212482854912",
      "id" : 496694212482854912,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuScwTEIcAAXz_w.jpg",
      "sizes" : [ {
        "h" : 457,
        "resize" : "fit",
        "w" : 472
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 329,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 472
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 472
      } ],
      "display_url" : "pic.twitter.com\/nTwocwdfR1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496706314949517312",
  "text" : "RT @JUNGLEPUSSY: WHEN BITCHES GO BACK FOR DICK THAT DON'T BENEFIT THEIR HEALTH http:\/\/t.co\/nTwocwdfR1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/JUNGLEPUSSY\/status\/496694212667383808\/photo\/1",
        "indices" : [ 62, 84 ],
        "url" : "http:\/\/t.co\/nTwocwdfR1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BuScwTEIcAAXz_w.jpg",
        "id_str" : "496694212482854912",
        "id" : 496694212482854912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BuScwTEIcAAXz_w.jpg",
        "sizes" : [ {
          "h" : 457,
          "resize" : "fit",
          "w" : 472
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 329,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 472
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 472
        } ],
        "display_url" : "pic.twitter.com\/nTwocwdfR1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "496694212667383808",
    "text" : "WHEN BITCHES GO BACK FOR DICK THAT DON'T BENEFIT THEIR HEALTH http:\/\/t.co\/nTwocwdfR1",
    "id" : 496694212667383808,
    "created_at" : "2014-08-05 16:28:23 +0000",
    "user" : {
      "name" : "BLACK POWER",
      "screen_name" : "JUNGLEPUSSY",
      "protected" : false,
      "id_str" : "15819295",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540918599418777600\/chzyY26l_normal.jpeg",
      "id" : 15819295,
      "verified" : false
    }
  },
  "id" : 496706314949517312,
  "created_at" : "2014-08-05 17:16:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496706048724434946",
  "text" : "coming to ES7\npriceless &amp;&amp; &amp;butt\nwhere the following evals to priceless:\n( isNaN(priceless) &amp;butt priceless &gt; Infinity )",
  "id" : 496706048724434946,
  "created_at" : "2014-08-05 17:15:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496693010176819202",
  "text" : "gmail added attaching money to messages like it was bitcoin 2011\n\nbeing able to spam your contacts for a few dollars each : priceless",
  "id" : 496693010176819202,
  "created_at" : "2014-08-05 16:23:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496466254426025985",
  "text" : "Bingo desu.",
  "id" : 496466254426025985,
  "created_at" : "2014-08-05 01:22:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "496316875404361728",
  "text" : "Zed and the art of analog audio graphy",
  "id" : 496316875404361728,
  "created_at" : "2014-08-04 15:28:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ErykahBadoula",
      "screen_name" : "fatbellybella",
      "indices" : [ 1, 15 ],
      "id_str" : "18278629",
      "id" : 18278629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/eUaqsu2Xg1",
      "expanded_url" : "http:\/\/youtu.be\/qrslDdZskno",
      "display_url" : "youtu.be\/qrslDdZskno"
    } ]
  },
  "geo" : { },
  "id_str" : "496084584958660610",
  "text" : "\"@fatbellybella: Watch The Classiest, Most Gentlemanly Arrest Ever .. Take Notes  http:\/\/t.co\/eUaqsu2Xg1\"  \n\nnotested",
  "id" : 496084584958660610,
  "created_at" : "2014-08-04 00:05:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495978788212060161",
  "text" : "BEAR IDEATION",
  "id" : 495978788212060161,
  "created_at" : "2014-08-03 17:05:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "495093510534463488",
  "text" : "I jus bought my first new personal computer, a laptop.  It cost me two months rents.",
  "id" : 495093510534463488,
  "created_at" : "2014-08-01 06:27:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]