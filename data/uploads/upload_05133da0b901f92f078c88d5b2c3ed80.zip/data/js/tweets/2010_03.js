Grailbird.data.tweets_2010_03 = 
 [ {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Random Guy",
      "screen_name" : "ThatRandGuy",
      "indices" : [ 0, 12 ],
      "id_str" : "1638646304",
      "id" : 1638646304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "11389687158",
  "geo" : { },
  "id_str" : "11390437340",
  "in_reply_to_user_id" : 33033995,
  "text" : "@thatrandguy by this place for $25 a month! http:\/\/bit.ly\/9DxL4x",
  "id" : 11390437340,
  "in_reply_to_status_id" : 11389687158,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "in_reply_to_screen_name" : "randsevilla",
  "in_reply_to_user_id_str" : "33033995",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11391436580",
  "text" : "With only two months left in this office, I now pardon the mice I catch.",
  "id" : 11391436580,
  "created_at" : "2010-03-31 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FLAUNT ",
      "screen_name" : "FlauntMagazine",
      "indices" : [ 3, 18 ],
      "id_str" : "22534727",
      "id" : 22534727
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11260748475",
  "text" : "RT @FlauntMagazine: I don't want no damage so how my gonna manage you?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "11259315073",
    "text" : "I don't want no damage so how my gonna manage you?",
    "id" : 11259315073,
    "created_at" : "2010-03-29 17:04:13 +0000",
    "user" : {
      "name" : "FLAUNT ",
      "screen_name" : "FlauntMagazine",
      "protected" : false,
      "id_str" : "22534727",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/533414581373116416\/Ipzt--kr_normal.jpeg",
      "id" : 22534727,
      "verified" : false
    }
  },
  "id" : 11260748475,
  "created_at" : "2010-03-29 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11098438524",
  "text" : "http:\/\/bit.ly\/aykMv0",
  "id" : 11098438524,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11098526440",
  "text" : "http:\/\/bit.ly\/btpDro",
  "id" : 11098526440,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11099041408",
  "text" : "http:\/\/bit.ly\/bncF9b",
  "id" : 11099041408,
  "created_at" : "2010-03-26 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "11036406012",
  "text" : "yeah heah http:\/\/bit.ly\/a2VtN3",
  "id" : 11036406012,
  "created_at" : "2010-03-25 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "facebook",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "twitter",
      "indices" : [ 45, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10958441110",
  "text" : "#facebook is for talking about what yr doing #twitter is yr doing it. PLS RT",
  "id" : 10958441110,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10958620523",
  "text" : "yeeaaahhhh http:\/\/bit.ly\/aRsLki",
  "id" : 10958620523,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NATIONALHEADQUARTERS",
      "screen_name" : "natlhq",
      "indices" : [ 96, 103 ],
      "id_str" : "211771606",
      "id" : 211771606
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "education",
      "indices" : [ 12, 22 ]
    }, {
      "text" : "technology",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10999892202",
  "text" : "Here we go. #education and #technology &gt;&gt;&gt; http:\/\/bit.ly\/czqlSA This is a place to be. @natlhq",
  "id" : 10999892202,
  "created_at" : "2010-03-24 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10899687371",
  "text" : "RT @thatrandguy: Stress Ape and Mayor Daley at The Hideout tonight",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ping.fm\/\" rel=\"nofollow\"\u003EPing.fm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10895716946",
    "text" : "Stress Ape and Mayor Daley at The Hideout tonight",
    "id" : 10895716946,
    "created_at" : "2010-03-22 23:16:12 +0000",
    "user" : {
      "name" : "GONZO_CAPITALISM",
      "screen_name" : "randsevilla",
      "protected" : false,
      "id_str" : "33033995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000855313373\/050b30d5ff53a3f3e6df5b8b52f57e3b_normal.jpeg",
      "id" : 33033995,
      "verified" : false
    }
  },
  "id" : 10899687371,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Random Guy",
      "screen_name" : "ThatRandGuy",
      "indices" : [ 0, 12 ],
      "id_str" : "1638646304",
      "id" : 1638646304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "10895716946",
  "geo" : { },
  "id_str" : "10899831573",
  "in_reply_to_user_id" : 33033995,
  "text" : "@thatrandguy how long is u chilly dog?",
  "id" : 10899831573,
  "in_reply_to_status_id" : 10895716946,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "randsevilla",
  "in_reply_to_user_id_str" : "33033995",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10933118795",
  "text" : "so much good news",
  "id" : 10933118795,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10933121539",
  "text" : "seriously",
  "id" : 10933121539,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hcr",
      "indices" : [ 100, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10933162578",
  "text" : "you have to be reading a future into it, but there is lots of good news on the wires. i don't think #hcr will be much of a movement afterall",
  "id" : 10933162578,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10933172416",
  "text" : "also, put away yr parenthesis",
  "id" : 10933172416,
  "created_at" : "2010-03-23 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JSON",
      "indices" : [ 11, 16 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10876756488",
  "text" : "i like the #JSON logo http:\/\/bit.ly\/15dC8i",
  "id" : 10876756488,
  "created_at" : "2010-03-22 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10876856460",
  "text" : "http:\/\/bit.ly\/czzFDP",
  "id" : 10876856460,
  "created_at" : "2010-03-22 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10883124194",
  "text" : "http:\/\/bit.ly\/bG834S FROM http:\/\/bit.ly\/aq9ctw",
  "id" : 10883124194,
  "created_at" : "2010-03-22 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "people",
      "indices" : [ 69, 76 ]
    }, {
      "text" : "technology",
      "indices" : [ 82, 93 ]
    }, {
      "text" : "distribution",
      "indices" : [ 99, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10883222944",
  "text" : "Goood lookin out =&gt; Mostmodernist is re-organizing massively. New #people. New #technology. New #distribution. Details forthcoming!",
  "id" : 10883222944,
  "created_at" : "2010-03-22 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geotags",
      "indices" : [ 36, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10892794040",
  "text" : "Has anybody considered geospam yet? #geotags",
  "id" : 10892794040,
  "created_at" : "2010-03-22 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10784187254",
  "text" : "I like to click googles ads for itself, even when the link i was looking for came up first spot.",
  "id" : 10784187254,
  "created_at" : "2010-03-20 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pregame",
      "indices" : [ 18, 26 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10794709658",
  "text" : "groove on dis one #pregame a throw back leap forward mix Edan - Echo Party http:\/\/bit.ly\/ap54Q5",
  "id" : 10794709658,
  "created_at" : "2010-03-20 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 48, 56 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10680931039",
  "text" : "I've decided against applying to be an engineer @twitter for now. Sorry guys. Come at me tho, if you got something.",
  "id" : 10680931039,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NorthKorea",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10682737810",
  "text" : "RT @natlhq: On The Spot With Kim Jong-Il: http:\/\/bit.ly\/aQ9hGs #NorthKorea",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NorthKorea",
        "indices" : [ 51, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10681495846",
    "text" : "On The Spot With Kim Jong-Il: http:\/\/bit.ly\/aQ9hGs #NorthKorea",
    "id" : 10681495846,
    "created_at" : "2010-03-18 17:37:27 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 10682737810,
  "created_at" : "2010-03-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10594239549",
  "text" : "Ima bee a photogger http:\/\/twitgoo.com\/ksqk0",
  "id" : 10594239549,
  "created_at" : "2010-03-16 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bob Nasty",
      "screen_name" : "throbfastoff",
      "indices" : [ 3, 16 ],
      "id_str" : "15895270",
      "id" : 15895270
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10531221841",
  "text" : "RT @throbfastoff: Map of undersea internet cables. \nhttp:\/\/image.guardian.co.uk\/sys-images\/Technology\/Pix\/pictures\/2008\/02\/01\/SeaCableHi.jpg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10531053759",
    "text" : "Map of undersea internet cables. \nhttp:\/\/image.guardian.co.uk\/sys-images\/Technology\/Pix\/pictures\/2008\/02\/01\/SeaCableHi.jpg",
    "id" : 10531053759,
    "created_at" : "2010-03-15 19:18:19 +0000",
    "user" : {
      "name" : "Bob Nasty",
      "screen_name" : "throbfastoff",
      "protected" : false,
      "id_str" : "15895270",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2827304581\/20ae4b6384c460191d1aaca12d3f6a8a_normal.jpeg",
      "id" : 15895270,
      "verified" : false
    }
  },
  "id" : 10531221841,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10531248648",
  "text" : "FCC laying out wireless broadband mega-plan for better future americana tomorrow: http:\/\/bit.ly\/cpn97H",
  "id" : 10531248648,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "indices" : [ 3, 13 ],
      "id_str" : "15865878",
      "id" : 15865878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10531263168",
  "text" : "RT @NiemanLab: Conde Nast experiments with funding streams. Teen Vogue readers can pay for beauty consultation with magazine staffers ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10528158679",
    "text" : "Conde Nast experiments with funding streams. Teen Vogue readers can pay for beauty consultation with magazine staffers http:\/\/j.mp\/bXz3RT",
    "id" : 10528158679,
    "created_at" : "2010-03-15 18:00:27 +0000",
    "user" : {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "protected" : false,
      "id_str" : "15865878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512664555827126272\/pzZXwZC8_normal.jpeg",
      "id" : 15865878,
      "verified" : true
    }
  },
  "id" : 10531263168,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anywhere",
      "screen_name" : "anywhere",
      "indices" : [ 10, 19 ],
      "id_str" : "9576402",
      "id" : 9576402
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 46, 54 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10535499699",
  "text" : "when will @anywhere be open to any developer? @twitter",
  "id" : 10535499699,
  "created_at" : "2010-03-15 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10403415250",
  "text" : "Language is the 6th sense.",
  "id" : 10403415250,
  "created_at" : "2010-03-13 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RHYMEFEST",
      "screen_name" : "RHYMEFEST",
      "indices" : [ 3, 13 ],
      "id_str" : "18408457",
      "id" : 18408457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10345872679",
  "text" : "RT @RHYMEFEST: Dope interview with Sherron Shabazz of Examiner, the brother went deep: http:\/\/bit.ly\/9YcTlP",
  "id" : 10345872679,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10353938442",
  "text" : "Ironically, as market values have plunged back to earth, the Gomez family could easily afford to own the duplex at today's appraised value.",
  "id" : 10353938442,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10353943220",
  "text" : "http:\/\/bit.ly\/c5a2lc",
  "id" : 10353943220,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10359073446",
  "text" : "movie film metavideo  http:\/\/bit.ly\/cfWt3L",
  "id" : 10359073446,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10387178261",
  "text" : "good pre -overage of Pacquiao \/ Clottey fight tomorrow  http:\/\/bit.ly\/9yHfzi",
  "id" : 10387178261,
  "created_at" : "2010-03-12 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Random Guy",
      "screen_name" : "ThatRandGuy",
      "indices" : [ 0, 12 ],
      "id_str" : "1638646304",
      "id" : 1638646304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "7528321346",
  "geo" : { },
  "id_str" : "10341960128",
  "in_reply_to_user_id" : 33033995,
  "text" : "@thatrandguy copyrighted images of businessmen shoveling http:\/\/bit.ly\/dbk2zl",
  "id" : 10341960128,
  "in_reply_to_status_id" : 7528321346,
  "created_at" : "2010-03-11 00:00:00 +0000",
  "in_reply_to_screen_name" : "randsevilla",
  "in_reply_to_user_id_str" : "33033995",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "twitter",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10130966371",
  "text" : "facial recognition meets #twitter http:\/\/bit.ly\/cfQzSO",
  "id" : 10130966371,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10135273704",
  "text" : "RT @thatrandguy: Nyc\/8mymoney\/ontheB43\/igottaleave",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10130161814",
    "text" : "Nyc\/8mymoney\/ontheB43\/igottaleave",
    "id" : 10130161814,
    "created_at" : "2010-03-07 18:21:04 +0000",
    "user" : {
      "name" : "GONZO_CAPITALISM",
      "screen_name" : "randsevilla",
      "protected" : false,
      "id_str" : "33033995",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000855313373\/050b30d5ff53a3f3e6df5b8b52f57e3b_normal.jpeg",
      "id" : 33033995,
      "verified" : false
    }
  },
  "id" : 10135273704,
  "created_at" : "2010-03-07 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DANCESTADAMUS",
      "screen_name" : "dances",
      "indices" : [ 3, 10 ],
      "id_str" : "15757699",
      "id" : 15757699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10038515494",
  "text" : "RT @dances: is anybody driving from philly to newyork this evening. OR AM I GETTING ON THE CHINATOWN @COSMOBAKE I FEEL UR PAIN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10038439432",
    "text" : "is anybody driving from philly to newyork this evening. OR AM I GETTING ON THE CHINATOWN @COSMOBAKE I FEEL UR PAIN",
    "id" : 10038439432,
    "created_at" : "2010-03-05 19:30:48 +0000",
    "user" : {
      "name" : "DANCESTADAMUS",
      "screen_name" : "dances",
      "protected" : false,
      "id_str" : "15757699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3448705225\/af403568784939234b79f14230dfd679_normal.jpeg",
      "id" : 15757699,
      "verified" : false
    }
  },
  "id" : 10038515494,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DANCESTADAMUS",
      "screen_name" : "dances",
      "indices" : [ 29, 36 ],
      "id_str" : "15757699",
      "id" : 15757699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10038544509",
  "text" : "Take the chinatown and relax @dances",
  "id" : 10038544509,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10042335695",
  "text" : "Puerto Rico Launching Smart Grid (Electricity) BROADBAND INTERNET http:\/\/bit.ly\/9f0DZu why not all US? Communication could be a freedom!",
  "id" : 10042335695,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10042396334",
  "text" : "That means internet through your plug holes!",
  "id" : 10042396334,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DANCESTADAMUS",
      "screen_name" : "dances",
      "indices" : [ 3, 10 ],
      "id_str" : "15757699",
      "id" : 15757699
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10042467657",
  "text" : "RT @dances: OH WHOA IS ME ITS A STARBUCKS THEY ARE TAKING MY CULTURE. 10 years from now youll be buying a vivian girls starbucks only cd ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "10039357727",
    "text" : "OH WHOA IS ME ITS A STARBUCKS THEY ARE TAKING MY CULTURE. 10 years from now youll be buying a vivian girls starbucks only cd u yuppie",
    "id" : 10039357727,
    "created_at" : "2010-03-05 19:55:30 +0000",
    "user" : {
      "name" : "DANCESTADAMUS",
      "screen_name" : "dances",
      "protected" : false,
      "id_str" : "15757699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3448705225\/af403568784939234b79f14230dfd679_normal.jpeg",
      "id" : 15757699,
      "verified" : false
    }
  },
  "id" : 10042467657,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "10043607356",
  "text" : "Give Us Yr Pig Fat, Keep Yr Diplomatics, says Vladimir Putin http:\/\/bit.ly\/daDfC4",
  "id" : 10043607356,
  "created_at" : "2010-03-05 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "future",
      "indices" : [ 59, 66 ]
    }, {
      "text" : "tech",
      "indices" : [ 67, 72 ]
    }, {
      "text" : "economics",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9936328091",
  "text" : "Anything you can do, I can pay somebody else to do better. #future #tech #economics",
  "id" : 9936328091,
  "created_at" : "2010-03-03 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "marketing",
      "indices" : [ 4, 14 ]
    }, {
      "text" : "tweetdeck",
      "indices" : [ 19, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9936725022",
  "text" : "add #marketing and #tweetdeck to that last one please then you hit re-tweet",
  "id" : 9936725022,
  "created_at" : "2010-03-03 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9858350050",
  "text" : "Try to ask yourself a question about yourself--something you know the answer to. Result: It's a hard task to ask an easy question.",
  "id" : 9858350050,
  "created_at" : "2010-03-02 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9858367664",
  "text" : "twitter me this",
  "id" : 9858367664,
  "created_at" : "2010-03-02 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "indices" : [ 0, 10 ],
      "id_str" : "15865878",
      "id" : 15865878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "9877544771",
  "geo" : { },
  "id_str" : "9878875268",
  "in_reply_to_user_id" : 15865878,
  "text" : "@NiemanLab yr second to last link''s dead dog",
  "id" : 9878875268,
  "in_reply_to_status_id" : 9877544771,
  "created_at" : "2010-03-02 00:00:00 +0000",
  "in_reply_to_screen_name" : "NiemanLab",
  "in_reply_to_user_id_str" : "15865878",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NASA",
      "screen_name" : "NASA",
      "indices" : [ 3, 8 ],
      "id_str" : "11348282",
      "id" : 11348282
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "9878970340",
  "text" : "RT @NASA: Our scientists have been crunching the numbers and it seems the Chilean quake may have shortened the length of a day -- http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "9876977179",
    "text" : "Our scientists have been crunching the numbers and it seems the Chilean quake may have shortened the length of a day -- http:\/\/bit.ly\/cum7oe",
    "id" : 9876977179,
    "created_at" : "2010-03-02 14:45:53 +0000",
    "user" : {
      "name" : "NASA",
      "screen_name" : "NASA",
      "protected" : false,
      "id_str" : "11348282",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/188302352\/nasalogo_twitter_normal.jpg",
      "id" : 11348282,
      "verified" : true
    }
  },
  "id" : 9878970340,
  "created_at" : "2010-03-02 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]