Grailbird.data.tweets_2009_07 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2921264129",
  "text" : "is using mobile twitter instead of regular ON A REGULAR COMPUTER",
  "id" : 2921264129,
  "created_at" : "2009-07-30 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2922295809",
  "text" : "Sign Balls, not Bills http:\/\/bit.ly\/jNroL",
  "id" : 2922295809,
  "created_at" : "2009-07-30 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2901298730",
  "text" : "Case of the \"maliciously and wrongfully published false and defamatory Tweet\" http:\/\/mostmodernist.com\/chicago\/",
  "id" : 2901298730,
  "created_at" : "2009-07-29 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2892792537",
  "text" : "SKINEMAX is coming... http:\/\/bit.ly\/13FiIt",
  "id" : 2892792537,
  "created_at" : "2009-07-28 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NATIONALHEADQUARTERS",
      "screen_name" : "natlhq",
      "indices" : [ 11, 18 ],
      "id_str" : "211771606",
      "id" : 211771606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2898346033",
  "text" : "*whistles* @natlhq",
  "id" : 2898346033,
  "created_at" : "2009-07-28 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2874218652",
  "text" : "Chicago Thriller Zombie Walk Photos and Ongoing Celebration http:\/\/bit.ly\/2z0Yw1",
  "id" : 2874218652,
  "created_at" : "2009-07-27 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2856976445",
  "text" : "is an adjective right now but one day'll be a tight noun",
  "id" : 2856976445,
  "created_at" : "2009-07-26 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2858055144",
  "text" : "Obama in a Plauditorium: Obama Video - Health Care Reform Town Hall, Cleveland OH July 23, 2009 http:\/\/bit.ly\/aU0o8",
  "id" : 2858055144,
  "created_at" : "2009-07-26 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2829324649",
  "text" : "[video] The First Lady Speaks At the 10th Annual Design Awards http:\/\/bit.ly\/4Rz7C",
  "id" : 2829324649,
  "created_at" : "2009-07-25 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2838942616",
  "text" : "Weekend Multimedia Essay: Obama on Education - \"Race to the Top\" - education reform with Ed. Sec. Arne Duncan http:\/\/bit.ly\/SGT9f",
  "id" : 2838942616,
  "created_at" : "2009-07-25 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2839201131",
  "text" : "RT @mostmodernist President Obama's Weekly Address: Health Insurance Reform, Small Business and Your Questions http:\/\/bit.ly\/6v2Uu",
  "id" : 2839201131,
  "created_at" : "2009-07-25 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2822868180",
  "text" : "ooga booga Chinese Scientists Make Live Mouse From Skin Stem Cells http:\/\/bit.ly\/YaZUa",
  "id" : 2822868180,
  "created_at" : "2009-07-24 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2822891204",
  "text" : "Get yr Michael Jackson On with limited edition buttons from http:\/\/bit.ly\/kkkGQ",
  "id" : 2822891204,
  "created_at" : "2009-07-24 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2792385287",
  "text" : "RT @mostmodernist Handmade Animals http:\/\/bit.ly\/OIWTP",
  "id" : 2792385287,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stones Throw",
      "screen_name" : "stonesthrow",
      "indices" : [ 0, 12 ],
      "id_str" : "7495882",
      "id" : 7495882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2803393258",
  "in_reply_to_user_id" : 7495882,
  "text" : "@stonesthrow whats shakin' stones throw!",
  "id" : 2803393258,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "in_reply_to_screen_name" : "stonesthrow",
  "in_reply_to_user_id_str" : "7495882",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2804358311",
  "text" : "RT @mostmodernist Avante-Web: BooneOakley.com Uses YouTube Video As Website http:\/\/bit.ly\/20yF2y",
  "id" : 2804358311,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mostmodernist",
      "indices" : [ 0, 14 ]
    }, {
      "text" : "Obama",
      "indices" : [ 15, 21 ]
    }, {
      "text" : "Chicago",
      "indices" : [ 25, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2805007958",
  "text" : "#mostmodernist #Obama In #Chicago TODAY JULY 23 http:\/\/bit.ly\/3DnNv",
  "id" : 2805007958,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2807622549",
  "text" : "was cut-off by President Obama's motorcade 12 minutes ago on the highway WELCOME HOME OBAMA",
  "id" : 2807622549,
  "created_at" : "2009-07-23 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NATIONALHEADQUARTERS",
      "screen_name" : "natlhq",
      "indices" : [ 0, 7 ],
      "id_str" : "211771606",
      "id" : 211771606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2780924968",
  "in_reply_to_user_id" : 58809542,
  "text" : "@natlhq hellooooo baby",
  "id" : 2780924968,
  "created_at" : "2009-07-22 00:00:00 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2781225790",
  "text" : "RT @mostmodernist Apple's FoxConn's Security Division Raids Employees House http:\/\/bit.ly\/6W1r6",
  "id" : 2781225790,
  "created_at" : "2009-07-22 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2781853377",
  "text" : "RT @mostmodernist Obama In Chicago JULY 23 http:\/\/bit.ly\/3DnNv",
  "id" : 2781853377,
  "created_at" : "2009-07-22 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2785141353",
  "text" : "is",
  "id" : 2785141353,
  "created_at" : "2009-07-22 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2764466067",
  "text" : "chug muck slubber glab me",
  "id" : 2764466067,
  "created_at" : "2009-07-21 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2737202836",
  "text" : "Discovers web5.0 in amazing new social web platform Netvibes read @ http:\/\/tinyurl.com\/ll7uax",
  "id" : 2737202836,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2742636586",
  "text" : "ooga oog jug bobo",
  "id" : 2742636586,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2742677209",
  "text" : "NETVIBES: THE FUTURE OF THE INTERNET &gt; http:\/\/tinyurl.com\/lm4frx",
  "id" : 2742677209,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2743274941",
  "text" : "RT @mostmodernist Listen : Bolivia, NeoCon Global Policy, The IMF http:\/\/bit.ly\/alByC",
  "id" : 2743274941,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2743716009",
  "text" : "RT @mostmodernist David Lynch Has Thoughts About Your iPhone http:\/\/ow.ly\/2bm0Xy",
  "id" : 2743716009,
  "created_at" : "2009-07-20 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2710299505",
  "text" : "RT @mostmodernist President Obama - Weekly Address on Health Reform http:\/\/tinyurl.com\/neoqu4",
  "id" : 2710299505,
  "created_at" : "2009-07-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2690645211",
  "text" : "UPDATES: Michael Jackson Memorial Portrait Contest + Thriller Zombie Walk at: http:\/\/imamissmichaeljackson.com",
  "id" : 2690645211,
  "created_at" : "2009-07-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2660517318",
  "in_reply_to_user_id" : 46961216,
  "text" : "@mostmodernist attn: CHICAGO &lt;&lt;&gt;&gt; BITCHPORK is COMING http:\/\/bit.ly\/8DkTu",
  "id" : 2660517318,
  "created_at" : "2009-07-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "johnnyscript",
  "in_reply_to_user_id_str" : "46961216",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2678013315",
  "text" : "ENHANCED VISUALS by NAT'L HQ on Vimeo: http:\/\/digg.com\/u18dDY",
  "id" : 2678013315,
  "created_at" : "2009-07-16 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2654441538",
  "text" : "RT @mostmodernist President Obama At Ease With Bob Costas Before MLB All-Star Game http:\/\/u.mavrev.com\/o4do",
  "id" : 2654441538,
  "created_at" : "2009-07-15 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2634091980",
  "text" : "RT @mostmodernist Day 2 Demagoue Watch: Sotomayor Hearings Via Live Internet Video Stream http:\/\/tinyurl.com\/l6cuft",
  "id" : 2634091980,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2635686497",
  "text" : "RT @mostmodernist re: Goldman Sachs Posts $3.44 Billions of Dollars Second-Quarter Profit http:\/\/bit.ly\/pp4Xz",
  "id" : 2635686497,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2641204742",
  "text" : "RT @mostmodernist President Obama Lookin' Good @ Speech to Ghana [video] HISTORIC \nhttp:\/\/twurl.nl\/cbmdr7",
  "id" : 2641204742,
  "created_at" : "2009-07-14 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2615245245",
  "text" : "RT @mostmodernist Demagoue Watch: Sotomayor Hearings Live Internet Video Stream http:\/\/tinyurl.com\/l6cuft",
  "id" : 2615245245,
  "created_at" : "2009-07-13 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2601896247",
  "text" : "Weekend Reading: On About Obama - President Obama's weekly adress, trip to Ghana & visit to the Pope http:\/\/tinyurl.com\/m77cyx",
  "id" : 2601896247,
  "created_at" : "2009-07-12 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2603377998",
  "text" : "President Obama's Speech to Ghana \"A new Moment of Hope\" http:\/\/tinyurl.com\/nfmw5g",
  "id" : 2603377998,
  "created_at" : "2009-07-12 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2588722303",
  "text" : "Weekend Reading: On About Obama - A  multimedia essay on President Obama's week abroad & weekly address http:\/\/tinyurl.com\/ljamkl",
  "id" : 2588722303,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2588965313",
  "text" : "New Auto-Tune The News Hits Youtube!! Just Released! Awesome! http:\/\/tinyurl.com\/ksewkv",
  "id" : 2588965313,
  "created_at" : "2009-07-11 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2570145825",
  "text" : "Fred Astaire & Cyd Charisse in Michale Jackson's Smooth Criminal [video] http:\/\/tinyurl.com\/nl9yz9",
  "id" : 2570145825,
  "created_at" : "2009-07-10 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2570155796",
  "text" : "Fred Astaire and Cyd Charisse in Michael Jackson's Smooth Criminal [video] http:\/\/tinyurl.com\/nl9yz9",
  "id" : 2570155796,
  "created_at" : "2009-07-10 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2554479410",
  "text" : "Michael Jackson tribute website: http:\/\/imamissmichaeljackson.com",
  "id" : 2554479410,
  "created_at" : "2009-07-09 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2554659998",
  "text" : "RT @mostmodernist White House Offering $2,500 for Best H1N1 Flu Virus PSA Video http:\/\/is.gd\/1sw5P",
  "id" : 2554659998,
  "created_at" : "2009-07-09 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2536442614",
  "text" : "RT @mostmodernist Oprahs's Harpo Studios Forces Take-Down of User Submitted Michael Jackson Videos http:\/\/tinyurl.com\/mzs92z",
  "id" : 2536442614,
  "created_at" : "2009-07-08 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2536637547",
  "text" : "Bury Mr. Jackson in Gary, Indiana http:\/\/bit.ly\/10HZ3M",
  "id" : 2536637547,
  "created_at" : "2009-07-08 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2536879756",
  "text" : "Michael Jackson: Bury Mr. Jackson in Gary, Indiana http:\/\/bit.ly\/10HZ3M",
  "id" : 2536879756,
  "created_at" : "2009-07-08 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2522215513",
  "text" : "RT @mostmodernist President Obama's Address to the New Economic School in Moscow [video + text] http:\/\/bit.ly\/upRvR",
  "id" : 2522215513,
  "created_at" : "2009-07-07 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2501777870",
  "text" : "RT @mostmodernist President Obama Commemorating 4th of July White House BBQ [video] http:\/\/cli.gs\/N8e1S",
  "id" : 2501777870,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2502910694",
  "text" : "RT @mostmodernist SUPREME COURT: Senator Sessions (Old. R. Alabama) quetsions Sotomayor's \"prior history\" of Advocacy... http:\/\/cli.gs\/430tY",
  "id" : 2502910694,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2502921090",
  "text" : "RT @mostmodernist \"Obstructionist Republican Clown\" College - click to attend http:\/\/cli.gs\/ZRpEp",
  "id" : 2502921090,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2500318736",
  "text" : "RT @mostmodernist INCREDIBLE 3D JIM HENSON TRIBUTE http:\/\/tinyurl.com\/krsn2q",
  "id" : 2500318736,
  "created_at" : "2009-07-06 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2471095659",
  "text" : "RT @mostmodernist Independence Day USA - youtube music video playlist http:\/\/tinyurl.com\/l7couw",
  "id" : 2471095659,
  "created_at" : "2009-07-04 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2472025034",
  "text" : "RT @mostmodernist President Obama's Independence Day Address, July 4th 2009 http:\/\/tinyurl.com\/ly8vyw",
  "id" : 2472025034,
  "created_at" : "2009-07-04 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2456492393",
  "text" : "RT @mostmodernist RUN, BLAGO, RUN! show opens July 24 http:\/\/bit.ly\/1eGTCf",
  "id" : 2456492393,
  "created_at" : "2009-07-03 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2458991239",
  "text" : "More guvnah? Sarah Palin to Resign http:\/\/www.cbsnews.com\/stories\/2009\/07\/03\/politics\/main5131961.shtml",
  "id" : 2458991239,
  "created_at" : "2009-07-03 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "2428310086",
  "text" : "RT @mostmodernist \"TerraStar\" Launches ISP Space Satelite From S. America; \"SkyTerra\" Not Far Behind http:\/\/bit.ly\/GcDwf",
  "id" : 2428310086,
  "created_at" : "2009-07-01 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]