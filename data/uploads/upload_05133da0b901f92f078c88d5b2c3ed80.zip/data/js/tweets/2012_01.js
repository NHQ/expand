Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jaan Orvet",
      "screen_name" : "orvet",
      "indices" : [ 0, 6 ],
      "id_str" : "1812341",
      "id" : 1812341
    }, {
      "name" : "Andreas Carlsson",
      "screen_name" : "nofont",
      "indices" : [ 7, 14 ],
      "id_str" : "15721460",
      "id" : 15721460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/AcyRH9t4",
      "expanded_url" : "http:\/\/opentypography.org",
      "display_url" : "opentypography.org"
    } ]
  },
  "geo" : { },
  "id_str" : "164393170560483328",
  "in_reply_to_user_id" : 1812341,
  "text" : "@ORVET @NOFONT I don't see any links to a typesetter.js repo in the smashing mag article or at http:\/\/t.co\/AcyRH9t4",
  "id" : 164393170560483328,
  "created_at" : "2012-01-31 17:02:40 +0000",
  "in_reply_to_screen_name" : "orvet",
  "in_reply_to_user_id_str" : "1812341",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mediagazer",
      "screen_name" : "mediagazer",
      "indices" : [ 3, 14 ],
      "id_str" : "75357513",
      "id" : 75357513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/z5jPUwYV",
      "expanded_url" : "http:\/\/www.cjr.org\/behind_the_news\/local_tv_stations_rally_to_opp_1.php?page=all",
      "display_url" : "cjr.org\/behind_the_new\u2026"
    }, {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/NSTKykmI",
      "expanded_url" : "http:\/\/mediagazer.com\/120130\/p1#a120130p1",
      "display_url" : "mediagazer.com\/120130\/p1#a120\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163898347978113025",
  "text" : "RT @mediagazer: Local TV Stations Rally to Oppose Media Transparency (Steven Waldman \/ CJR) http:\/\/t.co\/z5jPUwYV http:\/\/t.co\/NSTKykmI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mediagazer.com\/\" rel=\"nofollow\"\u003EMediagazer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/z5jPUwYV",
        "expanded_url" : "http:\/\/www.cjr.org\/behind_the_news\/local_tv_stations_rally_to_opp_1.php?page=all",
        "display_url" : "cjr.org\/behind_the_new\u2026"
      }, {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/NSTKykmI",
        "expanded_url" : "http:\/\/mediagazer.com\/120130\/p1#a120130p1",
        "display_url" : "mediagazer.com\/120130\/p1#a120\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "163870487410245633",
    "text" : "Local TV Stations Rally to Oppose Media Transparency (Steven Waldman \/ CJR) http:\/\/t.co\/z5jPUwYV http:\/\/t.co\/NSTKykmI",
    "id" : 163870487410245633,
    "created_at" : "2012-01-30 06:25:43 +0000",
    "user" : {
      "name" : "Mediagazer",
      "screen_name" : "mediagazer",
      "protected" : false,
      "id_str" : "75357513",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740681844\/mediaGazer_twitter2white_normal.png",
      "id" : 75357513,
      "verified" : false
    }
  },
  "id" : 163898347978113025,
  "created_at" : "2012-01-30 08:16:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162362444776341504",
  "text" : "My Fellow Young Tech Warriors, please don't claim to be revolutionary. Where does one revolution leave you? Where do a billion?",
  "id" : 162362444776341504,
  "created_at" : "2012-01-26 02:33:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nodejs",
      "indices" : [ 0, 7 ]
    }, {
      "text" : "NodeSummit",
      "indices" : [ 126, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162361548512313347",
  "text" : "#Nodejs Devs deserve better than real-time reality tv conditions. Also, hit me up if u want 2 produce real-time reality show. #NodeSummit",
  "id" : 162361548512313347,
  "created_at" : "2012-01-26 02:29:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NodeSummit",
      "indices" : [ 45, 56 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162359888360648704",
  "text" : "I will say this: every presenting company at #NodeSummit looked good and has mega talents. #nodejs",
  "id" : 162359888360648704,
  "created_at" : "2012-01-26 02:23:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rok Krulec",
      "screen_name" : "tantadruj",
      "indices" : [ 94, 104 ],
      "id_str" : "1535274073",
      "id" : 1535274073
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NodeSummit",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162357759554228226",
  "text" : "#NodeSummit quote of the day: \"They shouldn't let the moneypeople speak about the future.\" -- @tantadruj",
  "id" : 162357759554228226,
  "created_at" : "2012-01-26 02:14:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NodeSummit",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162355222218412033",
  "text" : "#NodeSummit was kinda lite beer",
  "id" : 162355222218412033,
  "created_at" : "2012-01-26 02:04:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rok Krulec",
      "screen_name" : "tantadruj",
      "indices" : [ 0, 10 ],
      "id_str" : "1535274073",
      "id" : 1535274073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162276251258724352",
  "geo" : { },
  "id_str" : "162280092607844352",
  "in_reply_to_user_id" : 15839432,
  "text" : "@tantadruj what is your location?",
  "id" : 162280092607844352,
  "in_reply_to_status_id" : 162276251258724352,
  "created_at" : "2012-01-25 21:06:03 +0000",
  "in_reply_to_screen_name" : "rokk",
  "in_reply_to_user_id_str" : "15839432",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rok Krulec",
      "screen_name" : "tantadruj",
      "indices" : [ 0, 10 ],
      "id_str" : "1535274073",
      "id" : 1535274073
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162270554064293888",
  "geo" : { },
  "id_str" : "162272728508923904",
  "in_reply_to_user_id" : 15839432,
  "text" : "@tantadruj are you at the conference?",
  "id" : 162272728508923904,
  "in_reply_to_status_id" : 162270554064293888,
  "created_at" : "2012-01-25 20:36:48 +0000",
  "in_reply_to_screen_name" : "rokk",
  "in_reply_to_user_id_str" : "15839432",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noclue",
      "indices" : [ 74, 81 ]
    }, {
      "text" : "nodesummit",
      "indices" : [ 82, 93 ]
    }, {
      "text" : "nonodejs",
      "indices" : [ 94, 103 ]
    }, {
      "text" : "lunch",
      "indices" : [ 104, 110 ]
    }, {
      "text" : "fakefood",
      "indices" : [ 111, 120 ]
    }, {
      "text" : "geeks",
      "indices" : [ 121, 127 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162272005134102529",
  "text" : "RT @tantadruj: They shouldn't let the moneypeople speak about the future. #noclue #nodesummit #nonodejs #lunch #fakefood #geeks and then ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "noclue",
        "indices" : [ 59, 66 ]
      }, {
        "text" : "nodesummit",
        "indices" : [ 67, 78 ]
      }, {
        "text" : "nonodejs",
        "indices" : [ 79, 88 ]
      }, {
        "text" : "lunch",
        "indices" : [ 89, 95 ]
      }, {
        "text" : "fakefood",
        "indices" : [ 96, 105 ]
      }, {
        "text" : "geeks",
        "indices" : [ 106, 112 ]
      }, {
        "text" : "nodejs",
        "indices" : [ 127, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.7680076606, -122.3925753067 ]
    },
    "id_str" : "162270554064293888",
    "text" : "They shouldn't let the moneypeople speak about the future. #noclue #nodesummit #nonodejs #lunch #fakefood #geeks and then some #nodejs",
    "id" : 162270554064293888,
    "created_at" : "2012-01-25 20:28:09 +0000",
    "user" : {
      "name" : "Rok Krulec",
      "screen_name" : "rokk",
      "protected" : false,
      "id_str" : "15839432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512282938495356928\/piDhB5-c_normal.jpeg",
      "id" : 15839432,
      "verified" : false
    }
  },
  "id" : 162272005134102529,
  "created_at" : "2012-01-25 20:33:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodesummit",
      "indices" : [ 26, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162269900759515136",
  "text" : "the answer is content duh #nodesummit",
  "id" : 162269900759515136,
  "created_at" : "2012-01-25 20:25:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodesummit",
      "indices" : [ 18, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162250569484992512",
  "text" : "where do i get my #nodesummit t-shirt?",
  "id" : 162250569484992512,
  "created_at" : "2012-01-25 19:08:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "content",
      "indices" : [ 45, 53 ]
    }, {
      "text" : "nodesummit",
      "indices" : [ 54, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162249984710950912",
  "text" : "don't vote for omegawd. long live Hollywood. #content #nodesummit",
  "id" : 162249984710950912,
  "created_at" : "2012-01-25 19:06:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speaker John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 0, 15 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162046051220590592",
  "in_reply_to_user_id" : 7713202,
  "text" : "@speakerboehner is demagogueing on twitter with \"facts\". Shame this man.",
  "id" : 162046051220590592,
  "created_at" : "2012-01-25 05:36:03 +0000",
  "in_reply_to_screen_name" : "SpeakerBoehner",
  "in_reply_to_user_id_str" : "7713202",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NodeSummit",
      "indices" : [ 54, 65 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162025882632978432",
  "text" : "Windows Azure looks pretty good! Do they have Ubuntu? #NodeSummit #nodejs",
  "id" : 162025882632978432,
  "created_at" : "2012-01-25 04:15:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 49, 63 ],
      "id_str" : "29255412",
      "id" : 29255412
    }, {
      "name" : "Node Summit",
      "screen_name" : "NodeSummit",
      "indices" : [ 76, 87 ],
      "id_str" : "293718395",
      "id" : 293718395
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "FYEAH",
      "indices" : [ 96, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160971009686638592",
  "text" : "I chose right my first Node.js conf to attend if @tjholowaychuk is going to @NodeSummit #nodejs #FYEAH",
  "id" : 160971009686638592,
  "created_at" : "2012-01-22 06:24:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160899208612806656",
  "geo" : { },
  "id_str" : "160925757370138624",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk Get well soon! Also try fasting.",
  "id" : 160925757370138624,
  "in_reply_to_status_id" : 160899208612806656,
  "created_at" : "2012-01-22 03:24:25 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/7rq5jjOy",
      "expanded_url" : "http:\/\/jeffdechambeau.com\/friending-fast-and-slow.html",
      "display_url" : "jeffdechambeau.com\/friending-fast\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159766588181069824",
  "text" : "I'm sure yr busy but http:\/\/t.co\/7rq5jjOy",
  "id" : 159766588181069824,
  "created_at" : "2012-01-18 22:38:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ja\u0361s\u035Co\u0361n \u2022\u035C\u2022",
      "screen_name" : "XaiaX",
      "indices" : [ 0, 6 ],
      "id_str" : "16076115",
      "id" : 16076115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159761729356709888",
  "geo" : { },
  "id_str" : "159762799864721408",
  "in_reply_to_user_id" : 16076115,
  "text" : "@XaiaX dude they're already in the sheets with viacom, disney et al.",
  "id" : 159762799864721408,
  "in_reply_to_status_id" : 159761729356709888,
  "created_at" : "2012-01-18 22:23:14 +0000",
  "in_reply_to_screen_name" : "XaiaX",
  "in_reply_to_user_id_str" : "16076115",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOPA",
      "indices" : [ 70, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159761799296724992",
  "text" : "Every time you reach for wikipedia like a phantom itch, retweet this. #SOPA",
  "id" : 159761799296724992,
  "created_at" : "2012-01-18 22:19:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159723261763133440",
  "text" : "I've said it before and I'll say it some more: it's Kraftwerk time.",
  "id" : 159723261763133440,
  "created_at" : "2012-01-18 19:46:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "memeorandum",
      "screen_name" : "memeorandum",
      "indices" : [ 115, 127 ],
      "id_str" : "817652",
      "id" : 817652
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/lhUgdK5F",
      "expanded_url" : "http:\/\/www.chron.com\/business\/energy\/article\/N-American-oil-output-could-top-40-year-old-peak-2193837.php",
      "display_url" : "chron.com\/business\/energ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159703450924490753",
  "text" : "N. American Oil Production projecting record output. Oil Companies sitting on $60 Billions ++ http:\/\/t.co\/lhUgdK5F @memeorandum",
  "id" : 159703450924490753,
  "created_at" : "2012-01-18 18:27:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Roberts",
      "screen_name" : "drgrist",
      "indices" : [ 3, 11 ],
      "id_str" : "22737278",
      "id" : 22737278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159699868884013056",
  "text" : "RT @drgrist: A party that claims an oil pipeline as the heart of its jobs program has entered the realm of self-parody.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159698102050242562",
    "text" : "A party that claims an oil pipeline as the heart of its jobs program has entered the realm of self-parody.",
    "id" : 159698102050242562,
    "created_at" : "2012-01-18 18:06:09 +0000",
    "user" : {
      "name" : "David Roberts",
      "screen_name" : "drgrist",
      "protected" : false,
      "id_str" : "22737278",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539861645653065728\/5C0TbLd5_normal.jpeg",
      "id" : 22737278,
      "verified" : false
    }
  },
  "id" : 159699868884013056,
  "created_at" : "2012-01-18 18:13:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andy Carvin",
      "screen_name" : "acarvin",
      "indices" : [ 3, 11 ],
      "id_str" : "778057",
      "id" : 778057
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sopajokes",
      "indices" : [ 113, 123 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159681329389248512",
  "text" : "RT @acarvin: What's the difference between a \u2588\u2588\u2588 and a \u2588\u2588\u2588\u2588? A \u2588\u2588\u2588 has nine \u2588\u2588\u2588\u2588, but a \u2588\u2588\u2588\u2588 croaks every night! #sopajokes",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sopajokes",
        "indices" : [ 100, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159670036343177218",
    "text" : "What's the difference between a \u2588\u2588\u2588 and a \u2588\u2588\u2588\u2588? A \u2588\u2588\u2588 has nine \u2588\u2588\u2588\u2588, but a \u2588\u2588\u2588\u2588 croaks every night! #sopajokes",
    "id" : 159670036343177218,
    "created_at" : "2012-01-18 16:14:37 +0000",
    "user" : {
      "name" : "Andy Carvin",
      "screen_name" : "acarvin",
      "protected" : false,
      "id_str" : "778057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528555203360878592\/RtBzJElP_normal.png",
      "id" : 778057,
      "verified" : true
    }
  },
  "id" : 159681329389248512,
  "created_at" : "2012-01-18 16:59:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "indices" : [ 0, 13 ],
      "id_str" : "15442036",
      "id" : 15442036
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOPA",
      "indices" : [ 90, 95 ]
    }, {
      "text" : "California",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/oLvT7E80",
      "expanded_url" : "http:\/\/projects.propublica.org\/sopa\/B000711",
      "display_url" : "projects.propublica.org\/sopa\/B000711"
    } ]
  },
  "geo" : { },
  "id_str" : "159679547212701696",
  "in_reply_to_user_id" : 15442036,
  "text" : "@SenatorBoxer takes it large from the tech and the tv\/movie industries, and supports SOPA #SOPA #California http:\/\/t.co\/oLvT7E80",
  "id" : 159679547212701696,
  "created_at" : "2012-01-18 16:52:25 +0000",
  "in_reply_to_screen_name" : "SenatorBoxer",
  "in_reply_to_user_id_str" : "15442036",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mpaa",
      "indices" : [ 66, 71 ]
    }, {
      "text" : "SOPA",
      "indices" : [ 72, 77 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/HX5JeNVW",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/30835791@N07\/sets\/72157614241935013\/",
      "display_url" : "flickr.com\/photos\/3083579\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159678355850006528",
  "text" : "time to revisit the republican clown college http:\/\/t.co\/HX5JeNVW #mpaa #SOPA",
  "id" : 159678355850006528,
  "created_at" : "2012-01-18 16:47:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sen. Barbara Boxer",
      "screen_name" : "SenatorBoxer",
      "indices" : [ 0, 13 ],
      "id_str" : "15442036",
      "id" : 15442036
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159677948377563137",
  "in_reply_to_user_id" : 15442036,
  "text" : "@SenatorBoxer hey you better get to opposing SOPA lady, you're nobody special",
  "id" : 159677948377563137,
  "created_at" : "2012-01-18 16:46:04 +0000",
  "in_reply_to_screen_name" : "SenatorBoxer",
  "in_reply_to_user_id_str" : "15442036",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Speaker John Boehner",
      "screen_name" : "SpeakerBoehner",
      "indices" : [ 0, 15 ],
      "id_str" : "7713202",
      "id" : 7713202
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159674794948829184",
  "geo" : { },
  "id_str" : "159675923795427328",
  "in_reply_to_user_id" : 7713202,
  "text" : "@SpeakerBoehner, sir, you are a pampered clown",
  "id" : 159675923795427328,
  "in_reply_to_status_id" : 159674794948829184,
  "created_at" : "2012-01-18 16:38:01 +0000",
  "in_reply_to_screen_name" : "SpeakerBoehner",
  "in_reply_to_user_id_str" : "7713202",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MPAA",
      "indices" : [ 38, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159675160549523456",
  "text" : "MPAA - Military Police Academy Awards #MPAA",
  "id" : 159675160549523456,
  "created_at" : "2012-01-18 16:34:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MPAA",
      "indices" : [ 129, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/pi8PQ3gK",
      "expanded_url" : "http:\/\/www.techdirt.com\/articles\/20120117\/13254717438\/lamar-smith-mpaa-brush-off-wikipedia-blackout-as-just-publicity-stunt.shtml",
      "display_url" : "techdirt.com\/articles\/20120\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159674774057000960",
  "text" : "\"It is irresponsible ... and an abuse of power\" says MPAA of Wikipedia blackout. Abuse of power! Audacious! http:\/\/t.co\/pi8PQ3gK #MPAA",
  "id" : 159674774057000960,
  "created_at" : "2012-01-18 16:33:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ProPublica",
      "screen_name" : "ProPublica",
      "indices" : [ 59, 70 ],
      "id_str" : "14606079",
      "id" : 14606079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SOPA",
      "indices" : [ 6, 11 ]
    }, {
      "text" : "PIPA",
      "indices" : [ 12, 17 ]
    } ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/joqux9zE",
      "expanded_url" : "http:\/\/projects.propublica.org\/sopa\/",
      "display_url" : "projects.propublica.org\/sopa\/"
    } ]
  },
  "geo" : { },
  "id_str" : "159664494577065984",
  "text" : "Known #SOPA #PIPA supporters here http:\/\/t.co\/joqux9zE via @propublica",
  "id" : 159664494577065984,
  "created_at" : "2012-01-18 15:52:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "LOLGOP",
      "screen_name" : "LOLGOP",
      "indices" : [ 0, 7 ],
      "id_str" : "11866582",
      "id" : 11866582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159392155788509185",
  "geo" : { },
  "id_str" : "159394033662312448",
  "in_reply_to_user_id" : 11866582,
  "text" : "@LOLGOP Wasn't she the Big Gippers' Secretary of Psychic Astrology?",
  "id" : 159394033662312448,
  "in_reply_to_status_id" : 159392155788509185,
  "created_at" : "2012-01-17 21:57:53 +0000",
  "in_reply_to_screen_name" : "LOLGOP",
  "in_reply_to_user_id_str" : "11866582",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amplify.la",
      "screen_name" : "amplifyla",
      "indices" : [ 65, 75 ],
      "id_str" : "379028519",
      "id" : 379028519
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/oPpWqqJR",
      "expanded_url" : "http:\/\/www.portfolio.com\/views\/blogs\/entrepreneurship\/2012\/01\/17\/startup-accelerator-amplify-shares-tips-to-getting-on-its-portfolio",
      "display_url" : "portfolio.com\/views\/blogs\/en\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159392761634750464",
  "text" : "I'm missing the \"incredibly high executives\" part of my startup. @amplifyla\nhttp:\/\/t.co\/oPpWqqJR",
  "id" : 159392761634750464,
  "created_at" : "2012-01-17 21:52:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Yahoo Board",
      "screen_name" : "YahooBoard",
      "indices" : [ 3, 14 ],
      "id_str" : "378869382",
      "id" : 378869382
    }, {
      "name" : "Flickr",
      "screen_name" : "Flickr",
      "indices" : [ 75, 82 ],
      "id_str" : "21237045",
      "id" : 21237045
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sopa",
      "indices" : [ 27, 32 ]
    }, {
      "text" : "yahoo4eva",
      "indices" : [ 110, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159387779527229440",
  "text" : "RT @YahooBoard: To protest #sopa we're stopping all product development on @flickr, effective five years ago. #yahoo4eva",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Flickr",
        "screen_name" : "Flickr",
        "indices" : [ 59, 66 ],
        "id_str" : "21237045",
        "id" : 21237045
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sopa",
        "indices" : [ 11, 16 ]
      }, {
        "text" : "yahoo4eva",
        "indices" : [ 94, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159358714845995011",
    "text" : "To protest #sopa we're stopping all product development on @flickr, effective five years ago. #yahoo4eva",
    "id" : 159358714845995011,
    "created_at" : "2012-01-17 19:37:33 +0000",
    "user" : {
      "name" : "Yahoo Board",
      "screen_name" : "YahooBoard",
      "protected" : false,
      "id_str" : "378869382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1556792773\/goofy-yahoo-logo_normal.gif",
      "id" : 378869382,
      "verified" : false
    }
  },
  "id" : 159387779527229440,
  "created_at" : "2012-01-17 21:33:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Bella",
      "screen_name" : "katbella5",
      "indices" : [ 0, 10 ],
      "id_str" : "104772730",
      "id" : 104772730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158425112129974272",
  "geo" : { },
  "id_str" : "159387586056568832",
  "in_reply_to_user_id" : 104772730,
  "text" : "@katbella5 he's in a safer place now",
  "id" : 159387586056568832,
  "in_reply_to_status_id" : 158425112129974272,
  "created_at" : "2012-01-17 21:32:16 +0000",
  "in_reply_to_screen_name" : "katbella5",
  "in_reply_to_user_id_str" : "104772730",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 7, 14 ],
      "id_str" : "285766850",
      "id" : 285766850
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/e3rghwgS",
      "expanded_url" : "http:\/\/live.nodeup.com\/",
      "display_url" : "live.nodeup.com"
    } ]
  },
  "geo" : { },
  "id_str" : "159026420885094400",
  "text" : "RSVPT  @NodeUp Live NodeUp podast at Bottom of the Hill on Monday the 23rd http:\/\/t.co\/e3rghwgS #nodejs",
  "id" : 159026420885094400,
  "created_at" : "2012-01-16 21:37:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157909010421514240",
  "text" : "RAISED IN the 80's? RAISE DIN 2012!",
  "id" : 157909010421514240,
  "created_at" : "2012-01-13 19:36:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "javascript",
      "indices" : [ 95, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157193818813382656",
  "text" : "I just realized that pie is the first three letters of piece. The piece inherits from the pie. #javascript",
  "id" : 157193818813382656,
  "created_at" : "2012-01-11 20:15:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "objectification",
      "indices" : [ 38, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/josGyLHa",
      "expanded_url" : "http:\/\/womeninnovatemobile.com\/",
      "display_url" : "womeninnovatemobile.com"
    } ]
  },
  "geo" : { },
  "id_str" : "156894496397860865",
  "text" : "Women Innovate Mobile got a nice logo #objectification http:\/\/t.co\/josGyLHa",
  "id" : 156894496397860865,
  "created_at" : "2012-01-11 00:25:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "jqueryUI",
      "indices" : [ 91, 100 ]
    }, {
      "text" : "jquery",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156888961221009408",
  "text" : "i'd like to be able to grab the range itself in a ranged slider, and move it like a window #jqueryUI #jquery",
  "id" : 156888961221009408,
  "created_at" : "2012-01-11 00:03:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Peteris Krumins",
      "screen_name" : "pkrumins",
      "indices" : [ 0, 9 ],
      "id_str" : "2134501",
      "id" : 2134501
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156861718797107200",
  "geo" : { },
  "id_str" : "156873744307060736",
  "in_reply_to_user_id" : 2134501,
  "text" : "@pkrumins it's beautiful!",
  "id" : 156873744307060736,
  "in_reply_to_status_id" : 156861718797107200,
  "created_at" : "2012-01-10 23:03:09 +0000",
  "in_reply_to_screen_name" : "pkrumins",
  "in_reply_to_user_id_str" : "2134501",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/o22isz6Y",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=GOMIBdM6N7Q",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "156836036641701889",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin !!! http:\/\/t.co\/o22isz6Y",
  "id" : 156836036641701889,
  "created_at" : "2012-01-10 20:33:19 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "::: Funkmosphere :::",
      "screen_name" : "funkmosphere",
      "indices" : [ 0, 13 ],
      "id_str" : "19418978",
      "id" : 19418978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156527947262599168",
  "geo" : { },
  "id_str" : "156529020475936768",
  "in_reply_to_user_id" : 19418978,
  "text" : "@funkmosphere ANSWER MY @ B4 U SIGN OFF",
  "id" : 156529020475936768,
  "in_reply_to_status_id" : 156527947262599168,
  "created_at" : "2012-01-10 00:13:21 +0000",
  "in_reply_to_screen_name" : "funkmosphere",
  "in_reply_to_user_id_str" : "19418978",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "::: Funkmosphere :::",
      "screen_name" : "funkmosphere",
      "indices" : [ 0, 13 ],
      "id_str" : "19418978",
      "id" : 19418978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156526904839643137",
  "in_reply_to_user_id" : 19418978,
  "text" : "@funkmosphere is Dam Funk doing his thing tonight?",
  "id" : 156526904839643137,
  "created_at" : "2012-01-10 00:04:56 +0000",
  "in_reply_to_screen_name" : "funkmosphere",
  "in_reply_to_user_id_str" : "19418978",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156105897368752128",
  "geo" : { },
  "id_str" : "156107976548167680",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs does that make you a discussion prescriptivist?",
  "id" : 156107976548167680,
  "in_reply_to_status_id" : 156105897368752128,
  "created_at" : "2012-01-08 20:20:16 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NodeUp",
      "screen_name" : "NodeUp",
      "indices" : [ 0, 7 ],
      "id_str" : "285766850",
      "id" : 285766850
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156105492589051904",
  "geo" : { },
  "id_str" : "156106964793962496",
  "in_reply_to_user_id" : 285766850,
  "text" : "@NodeUp at one of the hotels? In somebody's suite??",
  "id" : 156106964793962496,
  "in_reply_to_status_id" : 156105492589051904,
  "created_at" : "2012-01-08 20:16:15 +0000",
  "in_reply_to_screen_name" : "NodeUp",
  "in_reply_to_user_id_str" : "285766850",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Red List Radio",
      "screen_name" : "RedListRadio",
      "indices" : [ 56, 69 ],
      "id_str" : "227832849",
      "id" : 227832849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/Bd9hOQIk",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=NVGI6mhfJyA",
      "display_url" : "youtube.com\/watch?v=NVGI6m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "156105729932136448",
  "text" : "w0ot my lil pony + wutang = http:\/\/t.co\/Bd9hOQIk via RT @RedListRadio",
  "id" : 156105729932136448,
  "created_at" : "2012-01-08 20:11:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jussi Kalliokoski",
      "screen_name" : "quinnirill",
      "indices" : [ 9, 20 ],
      "id_str" : "209694378",
      "id" : 209694378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156088419993387008",
  "in_reply_to_user_id" : 327933057,
  "text" : "@ofmlabs @quinnirill Ooops, I mean is Audiolib.AudioDevice a generator?",
  "id" : 156088419993387008,
  "created_at" : "2012-01-08 19:02:33 +0000",
  "in_reply_to_screen_name" : "audiocogs",
  "in_reply_to_user_id_str" : "327933057",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jussi Kalliokoski",
      "screen_name" : "quinnirill",
      "indices" : [ 9, 20 ],
      "id_str" : "209694378",
      "id" : 209694378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155976911376490497",
  "geo" : { },
  "id_str" : "156071739271548928",
  "in_reply_to_user_id" : 327933057,
  "text" : "@ofmlabs @quinnirill is audiolib.device a generator? I don't see that in the docs.",
  "id" : 156071739271548928,
  "in_reply_to_status_id" : 155976911376490497,
  "created_at" : "2012-01-08 17:56:16 +0000",
  "in_reply_to_screen_name" : "audiocogs",
  "in_reply_to_user_id_str" : "327933057",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155782308325109760",
  "in_reply_to_user_id" : 327933057,
  "text" : "@ofmlabs audiolib.js needs docs! how can I help?",
  "id" : 155782308325109760,
  "created_at" : "2012-01-07 22:46:11 +0000",
  "in_reply_to_screen_name" : "audiocogs",
  "in_reply_to_user_id_str" : "327933057",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Node Summit",
      "screen_name" : "NodeSummit",
      "indices" : [ 0, 11 ],
      "id_str" : "293718395",
      "id" : 293718395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/b7lcDoMB",
      "expanded_url" : "http:\/\/www.jdvhotels.com\/hotels\/sanfrancisco",
      "display_url" : "jdvhotels.com\/hotels\/sanfran\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "155778306438995969",
  "geo" : { },
  "id_str" : "155779808607993856",
  "in_reply_to_user_id" : 293718395,
  "text" : "@NodeSummit we're staying one of these 'boutique' hotels and the rates are reasonable! http:\/\/t.co\/b7lcDoMB",
  "id" : 155779808607993856,
  "in_reply_to_status_id" : 155778306438995969,
  "created_at" : "2012-01-07 22:36:15 +0000",
  "in_reply_to_screen_name" : "NodeSummit",
  "in_reply_to_user_id_str" : "293718395",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jussi Kalliokoski",
      "screen_name" : "quinnirill",
      "indices" : [ 8, 19 ],
      "id_str" : "209694378",
      "id" : 209694378
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ofmlabs",
      "indices" : [ 38, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155777875277127680",
  "text" : "pinging @quinnirill ... pls report to #ofmlabs on irc",
  "id" : 155777875277127680,
  "created_at" : "2012-01-07 22:28:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/Zsx76PYc",
      "expanded_url" : "http:\/\/frugaldad.com\/2011\/11\/22\/media-consolidation-infographic\/",
      "display_url" : "frugaldad.com\/2011\/11\/22\/med\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155541954631966720",
  "text" : "RT @AngelineGragzin: Oh and then there's this: http:\/\/t.co\/Zsx76PYc Media Consolidation: The Illusion of Choice",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/Zsx76PYc",
        "expanded_url" : "http:\/\/frugaldad.com\/2011\/11\/22\/media-consolidation-infographic\/",
        "display_url" : "frugaldad.com\/2011\/11\/22\/med\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "155540073675366400",
    "text" : "Oh and then there's this: http:\/\/t.co\/Zsx76PYc Media Consolidation: The Illusion of Choice",
    "id" : 155540073675366400,
    "created_at" : "2012-01-07 06:43:38 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 155541954631966720,
  "created_at" : "2012-01-07 06:51:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moe tkacik",
      "screen_name" : "moetkacik",
      "indices" : [ 3, 13 ],
      "id_str" : "25003152",
      "id" : 25003152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155513431804477441",
  "text" : "RT @moetkacik: Walking down dark alley in pajamas behind hipster black guy who keeps looking back as though he's about to become a very  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155512805297102848",
    "text" : "Walking down dark alley in pajamas behind hipster black guy who keeps looking back as though he's about to become a very small statistic",
    "id" : 155512805297102848,
    "created_at" : "2012-01-07 04:55:16 +0000",
    "user" : {
      "name" : "moe tkacik",
      "screen_name" : "moetkacik",
      "protected" : false,
      "id_str" : "25003152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673875315\/Picture_273_normal.png",
      "id" : 25003152,
      "verified" : false
    }
  },
  "id" : 155513431804477441,
  "created_at" : "2012-01-07 04:57:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155513312958877696",
  "text" : "Is there any reason why not to use keep-alive connections over sockets, when both server and client are #nodejs nodes? Much any difference?",
  "id" : 155513312958877696,
  "created_at" : "2012-01-07 04:57:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155510102634401794",
  "text" : "I could multiplex a single TCP connection over websocket. Or each node could keep-alive a regular TCP connection with other nodes. #nodejs",
  "id" : 155510102634401794,
  "created_at" : "2012-01-07 04:44:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "Alanedit",
      "screen_name" : "Alanedit",
      "indices" : [ 17, 26 ],
      "id_str" : "46638392",
      "id" : 46638392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/a7wD2sAI",
      "expanded_url" : "http:\/\/3hubapp.com\/",
      "display_url" : "3hubapp.com"
    } ]
  },
  "in_reply_to_status_id_str" : "155504428491866113",
  "geo" : { },
  "id_str" : "155509802833936384",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin @Alanedit Amazon S3 account @ $0.093 per GB per month + monthly xfer cost + free app http:\/\/t.co\/a7wD2sAI = ur own cloud",
  "id" : 155509802833936384,
  "in_reply_to_status_id" : 155504428491866113,
  "created_at" : "2012-01-07 04:43:20 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Hontz",
      "screen_name" : "startupfoundry",
      "indices" : [ 0, 15 ],
      "id_str" : "243998621",
      "id" : 243998621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/82HlnPBr",
      "expanded_url" : "http:\/\/chromeos.hexxeh.net\/lime.php",
      "display_url" : "chromeos.hexxeh.net\/lime.php"
    } ]
  },
  "in_reply_to_status_id_str" : "155494314422706176",
  "geo" : { },
  "id_str" : "155496117688205312",
  "in_reply_to_user_id" : 243998621,
  "text" : "@startupfoundry http:\/\/t.co\/82HlnPBr ChromeOS",
  "id" : 155496117688205312,
  "in_reply_to_status_id" : 155494314422706176,
  "created_at" : "2012-01-07 03:48:58 +0000",
  "in_reply_to_screen_name" : "startupfoundry",
  "in_reply_to_user_id_str" : "243998621",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/2MKcd0A8",
      "expanded_url" : "http:\/\/bit.ly\/ymra1Y",
      "display_url" : "bit.ly\/ymra1Y"
    } ]
  },
  "geo" : { },
  "id_str" : "155469695221379072",
  "text" : "Why is a parking ticket in Los Angeles $70-150, while a ticket in Des Moines, Iowa is $5-10? Supply and Demand??? http:\/\/t.co\/2MKcd0A8",
  "id" : 155469695221379072,
  "created_at" : "2012-01-07 02:03:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "::: Funkmosphere :::",
      "screen_name" : "funkmosphere",
      "indices" : [ 0, 13 ],
      "id_str" : "19418978",
      "id" : 19418978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155464779786489856",
  "in_reply_to_user_id" : 19418978,
  "text" : "@funkmosphere when and where is the most nextus funk pls?",
  "id" : 155464779786489856,
  "created_at" : "2012-01-07 01:44:26 +0000",
  "in_reply_to_screen_name" : "funkmosphere",
  "in_reply_to_user_id_str" : "19418978",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupy",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154709479886299137",
  "text" : "3.5% of general revenue... from parking fines! That is some bankster shit. #occupy",
  "id" : 154709479886299137,
  "created_at" : "2012-01-04 23:43:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154708381247086593",
  "text" : "I don't think cities can cop \"cost of living\" as a reason for higher fees and fines.",
  "id" : 154708381247086593,
  "created_at" : "2012-01-04 23:38:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chicago",
      "indices" : [ 33, 41 ]
    }, {
      "text" : "NYC",
      "indices" : [ 45, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154708131253985281",
  "text" : "Why does a parking ticket in LA, #Chicago or #NYC cost $60 or $100, but a ticket in Des Moines costs $5 or $10?",
  "id" : 154708131253985281,
  "created_at" : "2012-01-04 23:37:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fees",
      "indices" : [ 127, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154707740923662336",
  "text" : "The number is actually 3.5% of the general revenue. Gen. Revenue doesn't include federal grants for non-discretionary budgets. #fees",
  "id" : 154707740923662336,
  "created_at" : "2012-01-04 23:36:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LA",
      "indices" : [ 109, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/EZlFpyHw",
      "expanded_url" : "http:\/\/mayor.lacity.org\/stellent\/groups\/electedofficials\/@myr_ch_contributor\/documents\/classmaterials\/lacityp_014117.pdf",
      "display_url" : "mayor.lacity.org\/stellent\/group\u2026"
    }, {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/Wgo5IigH",
      "expanded_url" : "http:\/\/mayor.lacity.org\/Issues\/BalancedBudget\/FrequentlyAskedQuestions\/index.htm",
      "display_url" : "mayor.lacity.org\/Issues\/Balance\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154706975274442752",
  "text" : "We are the 2%: Los Angeles gets 2% of budget from parking tickets. http:\/\/t.co\/EZlFpyHw http:\/\/t.co\/Wgo5IigH #LA",
  "id" : 154706975274442752,
  "created_at" : "2012-01-04 23:33:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 21, 33 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    }, {
      "name" : "Node Summit",
      "screen_name" : "NodeSummit",
      "indices" : [ 69, 80 ],
      "id_str" : "293718395",
      "id" : 293718395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154645412274388992",
  "text" : "RT @AngelineGragzin: @astromanies yeehaw we're goin to SAN FRAN!  RT @NodeSummit NodeJam Participant #26 - Omegawd - Research & Edit Rea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "astromanies",
        "screen_name" : "astromanies",
        "indices" : [ 0, 12 ],
        "id_str" : "2588933322",
        "id" : 2588933322
      }, {
        "name" : "Node Summit",
        "screen_name" : "NodeSummit",
        "indices" : [ 48, 59 ],
        "id_str" : "293718395",
        "id" : 293718395
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "154642819926077441",
    "geo" : { },
    "id_str" : "154645078382620673",
    "in_reply_to_user_id" : 46961216,
    "text" : "@astromanies yeehaw we're goin to SAN FRAN!  RT @NodeSummit NodeJam Participant #26 - Omegawd - Research & Edit Real-Time News & Information",
    "id" : 154645078382620673,
    "in_reply_to_status_id" : 154642819926077441,
    "created_at" : "2012-01-04 19:27:14 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 154645412274388992,
  "created_at" : "2012-01-04 19:28:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154644724219777025",
  "text" : "Obama appoints 1st head of \"Consumer Financial Protection Bureau.\" Yr rights as consumer are safe! Yr rights as citizen are still suspect.",
  "id" : 154644724219777025,
  "created_at" : "2012-01-04 19:25:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Node Summit",
      "screen_name" : "NodeSummit",
      "indices" : [ 0, 11 ],
      "id_str" : "293718395",
      "id" : 293718395
    }, {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 45, 61 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 62, 69 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154629320231485440",
  "geo" : { },
  "id_str" : "154642819926077441",
  "in_reply_to_user_id" : 293718395,
  "text" : "@NodeSummit hollar ya'll see you at the Jam! @AngelineGragzin #nodejs",
  "id" : 154642819926077441,
  "in_reply_to_status_id" : 154629320231485440,
  "created_at" : "2012-01-04 19:18:16 +0000",
  "in_reply_to_screen_name" : "NodeSummit",
  "in_reply_to_user_id_str" : "293718395",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Node Summit",
      "screen_name" : "NodeSummit",
      "indices" : [ 3, 14 ],
      "id_str" : "293718395",
      "id" : 293718395
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154641555360186369",
  "text" : "RT @NodeSummit: NodeJam Participant #26 - Omegawd - Research and Edit Real-Time News and Information - Congrats Jonathon (twttr handle?)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154629320231485440",
    "text" : "NodeJam Participant #26 - Omegawd - Research and Edit Real-Time News and Information - Congrats Jonathon (twttr handle?)",
    "id" : 154629320231485440,
    "created_at" : "2012-01-04 18:24:37 +0000",
    "user" : {
      "name" : "Node Summit",
      "screen_name" : "NodeSummit",
      "protected" : false,
      "id_str" : "293718395",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1566852138\/twitter-avatar-summit_normal.png",
      "id" : 293718395,
      "verified" : false
    }
  },
  "id" : 154641555360186369,
  "created_at" : "2012-01-04 19:13:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "moe tkacik",
      "screen_name" : "moetkacik",
      "indices" : [ 3, 13 ],
      "id_str" : "25003152",
      "id" : 25003152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154375082762969089",
  "text" : "RT @moetkacik: Fucking politics, it like a real world road rules reunion marathon, only consequential. And dumber.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154374651919876096",
    "text" : "Fucking politics, it like a real world road rules reunion marathon, only consequential. And dumber.",
    "id" : 154374651919876096,
    "created_at" : "2012-01-04 01:32:39 +0000",
    "user" : {
      "name" : "moe tkacik",
      "screen_name" : "moetkacik",
      "protected" : false,
      "id_str" : "25003152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/673875315\/Picture_273_normal.png",
      "id" : 25003152,
      "verified" : false
    }
  },
  "id" : 154375082762969089,
  "created_at" : "2012-01-04 01:34:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 92, 99 ]
    }, {
      "text" : "html5",
      "indices" : [ 100, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154006672560496641",
  "text" : "I came from the front end. Thanks to nodejs and html5 APIs, I got buffer-to-buffer covered! #nodejs #html5",
  "id" : 154006672560496641,
  "created_at" : "2012-01-03 01:10:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154005035653660673",
  "text" : "i hack node and only node cuz I never knowd aught but node #nodejs",
  "id" : 154005035653660673,
  "created_at" : "2012-01-03 01:03:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Rajlich",
      "screen_name" : "TooTallNate",
      "indices" : [ 0, 12 ],
      "id_str" : "277724842",
      "id" : 277724842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154000936027697153",
  "geo" : { },
  "id_str" : "154001609280598017",
  "in_reply_to_user_id" : 277724842,
  "text" : "@TooTallNate i think i just learned shell scripting from your NodeFLoyd experiment \\o\/",
  "id" : 154001609280598017,
  "in_reply_to_status_id" : 154000936027697153,
  "created_at" : "2012-01-03 00:50:19 +0000",
  "in_reply_to_screen_name" : "TooTallNate",
  "in_reply_to_user_id_str" : "277724842",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Rajlich",
      "screen_name" : "TooTallNate",
      "indices" : [ 33, 45 ],
      "id_str" : "277724842",
      "id" : 277724842
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154000329975939074",
  "text" : "getting a mega education reading @TooTallNate's many amazing modules on github all day (instead of working!) #nodejs",
  "id" : 154000329975939074,
  "created_at" : "2012-01-03 00:45:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153977231360794624",
  "text" : "We need a neater way add\/remove people from gov't at all levels with less delay. Our government needs a better package management system.",
  "id" : 153977231360794624,
  "created_at" : "2012-01-02 23:13:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Rajlich",
      "screen_name" : "TooTallNate",
      "indices" : [ 0, 12 ],
      "id_str" : "277724842",
      "id" : 277724842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153964123019952128",
  "geo" : { },
  "id_str" : "153965041870315520",
  "in_reply_to_user_id" : 277724842,
  "text" : "@TooTallNate sweeeeet! yr the man! so should i listen for stream.on('data').pipe() that, or will stream.pipe() do?",
  "id" : 153965041870315520,
  "in_reply_to_status_id" : 153964123019952128,
  "created_at" : "2012-01-02 22:25:01 +0000",
  "in_reply_to_screen_name" : "TooTallNate",
  "in_reply_to_user_id_str" : "277724842",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nathan Rajlich",
      "screen_name" : "TooTallNate",
      "indices" : [ 0, 12 ],
      "id_str" : "277724842",
      "id" : 277724842
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153962989341515776",
  "in_reply_to_user_id" : 277724842,
  "text" : "@TooTallNate re: node-icecast-stack Does the resulting audio stream automatically have that html5-audio-breaking metadata removed?",
  "id" : 153962989341515776,
  "created_at" : "2012-01-02 22:16:51 +0000",
  "in_reply_to_screen_name" : "TooTallNate",
  "in_reply_to_user_id_str" : "277724842",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "DisneyMemories",
      "indices" : [ 114, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153926253605421056",
  "text" : "waiting in lines, buying overpriced & unhealthy food items, Homeland Defense-like security, brainwashed children  #DisneyMemories",
  "id" : 153926253605421056,
  "created_at" : "2012-01-02 19:50:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jed Schmidt",
      "screen_name" : "jedschmidt",
      "indices" : [ 92, 103 ],
      "id_str" : "815114",
      "id" : 815114
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 47, 54 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 125 ],
      "url" : "https:\/\/t.co\/3rlK4cCq",
      "expanded_url" : "https:\/\/github.com\/jed\/authom",
      "display_url" : "github.com\/jed\/authom"
    } ]
  },
  "geo" : { },
  "id_str" : "153910212762415104",
  "text" : "After longtime pussyfooting about API AUTH for #nodejs apps, today I discovered \"authom\" by @jedschmidt https:\/\/t.co\/3rlK4cCq looks good",
  "id" : 153910212762415104,
  "created_at" : "2012-01-02 18:47:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]