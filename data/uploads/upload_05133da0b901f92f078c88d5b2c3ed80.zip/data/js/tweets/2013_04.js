Grailbird.data.tweets_2013_04 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328202530318327809",
  "text" : "I mastered sweeping at an early age.",
  "id" : 328202530318327809,
  "created_at" : "2013-04-27 17:42:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "328200167209713664",
  "text" : "Cleaning is a secret art.",
  "id" : 328200167209713664,
  "created_at" : "2013-04-27 17:33:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327915516213731328",
  "text" : "my bitch and my chicken hens be getting along together",
  "id" : 327915516213731328,
  "created_at" : "2013-04-26 22:42:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "327615747524268032",
  "text" : "GET TO THE FLOATING POINT",
  "id" : 327615747524268032,
  "created_at" : "2013-04-26 02:50:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "audiocogs",
      "screen_name" : "audiocogs",
      "indices" : [ 0, 10 ],
      "id_str" : "327933057",
      "id" : 327933057
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 104 ],
      "url" : "https:\/\/t.co\/1xMr5IanXw",
      "expanded_url" : "https:\/\/github.com\/audiocogs\/aac.js\/blob\/master\/src\/decoder.js#L36",
      "display_url" : "github.com\/audiocogs\/aac.\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "327527123533312001",
  "in_reply_to_user_id" : 327933057,
  "text" : "@audiocogs The aac player \/ decoder is failing for me on the demo site. Possibly https:\/\/t.co\/1xMr5IanXw",
  "id" : 327527123533312001,
  "created_at" : "2013-04-25 20:58:46 +0000",
  "in_reply_to_screen_name" : "audiocogs",
  "in_reply_to_user_id_str" : "327933057",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/F1ZVKwRYOc",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=HH5d2UToPrE",
      "display_url" : "youtube.com\/watch?v=HH5d2U\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326587079981154304",
  "text" : "i don't know how or why or what but http:\/\/t.co\/F1ZVKwRYOc",
  "id" : 326587079981154304,
  "created_at" : "2013-04-23 06:43:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 54 ],
      "url" : "http:\/\/t.co\/bB5qbE2Y15",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=0yDMEX57Lyc",
      "display_url" : "youtube.com\/watch?v=0yDMEX\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326575553530429442",
  "text" : "I am Willabe the web developer  http:\/\/t.co\/bB5qbE2Y15",
  "id" : 326575553530429442,
  "created_at" : "2013-04-23 05:57:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "luke arduini",
      "screen_name" : "luk",
      "indices" : [ 0, 4 ],
      "id_str" : "16569603",
      "id" : 16569603
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "326569732746661888",
  "geo" : { },
  "id_str" : "326574150653181952",
  "in_reply_to_user_id" : 16569603,
  "text" : "@luk wilco taco foxtrot",
  "id" : 326574150653181952,
  "in_reply_to_status_id" : 326569732746661888,
  "created_at" : "2013-04-23 05:51:59 +0000",
  "in_reply_to_screen_name" : "luk",
  "in_reply_to_user_id_str" : "16569603",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "326567669035831296",
  "text" : "i need the full fuckin html5 experience on a tablet already twenty thirteen. stop adding shit to APIs &amp; languages, and deliver the promises",
  "id" : 326567669035831296,
  "created_at" : "2013-04-23 05:26:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jordan santell",
      "screen_name" : "jsantell",
      "indices" : [ 0, 9 ],
      "id_str" : "13613402",
      "id" : 13613402
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 70 ],
      "url" : "https:\/\/t.co\/MVSrjvJC7X",
      "expanded_url" : "https:\/\/github.com\/jsantell\/web-audio-api-bugs\/tree\/master\/safari\/MediaElement-to-JSNode",
      "display_url" : "github.com\/jsantell\/web-a\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326562286149980160",
  "in_reply_to_user_id" : 13613402,
  "text" : "@jsantell I just discovered this the cruel way https:\/\/t.co\/MVSrjvJC7X",
  "id" : 326562286149980160,
  "created_at" : "2013-04-23 05:04:50 +0000",
  "in_reply_to_screen_name" : "jsantell",
  "in_reply_to_user_id_str" : "13613402",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/tg24fmSaxr",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=hcDFG1gXSwY",
      "display_url" : "youtube.com\/watch?v=hcDFG1\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "326462696641945600",
  "text" : "let this be your zeitguide freedom fighter http:\/\/t.co\/tg24fmSaxr",
  "id" : 326462696641945600,
  "created_at" : "2013-04-22 22:29:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 108 ],
      "url" : "http:\/\/t.co\/WzQETwqY39",
      "expanded_url" : "http:\/\/chinafilmbiz.com\/",
      "display_url" : "chinafilmbiz.com"
    } ]
  },
  "geo" : { },
  "id_str" : "326428785606029313",
  "text" : "\"A Good Day to Die Hard\" is the title for the Chinese release of that film franchise. http:\/\/t.co\/WzQETwqY39",
  "id" : 326428785606029313,
  "created_at" : "2013-04-22 20:14:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 27 ],
      "url" : "http:\/\/t.co\/fAI0i8BwQi",
      "expanded_url" : "http:\/\/instagram.com\/p\/YOFIOSD5cz\/",
      "display_url" : "instagram.com\/p\/YOFIOSD5cz\/"
    } ]
  },
  "geo" : { },
  "id_str" : "324627172612534272",
  "text" : "Hush http:\/\/t.co\/fAI0i8BwQi",
  "id" : 324627172612534272,
  "created_at" : "2013-04-17 20:55:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 39 ],
      "url" : "http:\/\/t.co\/4ftcI28EG5",
      "expanded_url" : "http:\/\/instagram.com\/p\/YOE-TLj5ci\/",
      "display_url" : "instagram.com\/p\/YOE-TLj5ci\/"
    } ]
  },
  "geo" : { },
  "id_str" : "324626807737446400",
  "text" : "See for yourself http:\/\/t.co\/4ftcI28EG5",
  "id" : 324626807737446400,
  "created_at" : "2013-04-17 20:53:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/KHPnuZ4MdA",
      "expanded_url" : "http:\/\/instagram.com\/p\/YOEzxdj5cY\/",
      "display_url" : "instagram.com\/p\/YOEzxdj5cY\/"
    } ]
  },
  "geo" : { },
  "id_str" : "324626331293872128",
  "text" : "The vibrant alley http:\/\/t.co\/KHPnuZ4MdA",
  "id" : 324626331293872128,
  "created_at" : "2013-04-17 20:52:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 4, 26 ],
      "url" : "http:\/\/t.co\/JCDe8TUwfg",
      "expanded_url" : "http:\/\/instagram.com\/p\/YOErCZj5cL\/",
      "display_url" : "instagram.com\/p\/YOErCZj5cL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "324626129854009344",
  "text" : "Mas http:\/\/t.co\/JCDe8TUwfg",
  "id" : 324626129854009344,
  "created_at" : "2013-04-17 20:51:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 72 ],
      "url" : "http:\/\/t.co\/iUyjH1CYvj",
      "expanded_url" : "http:\/\/instagram.com\/p\/YOEdw-D5cB\/",
      "display_url" : "instagram.com\/p\/YOEdw-D5cB\/"
    } ]
  },
  "geo" : { },
  "id_str" : "324625840191188993",
  "text" : "Back alley near International &amp; 17th, Oakland http:\/\/t.co\/iUyjH1CYvj",
  "id" : 324625840191188993,
  "created_at" : "2013-04-17 20:50:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/zsPG28BVfj",
      "expanded_url" : "http:\/\/www.downforeveryoneorjustme.com\/http:\/\/www.ftb.ca.gov\/forms\/search\/index.aspx",
      "display_url" : "downforeveryoneorjustme.com\/http:\/\/www.ftb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "323885765073436672",
  "text" : "http:\/\/t.co\/zsPG28BVfj",
  "id" : 323885765073436672,
  "created_at" : "2013-04-15 19:49:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 43 ],
      "url" : "http:\/\/t.co\/2XND0ap4jV",
      "expanded_url" : "http:\/\/arstechnica.com\/gaming\/2012\/08\/the-surprising-stealth-rebirth-of-the-american-arcade\/",
      "display_url" : "arstechnica.com\/gaming\/2012\/08\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "323640050208342016",
  "text" : "more games more play http:\/\/t.co\/2XND0ap4jV",
  "id" : 323640050208342016,
  "created_at" : "2013-04-15 03:32:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322792357328191488",
  "text" : "?",
  "id" : 322792357328191488,
  "created_at" : "2013-04-12 19:24:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "322792078671224834",
  "text" : "\"the pipes of unix\" or \"secret synthesizer\"",
  "id" : 322792078671224834,
  "created_at" : "2013-04-12 19:23:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "320333980434051073",
  "text" : "I'm building flat UI modules with a goal of mobile-touch \/ HTML5 support. So far I have radio select field and, the prize, a dial \/ knob",
  "id" : 320333980434051073,
  "created_at" : "2013-04-06 00:35:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 39 ],
      "url" : "https:\/\/t.co\/CSM0OxJFoj",
      "expanded_url" : "https:\/\/npmjs.org\/package\/uxer-flat-dial",
      "display_url" : "npmjs.org\/package\/uxer-f\u2026"
    }, {
      "indices" : [ 40, 63 ],
      "url" : "https:\/\/t.co\/G7FftMQwHR",
      "expanded_url" : "https:\/\/npmjs.org\/package\/flat-radio-field",
      "display_url" : "npmjs.org\/package\/flat-r\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "320333461510565888",
  "text" : "web development https:\/\/t.co\/CSM0OxJFoj https:\/\/t.co\/G7FftMQwHR",
  "id" : 320333461510565888,
  "created_at" : "2013-04-06 00:33:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "319853460969373697",
  "text" : "did gmail just force a feature on me?",
  "id" : 319853460969373697,
  "created_at" : "2013-04-04 16:46:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "luke",
      "screen_name" : "st_luke",
      "indices" : [ 0, 8 ],
      "id_str" : "1345293294",
      "id" : 1345293294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "319179752244129792",
  "geo" : { },
  "id_str" : "319180087847165953",
  "in_reply_to_user_id" : 16569603,
  "text" : "@st_luke but but but i am not changing the size of the parent element",
  "id" : 319180087847165953,
  "in_reply_to_status_id" : 319179752244129792,
  "created_at" : "2013-04-02 20:10:37 +0000",
  "in_reply_to_screen_name" : "luk",
  "in_reply_to_user_id_str" : "16569603",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/6IJHntPl7g",
      "expanded_url" : "http:\/\/jsfiddle.net\/LDsYG\/1\/",
      "display_url" : "jsfiddle.net\/LDsYG\/1\/"
    } ]
  },
  "geo" : { },
  "id_str" : "319178449963085825",
  "text" : "CSS problem: why does the tick marker shrink when the parent element is rotated? http:\/\/t.co\/6IJHntPl7g (press run to see the marker shrink)",
  "id" : 319178449963085825,
  "created_at" : "2013-04-02 20:04:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318849180607074304",
  "text" : "There is no going half-molasses.",
  "id" : 318849180607074304,
  "created_at" : "2013-04-01 22:15:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "indices" : [ 3, 12 ],
      "id_str" : "141834186",
      "id" : 141834186
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318810267112841217",
  "text" : "RT @FearDept: Keep your hands off the bitcoins.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "318808726800855041",
    "text" : "Keep your hands off the bitcoins.",
    "id" : 318808726800855041,
    "created_at" : "2013-04-01 19:34:58 +0000",
    "user" : {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "protected" : false,
      "id_str" : "141834186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453113104939761664\/9ZqHHvvA_normal.png",
      "id" : 141834186,
      "verified" : false
    }
  },
  "id" : 318810267112841217,
  "created_at" : "2013-04-01 19:41:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "videogamusic",
      "indices" : [ 124, 137 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318806561587879936",
  "text" : "Call 4 radical javascript developer(s) to partner in media company and immediately ship original cult HTML5 goods globally. #videogamusic",
  "id" : 318806561587879936,
  "created_at" : "2013-04-01 19:26:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318784248045768704",
  "text" : "I choose absolute positioning",
  "id" : 318784248045768704,
  "created_at" : "2013-04-01 17:57:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]