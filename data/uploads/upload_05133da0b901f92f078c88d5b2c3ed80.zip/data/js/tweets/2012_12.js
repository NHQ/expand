Grailbird.data.tweets_2012_12 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "somehow",
      "indices" : [ 60, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285619832400011264",
  "text" : "Can I use a 250W computer power supply as a 250W amplifier? #somehow",
  "id" : 285619832400011264,
  "created_at" : "2012-12-31 05:34:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/EXIFvfN4",
      "expanded_url" : "http:\/\/www.instructables.com\/id\/3D-Printed-Record\/",
      "display_url" : "instructables.com\/id\/3D-Printed-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "285578597073317889",
  "text" : "convert an audio file into a 3D model and print a record http:\/\/t.co\/EXIFvfN4",
  "id" : 285578597073317889,
  "created_at" : "2012-12-31 02:50:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 46, 62 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285576494988791809",
  "text" : "\"I am not happied by material possessions.\" - @AngelineGragzin",
  "id" : 285576494988791809,
  "created_at" : "2012-12-31 02:41:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "285576455256145920",
  "text" : "RT @IAM_SHAKESPEARE: The very firstlings of my heart shall be",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "285576012262154241",
    "text" : "The very firstlings of my heart shall be",
    "id" : 285576012262154241,
    "created_at" : "2012-12-31 02:40:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 285576455256145920,
  "created_at" : "2012-12-31 02:41:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jessica Lord",
      "screen_name" : "jllord",
      "indices" : [ 0, 7 ],
      "id_str" : "126718519",
      "id" : 126718519
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 8, 17 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "285509131836731392",
  "geo" : { },
  "id_str" : "285576216059207680",
  "in_reply_to_user_id" : 126718519,
  "text" : "@jllord @maxogden if you like to watch people shoot themselves just to watch themselves die",
  "id" : 285576216059207680,
  "in_reply_to_status_id" : 285509131836731392,
  "created_at" : "2012-12-31 02:40:50 +0000",
  "in_reply_to_screen_name" : "jllord",
  "in_reply_to_user_id_str" : "126718519",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "indices" : [ 3, 15 ],
      "id_str" : "850972790",
      "id" : 850972790
    }, {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 18, 30 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282379672862474240",
  "text" : "RT @TheHatGhost: \u201C@astromanies: &lt;lol length=\"1\"&gt;&lt;\/lol&gt;\u201D is this some kinda joke?!?!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "astromanies",
        "screen_name" : "astromanies",
        "indices" : [ 1, 13 ],
        "id_str" : "2588933322",
        "id" : 2588933322
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282377056652775424",
    "text" : "\u201C@astromanies: &lt;lol length=\"1\"&gt;&lt;\/lol&gt;\u201D is this some kinda joke?!?!",
    "id" : 282377056652775424,
    "created_at" : "2012-12-22 06:48:31 +0000",
    "user" : {
      "name" : "Blayne Greiner",
      "screen_name" : "TheHatGhost",
      "protected" : false,
      "id_str" : "850972790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489507115288260608\/d0-830iu_normal.jpeg",
      "id" : 850972790,
      "verified" : false
    }
  },
  "id" : 282379672862474240,
  "created_at" : "2012-12-22 06:58:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282373255753506818",
  "text" : "&lt;lol length=\"1\"&gt;&lt;\/lol&gt;",
  "id" : 282373255753506818,
  "created_at" : "2012-12-22 06:33:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/FHrPTrdq",
      "expanded_url" : "http:\/\/www.nsfwcorp.com\/dispatch\/three-heads-we-lose",
      "display_url" : "nsfwcorp.com\/dispatch\/three\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "282373156868608000",
  "text" : "Wow. Just Wow. Blood sucking for profit and teacher's union's invested in gun companies. http:\/\/t.co\/FHrPTrdq",
  "id" : 282373156868608000,
  "created_at" : "2012-12-22 06:33:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282350461418369024",
  "text" : "RT @IAM_SHAKESPEARE: Look like the time; bear welcome in your eye,",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "282349753432428546",
    "text" : "Look like the time; bear welcome in your eye,",
    "id" : 282349753432428546,
    "created_at" : "2012-12-22 05:00:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 282350461418369024,
  "created_at" : "2012-12-22 05:02:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "five",
      "indices" : [ 45, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282349718401589249",
  "text" : "spec for the &lt;lol&gt; element in the html #five",
  "id" : 282349718401589249,
  "created_at" : "2012-12-22 04:59:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "282348446755745792",
  "text" : "PIPPLE CANT READ. CANT READ THEY CONSTITUTION. WE NEED MORE READINGS!!!",
  "id" : 282348446755745792,
  "created_at" : "2012-12-22 04:54:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "281294997024804864",
  "text" : "Hillbilleh",
  "id" : 281294997024804864,
  "created_at" : "2012-12-19 07:08:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/4PTGARwK",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=CE0Q904gtMI",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "281293647281000448",
  "text" : "I had premonitions of eagles snatching babies after seeing them snatch goats off a cliff and then it happened on video http:\/\/t.co\/4PTGARwK",
  "id" : 281293647281000448,
  "created_at" : "2012-12-19 07:03:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "280910451938836480",
  "text" : "'all 1s linear'",
  "id" : 280910451938836480,
  "created_at" : "2012-12-18 05:40:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279822692176261120",
  "text" : "RT @IAM_SHAKESPEARE: Thrust thy sharp wit quite through my ignorance,",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "279820590746062848",
    "text" : "Thrust thy sharp wit quite through my ignorance,",
    "id" : 279820590746062848,
    "created_at" : "2012-12-15 05:30:02 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 279822692176261120,
  "created_at" : "2012-12-15 05:38:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 47 ],
      "url" : "https:\/\/t.co\/qhzl7Upc",
      "expanded_url" : "https:\/\/github.com\/NHQ\/sloop",
      "display_url" : "github.com\/NHQ\/sloop"
    } ]
  },
  "geo" : { },
  "id_str" : "279666803356078080",
  "text" : "loop over a buffer sample https:\/\/t.co\/qhzl7Upc",
  "id" : 279666803356078080,
  "created_at" : "2012-12-14 19:18:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hey",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279485107688054785",
  "text" : "Dog on a cold cow bone \/\/ Dog on a Cold Cow Bone \/\/ I'm at home, don't you know it, with a \/\/ Dog on a cold cow bone #hey",
  "id" : 279485107688054785,
  "created_at" : "2012-12-14 07:16:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279483776717971456",
  "text" : "Hang a cocoon and emerge and new specie.",
  "id" : 279483776717971456,
  "created_at" : "2012-12-14 07:11:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usa",
      "indices" : [ 29, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "279372714375000064",
  "text" : "this country is illiberalate #usa",
  "id" : 279372714375000064,
  "created_at" : "2012-12-13 23:50:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278391484976332800",
  "text" : "RT @IAM_SHAKESPEARE: been sharp and sententious; pleasant without scurrility, witty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278391168344154113",
    "text" : "been sharp and sententious; pleasant without scurrility, witty",
    "id" : 278391168344154113,
    "created_at" : "2012-12-11 06:50:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 278391484976332800,
  "created_at" : "2012-12-11 06:51:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278351664841367552",
  "text" : "RT @IAM_SHAKESPEARE: From women's eyes this doctrine I derive.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "278285472529260544",
    "text" : "From women's eyes this doctrine I derive.",
    "id" : 278285472529260544,
    "created_at" : "2012-12-10 23:50:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 278351664841367552,
  "created_at" : "2012-12-11 04:13:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "278030193862512640",
  "text" : "I am currently buying time. If I win anything, I will use it to buy more time.",
  "id" : 278030193862512640,
  "created_at" : "2012-12-10 06:55:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "277856145224392704",
  "text" : "My intro to hardware hacking was yesterday. There were not enough female wires.",
  "id" : 277856145224392704,
  "created_at" : "2012-12-09 19:24:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Postilnik",
      "screen_name" : "danielpostilnik",
      "indices" : [ 0, 16 ],
      "id_str" : "83694354",
      "id" : 83694354
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "277140143465431040",
  "geo" : { },
  "id_str" : "277167958449610752",
  "in_reply_to_user_id" : 83694354,
  "text" : "@danielpostilnik HAHA ur from RUSSIA",
  "id" : 277167958449610752,
  "in_reply_to_status_id" : 277140143465431040,
  "created_at" : "2012-12-07 21:49:25 +0000",
  "in_reply_to_screen_name" : "danielpostilnik",
  "in_reply_to_user_id_str" : "83694354",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RHYMEFEST",
      "screen_name" : "RHYMEFEST",
      "indices" : [ 0, 10 ],
      "id_str" : "18408457",
      "id" : 18408457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276998982662754304",
  "in_reply_to_user_id" : 18408457,
  "text" : "@RHYMEFEST Drones with cameras patrol, operated by middle school kids on their xbox. Interrupt. Aid investigation. Increase risk 4 criminals",
  "id" : 276998982662754304,
  "created_at" : "2012-12-07 10:37:58 +0000",
  "in_reply_to_screen_name" : "RHYMEFEST",
  "in_reply_to_user_id_str" : "18408457",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RHYMEFEST",
      "screen_name" : "RHYMEFEST",
      "indices" : [ 0, 10 ],
      "id_str" : "18408457",
      "id" : 18408457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276992536566972416",
  "geo" : { },
  "id_str" : "276997034697977857",
  "in_reply_to_user_id" : 18408457,
  "text" : "@RHYMEFEST Basically local superheros in light armor, with cameras, lights, sirens, real time comm, on the scene fast. Build up deterrence.",
  "id" : 276997034697977857,
  "in_reply_to_status_id" : 276992536566972416,
  "created_at" : "2012-12-07 10:30:14 +0000",
  "in_reply_to_screen_name" : "RHYMEFEST",
  "in_reply_to_user_id_str" : "18408457",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RHYMEFEST",
      "screen_name" : "RHYMEFEST",
      "indices" : [ 0, 10 ],
      "id_str" : "18408457",
      "id" : 18408457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276992536566972416",
  "geo" : { },
  "id_str" : "276996415601917953",
  "in_reply_to_user_id" : 18408457,
  "text" : "@RHYMEFEST Cops are heavy units. Can't keep up with the street. Vigilant local patrol. Light units + technology + connected communities.",
  "id" : 276996415601917953,
  "in_reply_to_status_id" : 276992536566972416,
  "created_at" : "2012-12-07 10:27:46 +0000",
  "in_reply_to_screen_name" : "RHYMEFEST",
  "in_reply_to_user_id_str" : "18408457",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RHYMEFEST",
      "screen_name" : "RHYMEFEST",
      "indices" : [ 0, 10 ],
      "id_str" : "18408457",
      "id" : 18408457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276982823632642049",
  "geo" : { },
  "id_str" : "276990859193487360",
  "in_reply_to_user_id" : 18408457,
  "text" : "@RHYMEFEST rap music",
  "id" : 276990859193487360,
  "in_reply_to_status_id" : 276982823632642049,
  "created_at" : "2012-12-07 10:05:41 +0000",
  "in_reply_to_screen_name" : "RHYMEFEST",
  "in_reply_to_user_id_str" : "18408457",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RHYMEFEST",
      "screen_name" : "RHYMEFEST",
      "indices" : [ 0, 10 ],
      "id_str" : "18408457",
      "id" : 18408457
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276982823632642049",
  "geo" : { },
  "id_str" : "276990640569606144",
  "in_reply_to_user_id" : 18408457,
  "text" : "@RHYMEFEST marketing &amp; advertisements targeting young psychology",
  "id" : 276990640569606144,
  "in_reply_to_status_id" : 276982823632642049,
  "created_at" : "2012-12-07 10:04:49 +0000",
  "in_reply_to_screen_name" : "RHYMEFEST",
  "in_reply_to_user_id_str" : "18408457",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "live",
      "indices" : [ 38, 43 ]
    }, {
      "text" : "set",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/gOZ7LWPG",
      "expanded_url" : "http:\/\/www.eastvillageradio.com\/",
      "display_url" : "eastvillageradio.com"
    } ]
  },
  "geo" : { },
  "id_str" : "276886512828825600",
  "text" : "TRY NOT TO ROB A MCDONALDS AFTERWARDS #live #set http:\/\/t.co\/gOZ7LWPG",
  "id" : 276886512828825600,
  "created_at" : "2012-12-07 03:11:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Jones",
      "screen_name" : "riverofdoubt",
      "indices" : [ 88, 101 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/gOZ7LWPG",
      "expanded_url" : "http:\/\/www.eastvillageradio.com\/",
      "display_url" : "eastvillageradio.com"
    } ]
  },
  "geo" : { },
  "id_str" : "276884103171829761",
  "text" : "Military Town Dance Clubs Listen To The Gold RIver Show RIGHT CHEA http:\/\/t.co\/gOZ7LWPG @riverofdoubt",
  "id" : 276884103171829761,
  "created_at" : "2012-12-07 03:01:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jerry Jones",
      "screen_name" : "riverofdoubt",
      "indices" : [ 0, 13 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "276882640899014656",
  "geo" : { },
  "id_str" : "276883282396860416",
  "in_reply_to_user_id" : 97794798,
  "text" : "@riverofdoubt I'm only retweeting if you gloss the house and throw in some jook, some Baltimore, and that NOLA",
  "id" : 276883282396860416,
  "in_reply_to_status_id" : 276882640899014656,
  "created_at" : "2012-12-07 02:58:13 +0000",
  "in_reply_to_screen_name" : "riverofdoubt",
  "in_reply_to_user_id_str" : "97794798",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usaf",
      "indices" : [ 48, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276881891829891073",
  "text" : "Muffhuckers didn't even know I was half blind.  #usaf",
  "id" : 276881891829891073,
  "created_at" : "2012-12-07 02:52:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/lnroAiVx",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/LGM-30_Minuteman",
      "display_url" : "en.wikipedia.org\/wiki\/LGM-30_Mi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "276881450601697280",
  "text" : "This was the middle school's mascot: http:\/\/t.co\/lnroAiVx STILL IN SERVICE BITCH",
  "id" : 276881450601697280,
  "created_at" : "2012-12-07 02:50:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trueStories",
      "indices" : [ 36, 48 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "276879067414945792",
  "text" : "I was in the US Air Force 13 years. #trueStories",
  "id" : 276879067414945792,
  "created_at" : "2012-12-07 02:41:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/MNfff8xe",
      "expanded_url" : "http:\/\/instagr.am\/p\/SxBDqfD5QL\/",
      "display_url" : "instagr.am\/p\/SxBDqfD5QL\/"
    } ]
  },
  "geo" : { },
  "id_str" : "275500829446914048",
  "text" : "If u build it, samurai will come. http:\/\/t.co\/MNfff8xe",
  "id" : 275500829446914048,
  "created_at" : "2012-12-03 07:24:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]