Grailbird.data.tweets_2012_09 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251909941672173568",
  "text" : "now with dependencies!",
  "id" : 251909941672173568,
  "created_at" : "2012-09-29 05:03:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 46, 55 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 56, 68 ],
      "id_str" : "136933779",
      "id" : 136933779
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 69, 76 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 77, 86 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "baudioParty",
      "indices" : [ 87, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 23, 44 ],
      "url" : "https:\/\/t.co\/Ir2CE2RW",
      "expanded_url" : "https:\/\/github.com\/NHQ\/dsp-interface",
      "display_url" : "github.com\/NHQ\/dsp-interf\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "251883318201688064",
  "text" : "just published module  https:\/\/t.co\/Ir2CE2RW  @substack @dominictarr @tmpvar @maxogden #baudioParty",
  "id" : 251883318201688064,
  "created_at" : "2012-09-29 03:17:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "251782422058901504",
  "text" : "j\/k I dont read the shit on the wall",
  "id" : 251782422058901504,
  "created_at" : "2012-09-28 20:36:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 0, 7 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/50JOwy7m",
      "expanded_url" : "http:\/\/images2.wikia.nocookie.net\/__cb20091124235935\/fma\/images\/e\/e4\/Garfiel.JPG",
      "display_url" : "images2.wikia.nocookie.net\/__cb2009112423\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "250436510980128769",
  "in_reply_to_user_id" : 14690653,
  "text" : "@regisl regissel ITS MUSIC TIME http:\/\/t.co\/50JOwy7m",
  "id" : 250436510980128769,
  "created_at" : "2012-09-25 03:28:11 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "contibulate",
      "indices" : [ 104, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249990073649618945",
  "text" : "Congratulations on ur first video upload, says youtube, upload higher quality videos, continues youtube #contibulate",
  "id" : 249990073649618945,
  "created_at" : "2012-09-23 21:54:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 40, 47 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249988590384324608",
  "geo" : { },
  "id_str" : "249989680739803137",
  "in_reply_to_user_id" : 14690653,
  "text" : "you get at least two childhoods, player @regisl",
  "id" : 249989680739803137,
  "in_reply_to_status_id" : 249988590384324608,
  "created_at" : "2012-09-23 21:52:39 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249988023461220353",
  "text" : "I don't know if it was I that could not stop or the donut.",
  "id" : 249988023461220353,
  "created_at" : "2012-09-23 21:46:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249982100671967232",
  "text" : "RT @IAM_SHAKESPEARE: CHANCELLOR. My good Lord Archbishop, I am very sorry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "249981473204101120",
    "text" : "CHANCELLOR. My good Lord Archbishop, I am very sorry",
    "id" : 249981473204101120,
    "created_at" : "2012-09-23 21:20:02 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 249982100671967232,
  "created_at" : "2012-09-23 21:22:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249980819685376000",
  "text" : "SYNCOPATHY",
  "id" : 249980819685376000,
  "created_at" : "2012-09-23 21:17:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "barnabus",
      "screen_name" : "othersome",
      "indices" : [ 3, 13 ],
      "id_str" : "230512239",
      "id" : 230512239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249962386436534274",
  "text" : "RT @othersome: be nice you have no idea what anybody has been through",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "249960185236447232",
    "text" : "be nice you have no idea what anybody has been through",
    "id" : 249960185236447232,
    "created_at" : "2012-09-23 19:55:26 +0000",
    "user" : {
      "name" : "barnabus",
      "screen_name" : "othersome",
      "protected" : false,
      "id_str" : "230512239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467946675991244800\/XVgJ9yBf_normal.jpeg",
      "id" : 230512239,
      "verified" : false
    }
  },
  "id" : 249962386436534274,
  "created_at" : "2012-09-23 20:04:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249940839395123201",
  "text" : "Who wanna donut?",
  "id" : 249940839395123201,
  "created_at" : "2012-09-23 18:38:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "theMoreYouShroed",
      "indices" : [ 107, 124 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249934741883731969",
  "geo" : { },
  "id_str" : "249939822968438785",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin thats harmonics \/ entropy. The indiscreet wave is at any time the product of multy waves. #theMoreYouShroed",
  "id" : 249939822968438785,
  "in_reply_to_status_id" : 249934741883731969,
  "created_at" : "2012-09-23 18:34:32 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249933907821219840",
  "text" : "People's packs in the weirdos.",
  "id" : 249933907821219840,
  "created_at" : "2012-09-23 18:11:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249741776615776258",
  "text" : "I'm listening to the new Kid Koala album 12-Bit Blues. You wish you were!",
  "id" : 249741776615776258,
  "created_at" : "2012-09-23 05:27:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249736308094820352",
  "text" : "that could be improved o'er course",
  "id" : 249736308094820352,
  "created_at" : "2012-09-23 05:05:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "physiq",
      "indices" : [ 21, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249735887380946945",
  "text" : "retention over speed #physiq",
  "id" : 249735887380946945,
  "created_at" : "2012-09-23 05:04:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/92sSaNgp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=7l6O26AC5RM",
      "display_url" : "youtube.com\/watch?v=7l6O26\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "249627121008377856",
  "text" : "just do as this hedgehog do http:\/\/t.co\/92sSaNgp",
  "id" : 249627121008377856,
  "created_at" : "2012-09-22 21:51:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249403397558652928",
  "text" : "Ima rockin a pocket full of oscillators",
  "id" : 249403397558652928,
  "created_at" : "2012-09-22 07:02:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249331127322550273",
  "text" : "RT @IAM_SHAKESPEARE: I pray for heartily, that it may find",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "249329676164669441",
    "text" : "I pray for heartily, that it may find",
    "id" : 249329676164669441,
    "created_at" : "2012-09-22 02:10:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 249331127322550273,
  "created_at" : "2012-09-22 02:15:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "indices" : [ 3, 14 ],
      "id_str" : "122112121",
      "id" : 122112121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249328174683537408",
  "text" : "RT @uptownherd: anyone might move back that old philadelphia brownstone by the tastykake factory but you can't go back to leningrad no m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "249324110176460800",
    "text" : "anyone might move back that old philadelphia brownstone by the tastykake factory but you can't go back to leningrad no matter who you are",
    "id" : 249324110176460800,
    "created_at" : "2012-09-22 01:47:54 +0000",
    "user" : {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "protected" : false,
      "id_str" : "122112121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518645860863709184\/iHz-222r_normal.jpeg",
      "id" : 122112121,
      "verified" : false
    }
  },
  "id" : 249328174683537408,
  "created_at" : "2012-09-22 02:04:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249328005229461504",
  "text" : "As for me, I hope to provide entertainments until that ship full of gold starts to sink in.",
  "id" : 249328005229461504,
  "created_at" : "2012-09-22 02:03:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249326833202503680",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs is right. It will take a capital effort. Capital fitness is the name of the game. Stay thirsty, my company.",
  "id" : 249326833202503680,
  "created_at" : "2012-09-22 01:58:43 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249325209264484352",
  "text" : "i just posted a picture",
  "id" : 249325209264484352,
  "created_at" : "2012-09-22 01:52:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249324447222333440",
  "text" : "picture QR codes with 7s, stars, and hearts for the zero bits",
  "id" : 249324447222333440,
  "created_at" : "2012-09-22 01:49:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julien Genestoux",
      "screen_name" : "julien51",
      "indices" : [ 0, 9 ],
      "id_str" : "5381582",
      "id" : 5381582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249315422095163392",
  "geo" : { },
  "id_str" : "249322867349676032",
  "in_reply_to_user_id" : 5381582,
  "text" : "@julien51 IPV6 &gt;&gt; your address becomes a QR code",
  "id" : 249322867349676032,
  "in_reply_to_status_id" : 249315422095163392,
  "created_at" : "2012-09-22 01:42:58 +0000",
  "in_reply_to_screen_name" : "julien51",
  "in_reply_to_user_id_str" : "5381582",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249267202140819456",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs and federated developers can host this FOSS app for pub and sub, add valued services like cloud storage, file Xfer. Or be free + ads.",
  "id" : 249267202140819456,
  "created_at" : "2012-09-21 22:01:46 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249266536672546816",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs we have the service API thing backwards. I should have my home page which has an API for twitter, if I want a service.",
  "id" : 249266536672546816,
  "created_at" : "2012-09-21 21:59:08 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249262022322176001",
  "geo" : { },
  "id_str" : "249266009918300160",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs ok twitter allows us to subscribe and send and receive tiny packets. this is easily done in an express app. The only service is hosting",
  "id" : 249266009918300160,
  "in_reply_to_status_id" : 249262022322176001,
  "created_at" : "2012-09-21 21:57:02 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "Julien Genestoux",
      "screen_name" : "julien51",
      "indices" : [ 5, 14 ],
      "id_str" : "5381582",
      "id" : 5381582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249262422857232384",
  "geo" : { },
  "id_str" : "249263493449129984",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs @julien51 replace email and twitter with https, Send and receive packets. Block unwanted packets. subscribe \/ follow.",
  "id" : 249263493449129984,
  "in_reply_to_status_id" : 249262422857232384,
  "created_at" : "2012-09-21 21:47:02 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "249256602065072128",
  "geo" : { },
  "id_str" : "249261768730365953",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs I don't think a service is the way to do it, especially if it is trying to do what an existing crap service already does",
  "id" : 249261768730365953,
  "in_reply_to_status_id" : 249256602065072128,
  "created_at" : "2012-09-21 21:40:11 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "timing",
      "indices" : [ 114, 121 ]
    }, {
      "text" : "nodejs",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 32, 53 ],
      "url" : "https:\/\/t.co\/cEISwqWG",
      "expanded_url" : "https:\/\/github.com\/NHQ\/since-when",
      "display_url" : "github.com\/NHQ\/since-when"
    }, {
      "indices" : [ 92, 113 ],
      "url" : "https:\/\/t.co\/vlc0oZBc",
      "expanded_url" : "https:\/\/github.com\/NHQ\/syncopation",
      "display_url" : "github.com\/NHQ\/syncopation"
    } ]
  },
  "geo" : { },
  "id_str" : "249260304930840577",
  "text" : "added new example to since-when https:\/\/t.co\/cEISwqWG and published new package syncopation https:\/\/t.co\/vlc0oZBc #timing #nodejs",
  "id" : 249260304930840577,
  "created_at" : "2012-09-21 21:34:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249230800623636480",
  "text" : "Aint got a plate to pancake on.",
  "id" : 249230800623636480,
  "created_at" : "2012-09-21 19:37:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249028187433086976",
  "text" : "awwhhh but I never get to play with the terminology!",
  "id" : 249028187433086976,
  "created_at" : "2012-09-21 06:12:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249026118638792704",
  "text" : "RT @IAM_SHAKESPEARE: They are harsh and heavy to me.                    [Music ceases]",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "249025171623665664",
    "text" : "They are harsh and heavy to me.                    [Music ceases]",
    "id" : 249025171623665664,
    "created_at" : "2012-09-21 06:00:02 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 249026118638792704,
  "created_at" : "2012-09-21 06:03:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249012796170321920",
  "text" : "\u007B\u007BWHAT CONSPIRACY, HO! WHAT WHAT ABOUT OUR EMBASSY\u007D\u007D",
  "id" : 249012796170321920,
  "created_at" : "2012-09-21 05:10:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249012417877647360",
  "text" : "I toasted the laptop speakers with 330-880 hertzes. Then I learned that my two ears hear pitch differently. And that I am half blind.",
  "id" : 249012417877647360,
  "created_at" : "2012-09-21 05:09:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryah",
      "screen_name" : "ryah",
      "indices" : [ 0, 5 ],
      "id_str" : "967076702",
      "id" : 967076702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "249010197094334464",
  "text" : "@ryah you don't like the sound of man wooing you, to a rhythm, and with all the other advantages of music?",
  "id" : 249010197094334464,
  "created_at" : "2012-09-21 05:00:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248866189084860420",
  "text" : "javascript you ruined up the noun switch",
  "id" : 248866189084860420,
  "created_at" : "2012-09-20 19:28:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248866071866654720",
  "text" : "javascript you really ruined up with the keyword switch",
  "id" : 248866071866654720,
  "created_at" : "2012-09-20 19:27:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248861431066411008",
  "text" : "THINK FAST &amp;&amp; THINK SLOW",
  "id" : 248861431066411008,
  "created_at" : "2012-09-20 19:09:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "248845462570946560",
  "text" : "IT WORKS",
  "id" : 248845462570946560,
  "created_at" : "2012-09-20 18:05:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 44 ],
      "url" : "https:\/\/t.co\/szw6DhUR",
      "expanded_url" : "https:\/\/gist.github.com\/3755547",
      "display_url" : "gist.github.com\/3755547"
    } ]
  },
  "geo" : { },
  "id_str" : "248827059542040577",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack simple tempo https:\/\/t.co\/szw6DhUR",
  "id" : 248827059542040577,
  "created_at" : "2012-09-20 16:52:48 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 59, 71 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/slBNxoBx",
      "expanded_url" : "http:\/\/substack.net\/audio\/methodical.ogg",
      "display_url" : "substack.net\/audio\/methodic\u2026"
    }, {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/Cma9GR5J",
      "expanded_url" : "http:\/\/substack.net\/audio\/methodical.json",
      "display_url" : "substack.net\/audio\/methodic\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "248825262886748161",
  "text" : "RT @substack: made this methodical algorithmic music with  @astromanies http:\/\/t.co\/slBNxoBx http:\/\/t.co\/Cma9GR5J",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "astromanies",
        "screen_name" : "astromanies",
        "indices" : [ 45, 57 ],
        "id_str" : "2588933322",
        "id" : 2588933322
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/slBNxoBx",
        "expanded_url" : "http:\/\/substack.net\/audio\/methodical.ogg",
        "display_url" : "substack.net\/audio\/methodic\u2026"
      }, {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/Cma9GR5J",
        "expanded_url" : "http:\/\/substack.net\/audio\/methodical.json",
        "display_url" : "substack.net\/audio\/methodic\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "248684465411461121",
    "text" : "made this methodical algorithmic music with  @astromanies http:\/\/t.co\/slBNxoBx http:\/\/t.co\/Cma9GR5J",
    "id" : 248684465411461121,
    "created_at" : "2012-09-20 07:26:11 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 248825262886748161,
  "created_at" : "2012-09-20 16:45:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 93, 100 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247873883640844288",
  "geo" : { },
  "id_str" : "247875483537133568",
  "in_reply_to_user_id" : 14690653,
  "text" : "THINE OWN ASS cuz if you take a hammer to the butt end of a sickle that's what you'll injure @regisl",
  "id" : 247875483537133568,
  "in_reply_to_status_id" : 247873883640844288,
  "created_at" : "2012-09-18 01:51:35 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247799870373646336",
  "text" : "I feed my lizard before I feed my goat. I am referring to my spirit farm.",
  "id" : 247799870373646336,
  "created_at" : "2012-09-17 20:51:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247571211876450304",
  "text" : "play -s -n synth 2 sin 220 sin 330 sin 440 sin 550 sin 660 fade .05 2 1 delay 0 0.1 0.2 0.3 0.4 synth 2 sin fmod 440",
  "id" : 247571211876450304,
  "created_at" : "2012-09-17 05:42:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247481985646354432",
  "text" : "RT @IAM_SHAKESPEARE: Your brain, and every function of your power,",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "247474953656606721",
    "text" : "Your brain, and every function of your power,",
    "id" : 247474953656606721,
    "created_at" : "2012-09-16 23:20:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 247481985646354432,
  "created_at" : "2012-09-16 23:47:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247472250188595200",
  "text" : "play -n synth 0.5 sin 200-300 fade 3 norm repeat 5 synth 2.5 square fmod 400\/7000",
  "id" : 247472250188595200,
  "created_at" : "2012-09-16 23:09:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 66, 73 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "timbre",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247226926849212416",
  "geo" : { },
  "id_str" : "247235945731080192",
  "in_reply_to_user_id" : 14318086,
  "text" : "tmpad &gt;&gt; RPMs &gt;&gt; air compressor &gt;&gt; tuba #timbre @tmpvar",
  "id" : 247235945731080192,
  "in_reply_to_status_id" : 247226926849212416,
  "created_at" : "2012-09-16 07:30:17 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 17, 24 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247226926849212416",
  "geo" : { },
  "id_str" : "247235382779981824",
  "in_reply_to_user_id" : 14318086,
  "text" : "MAN UREFACTORING @tmpvar",
  "id" : 247235382779981824,
  "in_reply_to_status_id" : 247226926849212416,
  "created_at" : "2012-09-16 07:28:03 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247235067498348545",
  "text" : "RT @IAM_SHAKESPEARE: The master-cord on's heart!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "247233364413775872",
    "text" : "The master-cord on's heart!",
    "id" : 247233364413775872,
    "created_at" : "2012-09-16 07:20:02 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 247235067498348545,
  "created_at" : "2012-09-16 07:26:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 18, 25 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "247226926849212416",
  "geo" : { },
  "id_str" : "247234644859305985",
  "in_reply_to_user_id" : 14318086,
  "text" : "AAAAHHHHYYYYYAAAA @tmpvar",
  "id" : 247234644859305985,
  "in_reply_to_status_id" : 247226926849212416,
  "created_at" : "2012-09-16 07:25:07 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247233092983599105",
  "text" : "tuning into 191 hertz right now and its nice",
  "id" : 247233092983599105,
  "created_at" : "2012-09-16 07:18:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jussi Kalliokoski",
      "screen_name" : "quinnirill",
      "indices" : [ 0, 11 ],
      "id_str" : "209694378",
      "id" : 209694378
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247205113154912256",
  "in_reply_to_user_id" : 209694378,
  "text" : "@quinnirill what is the state of using audiolib from inside a node app? will it play? do you have any examples?",
  "id" : 247205113154912256,
  "created_at" : "2012-09-16 05:27:46 +0000",
  "in_reply_to_screen_name" : "quinnirill",
  "in_reply_to_user_id_str" : "209694378",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247121561277038592",
  "text" : "oops its like i said ATM Machine",
  "id" : 247121561277038592,
  "created_at" : "2012-09-15 23:55:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247120164317966337",
  "text" : "Swept the porch. Cleaned the yard up. Reading abt GA algorithms. Need to do something with imminent pear harvest. Peck o pickled pear pies?",
  "id" : 247120164317966337,
  "created_at" : "2012-09-15 23:50:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dominic Tarr",
      "screen_name" : "dominictarr",
      "indices" : [ 0, 12 ],
      "id_str" : "136933779",
      "id" : 136933779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "247096340927115264",
  "in_reply_to_user_id" : 136933779,
  "text" : "@dominictarr is it advisable to use \"through\"  for all my new custom stream instance needs?",
  "id" : 247096340927115264,
  "created_at" : "2012-09-15 22:15:33 +0000",
  "in_reply_to_screen_name" : "dominictarr",
  "in_reply_to_user_id_str" : "136933779",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 58, 67 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246908259733237760",
  "geo" : { },
  "id_str" : "247043314782707712",
  "in_reply_to_user_id" : 125027291,
  "text" : "WOW beautiful work. you nailed the Socrato-Kernighan bust @substack",
  "id" : 247043314782707712,
  "in_reply_to_status_id" : 246908259733237760,
  "created_at" : "2012-09-15 18:44:50 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 3, 12 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/lIdbRIqh",
      "expanded_url" : "http:\/\/substack.net\/doc\/hujs\/",
      "display_url" : "substack.net\/doc\/hujs\/"
    } ]
  },
  "geo" : { },
  "id_str" : "247041832641515521",
  "text" : "RT @substack: slides from hujs in shanghai http:\/\/t.co\/lIdbRIqh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/lIdbRIqh",
        "expanded_url" : "http:\/\/substack.net\/doc\/hujs\/",
        "display_url" : "substack.net\/doc\/hujs\/"
      } ]
    },
    "geo" : { },
    "id_str" : "246908259733237760",
    "text" : "slides from hujs in shanghai http:\/\/t.co\/lIdbRIqh",
    "id" : 246908259733237760,
    "created_at" : "2012-09-15 09:48:11 +0000",
    "user" : {
      "name" : "substack",
      "screen_name" : "substack",
      "protected" : false,
      "id_str" : "125027291",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3342514715\/3fde89df63ea4dacf9de71369019df22_normal.png",
      "id" : 125027291,
      "verified" : false
    }
  },
  "id" : 247041832641515521,
  "created_at" : "2012-09-15 18:38:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freespeech",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246741549831053312",
  "text" : "just overheard \"we should do like the Arabs &amp; burn some our own local government embassy buildings. Symbolically of course\" #freespeech",
  "id" : 246741549831053312,
  "created_at" : "2012-09-14 22:45:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 111, 118 ],
      "id_str" : "14690653",
      "id" : 14690653
    }, {
      "name" : "the modern folk",
      "screen_name" : "themodernfolk",
      "indices" : [ 119, 133 ],
      "id_str" : "459523037",
      "id" : 459523037
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246713555926253568",
  "geo" : { },
  "id_str" : "246714553734410240",
  "in_reply_to_user_id" : 14690653,
  "text" : "we must co-opt the profit motive as there is no getting rid of it, and perhaps getting rid of it is a bad idea @regisl @themodernfolk",
  "id" : 246714553734410240,
  "in_reply_to_status_id" : 246713555926253568,
  "created_at" : "2012-09-14 20:58:28 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246698049718591488",
  "text" : "As one of the first projects for Johnny's Garage.",
  "id" : 246698049718591488,
  "created_at" : "2012-09-14 19:52:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246697259171991552",
  "text" : "Instead of comcast or AT&amp;T for my ISP, I'm fantasizing about bringing mega bandwidth to my neighborhood and starting a wifi mesh.",
  "id" : 246697259171991552,
  "created_at" : "2012-09-14 19:49:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/OgyOHmG7",
      "expanded_url" : "http:\/\/weburbanist.com\/2012\/09\/04\/abandoned-walmart-is-now-americas-largest-library\/",
      "display_url" : "weburbanist.com\/2012\/09\/04\/aba\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "246347468961349633",
  "text" : "whoa abandoned walmart in Texas turned into largest single level library in USA http:\/\/t.co\/OgyOHmG7",
  "id" : 246347468961349633,
  "created_at" : "2012-09-13 20:39:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/Wa7VGkd7",
      "expanded_url" : "http:\/\/www.ponnuki.net\/2012\/09\/kindleberry-pi\/",
      "display_url" : "ponnuki.net\/2012\/09\/kindle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "246345657131077632",
  "text" : "i've had daydreams about a large e-ink display for coding. this comes close http:\/\/t.co\/Wa7VGkd7",
  "id" : 246345657131077632,
  "created_at" : "2012-09-13 20:32:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bookmark",
      "indices" : [ 0, 9 ]
    }, {
      "text" : "music",
      "indices" : [ 10, 16 ]
    }, {
      "text" : "audio",
      "indices" : [ 17, 23 ]
    }, {
      "text" : "arduino",
      "indices" : [ 24, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/gvKrfKgm",
      "expanded_url" : "http:\/\/interface.khm.de\/index.php\/lab\/experiments\/arduino-realtime-audio-processing\/",
      "display_url" : "interface.khm.de\/index.php\/lab\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "246341952038109184",
  "text" : "#bookmark #music #audio #arduino http:\/\/t.co\/gvKrfKgm",
  "id" : 246341952038109184,
  "created_at" : "2012-09-13 20:17:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246332583544250368",
  "geo" : { },
  "id_str" : "246334806638600192",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar have you tested quarter inch audio jack IO on arduino?",
  "id" : 246334806638600192,
  "in_reply_to_status_id" : 246332583544250368,
  "created_at" : "2012-09-13 19:49:29 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 0, 7 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "246331572691800064",
  "geo" : { },
  "id_str" : "246332148477464576",
  "in_reply_to_user_id" : 14318086,
  "text" : "@tmpvar what can you do with that?",
  "id" : 246332148477464576,
  "in_reply_to_status_id" : 246331572691800064,
  "created_at" : "2012-09-13 19:38:55 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "henrik norberg",
      "screen_name" : "ThisIsHenrik",
      "indices" : [ 39, 52 ],
      "id_str" : "300323126",
      "id" : 300323126
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "246077979342565376",
  "text" : "do you want to join my knockout team?  @ThisIsHenrik",
  "id" : 246077979342565376,
  "created_at" : "2012-09-13 02:48:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "made",
      "indices" : [ 109, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245986894473736194",
  "text" : "Now that I got a nice big house I'm going to invite the local nerd youth build supercomputers in the garage. #made",
  "id" : 245986894473736194,
  "created_at" : "2012-09-12 20:47:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/1I2I62B9",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=N5IDAnB_rns",
      "display_url" : "youtube.com\/watch?v=N5IDAn\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "245980793787260928",
  "text" : "current context: just watched the whole of these http:\/\/t.co\/1I2I62B9 go ahead and have your thoughts read aloud",
  "id" : 245980793787260928,
  "created_at" : "2012-09-12 20:22:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "245976398601285632",
  "geo" : { },
  "id_str" : "245979026492121088",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs did the math say I me am are a ratio? [y\/n]",
  "id" : 245979026492121088,
  "in_reply_to_status_id" : 245976398601285632,
  "created_at" : "2012-09-12 20:15:44 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245947246137466880",
  "text" : "Funemployment is about to end. I'm taking a paycation.",
  "id" : 245947246137466880,
  "created_at" : "2012-09-12 18:09:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245346189774565376",
  "text" : "RT @IAM_SHAKESPEARE: To give her the avaunt, it is a pity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "245345927223709697",
    "text" : "To give her the avaunt, it is a pity",
    "id" : 245345927223709697,
    "created_at" : "2012-09-11 02:20:02 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 245346189774565376,
  "created_at" : "2012-09-11 02:21:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245340602093404161",
  "text" : "REBELUNITE!!!",
  "id" : 245340602093404161,
  "created_at" : "2012-09-11 01:58:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245338172727361538",
  "text" : "ADMIT IT UR A UXER",
  "id" : 245338172727361538,
  "created_at" : "2012-09-11 01:49:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/HlYthmVj",
      "expanded_url" : "http:\/\/skeu.it\/page\/2",
      "display_url" : "skeu.it\/page\/2"
    } ]
  },
  "geo" : { },
  "id_str" : "245336844429041664",
  "text" : "can i get my degree in spittin' UX\/UI for laughing at this blog http:\/\/t.co\/HlYthmVj",
  "id" : 245336844429041664,
  "created_at" : "2012-09-11 01:43:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "245333853919666177",
  "text" : "Is this the right channel to find a big screen playing football on?",
  "id" : 245333853919666177,
  "created_at" : "2012-09-11 01:32:03 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "244527146381504512",
  "text" : "RT @AngelineGragzin: IN-E-LUC-TA-BLE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 37.8560527643, -122.2756007846 ]
    },
    "id_str" : "244504937684418562",
    "text" : "IN-E-LUC-TA-BLE",
    "id" : 244504937684418562,
    "created_at" : "2012-09-08 18:38:14 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 244527146381504512,
  "created_at" : "2012-09-08 20:06:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243954758296154112",
  "text" : "RT @AngelineGragzin: \u201CYour body is the harp of your soul and it is yours to bring forth sweet music from it or confused sounds.\u201D - Khali ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "243952882238517248",
    "text" : "\u201CYour body is the harp of your soul and it is yours to bring forth sweet music from it or confused sounds.\u201D - Khalil Gibran",
    "id" : 243952882238517248,
    "created_at" : "2012-09-07 06:04:34 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 243954758296154112,
  "created_at" : "2012-09-07 06:12:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Visnu Pitiyanuvath",
      "screen_name" : "visnup",
      "indices" : [ 10, 17 ],
      "id_str" : "6121912",
      "id" : 6121912
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 18, 25 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243944066591645696",
  "geo" : { },
  "id_str" : "243947526959550464",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden @visnup @tmpvar every body sit down!",
  "id" : 243947526959550464,
  "in_reply_to_status_id" : 243944066591645696,
  "created_at" : "2012-09-07 05:43:17 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visnu Pitiyanuvath",
      "screen_name" : "visnup",
      "indices" : [ 32, 39 ],
      "id_str" : "6121912",
      "id" : 6121912
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 40, 49 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 50, 57 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243942988902969344",
  "geo" : { },
  "id_str" : "243943894998470658",
  "in_reply_to_user_id" : 6121912,
  "text" : "LOL thats not what its called.  @visnup @maxogden @tmpvar",
  "id" : 243943894998470658,
  "in_reply_to_status_id" : 243942988902969344,
  "created_at" : "2012-09-07 05:28:51 +0000",
  "in_reply_to_screen_name" : "visnup",
  "in_reply_to_user_id_str" : "6121912",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 27, 34 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 35, 44 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Visnu Pitiyanuvath",
      "screen_name" : "visnup",
      "indices" : [ 45, 52 ],
      "id_str" : "6121912",
      "id" : 6121912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243941359898210305",
  "geo" : { },
  "id_str" : "243943092804263937",
  "in_reply_to_user_id" : 14318086,
  "text" : "close enough. I'll drive.  @tmpvar @maxogden @visnup",
  "id" : 243943092804263937,
  "in_reply_to_status_id" : 243941359898210305,
  "created_at" : "2012-09-07 05:25:40 +0000",
  "in_reply_to_screen_name" : "tmpvar",
  "in_reply_to_user_id_str" : "14318086",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visnu Pitiyanuvath",
      "screen_name" : "visnup",
      "indices" : [ 26, 33 ],
      "id_str" : "6121912",
      "id" : 6121912
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 34, 43 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 44, 51 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243941273902391296",
  "geo" : { },
  "id_str" : "243941639037546496",
  "in_reply_to_user_id" : 6121912,
  "text" : "C&amp;C FURNITURE FACTORY @visnup @maxogden @tmpvar",
  "id" : 243941639037546496,
  "in_reply_to_status_id" : 243941273902391296,
  "created_at" : "2012-09-07 05:19:53 +0000",
  "in_reply_to_screen_name" : "visnup",
  "in_reply_to_user_id_str" : "6121912",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 44, 53 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 54, 61 ],
      "id_str" : "14318086",
      "id" : 14318086
    }, {
      "name" : "Visnu Pitiyanuvath",
      "screen_name" : "visnup",
      "indices" : [ 62, 69 ],
      "id_str" : "6121912",
      "id" : 6121912
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243940095399428097",
  "geo" : { },
  "id_str" : "243940729951510528",
  "in_reply_to_user_id" : 12241752,
  "text" : "yes he has a table saw that does miter cuts @maxogden @tmpvar @visnup",
  "id" : 243940729951510528,
  "in_reply_to_status_id" : 243940095399428097,
  "created_at" : "2012-09-07 05:16:16 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Visnu Pitiyanuvath",
      "screen_name" : "visnup",
      "indices" : [ 102, 109 ],
      "id_str" : "6121912",
      "id" : 6121912
    }, {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 110, 119 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 120, 127 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243937871017435136",
  "geo" : { },
  "id_str" : "243940015120478208",
  "in_reply_to_user_id" : 12241752,
  "text" : "Does anyone wanna go see some C&amp;C's? I know a lead hacker at a furniture manufacturer in Oakland. @visnup @maxogden @tmpvar",
  "id" : 243940015120478208,
  "in_reply_to_status_id" : 243937871017435136,
  "created_at" : "2012-09-07 05:13:26 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "xno\u0279\u01DD\u0283 u\u0250\u0131\u0279q",
      "screen_name" : "brianleroux",
      "indices" : [ 3, 15 ],
      "id_str" : "676363",
      "id" : 676363
    }, {
      "name" : "nodeconf",
      "screen_name" : "nodeconf",
      "indices" : [ 42, 51 ],
      "id_str" : "186697923",
      "id" : 186697923
    }, {
      "name" : "Mikeal",
      "screen_name" : "mikeal",
      "indices" : [ 68, 75 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243936491137552384",
  "text" : "RT @brianleroux: man I had a tonne of fun @nodeconf camp: thank you @mikeal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "nodeconf",
        "screen_name" : "nodeconf",
        "indices" : [ 25, 34 ],
        "id_str" : "186697923",
        "id" : 186697923
      }, {
        "name" : "Mikeal",
        "screen_name" : "mikeal",
        "indices" : [ 51, 58 ],
        "id_str" : "668423",
        "id" : 668423
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "243816793246945280",
    "text" : "man I had a tonne of fun @nodeconf camp: thank you @mikeal",
    "id" : 243816793246945280,
    "created_at" : "2012-09-06 21:03:48 +0000",
    "user" : {
      "name" : "xno\u0279\u01DD\u0283 u\u0250\u0131\u0279q",
      "screen_name" : "brianleroux",
      "protected" : false,
      "id_str" : "676363",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2268928025\/qg507kknw872kmyqhet9_normal.jpeg",
      "id" : 676363,
      "verified" : false
    }
  },
  "id" : 243936491137552384,
  "created_at" : "2012-09-07 04:59:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "meow",
      "indices" : [ 40, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243934220014190592",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden Ima need to borrow your tmpad #meow",
  "id" : 243934220014190592,
  "created_at" : "2012-09-07 04:50:24 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 11, 20 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 21, 30 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "nodeconf",
      "screen_name" : "nodeconf",
      "indices" : [ 31, 40 ],
      "id_str" : "186697923",
      "id" : 186697923
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "243774634732949504",
  "geo" : { },
  "id_str" : "243933755369193472",
  "in_reply_to_user_id" : 12241752,
  "text" : "GOOD FORM! @maxogden @substack @nodeconf",
  "id" : 243933755369193472,
  "in_reply_to_status_id" : 243774634732949504,
  "created_at" : "2012-09-07 04:48:34 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "243933550389383168",
  "text" : "I'm going to hack the mic one day.",
  "id" : 243933550389383168,
  "created_at" : "2012-09-07 04:47:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242180679390068736",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack but it is a subtle and mysterious progression over a normal listening range. First I thought the \"loop\" was getting longer!",
  "id" : 242180679390068736,
  "created_at" : "2012-09-02 08:42:28 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 99, 108 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/5rEQ0NqR",
      "expanded_url" : "http:\/\/i.imgur.com\/IaCrf.png",
      "display_url" : "i.imgur.com\/IaCrf.png"
    } ]
  },
  "geo" : { },
  "id_str" : "242177595028938752",
  "text" : "however I did notice that functions mutation tend toward a song for mosquitos http:\/\/t.co\/5rEQ0NqR @substack",
  "id" : 242177595028938752,
  "created_at" : "2012-09-02 08:30:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 126, 135 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242177090470944768",
  "text" : "I tried deciphering your code song and baudio for an hour. Gonna hafta sleep on it. Somewhere between freqs and sines im lost @substack",
  "id" : 242177090470944768,
  "created_at" : "2012-09-02 08:28:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 44, 53 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sweatdrops",
      "indices" : [ 23, 34 ]
    }, {
      "text" : "awesome",
      "indices" : [ 35, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242175370797924353",
  "text" : "I listened to 400 reps #sweatdrops #awesome @substack",
  "id" : 242175370797924353,
  "created_at" : "2012-09-02 08:21:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "linerNotes",
      "indices" : [ 75, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "242165939045548032",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack I would like to see your song richly annotated with math lessons #linerNotes",
  "id" : 242165939045548032,
  "created_at" : "2012-09-02 07:43:53 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 11, 20 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242139790047313920",
  "geo" : { },
  "id_str" : "242144249590718464",
  "in_reply_to_user_id" : 125027291,
  "text" : "i love it! @substack",
  "id" : 242144249590718464,
  "in_reply_to_status_id" : 242139790047313920,
  "created_at" : "2012-09-02 06:17:42 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 20, 29 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "242139790047313920",
  "geo" : { },
  "id_str" : "242142716216102913",
  "in_reply_to_user_id" : 125027291,
  "text" : "TESTING IMMEDIATELY @substack",
  "id" : 242142716216102913,
  "in_reply_to_status_id" : 242139790047313920,
  "created_at" : "2012-09-02 06:11:36 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/7pAUoJFN",
      "expanded_url" : "http:\/\/www.globalscaletechnologies.com\/p-54-dreamplug-devkit.aspx",
      "display_url" : "globalscaletechnologies.com\/p-54-dreamplug\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "242011973628334080",
  "text" : "dreamplug is a must http:\/\/t.co\/7pAUoJFN",
  "id" : 242011973628334080,
  "created_at" : "2012-09-01 21:32:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]