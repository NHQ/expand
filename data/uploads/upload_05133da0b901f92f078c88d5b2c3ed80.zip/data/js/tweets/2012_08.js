Grailbird.data.tweets_2012_08 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "241587161030352896",
  "text" : "RT @AncientProverbs: The loveliest of faces are to be seen by moonlight, when one sees half with the eye &amp; half with the fancy. -Per ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "241580186901045248",
    "text" : "The loveliest of faces are to be seen by moonlight, when one sees half with the eye &amp; half with the fancy. -Persian Proverb",
    "id" : 241580186901045248,
    "created_at" : "2012-08-31 16:56:19 +0000",
    "user" : {
      "name" : "Sports Motivation",
      "screen_name" : "Sports_HQ",
      "protected" : false,
      "id_str" : "139986343",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2679035753\/b0d2eb7d0b01e7381bd8ca944b055f60_normal.jpeg",
      "id" : 139986343,
      "verified" : false
    }
  },
  "id" : 241587161030352896,
  "created_at" : "2012-08-31 17:24:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 45, 52 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "241332880796708864",
  "geo" : { },
  "id_str" : "241337201500241921",
  "in_reply_to_user_id" : 14690653,
  "text" : "eyes and ears, I can barely pick up anything @regisl",
  "id" : 241337201500241921,
  "in_reply_to_status_id" : 241332880796708864,
  "created_at" : "2012-08-31 00:50:47 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240988628979957761",
  "text" : "My favorite part about watching video tutorials for hacking is the sound of mouse and keyboard buttons being pressed.",
  "id" : 240988628979957761,
  "created_at" : "2012-08-30 01:45:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240945224061431808",
  "text" : "It's way more fun to write programs than code them.",
  "id" : 240945224061431808,
  "created_at" : "2012-08-29 22:53:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240633748541022208",
  "text" : "sometimes my dog is at a loss to express in full her love for me",
  "id" : 240633748541022208,
  "created_at" : "2012-08-29 02:15:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240297083377164288",
  "text" : "\"Talkin bout yr daughter, a-like a gentleman oughta.\"",
  "id" : 240297083377164288,
  "created_at" : "2012-08-28 03:57:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240256290515992578",
  "text" : "Let me take that off your mind, and give you to something else to think about.",
  "id" : 240256290515992578,
  "created_at" : "2012-08-28 01:15:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240250211560218624",
  "text" : "i got next",
  "id" : 240250211560218624,
  "created_at" : "2012-08-28 00:51:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 25 ],
      "url" : "http:\/\/t.co\/OEiq2WyN",
      "expanded_url" : "http:\/\/app.net",
      "display_url" : "app.net"
    } ]
  },
  "geo" : { },
  "id_str" : "240249915777884162",
  "text" : "look http:\/\/t.co\/OEiq2WyN what became of your uncle diaspora",
  "id" : 240249915777884162,
  "created_at" : "2012-08-28 00:50:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240241721605242881",
  "text" : "Answer yourself why you really need to be wearing pants right now.",
  "id" : 240241721605242881,
  "created_at" : "2012-08-28 00:17:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julien Genestoux",
      "screen_name" : "julien51",
      "indices" : [ 0, 9 ],
      "id_str" : "5381582",
      "id" : 5381582
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "duh",
      "indices" : [ 134, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/gYO8ZpeN",
      "expanded_url" : "http:\/\/mydomain.com?s=blog.whatever.com",
      "display_url" : "mydomain.com\/?s=blog.whatev\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "240214288093040642",
  "in_reply_to_user_id" : 5381582,
  "text" : "@julien51 actually that link would be sub:\/\/blog.whatever.com\/subscribe ... and the browser would send you to http:\/\/t.co\/gYO8ZpeN... #duh",
  "id" : 240214288093040642,
  "created_at" : "2012-08-27 22:28:43 +0000",
  "in_reply_to_screen_name" : "julien51",
  "in_reply_to_user_id_str" : "5381582",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julien Genestoux",
      "screen_name" : "julien51",
      "indices" : [ 0, 9 ],
      "id_str" : "5381582",
      "id" : 5381582
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240186199971610625",
  "geo" : { },
  "id_str" : "240212782665068544",
  "in_reply_to_user_id" : 5381582,
  "text" : "@julien51 a) web app uses navigator.registerProtocolHandler. b) your blog \"subscribe\" button is a custom protocol sub:\/\/myappdomain.com?%s=",
  "id" : 240212782665068544,
  "in_reply_to_status_id" : 240186199971610625,
  "created_at" : "2012-08-27 22:22:44 +0000",
  "in_reply_to_screen_name" : "julien51",
  "in_reply_to_user_id_str" : "5381582",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 39, 46 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "240162066827206656",
  "geo" : { },
  "id_str" : "240162503043207168",
  "in_reply_to_user_id" : 14690653,
  "text" : "Plz explain how to do that @mana_horse @regisl",
  "id" : 240162503043207168,
  "in_reply_to_status_id" : 240162066827206656,
  "created_at" : "2012-08-27 19:02:57 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "240149406664495104",
  "text" : "RT @IAM_SHAKESPEARE: He was the author, thou the instrument.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "240149185008136192",
    "text" : "He was the author, thou the instrument.",
    "id" : 240149185008136192,
    "created_at" : "2012-08-27 18:10:02 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 240149406664495104,
  "created_at" : "2012-08-27 18:10:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 10, 19 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239888459504963586",
  "geo" : { },
  "id_str" : "239893704737968128",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden @substack ok somebody meet me at my compound to load plywood between now and then.",
  "id" : 239893704737968128,
  "in_reply_to_status_id" : 239888459504963586,
  "created_at" : "2012-08-27 01:14:50 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 10, 19 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 20, 29 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239884682890711040",
  "geo" : { },
  "id_str" : "239888258950111232",
  "in_reply_to_user_id" : 12241752,
  "text" : "what ime? @maxogden @substack",
  "id" : 239888258950111232,
  "in_reply_to_status_id" : 239884682890711040,
  "created_at" : "2012-08-27 00:53:12 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 93, 102 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Gather.at",
      "screen_name" : "gather",
      "indices" : [ 103, 110 ],
      "id_str" : "570467894",
      "id" : 570467894
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "testPassed",
      "indices" : [ 81, 92 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "239876803269894147",
  "geo" : { },
  "id_str" : "239881648009801729",
  "in_reply_to_user_id" : 12241752,
  "text" : "The directional arrow is a nice touch. It stayed true as I spun around in place. #testPassed @maxogden @gather",
  "id" : 239881648009801729,
  "in_reply_to_status_id" : 239876803269894147,
  "created_at" : "2012-08-27 00:26:56 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239813753502322689",
  "text" : "That is a new post by me (dev blog) to be followed up soon by another post on mostmodernist web application architecture",
  "id" : 239813753502322689,
  "created_at" : "2012-08-26 19:57:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/WYcOMnsV",
      "expanded_url" : "http:\/\/thehill.com\/conventions-2012\/gop-convention-tampa\/245329-threats-from-anarchists-lock-down-city",
      "display_url" : "thehill.com\/conventions-20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "239779590577463296",
  "text" : "Wow. Free speech zones. Protection against sea attack. The RNC  convention. 'we're practicing free speech too' http:\/\/t.co\/WYcOMnsV",
  "id" : 239779590577463296,
  "created_at" : "2012-08-26 17:41:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239521410811314176",
  "text" : "REST IN SPACE",
  "id" : 239521410811314176,
  "created_at" : "2012-08-26 00:35:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "239518179162984448",
  "text" : "FRAMEWORKS ARE JAILBAIT",
  "id" : 239518179162984448,
  "created_at" : "2012-08-26 00:22:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238759004036276225",
  "text" : "COGITO MUCHO ERGO SUMO",
  "id" : 238759004036276225,
  "created_at" : "2012-08-23 22:05:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238453833464967169",
  "geo" : { },
  "id_str" : "238454893130678273",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden YOU HAVE MY @",
  "id" : 238454893130678273,
  "in_reply_to_status_id" : 238453833464967169,
  "created_at" : "2012-08-23 01:57:31 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/dibyfW4h",
      "expanded_url" : "http:\/\/venturebeat.files.wordpress.com\/2012\/08\/nodejs.jpg",
      "display_url" : "venturebeat.files.wordpress.com\/2012\/08\/nodejs\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "238126267986243584",
  "text" : "I might as well make this my resume http:\/\/t.co\/dibyfW4h",
  "id" : 238126267986243584,
  "created_at" : "2012-08-22 04:11:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 34, 48 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238087328764153856",
  "geo" : { },
  "id_str" : "238112932108566528",
  "in_reply_to_user_id" : 29255412,
  "text" : "\"Gut genug\", as the German's say. @tjholowaychuk",
  "id" : 238112932108566528,
  "in_reply_to_status_id" : 238087328764153856,
  "created_at" : "2012-08-22 03:18:41 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 46, 60 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "238035951534866432",
  "text" : "it is easy to follow the footsteps of a giant @tjholowaychuk",
  "id" : 238035951534866432,
  "created_at" : "2012-08-21 22:12:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 25, 34 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Visnu Pitiyanuvath",
      "screen_name" : "visnup",
      "indices" : [ 35, 42 ],
      "id_str" : "6121912",
      "id" : 6121912
    }, {
      "name" : "Charlie Robbins",
      "screen_name" : "indexzero",
      "indices" : [ 43, 53 ],
      "id_str" : "13696102",
      "id" : 13696102
    }, {
      "name" : "Nuno Job (\u041D\u0443\u043D\u043E \u0414\u0436\u043E\u0431)",
      "screen_name" : "dscape",
      "indices" : [ 54, 61 ],
      "id_str" : "9279552",
      "id" : 9279552
    }, {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 62, 76 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238030993322303488",
  "geo" : { },
  "id_str" : "238031664431915008",
  "in_reply_to_user_id" : 12241752,
  "text" : "needs more document dump @maxogden @visnup @indexzero @dscape @tjholowaychuk",
  "id" : 238031664431915008,
  "in_reply_to_status_id" : 238030993322303488,
  "created_at" : "2012-08-21 21:55:45 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 47, 56 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "Visnu Pitiyanuvath",
      "screen_name" : "visnup",
      "indices" : [ 57, 64 ],
      "id_str" : "6121912",
      "id" : 6121912
    }, {
      "name" : "Charlie Robbins",
      "screen_name" : "indexzero",
      "indices" : [ 65, 75 ],
      "id_str" : "13696102",
      "id" : 13696102
    }, {
      "name" : "Nuno Job (\u041D\u0443\u043D\u043E \u0414\u0436\u043E\u0431)",
      "screen_name" : "dscape",
      "indices" : [ 76, 83 ],
      "id_str" : "9279552",
      "id" : 9279552
    }, {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 84, 98 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "238027893626773505",
  "geo" : { },
  "id_str" : "238030740049252354",
  "in_reply_to_user_id" : 12241752,
  "text" : "where is the NPM data, what does it look like? @maxogden @visnup @indexzero @dscape @tjholowaychuk",
  "id" : 238030740049252354,
  "in_reply_to_status_id" : 238027893626773505,
  "created_at" : "2012-08-21 21:52:05 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 34, 43 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237768250212089857",
  "geo" : { },
  "id_str" : "237783064372183041",
  "in_reply_to_user_id" : 12241752,
  "text" : "u wanna kick the drums some more? @maxogden",
  "id" : 237783064372183041,
  "in_reply_to_status_id" : 237768250212089857,
  "created_at" : "2012-08-21 05:27:55 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 44, 53 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 54, 63 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237674547527172096",
  "text" : "I need to drop off these tools, then scraps @maxogden @substack somebody else is on epoxy r&amp;d.",
  "id" : 237674547527172096,
  "created_at" : "2012-08-20 22:16:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 12, 21 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237650984044744704",
  "geo" : { },
  "id_str" : "237651823811497985",
  "in_reply_to_user_id" : 12241752,
  "text" : "REPRESENT N @maxogden",
  "id" : 237651823811497985,
  "in_reply_to_status_id" : 237650984044744704,
  "created_at" : "2012-08-20 20:46:24 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryah",
      "screen_name" : "ryah",
      "indices" : [ 116, 121 ],
      "id_str" : "967076702",
      "id" : 967076702
    }, {
      "name" : "Jerry Jones",
      "screen_name" : "riverofdoubt",
      "indices" : [ 122, 135 ],
      "id_str" : "97794798",
      "id" : 97794798
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/bxI4BOHs",
      "expanded_url" : "http:\/\/www.eastvillageradio.com\/shows\/nowplaying.aspx?contentid=20406&showid=337612&NowPlaying=0",
      "display_url" : "eastvillageradio.com\/shows\/nowplayi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "237650995277070337",
  "text" : "I ENDORSE THIS CRUNK IN PLACE OF YOUR USUAL AFTERNOON PEP SMACK http:\/\/t.co\/bxI4BOHs intro song == poser bounce cc\/ @ryah @riverofdoubt",
  "id" : 237650995277070337,
  "created_at" : "2012-08-20 20:43:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 31, 35 ],
      "id_str" : "8038312",
      "id" : 8038312
    }, {
      "name" : "ryah",
      "screen_name" : "ryah",
      "indices" : [ 36, 41 ],
      "id_str" : "967076702",
      "id" : 967076702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237631266483208192",
  "geo" : { },
  "id_str" : "237632364153544704",
  "in_reply_to_user_id" : 8038312,
  "text" : "my mind's biceps beg to differ @izs @ryah",
  "id" : 237632364153544704,
  "in_reply_to_status_id" : 237631266483208192,
  "created_at" : "2012-08-20 19:29:05 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237627961057095680",
  "text" : "There's only 8 bits between hire and ire",
  "id" : 237627961057095680,
  "created_at" : "2012-08-20 19:11:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 23, 32 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 33, 42 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/A4SMVjIT",
      "expanded_url" : "http:\/\/imgur.com\/fWCmS",
      "display_url" : "imgur.com\/fWCmS"
    } ]
  },
  "geo" : { },
  "id_str" : "237616112538374145",
  "text" : "gots plenty of plywood @maxogden @substack possible viking nose-cone prototype? http:\/\/t.co\/A4SMVjIT from the downed glider.",
  "id" : 237616112538374145,
  "created_at" : "2012-08-20 18:24:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Generating Bankroll",
      "screen_name" : "reptoddakin",
      "indices" : [ 104, 116 ],
      "id_str" : "2504632310",
      "id" : 2504632310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/sthWcS41",
      "expanded_url" : "http:\/\/www.latimes.com\/news\/politics\/la-pn-rep-todd-akin-no-pregnancy-from-legitimate-rape-20120819,0,7447581.story",
      "display_url" : "latimes.com\/news\/politics\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "237353409097920514",
  "text" : "The fembody politic! RT @AngieMacMcA The female body also has ways of shutting down your whole election @RepToddAkin http:\/\/t.co\/sthWcS41",
  "id" : 237353409097920514,
  "created_at" : "2012-08-20 01:00:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237333780573073409",
  "text" : "Krunk &amp; Vacuum",
  "id" : 237333780573073409,
  "created_at" : "2012-08-19 23:42:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teddy Cross",
      "screen_name" : "tkazec",
      "indices" : [ 103, 110 ],
      "id_str" : "172619774",
      "id" : 172619774
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237302814508990464",
  "geo" : { },
  "id_str" : "237304249619460097",
  "in_reply_to_user_id" : 172619774,
  "text" : "great, I could use a hash of every possible substring, please spit it out into a json file for me. thx @tkazec",
  "id" : 237304249619460097,
  "in_reply_to_status_id" : 237302814508990464,
  "created_at" : "2012-08-19 21:45:16 +0000",
  "in_reply_to_screen_name" : "tkazec",
  "in_reply_to_user_id_str" : "172619774",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 72, 79 ],
      "id_str" : "14690653",
      "id" : 14690653
    }, {
      "name" : "TIMESCANNER",
      "screen_name" : "timescanner",
      "indices" : [ 80, 92 ],
      "id_str" : "32769498",
      "id" : 32769498
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237302236223533056",
  "geo" : { },
  "id_str" : "237302653141544960",
  "in_reply_to_user_id" : 14690653,
  "text" : "I HAD A VISION OF TWITTER BECOMING THE WORLDS LARGEST DIGITAL LARP FEST @regisl @TIMESCANNER",
  "id" : 237302653141544960,
  "in_reply_to_status_id" : 237302236223533056,
  "created_at" : "2012-08-19 21:38:56 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Open Culture",
      "screen_name" : "openculture",
      "indices" : [ 109, 121 ],
      "id_str" : "19826509",
      "id" : 19826509
    }, {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 122, 138 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/LwtvcRgl",
      "expanded_url" : "http:\/\/www.openculture.com\/2010\/03\/mark_twain_captured_on_film_by_thomas_edison_1909.html",
      "display_url" : "openculture.com\/2010\/03\/mark_t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "237301994660954112",
  "text" : "THOMAS EDISON AND MARK TWAIN INVENT NOW CLASSIC BIT IN ONLY KNOWN FOOTAGE OF THE LATTER http:\/\/t.co\/LwtvcRgl @openculture @AngelineGragzin",
  "id" : 237301994660954112,
  "created_at" : "2012-08-19 21:36:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 0, 9 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237299988223373313",
  "in_reply_to_user_id" : 12241752,
  "text" : "@maxogden May I come over early and code in space?",
  "id" : 237299988223373313,
  "created_at" : "2012-08-19 21:28:20 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237268950919049216",
  "text" : "working on some rilly real shit",
  "id" : 237268950919049216,
  "created_at" : "2012-08-19 19:25:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "getify",
      "screen_name" : "getify",
      "indices" : [ 11, 18 ],
      "id_str" : "16686076",
      "id" : 16686076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237247809978523648",
  "geo" : { },
  "id_str" : "237247965608173569",
  "in_reply_to_user_id" : 16686076,
  "text" : "old yahoos @getify",
  "id" : 237247965608173569,
  "in_reply_to_status_id" : 237247809978523648,
  "created_at" : "2012-08-19 18:01:37 +0000",
  "in_reply_to_screen_name" : "getify",
  "in_reply_to_user_id_str" : "16686076",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "getify",
      "screen_name" : "getify",
      "indices" : [ 47, 54 ],
      "id_str" : "16686076",
      "id" : 16686076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237243627376631808",
  "geo" : { },
  "id_str" : "237247636527255552",
  "in_reply_to_user_id" : 16686076,
  "text" : "that's what you get trying to work with yahoos @getify",
  "id" : 237247636527255552,
  "in_reply_to_status_id" : 237243627376631808,
  "created_at" : "2012-08-19 18:00:19 +0000",
  "in_reply_to_screen_name" : "getify",
  "in_reply_to_user_id_str" : "16686076",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237042398428004352",
  "text" : "git night",
  "id" : 237042398428004352,
  "created_at" : "2012-08-19 04:24:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/TVJfE6kp",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=zMAe31FFHbo",
      "display_url" : "youtube.com\/watch?v=zMAe31\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "237040885613858817",
  "text" : "for purely metaphysical purposes I might listen to this song 20 times tonight http:\/\/t.co\/TVJfE6kp",
  "id" : 237040885613858817,
  "created_at" : "2012-08-19 04:18:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryah",
      "screen_name" : "ryah",
      "indices" : [ 0, 5 ],
      "id_str" : "967076702",
      "id" : 967076702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 26 ],
      "url" : "http:\/\/t.co\/FcmPzgL1",
      "expanded_url" : "http:\/\/www.eastvillageradio.com\/shows\/player\/main.php?p=20406&f=20406-131158-20120726",
      "display_url" : "eastvillageradio.com\/shows\/player\/m\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "237038712532373504",
  "text" : "@ryah http:\/\/t.co\/FcmPzgL1",
  "id" : 237038712532373504,
  "created_at" : "2012-08-19 04:10:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/1ZOpKJLx",
      "expanded_url" : "http:\/\/johnnyscript.us\/#message",
      "display_url" : "johnnyscript.us\/#message"
    } ]
  },
  "geo" : { },
  "id_str" : "237034574021021698",
  "text" : "somebody is sexting me from my website but they are enjoying anonymity http:\/\/t.co\/1ZOpKJLx",
  "id" : 237034574021021698,
  "created_at" : "2012-08-19 03:53:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237031912118566912",
  "text" : "Yes I captured video of the performance. David Lynch is a poser.",
  "id" : 237031912118566912,
  "created_at" : "2012-08-19 03:43:06 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237031430042050560",
  "text" : "True story : 1hr ago I walked across the street to the smallest music festival wherein the inch-for-inch best rapper performed. Bought CD.",
  "id" : 237031430042050560,
  "created_at" : "2012-08-19 03:41:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryah",
      "screen_name" : "ryah",
      "indices" : [ 115, 120 ],
      "id_str" : "967076702",
      "id" : 967076702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237030298959888384",
  "text" : "what do you want future bass, ninja tune, glitch, psych, downtempo, afro, trip, space, ambient... kraftwerk, what? @ryah",
  "id" : 237030298959888384,
  "created_at" : "2012-08-19 03:36:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryah",
      "screen_name" : "ryah",
      "indices" : [ 75, 80 ],
      "id_str" : "967076702",
      "id" : 967076702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237029178422210561",
  "text" : "what kind of music you looking for? I bet I can return you something fresh @ryah",
  "id" : 237029178422210561,
  "created_at" : "2012-08-19 03:32:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237027894449303552",
  "text" : "if ( !tooLate &amp;&amp; typeof melancholy == nostalgia for heartache ) return return return",
  "id" : 237027894449303552,
  "created_at" : "2012-08-19 03:27:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 35, 49 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "237015865856499712",
  "text" : "Not based on personal experience.  @tjholowaychuk",
  "id" : 237015865856499712,
  "created_at" : "2012-08-19 02:39:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 95, 109 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237014120300433411",
  "geo" : { },
  "id_str" : "237015530786140161",
  "in_reply_to_user_id" : 29255412,
  "text" : "I think they appreciate where home is after a little while. But they can drown in your toilet. @tjholowaychuk",
  "id" : 237015530786140161,
  "in_reply_to_status_id" : 237014120300433411,
  "created_at" : "2012-08-19 02:38:00 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 64, 78 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237013094780526593",
  "geo" : { },
  "id_str" : "237013598721949696",
  "in_reply_to_user_id" : 29255412,
  "text" : "They will chill out on your shoulder and in your breast pocket. @tjholowaychuk",
  "id" : 237013598721949696,
  "in_reply_to_status_id" : 237013094780526593,
  "created_at" : "2012-08-19 02:30:20 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 70, 79 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "237006003865018368",
  "geo" : { },
  "id_str" : "237012212806467584",
  "in_reply_to_user_id" : 12241752,
  "text" : "var obj = \u007B 'is cat alive?' : undefined, 'is cat dead?' : undefined \u007D @maxogden",
  "id" : 237012212806467584,
  "in_reply_to_status_id" : 237006003865018368,
  "created_at" : "2012-08-19 02:24:49 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/pXngHm7H",
      "expanded_url" : "http:\/\/www.technologyreview.com\/view\/428920\/the-emerging-revolution-in-game-theory\/?ref=rss",
      "display_url" : "technologyreview.com\/view\/428920\/th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "236929381795246080",
  "text" : "Vindication never made me so angry. Game theory has other, better strategies than ruining it for others? WELL FUCK ME  http:\/\/t.co\/pXngHm7H",
  "id" : 236929381795246080,
  "created_at" : "2012-08-18 20:55:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 86 ],
      "url" : "https:\/\/t.co\/MzvXfMxF",
      "expanded_url" : "https:\/\/plus.google.com\/105358765853568784679\/about?gl=us&hl=en",
      "display_url" : "plus.google.com\/10535876585356\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "236897638358863873",
  "text" : "Hack y Sandwich at Woody's across from the Parkway in 30 minutes https:\/\/t.co\/MzvXfMxF",
  "id" : 236897638358863873,
  "created_at" : "2012-08-18 18:49:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prop37",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/98LV7ad1",
      "expanded_url" : "http:\/\/www.rawstory.com\/rs\/2012\/08\/15\/monsanto-donates-4-2-million-to-defeat-california-gmo-labeling-initiative\/",
      "display_url" : "rawstory.com\/rs\/2012\/08\/15\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "236893057713319936",
  "text" : "Monsanto, DOW Chemicals, Coca-Cola putting millions into campaign against labeling GMO produce in California #prop37 http:\/\/t.co\/98LV7ad1",
  "id" : 236893057713319936,
  "created_at" : "2012-08-18 18:31:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "IFTTT",
      "screen_name" : "IFTTT",
      "indices" : [ 26, 32 ],
      "id_str" : "75079616",
      "id" : 75079616
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236890213652246528",
  "text" : "I completely forgot about @IFTTT. Was a great idea to start and seems to have a come a long way. Gonna try it out.",
  "id" : 236890213652246528,
  "created_at" : "2012-08-18 18:20:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GitHub",
      "screen_name" : "github",
      "indices" : [ 62, 69 ],
      "id_str" : "13334762",
      "id" : 13334762
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236881289859440640",
  "text" : "make it so I can follow a person from any of their repo pages @github don't make me go to their \"front page\"",
  "id" : 236881289859440640,
  "created_at" : "2012-08-18 17:44:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236734764189638656",
  "text" : "RT @IAM_SHAKESPEARE: That Clifford's manhood lies upon his tongue.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "236734179868553217",
    "text" : "That Clifford's manhood lies upon his tongue.",
    "id" : 236734179868553217,
    "created_at" : "2012-08-18 08:00:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 236734764189638656,
  "created_at" : "2012-08-18 08:02:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236615063774044160",
  "text" : "It's not where you're from, it's where you absorb APIs",
  "id" : 236615063774044160,
  "created_at" : "2012-08-18 00:06:41 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236604574234996736",
  "text" : "Uh oh. In this parable I am defeated by the machine.",
  "id" : 236604574234996736,
  "created_at" : "2012-08-17 23:25:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Diaz",
      "screen_name" : "ded",
      "indices" : [ 105, 109 ],
      "id_str" : "1199081",
      "id" : 1199081
    }, {
      "name" : "Ev Williams",
      "screen_name" : "ev",
      "indices" : [ 110, 113 ],
      "id_str" : "20",
      "id" : 20
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "236598324751388672",
  "geo" : { },
  "id_str" : "236602220584509440",
  "in_reply_to_user_id" : 1199081,
  "text" : "In 6 yrs web development I have never supported IE8. I went straight expert JS, HTML5, CSS, SVG, Node.js @ded @ev It was most def. obvious",
  "id" : 236602220584509440,
  "in_reply_to_status_id" : 236598324751388672,
  "created_at" : "2012-08-17 23:15:39 +0000",
  "in_reply_to_screen_name" : "ded",
  "in_reply_to_user_id_str" : "1199081",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236537745437237248",
  "text" : "I've got 4 * 4096 IPv6 addresses who wants one?",
  "id" : 236537745437237248,
  "created_at" : "2012-08-17 18:59:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Galligan",
      "screen_name" : "mg",
      "indices" : [ 10, 13 ],
      "id_str" : "607",
      "id" : 607
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236516940716322817",
  "text" : "greetings @mg",
  "id" : 236516940716322817,
  "created_at" : "2012-08-17 17:36:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236349029003448321",
  "text" : "Switching to IPv6, mother suckers",
  "id" : 236349029003448321,
  "created_at" : "2012-08-17 06:29:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236332158577422336",
  "text" : "Last night I put a boat up in a tree. They don't teach you that.",
  "id" : 236332158577422336,
  "created_at" : "2012-08-17 05:22:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/qQjnHHRD",
      "expanded_url" : "http:\/\/wurstcaptures.untergrund.net\/music\/",
      "display_url" : "wurstcaptures.untergrund.net\/music\/"
    } ]
  },
  "geo" : { },
  "id_str" : "236329752644964352",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack you've probably seen this http:\/\/t.co\/qQjnHHRD",
  "id" : 236329752644964352,
  "created_at" : "2012-08-17 05:12:58 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HACKHACKHACKHACK",
      "indices" : [ 110, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236260852053966849",
  "text" : "BUT SO MANY MORE BUSY, IMPORTANT, STUDICIOUS PEOPLE NEED TO IGNORE A MESSAGE FROM ME BEFORE TWITTER IMPLODES! #HACKHACKHACKHACK",
  "id" : 236260852053966849,
  "created_at" : "2012-08-17 00:39:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236193915148042240",
  "text" : "My apologies for trivializing your feed. Don't mention it.",
  "id" : 236193915148042240,
  "created_at" : "2012-08-16 20:13:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "homos",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236193173330853888",
  "text" : "It is impossible to (under-) estimate the effect the hand, as a tool, had on the evolution of the brain and mind. #homos",
  "id" : 236193173330853888,
  "created_at" : "2012-08-16 20:10:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236189658768343040",
  "text" : "Would you trade a hand for a third half brain?",
  "id" : 236189658768343040,
  "created_at" : "2012-08-16 19:56:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236185457266933761",
  "text" : "On the other hand (as I am adequate with both) I solved the riddle of the free, open, decentralized 'net, which I must by writes distill.",
  "id" : 236185457266933761,
  "created_at" : "2012-08-16 19:39:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236173819868483584",
  "text" : "Later, I may finish writing about my years working at dozens of the absolute worst public schools in the country.",
  "id" : 236173819868483584,
  "created_at" : "2012-08-16 18:53:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236173349192077312",
  "text" : "I'm going to practice my non-dominant hand mechanics now by throwing rocks in the marina with Coco.",
  "id" : 236173349192077312,
  "created_at" : "2012-08-16 18:51:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Guillermo Rauch",
      "screen_name" : "rauchg",
      "indices" : [ 54, 61 ],
      "id_str" : "15540222",
      "id" : 15540222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236171792115445760",
  "text" : "I'm going to Learnboost's Ed-Tech meetup tonight. cc\/ @rauchg",
  "id" : 236171792115445760,
  "created_at" : "2012-08-16 18:45:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "femtography",
      "indices" : [ 8, 20 ]
    } ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/K8ZgIEmE",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=SoHeWgLvlXI&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=SoHeWg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "236166491970625536",
  "text" : "call it #femtography Briefly mentioned in the  vid, the timing methods used to achieve the effect is  really clever. http:\/\/t.co\/K8ZgIEmE",
  "id" : 236166491970625536,
  "created_at" : "2012-08-16 18:24:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "236160583144189953",
  "text" : "I was not plucked from the masses.",
  "id" : 236160583144189953,
  "created_at" : "2012-08-16 18:00:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 9, 18 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 19, 28 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235955727221530624",
  "geo" : { },
  "id_str" : "235956009171030016",
  "in_reply_to_user_id" : 12241752,
  "text" : "YOU ARE? @maxogden @substack",
  "id" : 235956009171030016,
  "in_reply_to_status_id" : 235955727221530624,
  "created_at" : "2012-08-16 04:27:51 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 69, 76 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235917798809935874",
  "geo" : { },
  "id_str" : "235919564792283138",
  "in_reply_to_user_id" : 14690653,
  "text" : "It's not an acquired taste. But you might like it when you're older. @regisl",
  "id" : 235919564792283138,
  "in_reply_to_status_id" : 235917798809935874,
  "created_at" : "2012-08-16 02:03:02 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 69, 76 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235915573010259968",
  "geo" : { },
  "id_str" : "235916591638921217",
  "in_reply_to_user_id" : 14690653,
  "text" : "test your bridges under the weight of nonsense and misunderstandings @regisl",
  "id" : 235916591638921217,
  "in_reply_to_status_id" : 235915573010259968,
  "created_at" : "2012-08-16 01:51:13 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kimmy",
      "screen_name" : "arealliveghost",
      "indices" : [ 34, 49 ],
      "id_str" : "407895022",
      "id" : 407895022
    }, {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 50, 57 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235914969340846080",
  "geo" : { },
  "id_str" : "235915408836812802",
  "in_reply_to_user_id" : 407895022,
  "text" : "a limited edition with foil cover @aRealLiveGhost @regisl",
  "id" : 235915408836812802,
  "in_reply_to_status_id" : 235914969340846080,
  "created_at" : "2012-08-16 01:46:31 +0000",
  "in_reply_to_screen_name" : "arealliveghost",
  "in_reply_to_user_id_str" : "407895022",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Bella",
      "screen_name" : "katbella5",
      "indices" : [ 3, 13 ],
      "id_str" : "104772730",
      "id" : 104772730
    }, {
      "name" : "astromanies",
      "screen_name" : "astromanies",
      "indices" : [ 15, 27 ],
      "id_str" : "2588933322",
      "id" : 2588933322
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235901149193056257",
  "text" : "RT @katbella5: @astromanies your tweets make me laugh AND GIVE MEANING TO MY LIFE!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "astromanies",
        "screen_name" : "astromanies",
        "indices" : [ 0, 12 ],
        "id_str" : "2588933322",
        "id" : 2588933322
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "235651639967629312",
    "geo" : { },
    "id_str" : "235774760989126656",
    "in_reply_to_user_id" : 46961216,
    "text" : "@astromanies your tweets make me laugh AND GIVE MEANING TO MY LIFE!",
    "id" : 235774760989126656,
    "in_reply_to_status_id" : 235651639967629312,
    "created_at" : "2012-08-15 16:27:38 +0000",
    "in_reply_to_screen_name" : "johnnyscript",
    "in_reply_to_user_id_str" : "46961216",
    "user" : {
      "name" : "Kat Bella",
      "screen_name" : "katbella5",
      "protected" : false,
      "id_str" : "104772730",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3460549302\/e156cdbeac8b7c42a911d38d9f2225b0_normal.jpeg",
      "id" : 104772730,
      "verified" : false
    }
  },
  "id" : 235901149193056257,
  "created_at" : "2012-08-16 00:49:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kat Bella",
      "screen_name" : "katbella5",
      "indices" : [ 30, 40 ],
      "id_str" : "104772730",
      "id" : 104772730
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235901112509677568",
  "text" : "She enjoys reading my code! \u2665 @katbella5 \u2665 IM SO EMBARRASSED!",
  "id" : 235901112509677568,
  "created_at" : "2012-08-16 00:49:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 114, 123 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 124, 133 ],
      "id_str" : "125027291",
      "id" : 125027291
    }, {
      "name" : "icz",
      "screen_name" : "icz",
      "indices" : [ 134, 138 ],
      "id_str" : "14156100",
      "id" : 14156100
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "portents",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235897359106732032",
  "text" : "gather at weekly beers boats and bonfires @ Marina's Tea House evidence of extra flame burnings tonight #portents @maxogden @substack @icz",
  "id" : 235897359106732032,
  "created_at" : "2012-08-16 00:34:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HipHopChess",
      "screen_name" : "hiphopchess",
      "indices" : [ 58, 70 ],
      "id_str" : "7295172",
      "id" : 7295172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/KAt8qVIC",
      "expanded_url" : "http:\/\/hiphopchess.blogspot.com\/2012\/07\/in-shadow-of-sun-tzu-chess-jiu-jitsu.html",
      "display_url" : "hiphopchess.blogspot.com\/2012\/07\/in-sha\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "235894696851939328",
  "text" : "I liked your essay on zugzwang, Mang http:\/\/t.co\/KAt8qVIC @hiphopchess Me I'm zo zugzwang I let mating take its course naturally.",
  "id" : 235894696851939328,
  "created_at" : "2012-08-16 00:24:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235651639967629312",
  "text" : "And any other, less handsome text you might write.",
  "id" : 235651639967629312,
  "created_at" : "2012-08-15 08:18:23 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235651415291330560",
  "text" : "I'm going to edit a javascript verse I started earlier this year, which renders its own text perfectly legible in every unique context.",
  "id" : 235651415291330560,
  "created_at" : "2012-08-15 08:17:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235650679421681664",
  "text" : "GONNA WRITE SOME JAVASCRIPT NOW",
  "id" : 235650679421681664,
  "created_at" : "2012-08-15 08:14:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235650450299432960",
  "text" : "Better cover my tracks.",
  "id" : 235650450299432960,
  "created_at" : "2012-08-15 08:13:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235649649468403712",
  "text" : "I die in the afternoon as well and sometimes  evenings after a long walk.",
  "id" : 235649649468403712,
  "created_at" : "2012-08-15 08:10:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235649377954299905",
  "text" : "Life is too much. That is why we die each night.",
  "id" : 235649377954299905,
  "created_at" : "2012-08-15 08:09:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "indices" : [ 3, 12 ],
      "id_str" : "141834186",
      "id" : 141834186
    }, {
      "name" : "Josh Harkinson",
      "screen_name" : "JoshHarkinson",
      "indices" : [ 56, 70 ],
      "id_str" : "148900525",
      "id" : 148900525
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chalkupy",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/r50URqAs",
      "expanded_url" : "http:\/\/www.motherjones.com\/politics\/2012\/08\/war-chalk-arrests",
      "display_url" : "motherjones.com\/politics\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "235649053457784832",
  "text" : "RT @FearDept: We're arresting people as fast as we can. @JoshHarkinson describes the scope of the #chalkupy crisis: http:\/\/t.co\/r50URqAs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Josh Harkinson",
        "screen_name" : "JoshHarkinson",
        "indices" : [ 42, 56 ],
        "id_str" : "148900525",
        "id" : 148900525
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "chalkupy",
        "indices" : [ 84, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 102, 122 ],
        "url" : "http:\/\/t.co\/r50URqAs",
        "expanded_url" : "http:\/\/www.motherjones.com\/politics\/2012\/08\/war-chalk-arrests",
        "display_url" : "motherjones.com\/politics\/2012\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "235646658988359681",
    "text" : "We're arresting people as fast as we can. @JoshHarkinson describes the scope of the #chalkupy crisis: http:\/\/t.co\/r50URqAs",
    "id" : 235646658988359681,
    "created_at" : "2012-08-15 07:58:36 +0000",
    "user" : {
      "name" : "U.S. Dept. of Fear",
      "screen_name" : "FearDept",
      "protected" : false,
      "id_str" : "141834186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453113104939761664\/9ZqHHvvA_normal.png",
      "id" : 141834186,
      "verified" : false
    }
  },
  "id" : 235649053457784832,
  "created_at" : "2012-08-15 08:08:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Cohn",
      "screen_name" : "Digidave",
      "indices" : [ 102, 111 ],
      "id_str" : "6304662",
      "id" : 6304662
    }, {
      "name" : "Amy Webb",
      "screen_name" : "webbmedia",
      "indices" : [ 112, 122 ],
      "id_str" : "9500242",
      "id" : 9500242
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/OyhBkydu",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Adam_Curtis",
      "display_url" : "en.wikipedia.org\/wiki\/Adam_Curt\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "235491783734358016",
  "geo" : { },
  "id_str" : "235498594524884993",
  "in_reply_to_user_id" : 6304662,
  "text" : "I stopped breathing for a minute, hoping NYT had picked Adam Curtis to lead them http:\/\/t.co\/OyhBkydu @Digidave @webbmedia",
  "id" : 235498594524884993,
  "in_reply_to_status_id" : 235491783734358016,
  "created_at" : "2012-08-14 22:10:14 +0000",
  "in_reply_to_screen_name" : "Digidave",
  "in_reply_to_user_id_str" : "6304662",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235487430634004481",
  "text" : "Yes I am a Full Stack Artist",
  "id" : 235487430634004481,
  "created_at" : "2012-08-14 21:25:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryah",
      "screen_name" : "ryah",
      "indices" : [ 51, 56 ],
      "id_str" : "967076702",
      "id" : 967076702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235484697801666561",
  "text" : "i'm with you on that. I will add it to my rathers. @ryah Unfortunately, the civic sector can't sustain quality and care, in any industry.",
  "id" : 235484697801666561,
  "created_at" : "2012-08-14 21:15:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryah",
      "screen_name" : "ryah",
      "indices" : [ 31, 36 ],
      "id_str" : "967076702",
      "id" : 967076702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235470700440334336",
  "text" : "some of it yes, some of it not @ryah I'd rather have profitable hospitals than choking and broken. That article tries hard to be damning.",
  "id" : 235470700440334336,
  "created_at" : "2012-08-14 20:19:24 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 25, 34 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235457482758189056",
  "geo" : { },
  "id_str" : "235458853003743232",
  "in_reply_to_user_id" : 12241752,
  "text" : "ah as handcart good idea @maxogden",
  "id" : 235458853003743232,
  "in_reply_to_status_id" : 235457482758189056,
  "created_at" : "2012-08-14 19:32:19 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 119, 128 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235456443787124736",
  "text" : "It's a weak strongman challenge for 3 to carry, easy for 5. Put a call out? Who has a Sawsall? Twill be firewood soon. @maxogden",
  "id" : 235456443787124736,
  "created_at" : "2012-08-14 19:22:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 117, 126 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 127, 136 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "235452664396279808",
  "geo" : { },
  "id_str" : "235453321262018560",
  "in_reply_to_user_id" : 12241752,
  "text" : "shall I make as strong a claim for it as can be made in these parts, or should we hike it straight over to the shop? @maxogden @substack",
  "id" : 235453321262018560,
  "in_reply_to_status_id" : 235452664396279808,
  "created_at" : "2012-08-14 19:10:20 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 77, 86 ],
      "id_str" : "12241752",
      "id" : 12241752
    }, {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 87, 96 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/k8LUFSkh",
      "expanded_url" : "http:\/\/imgur.com\/a\/YEW79",
      "display_url" : "imgur.com\/a\/YEW79"
    } ]
  },
  "geo" : { },
  "id_str" : "235452337639022593",
  "text" : "30 ft. boat shaped thing washed up @ Marina's Tea House http:\/\/t.co\/k8LUFSkh @maxogden @substack",
  "id" : 235452337639022593,
  "created_at" : "2012-08-14 19:06:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235425665070026752",
  "text" : "Wondering how a \"Just in Case\" (JIC) compiled language could help me.",
  "id" : 235425665070026752,
  "created_at" : "2012-08-14 17:20:27 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235068100339433472",
  "text" : "\u266B I'm bringn sincerely baaack \u266B",
  "id" : 235068100339433472,
  "created_at" : "2012-08-13 17:39:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235065908232585216",
  "text" : "Cover letters should read like creative spam.",
  "id" : 235065908232585216,
  "created_at" : "2012-08-13 17:30:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235062282600734722",
  "text" : "WHOSITGONNABE",
  "id" : 235062282600734722,
  "created_at" : "2012-08-13 17:16:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "235059036846968833",
  "text" : "function hello_world_within_world (world)\n\u007B\n  for (world in world)\n  hello_world_within_world (world)\n\u007D",
  "id" : 235059036846968833,
  "created_at" : "2012-08-13 17:03:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 35, 39 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/4F46TGJ2",
      "expanded_url" : "http:\/\/imgur.com\/Bfstp",
      "display_url" : "imgur.com\/Bfstp"
    } ]
  },
  "geo" : { },
  "id_str" : "234114249432109056",
  "text" : "endgame saved http:\/\/t.co\/4F46TGJ2 @izs",
  "id" : 234114249432109056,
  "created_at" : "2012-08-11 02:29:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Directors Notes",
      "screen_name" : "WeAreDN",
      "indices" : [ 3, 11 ],
      "id_str" : "107678852",
      "id" : 107678852
    }, {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 13, 29 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "interview",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/uDBfgtQN",
      "expanded_url" : "http:\/\/j.mp\/P6rL4K",
      "display_url" : "j.mp\/P6rL4K"
    } ]
  },
  "geo" : { },
  "id_str" : "234103479860342785",
  "text" : "RT @WeAreDN: @AngelineGragzin joins DN for an #interview about her surreally great short THE ANIMALS http:\/\/t.co\/uDBfgtQN",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Angeline Gragasin",
        "screen_name" : "AngelineGragzin",
        "indices" : [ 0, 16 ],
        "id_str" : "58809542",
        "id" : 58809542
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "interview",
        "indices" : [ 33, 43 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/uDBfgtQN",
        "expanded_url" : "http:\/\/j.mp\/P6rL4K",
        "display_url" : "j.mp\/P6rL4K"
      } ]
    },
    "geo" : { },
    "id_str" : "234094299522953216",
    "in_reply_to_user_id" : 58809542,
    "text" : "@AngelineGragzin joins DN for an #interview about her surreally great short THE ANIMALS http:\/\/t.co\/uDBfgtQN",
    "id" : 234094299522953216,
    "created_at" : "2012-08-11 01:10:04 +0000",
    "in_reply_to_screen_name" : "AngelineGragzin",
    "in_reply_to_user_id_str" : "58809542",
    "user" : {
      "name" : "Directors Notes",
      "screen_name" : "WeAreDN",
      "protected" : false,
      "id_str" : "107678852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739577393\/DN_Logo_-_Large_Icon_normal.png",
      "id" : 107678852,
      "verified" : false
    }
  },
  "id" : 234103479860342785,
  "created_at" : "2012-08-11 01:46:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jed Schmidt",
      "screen_name" : "jedschmidt",
      "indices" : [ 86, 97 ],
      "id_str" : "815114",
      "id" : 815114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233820454073286657",
  "geo" : { },
  "id_str" : "233826503937380352",
  "in_reply_to_user_id" : 815114,
  "text" : "Is there some code that you must code if you seek publicly code which does not exist? @jedschmidt",
  "id" : 233826503937380352,
  "in_reply_to_status_id" : 233820454073286657,
  "created_at" : "2012-08-10 07:25:57 +0000",
  "in_reply_to_screen_name" : "jedschmidt",
  "in_reply_to_user_id_str" : "815114",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 97, 101 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233656866033520640",
  "text" : "Saw you in front of subrosa. Thought you were entering, but then you were gone. Location change? @izs",
  "id" : 233656866033520640,
  "created_at" : "2012-08-09 20:11:52 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233606521777442817",
  "text" : "I get a get a text messages with referrer data when my site is visited. That's what I call analytics.",
  "id" : 233606521777442817,
  "created_at" : "2012-08-09 16:51:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 87, 101 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233437355816673280",
  "geo" : { },
  "id_str" : "233447345075933184",
  "in_reply_to_user_id" : 29255412,
  "text" : "Is there a Component module for using \/ including these components? Is that the thing? @tjholowaychuk",
  "id" : 233447345075933184,
  "in_reply_to_status_id" : 233437355816673280,
  "created_at" : "2012-08-09 06:19:18 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 124, 138 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 123 ],
      "url" : "https:\/\/t.co\/I84Bg6kE",
      "expanded_url" : "https:\/\/github.com\/component\/dialog\/blob\/master\/index.js",
      "display_url" : "github.com\/component\/dial\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "233435138229403648",
  "text" : "How do you require('emitter')? package.json has dependency \"emitter-component\". Que component.json?   https:\/\/t.co\/I84Bg6kE @tjholowaychuk",
  "id" : 233435138229403648,
  "created_at" : "2012-08-09 05:30:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233419626304925696",
  "text" : "designs: make it big",
  "id" : 233419626304925696,
  "created_at" : "2012-08-09 04:29:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233418938476810240",
  "text" : "style: getting drunken",
  "id" : 233418938476810240,
  "created_at" : "2012-08-09 04:26:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233386162432126976",
  "text" : "sent tweet, took nap, woke up FTW",
  "id" : 233386162432126976,
  "created_at" : "2012-08-09 02:16:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 30, 34 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/QM9o8gMv",
      "expanded_url" : "http:\/\/johnnyscript.us",
      "display_url" : "johnnyscript.us"
    } ]
  },
  "in_reply_to_status_id_str" : "233337518999875584",
  "geo" : { },
  "id_str" : "233339732539617284",
  "in_reply_to_user_id" : 8038312,
  "text" : "try mine http:\/\/t.co\/QM9o8gMv @izs it's different",
  "id" : 233339732539617284,
  "in_reply_to_status_id" : 233337518999875584,
  "created_at" : "2012-08-08 23:11:42 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233335893275066370",
  "text" : "To her credit, she is a data miner.",
  "id" : 233335893275066370,
  "created_at" : "2012-08-08 22:56:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCHOOLOLOLO",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233334955529363456",
  "text" : "Grilled at interview by New Grad Engineer. How would you design SQL tables for this structured data, so you can look it up? #SCHOOLOLOLO",
  "id" : 233334955529363456,
  "created_at" : "2012-08-08 22:52:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marak",
      "screen_name" : "marak",
      "indices" : [ 18, 24 ],
      "id_str" : "110465841",
      "id" : 110465841
    }, {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 63, 79 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233094480192995329",
  "geo" : { },
  "id_str" : "233098086799519744",
  "in_reply_to_user_id" : 110465841,
  "text" : "I know how u feel @marak I'm tryna explain 128 bits of IPv6 to @AngelineGragzin  tho she didn't ask and ran away refusing to understand",
  "id" : 233098086799519744,
  "in_reply_to_status_id" : 233094480192995329,
  "created_at" : "2012-08-08 07:11:29 +0000",
  "in_reply_to_screen_name" : "marak",
  "in_reply_to_user_id_str" : "110465841",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "indices" : [ 3, 14 ],
      "id_str" : "122112121",
      "id" : 122112121
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233096581203755008",
  "text" : "RT @uptownherd: do you make music to express yourself? do you want to make a mark on society? fuck you!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233091279075045376",
    "text" : "do you make music to express yourself? do you want to make a mark on society? fuck you!",
    "id" : 233091279075045376,
    "created_at" : "2012-08-08 06:44:26 +0000",
    "user" : {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "protected" : false,
      "id_str" : "122112121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518645860863709184\/iHz-222r_normal.jpeg",
      "id" : 122112121,
      "verified" : false
    }
  },
  "id" : 233096581203755008,
  "created_at" : "2012-08-08 07:05:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "Fancy Hands",
      "screen_name" : "FancyHands",
      "indices" : [ 139, 140 ],
      "id_str" : "127026349",
      "id" : 127026349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "233082239825625088",
  "text" : "RT @AngelineGragzin: \"If you need a machine &amp; don\u2019t buy it, then you will ultimately find that you have paid for it &amp; don\u2019t have ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fancy Hands",
        "screen_name" : "FancyHands",
        "indices" : [ 137, 148 ],
        "id_str" : "127026349",
        "id" : 127026349
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "233081102875635712",
    "text" : "\"If you need a machine &amp; don\u2019t buy it, then you will ultimately find that you have paid for it &amp; don\u2019t have it\"\n- Henry Ford via @fancyhands",
    "id" : 233081102875635712,
    "created_at" : "2012-08-08 06:04:00 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 233082239825625088,
  "created_at" : "2012-08-08 06:08:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 41, 50 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233055125365743616",
  "geo" : { },
  "id_str" : "233081975861293056",
  "in_reply_to_user_id" : 12241752,
  "text" : "Is he interested in joining a startup??? @maxogden",
  "id" : 233081975861293056,
  "in_reply_to_status_id" : 233055125365743616,
  "created_at" : "2012-08-08 06:07:28 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 114, 128 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "233024816184164352",
  "geo" : { },
  "id_str" : "233080443208077312",
  "in_reply_to_user_id" : 29255412,
  "text" : "Are you officially out against constructors \/ prototypes? This demands attention. I no longer have to be ashamed! @tjholowaychuk",
  "id" : 233080443208077312,
  "in_reply_to_status_id" : 233024816184164352,
  "created_at" : "2012-08-08 06:01:22 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rebecca Murphey",
      "screen_name" : "rmurphey",
      "indices" : [ 36, 45 ],
      "id_str" : "6490602",
      "id" : 6490602
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/qQjnHHRD",
      "expanded_url" : "http:\/\/wurstcaptures.untergrund.net\/music\/",
      "display_url" : "wurstcaptures.untergrund.net\/music\/"
    } ]
  },
  "in_reply_to_status_id_str" : "232943962481127426",
  "geo" : { },
  "id_str" : "232948468879077376",
  "in_reply_to_user_id" : 6490602,
  "text" : "check this out http:\/\/t.co\/qQjnHHRD @rmurphey",
  "id" : 232948468879077376,
  "in_reply_to_status_id" : 232943962481127426,
  "created_at" : "2012-08-07 21:16:57 +0000",
  "in_reply_to_screen_name" : "rmurphey",
  "in_reply_to_user_id_str" : "6490602",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PLT HULK",
      "screen_name" : "PLT_Hulk",
      "indices" : [ 70, 79 ],
      "id_str" : "484936561",
      "id" : 484936561
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "232945125502881792",
  "geo" : { },
  "id_str" : "232945786500038657",
  "in_reply_to_user_id" : 484936561,
  "text" : "HULK U GOTTA SMASH SOMETHING ONCE IN A WHILE SO U DONT GET STEPPED ON @PLT_Hulk",
  "id" : 232945786500038657,
  "in_reply_to_status_id" : 232945125502881792,
  "created_at" : "2012-08-07 21:06:18 +0000",
  "in_reply_to_screen_name" : "PLT_Hulk",
  "in_reply_to_user_id_str" : "484936561",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232942857445584896",
  "text" : "What company can contain the least niche of my ambitions? I shall join you as one.",
  "id" : 232942857445584896,
  "created_at" : "2012-08-07 20:54:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Chevron",
      "indices" : [ 31, 39 ]
    } ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/DYZUzUV7",
      "expanded_url" : "http:\/\/ens-newswire.com\/?p=47609",
      "display_url" : "ens-newswire.com\/?p=47609"
    } ]
  },
  "geo" : { },
  "id_str" : "232718539876868096",
  "text" : "After 19 years of legislation, #Chevron is about to stick its nose up to the rule of law and default on judgement http:\/\/t.co\/DYZUzUV7",
  "id" : 232718539876868096,
  "created_at" : "2012-08-07 06:03:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chevron",
      "indices" : [ 54, 62 ]
    }, {
      "text" : "richmondchevron",
      "indices" : [ 63, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "232714157902946304",
  "text" : "we need more pictures of this fire from san francisco #chevron #richmondchevron",
  "id" : 232714157902946304,
  "created_at" : "2012-08-07 05:45:53 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "benhuh",
      "screen_name" : "benhuh",
      "indices" : [ 33, 40 ],
      "id_str" : "14112294",
      "id" : 14112294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/5rrdSsIy",
      "expanded_url" : "http:\/\/johnnyscript.tumblr.com\/post\/28746564355\/citizen-mission-real-time-news-thing-or-yet-another",
      "display_url" : "johnnyscript.tumblr.com\/post\/287465643\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "231964230616752128",
  "geo" : { },
  "id_str" : "231983470023430145",
  "in_reply_to_user_id" : 14112294,
  "text" : "im all about some new journalism @benhuh http:\/\/t.co\/5rrdSsIy",
  "id" : 231983470023430145,
  "in_reply_to_status_id" : 231964230616752128,
  "created_at" : "2012-08-05 05:22:23 +0000",
  "in_reply_to_screen_name" : "benhuh",
  "in_reply_to_user_id_str" : "14112294",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "maxwell ogden",
      "screen_name" : "maxogden",
      "indices" : [ 69, 78 ],
      "id_str" : "12241752",
      "id" : 12241752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "231464611239571456",
  "geo" : { },
  "id_str" : "231474254552633344",
  "in_reply_to_user_id" : 12241752,
  "text" : "I saw a longbeard on a bike at Embarcadero &amp; 5th late last night @maxogden  possible match?",
  "id" : 231474254552633344,
  "in_reply_to_status_id" : 231464611239571456,
  "created_at" : "2012-08-03 19:38:57 +0000",
  "in_reply_to_screen_name" : "maxogden",
  "in_reply_to_user_id_str" : "12241752",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marco Rogers",
      "screen_name" : "polotek",
      "indices" : [ 25, 33 ],
      "id_str" : "20079975",
      "id" : 20079975
    }, {
      "name" : "getify",
      "screen_name" : "getify",
      "indices" : [ 34, 41 ],
      "id_str" : "16686076",
      "id" : 16686076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "230782005862866944",
  "geo" : { },
  "id_str" : "230782248130064384",
  "in_reply_to_user_id" : 20079975,
  "text" : "ya'll need to go irc off @polotek @getify",
  "id" : 230782248130064384,
  "in_reply_to_status_id" : 230782005862866944,
  "created_at" : "2012-08-01 21:49:10 +0000",
  "in_reply_to_screen_name" : "polotek",
  "in_reply_to_user_id_str" : "20079975",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/yfkV5xgO",
      "expanded_url" : "http:\/\/johnnyscript.tumblr.com\/post\/28470756019\/desk-prototypes-retrospective",
      "display_url" : "johnnyscript.tumblr.com\/post\/284707560\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "230756583381024768",
  "text" : "My DIY desk retrospective http:\/\/t.co\/yfkV5xgO",
  "id" : 230756583381024768,
  "created_at" : "2012-08-01 20:07:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230491070654468096",
  "text" : "Eating is one of the sixth senses.",
  "id" : 230491070654468096,
  "created_at" : "2012-08-01 02:32:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230490599478931456",
  "text" : "I prefer to have my ears than my eyes entertained.",
  "id" : 230490599478931456,
  "created_at" : "2012-08-01 02:30:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "230488419141300224",
  "text" : "Oakland is my new home.",
  "id" : 230488419141300224,
  "created_at" : "2012-08-01 02:21:36 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]