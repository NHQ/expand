Grailbird.data.tweets_2011_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Al Gore",
      "screen_name" : "algore",
      "indices" : [ 24, 31 ],
      "id_str" : "17220934",
      "id" : 17220934
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "weather",
      "indices" : [ 77, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "85076741391007744",
  "text" : "Summer forecast from RT @algore \"Ice and snow disappearing from Mt. Rainier\" #weather",
  "id" : 85076741391007744,
  "created_at" : "2011-06-26 20:07:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 42 ],
      "url" : "http:\/\/t.co\/6kZa9LN",
      "expanded_url" : "http:\/\/thenounproject.com\/noun\/mammogram\/",
      "display_url" : "thenounproject.com\/noun\/mammogram\/"
    } ]
  },
  "geo" : { },
  "id_str" : "83743381460762624",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia HEY LADIES http:\/\/t.co\/6kZa9LN",
  "id" : 83743381460762624,
  "created_at" : "2011-06-23 03:49:12 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Quick Bank",
      "screen_name" : "avclubchicago",
      "indices" : [ 0, 14 ],
      "id_str" : "2197094138",
      "id" : 2197094138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83334269505773568",
  "text" : "@AVClubChicago meh, that ain't no 8 foot tall wedding DJ",
  "id" : 83334269505773568,
  "created_at" : "2011-06-22 00:43:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 0, 13 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83258051020328960",
  "in_reply_to_user_id" : 279390084,
  "text" : "@YourAnonNews I've always wanted a list of all persons\/groups invested in Monsanto so I could write them a harsh letter. pls &amp thx!",
  "id" : 83258051020328960,
  "created_at" : "2011-06-21 19:40:40 +0000",
  "in_reply_to_screen_name" : "YourAnonNews",
  "in_reply_to_user_id_str" : "279390084",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 3, 16 ],
      "id_str" : "279390084",
      "id" : 279390084
    }, {
      "name" : "Tripster In Drag",
      "screen_name" : "ClowdClod",
      "indices" : [ 21, 31 ],
      "id_str" : "295845779",
      "id" : 295845779
    }, {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "indices" : [ 33, 46 ],
      "id_str" : "279390084",
      "id" : 279390084
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "83256495520755714",
  "text" : "RT @YourAnonNews: RT @ClowdClod: @YourAnonNews Oh hell yeah ! Monsanto ! Scum-Fucking-Dogshit-of-the-Earth !! Thank you for choosing Mon ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tripster In Drag",
        "screen_name" : "ClowdClod",
        "indices" : [ 3, 13 ],
        "id_str" : "295845779",
        "id" : 295845779
      }, {
        "name" : "Anonymous",
        "screen_name" : "YourAnonNews",
        "indices" : [ 15, 28 ],
        "id_str" : "279390084",
        "id" : 279390084
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "83256146261053440",
    "text" : "RT @ClowdClod: @YourAnonNews Oh hell yeah ! Monsanto ! Scum-Fucking-Dogshit-of-the-Earth !! Thank you for choosing Monsanto :-P",
    "id" : 83256146261053440,
    "created_at" : "2011-06-21 19:33:06 +0000",
    "user" : {
      "name" : "Anonymous",
      "screen_name" : "YourAnonNews",
      "protected" : false,
      "id_str" : "279390084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509955174442336256\/FG7seSO2_normal.png",
      "id" : 279390084,
      "verified" : false
    }
  },
  "id" : 83256495520755714,
  "created_at" : "2011-06-21 19:34:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Day Of Rage",
      "screen_name" : "USDayofRage",
      "indices" : [ 3, 15 ],
      "id_str" : "263466153",
      "id" : 263466153
    }, {
      "name" : "U.S. Dept of Defense",
      "screen_name" : "DeptofDefense",
      "indices" : [ 31, 45 ],
      "id_str" : "66369181",
      "id" : 66369181
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usdor",
      "indices" : [ 139, 140 ]
    }, {
      "text" : "opESR",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/kV1xtfX",
      "expanded_url" : "http:\/\/bit.ly\/jn0aq2",
      "display_url" : "bit.ly\/jn0aq2"
    } ]
  },
  "geo" : { },
  "id_str" : "83228939044143104",
  "text" : "RT @USDayofRage: Leaked Video: @DeptofDefense Discusses Eliminating Religious Fanaticism Through Gene-Targeting Vaccine http:\/\/t.co\/kV1x ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "U.S. Dept of Defense",
        "screen_name" : "DeptofDefense",
        "indices" : [ 14, 28 ],
        "id_str" : "66369181",
        "id" : 66369181
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "usdor",
        "indices" : [ 123, 129 ]
      }, {
        "text" : "opESR",
        "indices" : [ 130, 136 ]
      } ],
      "urls" : [ {
        "indices" : [ 103, 122 ],
        "url" : "http:\/\/t.co\/kV1xtfX",
        "expanded_url" : "http:\/\/bit.ly\/jn0aq2",
        "display_url" : "bit.ly\/jn0aq2"
      } ]
    },
    "geo" : { },
    "id_str" : "83226173424926720",
    "text" : "Leaked Video: @DeptofDefense Discusses Eliminating Religious Fanaticism Through Gene-Targeting Vaccine http:\/\/t.co\/kV1xtfX #usdor #opESR",
    "id" : 83226173424926720,
    "created_at" : "2011-06-21 17:34:00 +0000",
    "user" : {
      "name" : "US Day Of Rage",
      "screen_name" : "USDayofRage",
      "protected" : false,
      "id_str" : "263466153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000107097751\/f5ea6fe9a592cff1293a59fb80b947ac_normal.jpeg",
      "id" : 263466153,
      "verified" : false
    }
  },
  "id" : 83228939044143104,
  "created_at" : "2011-06-21 17:45:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "unsaidmag",
      "screen_name" : "UNSAIDmag",
      "indices" : [ 3, 13 ],
      "id_str" : "316840019",
      "id" : 316840019
    }, {
      "name" : "Caketrain",
      "screen_name" : "caketrainpress",
      "indices" : [ 15, 30 ],
      "id_str" : "45758990",
      "id" : 45758990
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "82676943287361536",
  "text" : "RT @UNSAIDmag: @caketrainpress Gordon Lush stands autocorrected.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caketrain",
        "screen_name" : "caketrainpress",
        "indices" : [ 0, 15 ],
        "id_str" : "45758990",
        "id" : 45758990
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "82634679026585600",
    "geo" : { },
    "id_str" : "82649623105257472",
    "in_reply_to_user_id" : 45758990,
    "text" : "@caketrainpress Gordon Lush stands autocorrected.",
    "id" : 82649623105257472,
    "in_reply_to_status_id" : 82634679026585600,
    "created_at" : "2011-06-20 03:23:00 +0000",
    "in_reply_to_screen_name" : "caketrainpress",
    "in_reply_to_user_id_str" : "45758990",
    "user" : {
      "name" : "unsaidmag",
      "screen_name" : "UNSAIDmag",
      "protected" : false,
      "id_str" : "316840019",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1394991524\/Unsaid_Twit_normal.jpg",
      "id" : 316840019,
      "verified" : false
    }
  },
  "id" : 82676943287361536,
  "created_at" : "2011-06-20 05:11:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mikeal",
      "screen_name" : "mikeal",
      "indices" : [ 0, 7 ],
      "id_str" : "668423",
      "id" : 668423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "81165847552462848",
  "geo" : { },
  "id_str" : "81173271726399488",
  "in_reply_to_user_id" : 668423,
  "text" : "@mikeal hey can I get a contact about nodeconf pls &amp thanks",
  "id" : 81173271726399488,
  "in_reply_to_status_id" : 81165847552462848,
  "created_at" : "2011-06-16 01:36:30 +0000",
  "in_reply_to_screen_name" : "mikeal",
  "in_reply_to_user_id_str" : "668423",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "Mikeal",
      "screen_name" : "mikeal",
      "indices" : [ 18, 25 ],
      "id_str" : "668423",
      "id" : 668423
    }, {
      "name" : "Nodejitsu",
      "screen_name" : "nodejitsu",
      "indices" : [ 77, 87 ],
      "id_str" : "157442008",
      "id" : 157442008
    }, {
      "name" : "Uber",
      "screen_name" : "Uber",
      "indices" : [ 88, 93 ],
      "id_str" : "19103481",
      "id" : 19103481
    }, {
      "name" : "Yammer",
      "screen_name" : "Yammer",
      "indices" : [ 98, 105 ],
      "id_str" : "16049723",
      "id" : 16049723
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 106, 125 ],
      "url" : "http:\/\/t.co\/QGmEMbM",
      "expanded_url" : "http:\/\/www.nodeconf.com\/summercamp.html",
      "display_url" : "nodeconf.com\/summercamp.html"
    } ]
  },
  "geo" : { },
  "id_str" : "81171355676057601",
  "in_reply_to_user_id" : 58809542,
  "text" : "@angelinegragzin \u201C@mikeal: welcome our awesome NodeConf SummerCamp sponsors: @nodejitsu @uber and @yammer http:\/\/t.co\/QGmEMbM\u201D",
  "id" : 81171355676057601,
  "created_at" : "2011-06-16 01:28:53 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 103 ],
      "url" : "http:\/\/t.co\/qLncoOV",
      "expanded_url" : "http:\/\/twitpic.com\/5c4gac",
      "display_url" : "twitpic.com\/5c4gac"
    }, {
      "indices" : [ 107, 126 ],
      "url" : "http:\/\/t.co\/hdqSp8w",
      "expanded_url" : "http:\/\/twitpic.com\/5c4gil",
      "display_url" : "twitpic.com\/5c4gil"
    } ]
  },
  "geo" : { },
  "id_str" : "81170632817123329",
  "in_reply_to_user_id" : 58809542,
  "text" : "@angelinegragzin pics of snake & spiders & insects on railing to escape floods NSW  http:\/\/t.co\/qLncoOV &  http:\/\/t.co\/hdqSp8w",
  "id" : 81170632817123329,
  "created_at" : "2011-06-16 01:26:01 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Samy Kamkar",
      "screen_name" : "samykamkar",
      "indices" : [ 3, 14 ],
      "id_str" : "15092452",
      "id" : 15092452
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "VelocityConf",
      "indices" : [ 139, 140 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 99 ],
      "url" : "http:\/\/t.co\/oGJU1FQ",
      "expanded_url" : "http:\/\/samy.pl\/jiagra",
      "display_url" : "samy.pl\/jiagra"
    } ]
  },
  "geo" : { },
  "id_str" : "81169877569781762",
  "text" : "RT @samykamkar: I've created Jiagra, a Javascript\/Website Performance Enhancer: http:\/\/t.co\/oGJU1FQ (prerender\/prefetch polyfill) missin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "VelocityConf",
        "indices" : [ 122, 135 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 83 ],
        "url" : "http:\/\/t.co\/oGJU1FQ",
        "expanded_url" : "http:\/\/samy.pl\/jiagra",
        "display_url" : "samy.pl\/jiagra"
      } ]
    },
    "geo" : { },
    "id_str" : "81166030679973888",
    "text" : "I've created Jiagra, a Javascript\/Website Performance Enhancer: http:\/\/t.co\/oGJU1FQ (prerender\/prefetch polyfill) missing #VelocityConf",
    "id" : 81166030679973888,
    "created_at" : "2011-06-16 01:07:44 +0000",
    "user" : {
      "name" : "Samy Kamkar",
      "screen_name" : "samykamkar",
      "protected" : false,
      "id_str" : "15092452",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/427715845469392896\/AdPfbXVY_normal.png",
      "id" : 15092452,
      "verified" : false
    }
  },
  "id" : 81169877569781762,
  "created_at" : "2011-06-16 01:23:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Day Of Rage",
      "screen_name" : "USDayofRage",
      "indices" : [ 3, 15 ],
      "id_str" : "263466153",
      "id" : 263466153
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usdor",
      "indices" : [ 104, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81149374012456960",
  "text" : "RT @USDayofRage: Public discourse has devolved into 3 rhetorical devices. Satire. False hope. Demagogy. #usdor - http:\/\/ow.ly\/5i2kH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "usdor",
        "indices" : [ 87, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "81149053064318976",
    "text" : "Public discourse has devolved into 3 rhetorical devices. Satire. False hope. Demagogy. #usdor - http:\/\/ow.ly\/5i2kH",
    "id" : 81149053064318976,
    "created_at" : "2011-06-16 00:00:16 +0000",
    "user" : {
      "name" : "US Day Of Rage",
      "screen_name" : "USDayofRage",
      "protected" : false,
      "id_str" : "263466153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000107097751\/f5ea6fe9a592cff1293a59fb80b947ac_normal.jpeg",
      "id" : 263466153,
      "verified" : false
    }
  },
  "id" : 81149374012456960,
  "created_at" : "2011-06-16 00:01:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CLEAR 4G",
      "screen_name" : "CLEAR",
      "indices" : [ 81, 87 ],
      "id_str" : "28604120",
      "id" : 28604120
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "81117816463441920",
  "text" : "ClearWire's G service is general pretty weak and very inconsistent in losAngeles @Clear kills me SSH ack ack ack",
  "id" : 81117816463441920,
  "created_at" : "2011-06-15 21:56:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 104 ],
      "url" : "http:\/\/t.co\/76kZuOw",
      "expanded_url" : "http:\/\/bit.ly\/jycGvs",
      "display_url" : "bit.ly\/jycGvs"
    } ]
  },
  "geo" : { },
  "id_str" : "81099965610471425",
  "text" : "take a sci-fi ride with the ghost of consumer future in MAN v. CANDY MACHINE [video] http:\/\/t.co\/76kZuOw",
  "id" : 81099965610471425,
  "created_at" : "2011-06-15 20:45:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 56, 75 ],
      "url" : "http:\/\/t.co\/WqkGUDT",
      "expanded_url" : "http:\/\/slate.me\/jjJZjS",
      "display_url" : "slate.me\/jjJZjS"
    } ]
  },
  "geo" : { },
  "id_str" : "80780722603954178",
  "text" : "political campaigning by \"rogue conservative filmmaker\" http:\/\/t.co\/WqkGUDT",
  "id" : 80780722603954178,
  "created_at" : "2011-06-14 23:36:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Day Of Rage",
      "screen_name" : "USDayofRage",
      "indices" : [ 3, 15 ],
      "id_str" : "263466153",
      "id" : 263466153
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "usdor",
      "indices" : [ 116, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80775689145565184",
  "text" : "RT @USDayofRage: Corporate campaign financing is bleeding democracy with suitcases of multinational corporate cash. #usdor - http:\/\/ow.l ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "usdor",
        "indices" : [ 99, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80771840364122112",
    "text" : "Corporate campaign financing is bleeding democracy with suitcases of multinational corporate cash. #usdor - http:\/\/ow.ly\/5g9P8",
    "id" : 80771840364122112,
    "created_at" : "2011-06-14 23:01:22 +0000",
    "user" : {
      "name" : "US Day Of Rage",
      "screen_name" : "USDayofRage",
      "protected" : false,
      "id_str" : "263466153",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000107097751\/f5ea6fe9a592cff1293a59fb80b947ac_normal.jpeg",
      "id" : 263466153,
      "verified" : false
    }
  },
  "id" : 80775689145565184,
  "created_at" : "2011-06-14 23:16:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    }, {
      "name" : "Indiewire",
      "screen_name" : "indiewire",
      "indices" : [ 65, 75 ],
      "id_str" : "13992132",
      "id" : 13992132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 133 ],
      "url" : "http:\/\/t.co\/muR3EMP",
      "expanded_url" : "http:\/\/www.indiewire.com\/article\/indiewires_project_of_the_day_all-women_production_the_animals\/",
      "display_url" : "indiewire.com\/article\/indiew\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "80773321402236928",
  "text" : "RT @AngelineGragzin: Neat! My film \"The Animals\" was featured as @indiewire's Project of The Day! Thanks guys! :) http:\/\/t.co\/muR3EMP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Indiewire",
        "screen_name" : "indiewire",
        "indices" : [ 44, 54 ],
        "id_str" : "13992132",
        "id" : 13992132
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 112 ],
        "url" : "http:\/\/t.co\/muR3EMP",
        "expanded_url" : "http:\/\/www.indiewire.com\/article\/indiewires_project_of_the_day_all-women_production_the_animals\/",
        "display_url" : "indiewire.com\/article\/indiew\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "80747352071221248",
    "text" : "Neat! My film \"The Animals\" was featured as @indiewire's Project of The Day! Thanks guys! :) http:\/\/t.co\/muR3EMP",
    "id" : 80747352071221248,
    "created_at" : "2011-06-14 21:24:03 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 80773321402236928,
  "created_at" : "2011-06-14 23:07:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MissBwalya",
      "screen_name" : "missbwalya",
      "indices" : [ 3, 14 ],
      "id_str" : "148073786",
      "id" : 148073786
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "80130900976877568",
  "text" : "RT @missbwalya: Which African township will be receiving the \"Miami Heat 2011 NBA Champions\" t-shirts & paraphernalia.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "80104445291147264",
    "text" : "Which African township will be receiving the \"Miami Heat 2011 NBA Champions\" t-shirts & paraphernalia.",
    "id" : 80104445291147264,
    "created_at" : "2011-06-13 02:49:22 +0000",
    "user" : {
      "name" : "MissBwalya",
      "screen_name" : "missbwalya",
      "protected" : false,
      "id_str" : "148073786",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2916635726\/1c21bb960e8a8f0cf7ddf836a8a44dc2_normal.jpeg",
      "id" : 148073786,
      "verified" : false
    }
  },
  "id" : 80130900976877568,
  "created_at" : "2011-06-13 04:34:30 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 63 ],
      "url" : "http:\/\/t.co\/hRvwU5J",
      "expanded_url" : "http:\/\/www.w3schools.com\/jsref\/met_nav_taintenabled.asp",
      "display_url" : "w3schools.com\/jsref\/met_nav_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "79658138554466307",
  "text" : "DOES YOUR WEB BROWSER HAVE TAINT ENABLED??? http:\/\/t.co\/hRvwU5J",
  "id" : 79658138554466307,
  "created_at" : "2011-06-11 21:15:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 0, 11 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78941178480955392",
  "in_reply_to_user_id" : 30313925,
  "text" : "@whitehouse no more John Kerry pls http:\/\/reut.rs\/kpQCoa this is a mid-article reference",
  "id" : 78941178480955392,
  "created_at" : "2011-06-09 21:46:58 +0000",
  "in_reply_to_screen_name" : "WhiteHouse",
  "in_reply_to_user_id_str" : "30313925",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "node js",
      "screen_name" : "nodejs",
      "indices" : [ 0, 7 ],
      "id_str" : "91985735",
      "id" : 91985735
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "webcomics",
      "indices" : [ 8, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78939146927882241",
  "in_reply_to_user_id" : 91985735,
  "text" : "@nodejs #webcomics http:\/\/mattiasgeniar.be\/wp-content\/uploads\/2008\/09\/regular_expressions.png",
  "id" : 78939146927882241,
  "created_at" : "2011-06-09 21:38:53 +0000",
  "in_reply_to_screen_name" : "nodejs",
  "in_reply_to_user_id_str" : "91985735",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reminder",
      "indices" : [ 0, 9 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "78159782506270720",
  "text" : "#reminder http:\/\/schema.org\/docs\/schemas.html",
  "id" : 78159782506270720,
  "created_at" : "2011-06-07 18:01:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77809643816103936",
  "text" : "Does anybody know the Value-Delish Coefficient? I'm pretty sure it uses the Flavour-Sensation Equation.",
  "id" : 77809643816103936,
  "created_at" : "2011-06-06 18:50:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77793940769746944",
  "text" : "Greenland's only \"newspaper\" http:\/\/sermitsiaq.ag\/",
  "id" : 77793940769746944,
  "created_at" : "2011-06-06 17:48:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77793575890452481",
  "text" : "ibid. http:\/\/earthobservatory.nasa.gov\/NaturalHazards\/view.php?id=50854",
  "id" : 77793575890452481,
  "created_at" : "2011-06-06 17:46:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "maps",
      "indices" : [ 5, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "77793370872885248",
  "text" : "neat #maps http:\/\/nie.mn\/iOJw2V",
  "id" : 77793370872885248,
  "created_at" : "2011-06-06 17:45:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76752519564492801",
  "text" : "these days you gotta boycot the subject.",
  "id" : 76752519564492801,
  "created_at" : "2011-06-03 20:50:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "oppositeday",
      "indices" : [ 68, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76501941336817665",
  "text" : "RT @mrfaulty: A Monsanto ad from the 1970s: http:\/\/flic.kr\/p\/8mYBWq #oppositeday",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "oppositeday",
        "indices" : [ 54, 66 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76496681616683008",
    "text" : "A Monsanto ad from the 1970s: http:\/\/flic.kr\/p\/8mYBWq #oppositeday",
    "id" : 76496681616683008,
    "created_at" : "2011-06-03 03:53:24 +0000",
    "user" : {
      "name" : "N'Badd Taste",
      "screen_name" : "VomitingLarry",
      "protected" : false,
      "id_str" : "87359828",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2793668509\/a6d688a3d000892d46cde9c7a90ec9ab_normal.jpeg",
      "id" : 87359828,
      "verified" : false
    }
  },
  "id" : 76501941336817665,
  "created_at" : "2011-06-03 04:14:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "indices" : [ 3, 11 ],
      "id_str" : "3163591",
      "id" : 3163591
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76318833350156288",
  "text" : "RT @gknauss: Decided I don't like the typeface on our new microwave.\n\nWhat the _fuck_ have you people done to me?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "76145298828824576",
    "text" : "Decided I don't like the typeface on our new microwave.\n\nWhat the _fuck_ have you people done to me?",
    "id" : 76145298828824576,
    "created_at" : "2011-06-02 04:37:08 +0000",
    "user" : {
      "name" : "Greg Knauss",
      "screen_name" : "gknauss",
      "protected" : false,
      "id_str" : "3163591",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/38137892\/greg-icon-128_normal.gif",
      "id" : 3163591,
      "verified" : false
    }
  },
  "id" : 76318833350156288,
  "created_at" : "2011-06-02 16:06:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 22, 36 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76098612404305921",
  "text" : "thanks for everything @tjholowaychuk !",
  "id" : 76098612404305921,
  "created_at" : "2011-06-02 01:31:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76085740735447040",
  "text" : "This is completely absurd. Funny ha ha absurd. The punchline is the arrival of the coast guard. Warning: suicide http:\/\/on.msnbc.com\/iBxrT7",
  "id" : 76085740735447040,
  "created_at" : "2011-06-02 00:40:28 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 65, 72 ]
    }, {
      "text" : "npm",
      "indices" : [ 73, 77 ]
    }, {
      "text" : "express",
      "indices" : [ 78, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "76084563176194048",
  "text" : "a newb all over again now that I am upgrading to new versions of #nodejs #npm #express",
  "id" : 76084563176194048,
  "created_at" : "2011-06-02 00:35:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76078232323096576",
  "geo" : { },
  "id_str" : "76082014478012417",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk long time express user, fan, TJ please help!! http:\/\/groups.google.com\/group\/express-js\/browse_thread\/thread\/64b8b8ddcc8072ad",
  "id" : 76082014478012417,
  "in_reply_to_status_id" : 76078232323096576,
  "created_at" : "2011-06-02 00:25:40 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "node",
      "indices" : [ 16, 21 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "76077307114164224",
  "geo" : { },
  "id_str" : "76080402900586496",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs no but the #node account is run by a former MTV jockey and lamer who runs a nerd lifestyle website",
  "id" : 76080402900586496,
  "in_reply_to_status_id" : 76077307114164224,
  "created_at" : "2011-06-02 00:19:16 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75994962843545600",
  "text" : "@kmartsurrealism your double-double, sir http:\/\/www.youtube.com\/watch?v=P7o69bMCx-Y",
  "id" : 75994962843545600,
  "created_at" : "2011-06-01 18:39:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rip",
      "indices" : [ 94, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "75934007484878848",
  "text" : "Did you know that Randy Mario Poffo died 5\/20\/2011? http:\/\/en.wikipedia.org\/wiki\/Randy_Savage #rip",
  "id" : 75934007484878848,
  "created_at" : "2011-06-01 14:37:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]