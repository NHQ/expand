Grailbird.data.tweets_2011_05 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74896682361425920",
  "text" : "chance blown for 20 under 20 and 30 under 30 already.",
  "id" : 74896682361425920,
  "created_at" : "2011-05-29 17:55:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74502756571955200",
  "text" : "RIP Gil-Scott Heron http:\/\/n.pr\/lCMcKp",
  "id" : 74502756571955200,
  "created_at" : "2011-05-28 15:50:16 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nieman Lab",
      "screen_name" : "NiemanLab",
      "indices" : [ 0, 10 ],
      "id_str" : "15865878",
      "id" : 15865878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "74161706846273536",
  "geo" : { },
  "id_str" : "74163278615547904",
  "in_reply_to_user_id" : 15865878,
  "text" : "@NiemanLab journalism is not = reporting on something just because it exists",
  "id" : 74163278615547904,
  "in_reply_to_status_id" : 74161706846273536,
  "created_at" : "2011-05-27 17:21:18 +0000",
  "in_reply_to_screen_name" : "NiemanLab",
  "in_reply_to_user_id_str" : "15865878",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "74162895738511360",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk May I use this cluster vhost ex. nearly verbatim to host multiple domani on a single node web server? http:\/\/bit.ly\/izebPv",
  "id" : 74162895738511360,
  "created_at" : "2011-05-27 17:19:46 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 61 ],
      "url" : "http:\/\/t.co\/kpSCghA",
      "expanded_url" : "http:\/\/j.mp\/m8eY1F",
      "display_url" : "j.mp\/m8eY1F"
    } ]
  },
  "geo" : { },
  "id_str" : "73418668175917056",
  "text" : "i knew this would happen to publishing :O http:\/\/t.co\/kpSCghA",
  "id" : 73418668175917056,
  "created_at" : "2011-05-25 16:02:29 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakim El Hattab",
      "screen_name" : "hakimel",
      "indices" : [ 3, 11 ],
      "id_str" : "73339662",
      "id" : 73339662
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "73415215164833792",
  "text" : "RT @hakimel: Game framework for building HTML RPG's. http:\/\/rpgjs.com\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "73412391412580353",
    "text" : "Game framework for building HTML RPG's. http:\/\/rpgjs.com\/",
    "id" : 73412391412580353,
    "created_at" : "2011-05-25 15:37:32 +0000",
    "user" : {
      "name" : "Hakim El Hattab",
      "screen_name" : "hakimel",
      "protected" : false,
      "id_str" : "73339662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/515506205406408704\/rpmu0mf2_normal.jpeg",
      "id" : 73339662,
      "verified" : false
    }
  },
  "id" : 73415215164833792,
  "created_at" : "2011-05-25 15:48:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ryah",
      "screen_name" : "ryah",
      "indices" : [ 0, 5 ],
      "id_str" : "967076702",
      "id" : 967076702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71097266886283264",
  "text" : "@ryah life's too many things for PBR",
  "id" : 71097266886283264,
  "created_at" : "2011-05-19 06:18:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71096961612255233",
  "text" : "Two steps forward, cliff \/\/ followed by ten step abyss \/\/ bitch, where's my bridge at?",
  "id" : 71096961612255233,
  "created_at" : "2011-05-19 06:16:51 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "71095429529481217",
  "text" : "two steps forward, ten step abyss",
  "id" : 71095429529481217,
  "created_at" : "2011-05-19 06:10:45 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "70385447234314240",
  "text" : "if ur lazy and ur native clap yr hands",
  "id" : 70385447234314240,
  "created_at" : "2011-05-17 07:09:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fiction",
      "indices" : [ 131, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69989010612826112",
  "text" : "This CYOA \"game\" http:\/\/bit.ly\/ijGYKJ from http:\/\/bit.ly\/lkq6ke using this free html\/js \"game\" editing engine http:\/\/bit.ly\/kkSscQ #fiction",
  "id" : 69989010612826112,
  "created_at" : "2011-05-16 04:54:15 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69856711665651712",
  "text" : "a real, paid congress persona wrote that",
  "id" : 69856711665651712,
  "created_at" : "2011-05-15 20:08:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69856597324726272",
  "text" : "\"Preventing Real Online Threats to Economic Creativity and Theft of Intellectual Property Act of 2011\" http:\/\/bit.ly\/los39z",
  "id" : 69856597324726272,
  "created_at" : "2011-05-15 20:08:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69818803084730368",
  "text" : "RT @AngelineGragzin: Philip Lorca diCorcia: Roid http:\/\/thelovemagazine.co.uk\/instant.php?id=5330523910",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "69699302032818176",
    "text" : "Philip Lorca diCorcia: Roid http:\/\/thelovemagazine.co.uk\/instant.php?id=5330523910",
    "id" : 69699302032818176,
    "created_at" : "2011-05-15 09:43:03 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 69818803084730368,
  "created_at" : "2011-05-15 17:37:54 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69569085846990848",
  "text" : "zombie Reagan saves the US from blacks and disco http:\/\/www.washingtonmonthly.com\/political-animal\/2011_05\/beyond_parody029571.php",
  "id" : 69569085846990848,
  "created_at" : "2011-05-15 01:05:37 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dustin Diaz",
      "screen_name" : "ded",
      "indices" : [ 0, 4 ],
      "id_str" : "1199081",
      "id" : 1199081
    }, {
      "name" : "jacob",
      "screen_name" : "fat",
      "indices" : [ 5, 9 ],
      "id_str" : "16521996",
      "id" : 16521996
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68732852329644032",
  "geo" : { },
  "id_str" : "69234626350170113",
  "in_reply_to_user_id" : 1199081,
  "text" : "@ded @fat will do soon. just got new NPM installed correct (I hope), need to mux around.",
  "id" : 69234626350170113,
  "in_reply_to_status_id" : 68732852329644032,
  "created_at" : "2011-05-14 02:56:35 +0000",
  "in_reply_to_screen_name" : "ded",
  "in_reply_to_user_id_str" : "1199081",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodwill",
      "indices" : [ 69, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "69184375736119296",
  "text" : "Here's hoping your next injury, accident or illness doesn't kill ya. #goodwill",
  "id" : 69184375736119296,
  "created_at" : "2011-05-13 23:36:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laurie Voss",
      "screen_name" : "seldo",
      "indices" : [ 0, 6 ],
      "id_str" : "15453",
      "id" : 15453
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "69168095180238848",
  "geo" : { },
  "id_str" : "69174665913966592",
  "in_reply_to_user_id" : 15453,
  "text" : "@seldo I'm only \"sciensticious\" so I don't have the answer you seek, but the comments section is funny.",
  "id" : 69174665913966592,
  "in_reply_to_status_id" : 69168095180238848,
  "created_at" : "2011-05-13 22:58:20 +0000",
  "in_reply_to_screen_name" : "seldo",
  "in_reply_to_user_id_str" : "15453",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68851542995894272",
  "text" : "javascript is gonna be like latin when latin was the shiiiit",
  "id" : 68851542995894272,
  "created_at" : "2011-05-13 01:34:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marak squires",
      "screen_name" : "maraksquires",
      "indices" : [ 0, 13 ],
      "id_str" : "745792987",
      "id" : 745792987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68841820406300672",
  "in_reply_to_user_id" : 110465841,
  "text" : "@maraksquires does haibu automatically create a node *server on port 80?",
  "id" : 68841820406300672,
  "created_at" : "2011-05-13 00:55:43 +0000",
  "in_reply_to_screen_name" : "marak",
  "in_reply_to_user_id_str" : "110465841",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marak squires",
      "screen_name" : "maraksquires",
      "indices" : [ 0, 13 ],
      "id_str" : "745792987",
      "id" : 745792987
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68840268719329280",
  "in_reply_to_user_id" : 110465841,
  "text" : "@maraksquires very excited to eventually understand how to haibu #nodejs app server https:\/\/github.com\/nodejitsu\/haibu",
  "id" : 68840268719329280,
  "created_at" : "2011-05-13 00:49:33 +0000",
  "in_reply_to_screen_name" : "marak",
  "in_reply_to_user_id_str" : "110465841",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68812878462976001",
  "text" : "according to OSX activity monitor, the Chrome browser per tab memory usage spectrum goes from 5 mb to 200 mb, many in in the 10-50 range",
  "id" : 68812878462976001,
  "created_at" : "2011-05-12 23:00:43 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68747252444835840",
  "text" : "it's a hot butter pop dog",
  "id" : 68747252444835840,
  "created_at" : "2011-05-12 18:39:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacob",
      "screen_name" : "fat",
      "indices" : [ 0, 4 ],
      "id_str" : "16521996",
      "id" : 16521996
    }, {
      "name" : "Dustin Diaz",
      "screen_name" : "ded",
      "indices" : [ 5, 9 ],
      "id_str" : "1199081",
      "id" : 1199081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "68442041180364800",
  "geo" : { },
  "id_str" : "68715379207311360",
  "in_reply_to_user_id" : 16521996,
  "text" : "@fat @ded old version of NPM. Having trouble with installing new version, ergo no 'node_modules' directory... I think that's the issue.",
  "id" : 68715379207311360,
  "in_reply_to_status_id" : 68442041180364800,
  "created_at" : "2011-05-12 16:33:17 +0000",
  "in_reply_to_screen_name" : "fat",
  "in_reply_to_user_id_str" : "16521996",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68518960798253056",
  "text" : "this link is neat about science fiction \"inventions\" dating back to the 15th century http:\/\/www.technovelgy.com\/ct\/ctnlistPubDate.asp",
  "id" : 68518960798253056,
  "created_at" : "2011-05-12 03:32:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacob",
      "screen_name" : "fat",
      "indices" : [ 0, 4 ],
      "id_str" : "16521996",
      "id" : 16521996
    }, {
      "name" : "Dustin Diaz",
      "screen_name" : "ded",
      "indices" : [ 5, 9 ],
      "id_str" : "1199081",
      "id" : 1199081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68383980671602688",
  "in_reply_to_user_id" : 16521996,
  "text" : "@fat @ded I got an error \"No such file ... 'node_modules\/ender-js\/package.json'\" And there is no ender.js in my folder...",
  "id" : 68383980671602688,
  "created_at" : "2011-05-11 18:36:26 +0000",
  "in_reply_to_screen_name" : "fat",
  "in_reply_to_user_id_str" : "16521996",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacob",
      "screen_name" : "fat",
      "indices" : [ 0, 4 ],
      "id_str" : "16521996",
      "id" : 16521996
    }, {
      "name" : "Dustin Diaz",
      "screen_name" : "ded",
      "indices" : [ 5, 9 ],
      "id_str" : "1199081",
      "id" : 1199081
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68383750618222592",
  "in_reply_to_user_id" : 16521996,
  "text" : "@fat @ded - HI I am confused about how build works. Is ender.js the collected lib, and should it be present in my app folder?",
  "id" : 68383750618222592,
  "created_at" : "2011-05-11 18:35:31 +0000",
  "in_reply_to_screen_name" : "fat",
  "in_reply_to_user_id_str" : "16521996",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 15, 27 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68030842630455296",
  "text" : "annex mexieco! #immigration rule of law \/\/ a rue flow",
  "id" : 68030842630455296,
  "created_at" : "2011-05-10 19:13:11 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 23, 34 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "68030097071939584",
  "text" : "this better be radical @whitehouse let's annex Mexico sort of",
  "id" : 68030097071939584,
  "created_at" : "2011-05-10 19:10:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "marak squires",
      "screen_name" : "maraksquires",
      "indices" : [ 0, 13 ],
      "id_str" : "745792987",
      "id" : 745792987
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "67737532519034880",
  "geo" : { },
  "id_str" : "67741695558688768",
  "in_reply_to_user_id" : 110465841,
  "text" : "@maraksquires qouth: Java\u2122",
  "id" : 67741695558688768,
  "in_reply_to_status_id" : 67737532519034880,
  "created_at" : "2011-05-10 00:04:13 +0000",
  "in_reply_to_screen_name" : "marak",
  "in_reply_to_user_id_str" : "110465841",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Davide 'Fol' Casali",
      "screen_name" : "Folletto",
      "indices" : [ 12, 21 ],
      "id_str" : "21693",
      "id" : 21693
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nodejs",
      "indices" : [ 80, 87 ]
    } ],
    "urls" : [ {
      "indices" : [ 111, 130 ],
      "url" : "http:\/\/t.co\/O1oMqE8",
      "expanded_url" : "http:\/\/bit.ly\/lMc6XO",
      "display_url" : "bit.ly\/lMc6XO"
    } ]
  },
  "geo" : { },
  "id_str" : "67601724508078080",
  "text" : "servers RT \u201C@Folletto: A benchmark between Misultin, MochiWeb, Cowboy (Erlang), #nodejs, and Tornado (Python): http:\/\/t.co\/O1oMqE8\u201D",
  "id" : 67601724508078080,
  "created_at" : "2011-05-09 14:48:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 30, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66614543438192641",
  "text" : "desperate is the new american #immigration",
  "id" : 66614543438192641,
  "created_at" : "2011-05-06 21:25:19 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "immigration",
      "indices" : [ 76, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66614286297993216",
  "text" : "we want those people to be citizens who risk their hide for the opportunity #immigration",
  "id" : 66614286297993216,
  "created_at" : "2011-05-06 21:24:18 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Roger Ebert",
      "screen_name" : "ebertchicago",
      "indices" : [ 0, 13 ],
      "id_str" : "79797834",
      "id" : 79797834
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "66350957360975872",
  "in_reply_to_user_id" : 79797834,
  "text" : "@ebertchicago I don't think the nature of bin Laden's death has been revealed by our chaste media: went into his home, put one in his dome",
  "id" : 66350957360975872,
  "created_at" : "2011-05-06 03:57:55 +0000",
  "in_reply_to_screen_name" : "ebertchicago",
  "in_reply_to_user_id_str" : "79797834",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "drought",
      "indices" : [ 75, 83 ]
    }, {
      "text" : "flood",
      "indices" : [ 84, 90 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65624696309297152",
  "text" : "we must divert the mississippi to oklahoma and west texas, just this once. #drought #flood",
  "id" : 65624696309297152,
  "created_at" : "2011-05-04 03:52:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65624111921111041",
  "text" : "\"The power of nature to overcome the best defenses should never be underestimated\" http:\/\/j.mp\/mC3Mfe",
  "id" : 65624111921111041,
  "created_at" : "2011-05-04 03:49:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TJ Holowaychuk",
      "screen_name" : "tjholowaychuk",
      "indices" : [ 0, 14 ],
      "id_str" : "29255412",
      "id" : 29255412
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "65590693061599233",
  "geo" : { },
  "id_str" : "65592030855839744",
  "in_reply_to_user_id" : 29255412,
  "text" : "@tjholowaychuk Everybody loves the drama of an evil murder played out.",
  "id" : 65592030855839744,
  "in_reply_to_status_id" : 65590693061599233,
  "created_at" : "2011-05-04 01:42:13 +0000",
  "in_reply_to_screen_name" : "tjholowaychuk",
  "in_reply_to_user_id_str" : "29255412",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "65007871997382656",
  "text" : "WHAT UP NOW OSAMA BIN LADEN",
  "id" : 65007871997382656,
  "created_at" : "2011-05-02 11:00:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "64570669895122945",
  "text" : "big fly on my screen unperturbed by vertigo scrolling",
  "id" : 64570669895122945,
  "created_at" : "2011-05-01 06:03:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 0, 16 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "64474069101330432",
  "geo" : { },
  "id_str" : "64530241024036864",
  "in_reply_to_user_id" : 58809542,
  "text" : "@AngelineGragzin http:\/\/curiositycounts.com\/post\/5049135006\/jell-o-bouncing-in-ultra-slow-motion-at-6200-fps",
  "id" : 64530241024036864,
  "in_reply_to_status_id" : 64474069101330432,
  "created_at" : "2011-05-01 03:23:03 +0000",
  "in_reply_to_screen_name" : "AngelineGragzin",
  "in_reply_to_user_id_str" : "58809542",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]