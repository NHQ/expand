Grailbird.data.tweets_2013_03 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "318047780822204417",
  "text" : "This is what we do for fun \/\/ The games we play will reality become.",
  "id" : 318047780822204417,
  "created_at" : "2013-03-30 17:11:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "V Ro",
      "screen_name" : "vrroanhorse",
      "indices" : [ 0, 12 ],
      "id_str" : "557228721",
      "id" : 557228721
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317725616927567872",
  "geo" : { },
  "id_str" : "317729897793613824",
  "in_reply_to_user_id" : 557228721,
  "text" : "@vrroanhorse that looks like a strain of authentic Off Hollywood SoCal, unfortunately and all",
  "id" : 317729897793613824,
  "in_reply_to_status_id" : 317725616927567872,
  "created_at" : "2013-03-29 20:08:05 +0000",
  "in_reply_to_screen_name" : "vrroanhorse",
  "in_reply_to_user_id_str" : "557228721",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bonnie Ruberg",
      "screen_name" : "MyOwnVelouria",
      "indices" : [ 0, 14 ],
      "id_str" : "15696867",
      "id" : 15696867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "317711908595707904",
  "geo" : { },
  "id_str" : "317727344972402688",
  "in_reply_to_user_id" : 15696867,
  "text" : "@MyOwnVelouria U asked for it. Ur being treated just like every other chapped, nail bitten, needs to take a look in the mirror game nerd!",
  "id" : 317727344972402688,
  "in_reply_to_status_id" : 317711908595707904,
  "created_at" : "2013-03-29 19:57:56 +0000",
  "in_reply_to_screen_name" : "MyOwnVelouria",
  "in_reply_to_user_id_str" : "15696867",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/r2Ps5vQ9x4",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?feature=player_embedded&v=Dp0Bt2cbcc8",
      "display_url" : "youtube.com\/watch?feature=\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "317725008791207938",
  "text" : "POLL: HOW DO YOU RATE CONGESS? http:\/\/t.co\/r2Ps5vQ9x4",
  "id" : 317725008791207938,
  "created_at" : "2013-03-29 19:48:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/oPSWvtwcXI",
      "expanded_url" : "http:\/\/rt.com\/usa\/monsanto-congress-silently-slips-830\/",
      "display_url" : "rt.com\/usa\/monsanto-c\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "316972799853993984",
  "text" : "Them that splice rare swine protein in2 the DNA of corn tortillas spliced it all legal just now. It's just that easy! http:\/\/t.co\/oPSWvtwcXI",
  "id" : 316972799853993984,
  "created_at" : "2013-03-27 17:59:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Caswell",
      "screen_name" : "creationix",
      "indices" : [ 0, 11 ],
      "id_str" : "70596949",
      "id" : 70596949
    }, {
      "name" : "Elijah Insua",
      "screen_name" : "tmpvar",
      "indices" : [ 12, 19 ],
      "id_str" : "14318086",
      "id" : 14318086
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "315990310138281984",
  "geo" : { },
  "id_str" : "315992447614332928",
  "in_reply_to_user_id" : 70596949,
  "text" : "@creationix @tmpvar +10",
  "id" : 315992447614332928,
  "in_reply_to_status_id" : 315990310138281984,
  "created_at" : "2013-03-25 01:04:05 +0000",
  "in_reply_to_screen_name" : "creationix",
  "in_reply_to_user_id_str" : "70596949",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "indices" : [ 3, 17 ],
      "id_str" : "749863",
      "id" : 749863
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "315561126974857216",
  "text" : "RT @hotdogsladies: I\u2019m nice to people I meet since most will eventually be in independent films.\n\nThen I can say that I was nice to them ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "315557772118851584",
    "text" : "I\u2019m nice to people I meet since most will eventually be in independent films.\n\nThen I can say that I was nice to them before it was popular.",
    "id" : 315557772118851584,
    "created_at" : "2013-03-23 20:16:50 +0000",
    "user" : {
      "name" : "Merlin Mann",
      "screen_name" : "hotdogsladies",
      "protected" : false,
      "id_str" : "749863",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548615975268921345\/15phrwGy_normal.jpeg",
      "id" : 749863,
      "verified" : true
    }
  },
  "id" : 315561126974857216,
  "created_at" : "2013-03-23 20:30:10 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314748413122056192",
  "text" : "the uniqueness of all things is receding.",
  "id" : 314748413122056192,
  "created_at" : "2013-03-21 14:40:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "314084243380776960",
  "text" : "I am a golden gumball machine and so are you.",
  "id" : 314084243380776960,
  "created_at" : "2013-03-19 18:41:33 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Japanese Emoticons",
      "screen_name" : "JapanEmoticons",
      "indices" : [ 3, 18 ],
      "id_str" : "1006010888",
      "id" : 1006010888
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 68 ],
      "url" : "http:\/\/t.co\/64DuxppCxq",
      "expanded_url" : "http:\/\/www.japaneseemoticons.org\/",
      "display_url" : "japaneseemoticons.org"
    } ]
  },
  "geo" : { },
  "id_str" : "314081780338663424",
  "text" : "RT @JapanEmoticons: \uFF65:*:\uFF65(*\/\/\/\/\/\u2207\/\/\/\/\/*)\uFF65:*:\uFF65 http:\/\/t.co\/64DuxppCxq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/pha22.net\/twitterbot\/\" rel=\"nofollow\"\u003EEasyBotter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 26, 48 ],
        "url" : "http:\/\/t.co\/64DuxppCxq",
        "expanded_url" : "http:\/\/www.japaneseemoticons.org\/",
        "display_url" : "japaneseemoticons.org"
      } ]
    },
    "geo" : { },
    "id_str" : "314073791582048256",
    "text" : "\uFF65:*:\uFF65(*\/\/\/\/\/\u2207\/\/\/\/\/*)\uFF65:*:\uFF65 http:\/\/t.co\/64DuxppCxq",
    "id" : 314073791582048256,
    "created_at" : "2013-03-19 18:00:01 +0000",
    "user" : {
      "name" : "Japanese Emoticons",
      "screen_name" : "JapanEmoticons",
      "protected" : false,
      "id_str" : "1006010888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3007248902\/d338fe2c312f30eca946a7ea00d3b130_normal.jpeg",
      "id" : 1006010888,
      "verified" : false
    }
  },
  "id" : 314081780338663424,
  "created_at" : "2013-03-19 18:31:46 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/ZH8hlNX3ye",
      "expanded_url" : "http:\/\/vvikileaks.org",
      "display_url" : "vvikileaks.org"
    } ]
  },
  "geo" : { },
  "id_str" : "313820321113333761",
  "text" : "I let my claim to http:\/\/t.co\/ZH8hlNX3ye expire",
  "id" : 313820321113333761,
  "created_at" : "2013-03-19 01:12:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 13, 22 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 138 ],
      "url" : "https:\/\/t.co\/P5mt3G3z9r",
      "expanded_url" : "https:\/\/docs.google.com\/document\/d\/1WB13OZcx3UyQh6eHulecj3mCMNCrkf_n6GfxNAbxIds\/edit?usp=sharing",
      "display_url" : "docs.google.com\/document\/d\/1WB\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "313800943982497792",
  "text" : "talking with @substack about the upper eduction bubble, reminded me I wrote an essay about what a fraud that it is https:\/\/t.co\/P5mt3G3z9r",
  "id" : 313800943982497792,
  "created_at" : "2013-03-18 23:55:49 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 57 ],
      "url" : "https:\/\/t.co\/EeCmNYExF9",
      "expanded_url" : "https:\/\/code.google.com\/p\/chromium\/issues\/detail?id=213783",
      "display_url" : "code.google.com\/p\/chromium\/iss\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "313710035303809024",
  "text" : "pls star this issue for web audio https:\/\/t.co\/EeCmNYExF9",
  "id" : 313710035303809024,
  "created_at" : "2013-03-18 17:54:35 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Webdev",
      "indices" : [ 59, 66 ]
    } ],
    "urls" : [ {
      "indices" : [ 36, 58 ],
      "url" : "http:\/\/t.co\/V6iyHz336W",
      "expanded_url" : "http:\/\/johnnyscript.us\/",
      "display_url" : "johnnyscript.us"
    } ]
  },
  "geo" : { },
  "id_str" : "313472301427462144",
  "text" : "HURRAY I FINNALY GOT MY NEW SITE UP http:\/\/t.co\/V6iyHz336W #Webdev",
  "id" : 313472301427462144,
  "created_at" : "2013-03-18 02:09:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "313080781482377216",
  "text" : "can u dig it?",
  "id" : 313080781482377216,
  "created_at" : "2013-03-17 00:14:09 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shazam",
      "indices" : [ 26, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312696596800352256",
  "text" : "github search my own code #shazam",
  "id" : 312696596800352256,
  "created_at" : "2013-03-15 22:47:32 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "312634029264474112",
  "text" : "browserify: the breeder's choice for front-end web development",
  "id" : 312634029264474112,
  "created_at" : "2013-03-15 18:38:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "regisl",
      "screen_name" : "regisl",
      "indices" : [ 0, 7 ],
      "id_str" : "14690653",
      "id" : 14690653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "312075283756900353",
  "geo" : { },
  "id_str" : "312076347331735552",
  "in_reply_to_user_id" : 14690653,
  "text" : "@regisl The toad will croak.",
  "id" : 312076347331735552,
  "in_reply_to_status_id" : 312075283756900353,
  "created_at" : "2013-03-14 05:42:53 +0000",
  "in_reply_to_screen_name" : "regisl",
  "in_reply_to_user_id_str" : "14690653",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "indices" : [ 3, 19 ],
      "id_str" : "58809542",
      "id" : 58809542
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/AngelineGragzin\/status\/311979065273880576\/photo\/1",
      "indices" : [ 139, 140 ],
      "url" : "http:\/\/t.co\/NUV6WPKFgX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BFRfTpOCEAIFU41.jpg",
      "id_str" : "311979065282269186",
      "id" : 311979065282269186,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFRfTpOCEAIFU41.jpg",
      "sizes" : [ {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 683,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/NUV6WPKFgX"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/Zv5tPc9lHg",
      "expanded_url" : "http:\/\/bit.ly\/13TPEFj",
      "display_url" : "bit.ly\/13TPEFj"
    } ]
  },
  "geo" : { },
  "id_str" : "311979236351176704",
  "text" : "RT @AngelineGragzin: PHOTO: Think Oakland is a scary place? This is what living in Oakland is actually like. (via http:\/\/t.co\/Zv5tPc9lHg ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/AngelineGragzin\/status\/311979065273880576\/photo\/1",
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/NUV6WPKFgX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BFRfTpOCEAIFU41.jpg",
        "id_str" : "311979065282269186",
        "id" : 311979065282269186,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BFRfTpOCEAIFU41.jpg",
        "sizes" : [ {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 683,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/NUV6WPKFgX"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/Zv5tPc9lHg",
        "expanded_url" : "http:\/\/bit.ly\/13TPEFj",
        "display_url" : "bit.ly\/13TPEFj"
      } ]
    },
    "geo" : { },
    "id_str" : "311979065273880576",
    "text" : "PHOTO: Think Oakland is a scary place? This is what living in Oakland is actually like. (via http:\/\/t.co\/Zv5tPc9lHg) http:\/\/t.co\/NUV6WPKFgX",
    "id" : 311979065273880576,
    "created_at" : "2013-03-13 23:16:20 +0000",
    "user" : {
      "name" : "Angeline Gragasin",
      "screen_name" : "AngelineGragzin",
      "protected" : false,
      "id_str" : "58809542",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/524202279616794624\/7qr0HcJn_normal.png",
      "id" : 58809542,
      "verified" : false
    }
  },
  "id" : 311979236351176704,
  "created_at" : "2013-03-13 23:17:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311979217871056896",
  "text" : "investment thesis",
  "id" : 311979217871056896,
  "created_at" : "2013-03-13 23:16:56 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311960054028988416",
  "text" : "RT @IAM_SHAKESPEARE: I scorn you not; it seems that you scorn me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "311959863175569409",
    "text" : "I scorn you not; it seems that you scorn me.",
    "id" : 311959863175569409,
    "created_at" : "2013-03-13 22:00:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 311960054028988416,
  "created_at" : "2013-03-13 22:00:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311953473820319744",
  "text" : "no arguments?",
  "id" : 311953473820319744,
  "created_at" : "2013-03-13 21:34:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311952569054412800",
  "text" : "i like the idea of writing functions which require the user to define functions local variables in their own scope. Pls advise.",
  "id" : 311952569054412800,
  "created_at" : "2013-03-13 21:31:02 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "isaacs anta",
      "screen_name" : "izs",
      "indices" : [ 0, 4 ],
      "id_str" : "8038312",
      "id" : 8038312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311726956326555648",
  "geo" : { },
  "id_str" : "311924554106810368",
  "in_reply_to_user_id" : 8038312,
  "text" : "@izs I found a bug in that. I followed your directions but my package.json did not change license to ill :\\",
  "id" : 311924554106810368,
  "in_reply_to_status_id" : 311726956326555648,
  "created_at" : "2013-03-13 19:39:43 +0000",
  "in_reply_to_screen_name" : "izs",
  "in_reply_to_user_id_str" : "8038312",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311724626306822145",
  "text" : "it only took me 5 initial commits to reach version 0.1.0",
  "id" : 311724626306822145,
  "created_at" : "2013-03-13 06:25:17 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311720659254378496",
  "text" : "Also I don't call my github remote \"origin\" I call it github",
  "id" : 311720659254378496,
  "created_at" : "2013-03-13 06:09:31 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311720508498522112",
  "text" : "github tip: set your remote to git@github.com:user\/repo.git instead of https method and they won't ask for user:pass",
  "id" : 311720508498522112,
  "created_at" : "2013-03-13 06:08:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TSA",
      "indices" : [ 49, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311696657735639040",
  "text" : "self.postMessage(\u007Bblob: blob, message: 'blob!'\u007D) #TSA",
  "id" : 311696657735639040,
  "created_at" : "2013-03-13 04:34:08 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311696140460519425",
  "text" : "\"The Float-Thirty-Two Array of Chunksize awaits your decision\"",
  "id" : 311696140460519425,
  "created_at" : "2013-03-13 04:32:05 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "luke",
      "screen_name" : "st_luke",
      "indices" : [ 0, 8 ],
      "id_str" : "1345293294",
      "id" : 1345293294
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TSA",
      "indices" : [ 34, 38 ]
    }, {
      "text" : "T",
      "indices" : [ 39, 41 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "311692990387191808",
  "geo" : { },
  "id_str" : "311694803060531200",
  "in_reply_to_user_id" : 16569603,
  "text" : "@st_luke OPT OUT WITH YR COCK OUT #TSA #T&amp;A",
  "id" : 311694803060531200,
  "in_reply_to_status_id" : 311692990387191808,
  "created_at" : "2013-03-13 04:26:46 +0000",
  "in_reply_to_screen_name" : "luk",
  "in_reply_to_user_id_str" : "16569603",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fillit",
      "indices" : [ 36, 43 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311682689801523200",
  "text" : "they filibuster \/\/ we fill a buffer #fillit",
  "id" : 311682689801523200,
  "created_at" : "2013-03-13 03:38:38 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tinyModules",
      "indices" : [ 80, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 79 ],
      "url" : "https:\/\/t.co\/KF7QBkyYED",
      "expanded_url" : "https:\/\/github.com\/NHQ\/work-slave",
      "display_url" : "github.com\/NHQ\/work-slave"
    } ]
  },
  "geo" : { },
  "id_str" : "311615083555995649",
  "text" : "npm install work-slave, use it with browserify and brfs https:\/\/t.co\/KF7QBkyYED #tinyModules",
  "id" : 311615083555995649,
  "created_at" : "2013-03-12 23:10:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Derek Erdman",
      "screen_name" : "derekerdman",
      "indices" : [ 3, 15 ],
      "id_str" : "29315069",
      "id" : 29315069
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/jX0ODdLsYz",
      "expanded_url" : "http:\/\/instagr.am\/p\/WvxhnFKqGC\/",
      "display_url" : "instagr.am\/p\/WvxhnFKqGC\/"
    } ]
  },
  "geo" : { },
  "id_str" : "311390747733680130",
  "text" : "RT @derekerdman: WHOA, the Midwest has really great signs. http:\/\/t.co\/jX0ODdLsYz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/jX0ODdLsYz",
        "expanded_url" : "http:\/\/instagr.am\/p\/WvxhnFKqGC\/",
        "display_url" : "instagr.am\/p\/WvxhnFKqGC\/"
      } ]
    },
    "geo" : { },
    "id_str" : "311354736605552640",
    "text" : "WHOA, the Midwest has really great signs. http:\/\/t.co\/jX0ODdLsYz",
    "id" : 311354736605552640,
    "created_at" : "2013-03-12 05:55:28 +0000",
    "user" : {
      "name" : "Derek Erdman",
      "screen_name" : "derekerdman",
      "protected" : false,
      "id_str" : "29315069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/429712364716314624\/NvH07Ag7_normal.jpeg",
      "id" : 29315069,
      "verified" : false
    }
  },
  "id" : 311390747733680130,
  "created_at" : "2013-03-12 08:18:34 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "311390026187567104",
  "text" : "turtlespace",
  "id" : 311390026187567104,
  "created_at" : "2013-03-12 08:15:42 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "yay",
      "indices" : [ 119, 123 ]
    }, {
      "text" : "goSpeedModules",
      "indices" : [ 124, 139 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/BTs2dlK4Jd",
      "expanded_url" : "https:\/\/github.com\/NHQ\/opa",
      "display_url" : "github.com\/NHQ\/opa"
    }, {
      "indices" : [ 95, 118 ],
      "url" : "https:\/\/t.co\/tNZPKBQLQc",
      "expanded_url" : "https:\/\/github.com\/substack\/brfs",
      "display_url" : "github.com\/substack\/brfs"
    } ]
  },
  "geo" : { },
  "id_str" : "310261468153143296",
  "text" : "OPA upgraded to use latest version of browserify https:\/\/t.co\/BTs2dlK4Jd and brfs is baked in! https:\/\/t.co\/tNZPKBQLQc #yay #goSpeedModules",
  "id" : 310261468153143296,
  "created_at" : "2013-03-09 05:31:13 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "310173327618609152",
  "text" : "Iftah Ya Simsim !",
  "id" : 310173327618609152,
  "created_at" : "2013-03-08 23:40:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bidoun Magazine",
      "screen_name" : "Bidoun",
      "indices" : [ 0, 7 ],
      "id_str" : "20493283",
      "id" : 20493283
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sesameStreet",
      "indices" : [ 131, 144 ]
    }, {
      "text" : "music",
      "indices" : [ 145, 151 ]
    } ],
    "urls" : [ {
      "indices" : [ 24, 46 ],
      "url" : "http:\/\/t.co\/w6CHDx8SxJ",
      "expanded_url" : "http:\/\/www.saudiaramcoworld.com\/",
      "display_url" : "saudiaramcoworld.com"
    }, {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/lM2UMGxjJR",
      "expanded_url" : "http:\/\/www.saudiaramcoworld.com\/issue\/197905\/sesame.opens..htm",
      "display_url" : "saudiaramcoworld.com\/issue\/197905\/s\u2026"
    }, {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/Ww50EnvfZA",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=W7x814NtK8Y",
      "display_url" : "youtube.com\/watch?v=W7x814\u2026"
    }, {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/cRmqflto0G",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=xvdEKZ7_K20",
      "display_url" : "youtube.com\/watch?v=xvdEKZ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "310172871362224128",
  "in_reply_to_user_id" : 20493283,
  "text" : "@Bidoun back issue &gt; http:\/\/t.co\/w6CHDx8SxJ &gt; http:\/\/t.co\/lM2UMGxjJR &gt; http:\/\/t.co\/Ww50EnvfZA &gt; http:\/\/t.co\/cRmqflto0G #sesameStreet #music",
  "id" : 310172871362224128,
  "created_at" : "2013-03-08 23:39:09 +0000",
  "in_reply_to_screen_name" : "Bidoun",
  "in_reply_to_user_id_str" : "20493283",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309896751282802689",
  "text" : "RT @IAM_SHAKESPEARE: When I a fat and bean-fed horse beguile,",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309896264718381056",
    "text" : "When I a fat and bean-fed horse beguile,",
    "id" : 309896264718381056,
    "created_at" : "2013-03-08 05:20:01 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 309896751282802689,
  "created_at" : "2013-03-08 05:21:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 5, 28 ],
      "url" : "https:\/\/t.co\/CnBCGlIntZ",
      "expanded_url" : "https:\/\/soundcloud.com\/pelvispelvis\/dancing-in-tongues",
      "display_url" : "soundcloud.com\/pelvispelvis\/d\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309895281724518400",
  "text" : "q.v. https:\/\/t.co\/CnBCGlIntZ",
  "id" : 309895281724518400,
  "created_at" : "2013-03-08 05:16:07 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309894693678882816",
  "text" : "ah oo ah ee",
  "id" : 309894693678882816,
  "created_at" : "2013-03-08 05:13:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 50 ],
      "url" : "http:\/\/t.co\/XNKgv8bi8s",
      "expanded_url" : "http:\/\/baud.io",
      "display_url" : "baud.io"
    } ]
  },
  "geo" : { },
  "id_str" : "309894661001064449",
  "text" : "probably another band? lame http:\/\/t.co\/XNKgv8bi8s",
  "id" : 309894661001064449,
  "created_at" : "2013-03-08 05:13:39 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/JlaBOrGtVk",
      "expanded_url" : "http:\/\/pelv.is",
      "display_url" : "pelv.is"
    } ]
  },
  "geo" : { },
  "id_str" : "309894515534200833",
  "text" : "http:\/\/t.co\/JlaBOrGtVk marks the first time a domain name i wanted was occupied by some deeshit",
  "id" : 309894515534200833,
  "created_at" : "2013-03-08 05:13:04 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 6, 28 ],
      "url" : "http:\/\/t.co\/JlaBOrGtVk",
      "expanded_url" : "http:\/\/pelv.is",
      "display_url" : "pelv.is"
    } ]
  },
  "geo" : { },
  "id_str" : "309893738786869248",
  "text" : "bravo http:\/\/t.co\/JlaBOrGtVk bravo",
  "id" : 309893738786869248,
  "created_at" : "2013-03-08 05:09:59 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309890774483488768",
  "text" : "lil' A\/B",
  "id" : 309890774483488768,
  "created_at" : "2013-03-08 04:58:12 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309890709786357760",
  "text" : "thief that I am \/\/ take inspiration from eveyone",
  "id" : 309890709786357760,
  "created_at" : "2013-03-08 04:57:57 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309874576530227200",
  "text" : "and then covering music videos was born",
  "id" : 309874576530227200,
  "created_at" : "2013-03-08 03:53:50 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/VGZrALzORH",
      "expanded_url" : "http:\/\/cull.tv\/#!\/173294\/3545124",
      "display_url" : "cull.tv\/#!\/173294\/3545\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "309874312276492288",
  "text" : "alert( http:\/\/t.co\/VGZrALzORH )",
  "id" : 309874312276492288,
  "created_at" : "2013-03-08 03:52:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309759361297809408",
  "text" : "i forgot what i was gonna speak n spell",
  "id" : 309759361297809408,
  "created_at" : "2013-03-07 20:16:01 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "indices" : [ 3, 19 ],
      "id_str" : "64119853",
      "id" : 64119853
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309579258882306048",
  "text" : "RT @IAM_SHAKESPEARE: spread yourselves.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/saint-rebel.com\/2009\/08\/09\/the-complete-works-of-william-shakespeare-on-twitter\/\" rel=\"nofollow\"\u003EIAM_SHAKESPEARE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "309579178246828033",
    "text" : "spread yourselves.",
    "id" : 309579178246828033,
    "created_at" : "2013-03-07 08:20:02 +0000",
    "user" : {
      "name" : "Willy Shakes",
      "screen_name" : "IAM_SHAKESPEARE",
      "protected" : false,
      "id_str" : "64119853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/354189087\/silly-shakespeare_normal.jpg",
      "id" : 64119853,
      "verified" : false
    }
  },
  "id" : 309579258882306048,
  "created_at" : "2013-03-07 08:20:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309579147150233600",
  "text" : "i was impressed just now by how much gibberish is possible",
  "id" : 309579147150233600,
  "created_at" : "2013-03-07 08:19:55 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309005381659684865",
  "text" : "BUSTA CAPS LOCK",
  "id" : 309005381659684865,
  "created_at" : "2013-03-05 18:19:58 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "chromebook",
      "indices" : [ 72, 83 ]
    }, {
      "text" : "chrubuntu",
      "indices" : [ 84, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309004835129290752",
  "text" : "replaced it with search even but where the dambla page up and page down #chromebook #chrubuntu",
  "id" : 309004835129290752,
  "created_at" : "2013-03-05 18:17:48 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "309004493528383488",
  "text" : "removing the caps lock key on an internet computer keyboard is some kind sick joke",
  "id" : 309004493528383488,
  "created_at" : "2013-03-05 18:16:26 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308963923825160192",
  "text" : "oh hell no getting publishers clearinghouse spam ads in my gmail THIS IS  FUCKING REGRESSION",
  "id" : 308963923825160192,
  "created_at" : "2013-03-05 15:35:14 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308963466612469762",
  "text" : "setInterval is 729840 nanoseconds off 1 second mark;\nsince-when is 7472 nanoseconds off 1 second mark",
  "id" : 308963466612469762,
  "created_at" : "2013-03-05 15:33:25 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "manmachine",
      "indices" : [ 34, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308817848229318656",
  "text" : "i wrote one that optimizes itself #manmachine",
  "id" : 308817848229318656,
  "created_at" : "2013-03-05 05:54:47 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 86 ],
      "url" : "https:\/\/t.co\/E9cn6EdlNQ",
      "expanded_url" : "https:\/\/github.com\/NHQ\/since-when",
      "display_url" : "github.com\/NHQ\/since-when"
    } ]
  },
  "geo" : { },
  "id_str" : "308817331965022208",
  "text" : "new and improved methods for high resolution timing in Node.js https:\/\/t.co\/E9cn6EdlNQ",
  "id" : 308817331965022208,
  "created_at" : "2013-03-05 05:52:44 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "substack",
      "screen_name" : "substack",
      "indices" : [ 0, 9 ],
      "id_str" : "125027291",
      "id" : 125027291
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "308749645453086720",
  "geo" : { },
  "id_str" : "308750985243803651",
  "in_reply_to_user_id" : 125027291,
  "text" : "@substack THEY TAKEN OVER MUSIC!!",
  "id" : 308750985243803651,
  "in_reply_to_status_id" : 308749645453086720,
  "created_at" : "2013-03-05 01:29:05 +0000",
  "in_reply_to_screen_name" : "substack",
  "in_reply_to_user_id_str" : "125027291",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "308517002761355264",
  "text" : "This is very important, if you skipped the previous sentence, now is a good time to go back and re-read it!",
  "id" : 308517002761355264,
  "created_at" : "2013-03-04 09:59:20 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307575809873412097",
  "text" : "ballasts and pillars yall",
  "id" : 307575809873412097,
  "created_at" : "2013-03-01 19:39:22 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307575382482231296",
  "text" : "Homemade furniture revelation = paintcans",
  "id" : 307575382482231296,
  "created_at" : "2013-03-01 19:37:40 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "307568006765084672",
  "text" : "Welcome to the Ardor of Haos",
  "id" : 307568006765084672,
  "created_at" : "2013-03-01 19:08:21 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]