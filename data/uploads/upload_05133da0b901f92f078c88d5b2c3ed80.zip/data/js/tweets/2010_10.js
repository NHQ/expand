Grailbird.data.tweets_2010_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29316268540",
  "text" : "I need some good business news oriented twitters to follow. Any suggestions?",
  "id" : 29316268540,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Rumpus",
      "screen_name" : "The_Rumpus",
      "indices" : [ 3, 14 ],
      "id_str" : "19728966",
      "id" : 19728966
    }, {
      "name" : "The New Yorker",
      "screen_name" : "NewYorker",
      "indices" : [ 77, 87 ],
      "id_str" : "14677919",
      "id" : 14677919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "29318338691",
  "text" : "RT @The_Rumpus: A 1948 Shirley Jackson story so creepy people canceled their @newyorker subscriptions. http:\/\/bit.ly\/9lPjC8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New Yorker",
        "screen_name" : "NewYorker",
        "indices" : [ 61, 71 ],
        "id_str" : "14677919",
        "id" : 14677919
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "29310515346",
    "text" : "A 1948 Shirley Jackson story so creepy people canceled their @newyorker subscriptions. http:\/\/bit.ly\/9lPjC8",
    "id" : 29310515346,
    "created_at" : "2010-10-31 21:06:36 +0000",
    "user" : {
      "name" : "The Rumpus",
      "screen_name" : "The_Rumpus",
      "protected" : false,
      "id_str" : "19728966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/541996157\/Rumpus_normal.jpg",
      "id" : 19728966,
      "verified" : false
    }
  },
  "id" : 29318338691,
  "created_at" : "2010-10-31 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28944390891",
  "text" : "and now for repetitious play of music which moves me.",
  "id" : 28944390891,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "28951805969",
  "geo" : { },
  "id_str" : "28952818606",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb what arouses?",
  "id" : 28952818606,
  "in_reply_to_status_id" : 28951805969,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28957959642",
  "text" : "having a helluva time trying to believe what I can't imagine.",
  "id" : 28957959642,
  "created_at" : "2010-10-28 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28840716452",
  "text" : "Just commented on googleTV blog, had to type 'stdowar' to prove I'm human. goo.gl\/3aDQ",
  "id" : 28840716452,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28841291457",
  "text" : "It's really hard to talk to google. Information therapy.",
  "id" : 28841291457,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "teaparty",
      "indices" : [ 64, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28843304563",
  "text" : "thinkin about watching this http:\/\/astroturfwars.org\/ about the #teaparty. Prolly has all the ugly americana you would swing a stick at.",
  "id" : 28843304563,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28932945605",
  "text" : "I need to speak to somebody whose muse isn't an idea. I'm curious about that lifestyle and its benefits to creativity and production.",
  "id" : 28932945605,
  "created_at" : "2010-10-27 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Random Guy",
      "screen_name" : "ThatRandGuy",
      "indices" : [ 0, 12 ],
      "id_str" : "1638646304",
      "id" : 1638646304
    }, {
      "name" : "\u0633\u064A\u0641 \u0627\u0644\u0644\u0647",
      "screen_name" : "JayElectronica",
      "indices" : [ 20, 35 ],
      "id_str" : "17740885",
      "id" : 17740885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28836213140",
  "in_reply_to_user_id" : 33033995,
  "text" : "@thatrandguy ??? RT @JayElectronica http:\/\/www.yooouuutuuube.com\/v\/?width=192&height=180&yt=zh59b1fcZ3k&flux=1&direction=rand",
  "id" : 28836213140,
  "created_at" : "2010-10-26 00:00:00 +0000",
  "in_reply_to_screen_name" : "randsevilla",
  "in_reply_to_user_id_str" : "33033995",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28638612380",
  "text" : "Thomas oas a test",
  "id" : 28638612380,
  "created_at" : "2010-10-24 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28465277879",
  "text" : "a cloud and its shadow, near rare earth open pit mine via google satellite http:\/\/bit.ly\/cL2QJ3",
  "id" : 28465277879,
  "created_at" : "2010-10-23 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The FCC",
      "screen_name" : "FCC",
      "indices" : [ 12, 16 ],
      "id_str" : "66369206",
      "id" : 66369206
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "specCrunch",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "28043697925",
  "text" : "#specCrunch @FCC Wireless broadband as an interstate highway = free access to markets = should not be in the hands of private companies",
  "id" : 28043697925,
  "created_at" : "2010-10-21 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "is",
      "indices" : [ 30, 33 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27798972230",
  "text" : "You're in luck, I say. My way #is the highway.",
  "id" : 27798972230,
  "created_at" : "2010-10-19 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Aziz Ansari",
      "screen_name" : "azizansari",
      "indices" : [ 0, 11 ],
      "id_str" : "6480682",
      "id" : 6480682
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27698173494",
  "geo" : { },
  "id_str" : "27698440388",
  "in_reply_to_user_id" : 6480682,
  "text" : "@azizansari beauty bar is a crappy place! It's like cayote ugly for hipsters!",
  "id" : 27698440388,
  "in_reply_to_status_id" : 27698173494,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "azizansari",
  "in_reply_to_user_id_str" : "6480682",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27698570264",
  "text" : "so bored, might go on a twitter purge. Or is it a binge?",
  "id" : 27698570264,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27698601125",
  "text" : "i accidentally cracked a nut there.",
  "id" : 27698601125,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27698883694",
  "text" : "at times twitter makes me yearn for chat rooms. How'd we go from real time chat to BB forums to flicking thoughts like boogers into a void?",
  "id" : 27698883694,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27699313996",
  "text" : "one mood to rule them all",
  "id" : 27699313996,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27699388487",
  "text" : "here's why i use twitter. I'm actually trying to write more words than i speak, and live a life of thoughts and deeds only.",
  "id" : 27699388487,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27699464156",
  "text" : "if i didn't have a woman I prolly wouldn't ever speak",
  "id" : 27699464156,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27699576296",
  "text" : "a woman is the opposite of a void, and you don't mind putting as much into that as you can.",
  "id" : 27699576296,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27699786422",
  "text" : "my woman right now is a digital Medusa. Q: what if hair was wireless?",
  "id" : 27699786422,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27700041445",
  "text" : "i sentence the USA 6-10 years unsupervised absurdity. # When change changes direction \/#",
  "id" : 27700041445,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27700644087",
  "text" : "Smells like one of the meat factories nearby me is gone up in flame broil. Am surprised my Southern Bellehound isn't aroused.",
  "id" : 27700644087,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. SunWolf",
      "screen_name" : "TheSocialBrain",
      "indices" : [ 11, 26 ],
      "id_str" : "43540843",
      "id" : 43540843
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27701341653",
  "geo" : { },
  "id_str" : "27701471554",
  "in_reply_to_user_id" : 43540843,
  "text" : "Sometimes, @TheSocialBrain, you're like wired magazine + cosmo magazine",
  "id" : 27701471554,
  "in_reply_to_status_id" : 27701341653,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "in_reply_to_screen_name" : "TheSocialBrain",
  "in_reply_to_user_id_str" : "43540843",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0410\u043B\u044F\u0431\u0438\u043D \u0410\u043D\u0430\u0442\u043E\u043B\u0438\u0439",
      "screen_name" : "fchimero",
      "indices" : [ 43, 52 ],
      "id_str" : "2833375983",
      "id" : 2833375983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27761675415",
  "text" : "I'm lovin' it. Infographic of the year. By @fchimero \"How Not to Be a Dumbass Super Computer\" http:\/\/www.frankchimero.com\/idea\/",
  "id" : 27761675415,
  "created_at" : "2010-10-18 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27591400999",
  "text" : "Learned how to make stuff with fiberglass today. Favricating a shower area. Stay tuned form y next tweet.",
  "id" : 27591400999,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27591510334",
  "text" : "hose a man down, clean him for a day. Teach him to make a shower, and lead a horse to water. Neigh I say, I'll stay dirty.",
  "id" : 27591510334,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27591739857",
  "text" : "Where's a gong when you need one?",
  "id" : 27591739857,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27591903656",
  "text" : "Did you hear about the US Army's new \"social network\"? Their getting all web two la la. It's called crowd scorching.",
  "id" : 27591903656,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27591960708",
  "text" : "That's right, I used the wong word their. It's not cuz Um dumb, it's cuz I'm grammarless.",
  "id" : 27591960708,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27592141766",
  "text" : "All languages is pronunciation. Anybody care to disagree?",
  "id" : 27592141766,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27592368428",
  "text" : "You say word, yo digo palabra.",
  "id" : 27592368428,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27614616381",
  "text" : "swiggin hendricks b4 bed, hopes for no dreams",
  "id" : 27614616381,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27643500991",
  "text" : "gay teens for governor",
  "id" : 27643500991,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27656569396",
  "text" : "Interesting: cynicism shrinks your brain.",
  "id" : 27656569396,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karen Abad",
      "screen_name" : "karenabad",
      "indices" : [ 3, 13 ],
      "id_str" : "11728312",
      "id" : 11728312
    }, {
      "name" : "NATIONALHEADQUARTERS",
      "screen_name" : "natlhq",
      "indices" : [ 78, 85 ],
      "id_str" : "211771606",
      "id" : 211771606
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27681325931",
  "text" : "RT @karenabad Inspired by Isabella Rossellini's Green Porno, here is mine and @natlhq's film: \"Bloom Porno\" http:\/\/vimeo.com\/15929768",
  "id" : 27681325931,
  "created_at" : "2010-10-17 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27511377143",
  "text" : "Internet Fatigue? There's a nap for that.",
  "id" : 27511377143,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "js",
      "indices" : [ 44, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27511943720",
  "text" : "i'm like pre Rosetta Stone tryna understand #js but ima superman it soonday",
  "id" : 27511943720,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27512304714",
  "text" : "I still need about a thousand books. The internet is an Oz. Tell me something I need to know. If I only had a room full of brains.",
  "id" : 27512304714,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27512477719",
  "text" : "\"Like pooping in a cooler.\"",
  "id" : 27512477719,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RIP",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27551757627",
  "text" : "#RIP to Dr. Mandelbrot",
  "id" : 27551757627,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barack Obama",
      "screen_name" : "BarackObama",
      "indices" : [ 0, 12 ],
      "id_str" : "813286",
      "id" : 813286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27581798711",
  "in_reply_to_user_id" : 813286,
  "text" : "@barackobama wants me to call people and is giving me their numbers so I can ask i they support party line candidates.",
  "id" : 27581798711,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "BarackObama",
  "in_reply_to_user_id_str" : "813286",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27581905246",
  "text" : "\"Excuse me, do you support the stagnant status quo asshats here in Illinois? You know, the gov't that hasn't done shit in a decade?\"",
  "id" : 27581905246,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NATIONALHEADQUARTERS",
      "screen_name" : "natlhq",
      "indices" : [ 128, 135 ],
      "id_str" : "211771606",
      "id" : 211771606
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "startupschool",
      "indices" : [ 0, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27582153515",
  "text" : "#startupschool Hi do you want to join a start up, and you are a programmer? Before you join tech culture try culture tech =&gt; @natlhq",
  "id" : 27582153515,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "monoskop",
      "screen_name" : "monoskop",
      "indices" : [ 0, 9 ],
      "id_str" : "50769684",
      "id" : 50769684
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27583512941",
  "geo" : { },
  "id_str" : "27585558623",
  "in_reply_to_user_id" : 50769684,
  "text" : "@monoskop can you use some other type of file sharing that doesn't milk clicks and then fail to download?",
  "id" : 27585558623,
  "in_reply_to_status_id" : 27583512941,
  "created_at" : "2010-10-16 00:00:00 +0000",
  "in_reply_to_screen_name" : "monoskop",
  "in_reply_to_user_id_str" : "50769684",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BobbleHead Bob",
      "screen_name" : "chiaslut",
      "indices" : [ 3, 12 ],
      "id_str" : "14149613",
      "id" : 14149613
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NowYouKnow",
      "indices" : [ 129, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27394390379",
  "text" : "RT @chiaslut: Wondering what the contiguous US looks like visualized by distance to the nearest McDonald's? http:\/\/bit.ly\/cc8fWq #NowYouKnow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.destroytwitter.com\" rel=\"nofollow\"\u003EDestroyTwitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NowYouKnow",
        "indices" : [ 115, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27361886451",
    "text" : "Wondering what the contiguous US looks like visualized by distance to the nearest McDonald's? http:\/\/bit.ly\/cc8fWq #NowYouKnow",
    "id" : 27361886451,
    "created_at" : "2010-10-14 17:36:16 +0000",
    "user" : {
      "name" : "BobbleHead Bob",
      "screen_name" : "chiaslut",
      "protected" : false,
      "id_str" : "14149613",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529410275623972864\/IDVo_oZa_normal.jpeg",
      "id" : 14149613,
      "verified" : false
    }
  },
  "id" : 27394390379,
  "created_at" : "2010-10-15 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27276738037",
  "geo" : { },
  "id_str" : "27301935147",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb this one is heavy http:\/\/teachingamericanhistory.org\/library\/index.asp?document=39",
  "id" : 27301935147,
  "in_reply_to_status_id" : 27276738037,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27389037962",
  "text" : "RT @survivesthebomb: Would you spend it? I would spend it. http:\/\/twitpic.com\/2xnmey",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27388197772",
    "text" : "Would you spend it? I would spend it. http:\/\/twitpic.com\/2xnmey",
    "id" : 27388197772,
    "created_at" : "2010-10-14 23:45:35 +0000",
    "user" : {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "protected" : false,
      "id_str" : "122112121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518645860863709184\/iHz-222r_normal.jpeg",
      "id" : 122112121,
      "verified" : false
    }
  },
  "id" : 27389037962,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "27388197772",
  "geo" : { },
  "id_str" : "27389215623",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb should he go on something more folks can afford? Also, I saw an $11 bill graffiti under a bridge in my old hood.",
  "id" : 27389215623,
  "in_reply_to_status_id" : 27388197772,
  "created_at" : "2010-10-14 00:00:00 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27250125207",
  "text" : "RT @survivesthebomb: You want your people to learn history, America? Every fiscal quarter, put new faces on the money.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "27211383749",
    "text" : "You want your people to learn history, America? Every fiscal quarter, put new faces on the money.",
    "id" : 27211383749,
    "created_at" : "2010-10-13 04:32:59 +0000",
    "user" : {
      "name" : "tito mozart",
      "screen_name" : "uptownherd",
      "protected" : false,
      "id_str" : "122112121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/518645860863709184\/iHz-222r_normal.jpeg",
      "id" : 122112121,
      "verified" : false
    }
  },
  "id" : 27250125207,
  "created_at" : "2010-10-13 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "27038831318",
  "text" : "Man is an island, in a galapagos.",
  "id" : 27038831318,
  "created_at" : "2010-10-11 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26682017742",
  "geo" : { },
  "id_str" : "26887725017",
  "in_reply_to_user_id" : 122112121,
  "text" : "@survivesthebomb whats yr texas software idea",
  "id" : 26887725017,
  "in_reply_to_status_id" : 26682017742,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "uptownherd",
  "in_reply_to_user_id_str" : "122112121",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daniel Erickson",
      "screen_name" : "TechWraith",
      "indices" : [ 0, 11 ],
      "id_str" : "14063139",
      "id" : 14063139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26891609605",
  "geo" : { },
  "id_str" : "26891784344",
  "in_reply_to_user_id" : 14063139,
  "text" : "@TechWraith cloud9?",
  "id" : 26891784344,
  "in_reply_to_status_id" : 26891609605,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "TechWraith",
  "in_reply_to_user_id_str" : "14063139",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hakim El Hattab",
      "screen_name" : "hakimel",
      "indices" : [ 0, 8 ],
      "id_str" : "73339662",
      "id" : 73339662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PSA",
      "indices" : [ 83, 87 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26943125884",
  "geo" : { },
  "id_str" : "26944190865",
  "in_reply_to_user_id" : 73339662,
  "text" : "@hakimel i'm sorry to inform you, but what you called irony is not one iota irony. #PSA",
  "id" : 26944190865,
  "in_reply_to_status_id" : 26943125884,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "in_reply_to_screen_name" : "hakimel",
  "in_reply_to_user_id_str" : "73339662",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ja\u0361s\u035Co\u0361n \u2022\u035C\u2022",
      "screen_name" : "XaiaX",
      "indices" : [ 3, 9 ],
      "id_str" : "16076115",
      "id" : 16076115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26974540077",
  "text" : "RT @XaiaX: In binary, 101010 is 42: The answer to life, the universe, and everything.\nIn Roman Numerals, 10 10 10 is XXX: Porn.\nCoincidence?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "26960922980",
    "text" : "In binary, 101010 is 42: The answer to life, the universe, and everything.\nIn Roman Numerals, 10 10 10 is XXX: Porn.\nCoincidence?",
    "id" : 26960922980,
    "created_at" : "2010-10-10 18:40:22 +0000",
    "user" : {
      "name" : "Ja\u0361s\u035Co\u0361n \u2022\u035C\u2022",
      "screen_name" : "XaiaX",
      "protected" : false,
      "id_str" : "16076115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/528668002929999872\/98N1y7ya_normal.jpeg",
      "id" : 16076115,
      "verified" : false
    }
  },
  "id" : 26974540077,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26974844174",
  "text" : "he knows who's listening http:\/\/www.guardian.co.uk\/world\/2010\/oct\/10\/all-the-presidents-emails?utm_source=twitterfeed&utm_medium=twitter",
  "id" : 26974844174,
  "created_at" : "2010-10-10 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twidroyd.com\" rel=\"nofollow\"\u003Etwidroyd (original)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26879244395",
  "text" : "The Greatest Scientist of The Time.",
  "id" : 26879244395,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twidroyd.com\" rel=\"nofollow\"\u003Etwidroyd (original)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26879295478",
  "text" : "essential wonder",
  "id" : 26879295478,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twidroyd.com\" rel=\"nofollow\"\u003Etwidroyd (original)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26883318512",
  "text" : "Crazy to think",
  "id" : 26883318512,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twidroyd.com\" rel=\"nofollow\"\u003Etwidroyd (original)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26883386915",
  "text" : "People don't believe what they're told. They believe what they're asked though.",
  "id" : 26883386915,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twidroyd.com\" rel=\"nofollow\"\u003Etwidroyd (original)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26883974397",
  "text" : "Resolution  http:\/\/plixi.com\/p\/49688342",
  "id" : 26883974397,
  "created_at" : "2010-10-09 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twidroyd.com\" rel=\"nofollow\"\u003Etwidroyd (original)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26672954475",
  "text" : "It means they're stay dead.  http:\/\/plixi.com\/p\/49226139",
  "id" : 26672954475,
  "created_at" : "2010-10-07 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26283243656",
  "text" : "Between dashes is not the place--try to dis-embed your thoughts--to cram information.",
  "id" : 26283243656,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26287488616",
  "text" : "today is Third Lord's Day",
  "id" : 26287488616,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26286847308",
  "geo" : { },
  "id_str" : "26287690045",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia Everybody fears life & death. The good ones are the ones who fear em least.",
  "id" : 26287690045,
  "in_reply_to_status_id" : 26286847308,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26287990757",
  "text" : "I been missing you too, music.",
  "id" : 26287990757,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26288148891",
  "geo" : { },
  "id_str" : "26288385281",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia i don't read the difference",
  "id" : 26288385281,
  "in_reply_to_status_id" : 26288148891,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26288148891",
  "geo" : { },
  "id_str" : "26288609011",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia how many of us get to be as serious a threats as the stab driver? Fewer than fear a cab reckoning.",
  "id" : 26288609011,
  "in_reply_to_status_id" : 26288148891,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26288806463",
  "text" : "WAIT",
  "id" : 26288806463,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amelia Gray",
      "screen_name" : "grayamelia",
      "indices" : [ 0, 11 ],
      "id_str" : "181328570",
      "id" : 181328570
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "26288148891",
  "geo" : { },
  "id_str" : "26288827573",
  "in_reply_to_user_id" : 181328570,
  "text" : "@grayamelia \nAnimal instincts react a fire. \nNo choice. \nFlight or dance off.",
  "id" : 26288827573,
  "in_reply_to_status_id" : 26288148891,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "in_reply_to_screen_name" : "grayamelia",
  "in_reply_to_user_id_str" : "181328570",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26289195630",
  "text" : "twitter is still stupid I don't care what I or anybody's said. NFL is still a far superior product.",
  "id" : 26289195630,
  "created_at" : "2010-10-03 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twidroyd.com\" rel=\"nofollow\"\u003Etwidroyd (original)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "26046811606",
  "text" : "Pillar http:\/\/plixi.com\/p\/48057732",
  "id" : 26046811606,
  "created_at" : "2010-10-01 00:00:00 +0000",
  "user" : {
    "name" : "( +\\-)",
    "screen_name" : "johnnyscript",
    "protected" : false,
    "id_str" : "46961216",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531252261557501952\/59BeQp3x_normal.jpeg",
    "id" : 46961216,
    "verified" : false
  }
} ]