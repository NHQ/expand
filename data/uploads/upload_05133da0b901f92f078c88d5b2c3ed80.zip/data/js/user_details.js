var user_details =  {
  "screen_name" : "johnnyscript",
  "location" : "Middle-East, Oakland",
  "full_name" : "( +\\-)",
  "bio" : "i don't exist yet, my technology isn't good enough",
  "id" : "46961216",
  "created_at" : "2009-06-13 20:52:01 +0000"
}